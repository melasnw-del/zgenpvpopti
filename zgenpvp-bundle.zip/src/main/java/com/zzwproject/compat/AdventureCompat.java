package com.zzwproject.compat;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import net.kyori.adventure.text.Component;

public final class AdventureCompat {
   private static final String LEGACY_SERIALIZER = "net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer";
   private static volatile Method legacySectionMethod;
   private static volatile Method deserializeMethod;

   private AdventureCompat() {
   }

   public static Component deserializeLegacy(String var0) {
      String var1 = var0 == null ? "" : var0;

      try {
         Class var2 = Class.forName("net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer", true, AdventureCompat.class.getClassLoader());
         Method var8 = legacySectionMethod;
         if (var8 == null) {
            var8 = var2.getMethod("legacySection");
            legacySectionMethod = var8;
         }

         Object var4 = var8.invoke(null);
         Method var5 = deserializeMethod;
         if (var5 == null) {
            var5 = var2.getMethod("deserialize", String.class);
            deserializeMethod = var5;
         }

         return (Component)var5.invoke(var4, var1);
      } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException var6) {
         throw new IllegalStateException("Paper Adventure legacy serializer kullanilamiyor.", var6);
      } catch (InvocationTargetException var7) {
         Throwable var3 = var7.getCause() == null ? var7 : var7.getCause();
         throw new IllegalStateException("Adventure legacy metin donusturme basarisiz.", var3);
      }
   }
}
