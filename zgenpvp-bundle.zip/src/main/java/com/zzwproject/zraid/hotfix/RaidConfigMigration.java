package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Method;

public final class RaidConfigMigration {
   private RaidConfigMigration() {
   }

   public static void apply(Object var0) {
      if (var0 != null) {
         try {
            Object var1 = var0.getClass().getMethod("getConfig").invoke(var0);
            long var2 = number(call(var1, "getLong", "session.duration-seconds", 720L), 720L);
            boolean var4 = false;
            if (var2 == 720L || var2 <= 0L) {
               call(var1, "set", "session.duration-seconds", 900L);
               var4 = true;
            }

            Object var5 = call(var1, "getBoolean", "start.manual-pickaxe-start", Boolean.TRUE);
            if (Boolean.TRUE.equals(var5)) {
               call(var1, "set", "start.manual-pickaxe-start", Boolean.FALSE);
               var4 = true;
            }

            if (var4) {
               var0.getClass().getMethod("saveConfig").invoke(var0);
            }
         } catch (Throwable var6) {
         }
      }
   }

   private static long number(Object var0, long var1) {
      return var0 instanceof Number var3 ? var3.longValue() : var1;
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
               Class[] var8 = var7.getParameterTypes();
               boolean var9 = true;

               for (int var10 = 0; var10 < var8.length; var10++) {
                  if (!fits(var8[var10], var2[var10])) {
                     var9 = false;
                     break;
                  }
               }

               if (var9) {
                  return var7;
               }
            }
         }
      }

      for (Method var14 : var0.getMethods()) {
         if (var14.getName().equals(var1) && var14.getParameterCount() == var2.length) {
            Class[] var15 = var14.getParameterTypes();
            boolean var16 = true;

            for (int var17 = 0; var17 < var15.length; var17++) {
               if (!fits(var15[var17], var2[var17])) {
                  var16 = false;
                  break;
               }
            }

            if (var16) {
               return var14;
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == int.class && var1 instanceof Integer
               || var0 == long.class && var1 instanceof Long
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }
}
