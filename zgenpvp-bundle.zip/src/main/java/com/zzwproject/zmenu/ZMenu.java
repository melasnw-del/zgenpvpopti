package com.zzwproject.zmenu;

import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zmenu.command.EmptyTabCompleter;
import com.zzwproject.zmenu.command.GeneratorCommand;
import com.zzwproject.zmenu.command.MenuCommand;
import com.zzwproject.zmenu.command.NightVisionCommand;
import com.zzwproject.zmenu.command.RulesCommand;
import com.zzwproject.zmenu.command.WikiCommand;
import com.zzwproject.zmenu.command.ZMenuCommand;
import com.zzwproject.zmenu.gui.GeneratorMenu;
import com.zzwproject.zmenu.gui.RulesMenu;
import com.zzwproject.zmenu.gui.ServerMenu;
import com.zzwproject.zmenu.gui.WikiMenu;
import com.zzwproject.zmenu.listener.MenuListener;
import com.zzwproject.zmenu.listener.NightVisionJoinListener;
import com.zzwproject.zmenu.service.GeneratorService;
import com.zzwproject.zmenu.service.NightVisionService;
import com.zzwproject.zmenu.util.MessageUtil;
import com.zzwproject.zmenu.util.SoundUtil;
import java.io.File;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class ZMenu extends LegacyPluginBase {
   private FileConfiguration messages;
   private FileConfiguration sounds;
   private FileConfiguration wikiConfig;
   private FileConfiguration rulesConfig;
   private MessageUtil messageUtil;
   private SoundUtil soundUtil;
   private NightVisionService nightVisionService;
   private GeneratorService generatorService;
   private ServerMenu serverMenu;
   private WikiMenu wikiMenu;
   private GeneratorMenu generatorMenu;
   private RulesMenu rulesMenu;

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      this.saveIfMissing("messages.yml");
      this.saveIfMissing("sounds.yml");
      this.saveIfMissing("wiki.yml");
      this.saveIfMissing("rules.yml");
      this.reloadExtra();
      this.messageUtil = new MessageUtil(this);
      this.soundUtil = new SoundUtil(this);
      this.nightVisionService = new NightVisionService(this);
      this.generatorService = new GeneratorService(this);
      this.rebuildMenus();
      this.nightVisionService.load();
      this.registerCommands();
      this.getServer().getPluginManager().registerEvents(new MenuListener(this), this);
      this.getServer().getPluginManager().registerEvents(new NightVisionJoinListener(this), this);
      this.getLogger().info("ZMenu 1.1.6 aktif.");
   }

   @Override
   public void onDisable() {
      if (this.nightVisionService != null) {
         this.nightVisionService.save();
      }
   }

   public void reloadPlugin() {
      this.reloadConfig();
      this.reloadExtra();
      this.rebuildMenus();
   }

   private void rebuildMenus() {
      this.serverMenu = new ServerMenu(this);
      this.wikiMenu = new WikiMenu(this);
      this.generatorMenu = new GeneratorMenu(this);
      this.rulesMenu = new RulesMenu(this);
   }

   private void registerCommands() {
      EmptyTabCompleter var1 = new EmptyTabCompleter();
      this.setExecutor("menu", new MenuCommand(this), var1);
      this.setExecutor("nightvision", new NightVisionCommand(this), var1);
      this.setExecutor("wiki", new WikiCommand(this), var1);
      this.setExecutor("generators", new GeneratorCommand(this), var1);
      this.setExecutor("rules", new RulesCommand(this), var1);
      ZMenuCommand var2 = new ZMenuCommand(this);
      this.setExecutor("zmenu", var2, var2);
   }

   private void setExecutor(String var1, CommandExecutor var2, TabCompleter var3) {
      PluginCommand var4 = this.getCommand(var1);
      if (var4 != null) {
         var4.setExecutor(var2);
         var4.setTabCompleter(var3);
      }
   }

   private void saveIfMissing(String var1) {
      File var2 = new File(this.getDataFolder(), var1);
      if (!var2.exists()) {
         this.saveResource(var1, false);
      }
   }

   private void reloadExtra() {
      this.messages = YamlConfiguration.loadConfiguration(new File(this.getDataFolder(), "messages.yml"));
      this.sounds = YamlConfiguration.loadConfiguration(new File(this.getDataFolder(), "sounds.yml"));
      this.wikiConfig = YamlConfiguration.loadConfiguration(new File(this.getDataFolder(), "wiki.yml"));
      this.rulesConfig = YamlConfiguration.loadConfiguration(new File(this.getDataFolder(), "rules.yml"));
   }

   public FileConfiguration messages() {
      return this.messages;
   }

   public FileConfiguration sounds() {
      return this.sounds;
   }

   public FileConfiguration wikiConfig() {
      return this.wikiConfig;
   }

   public FileConfiguration rulesConfig() {
      return this.rulesConfig;
   }

   public MessageUtil message() {
      return this.messageUtil;
   }

   public SoundUtil sound() {
      return this.soundUtil;
   }

   public NightVisionService nightVision() {
      return this.nightVisionService;
   }

   public GeneratorService generatorService() {
      return this.generatorService;
   }

   public ServerMenu menu() {
      return this.serverMenu;
   }

   public WikiMenu wiki() {
      return this.wikiMenu;
   }

   public GeneratorMenu generators() {
      return this.generatorMenu;
   }

   public RulesMenu rules() {
      return this.rulesMenu;
   }
}
