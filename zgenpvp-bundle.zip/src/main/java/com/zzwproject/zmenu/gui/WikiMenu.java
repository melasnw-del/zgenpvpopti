package com.zzwproject.zmenu.gui;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zmenu.ZMenu;
import com.zzwproject.zmenu.util.ColorUtil;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

public final class WikiMenu {
   private static final List<Integer> DEFAULT_CONTENT_SLOTS = List.of(10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34);
   private static final int[] GENERATOR_LEVEL_SLOTS = buildGeneratorSlots();
   private final ZMenu plugin;
   private final DecimalFormat numberFormat = new DecimalFormat("#,##0.##");

   public WikiMenu(ZMenu var1) {
      this.plugin = var1;
   }

   public void open(Player var1, int var2) {
      FileConfiguration var3 = this.plugin.wikiConfig();
      List var4 = this.entryKeys(var3);
      List var5 = this.configuredSlots(var3);
      int var6 = Math.max(1, var5.size());
      int var7 = Math.max(1, (int)Math.ceil((double)var4.size() / var6));
      int var8 = Math.max(0, Math.min(var2, var7 - 1));
      String var9 = var3.getString("wiki.title", "&8GenPvP Wiki &8• &f%page%/%pages%")
         .replace("%page%", String.valueOf(var8 + 1))
         .replace("%pages%", String.valueOf(var7));
      MenuHolder var10 = new MenuHolder("wiki-index", var8);
      Inventory var11 = Bukkit.createInventory(var10, 54, ColorUtil.color(var9));
      this.fill(var3, var11);
      int var12 = var8 * var6;
      int var13 = Math.min(var4.size(), var12 + var6);

      for (int var14 = var12; var14 < var13; var14++) {
         String var15 = (String)var4.get(var14);
         ConfigurationSection var16 = var3.getConfigurationSection("entries." + var15);
         if (var16 != null) {
            int var17 = (Integer)var5.get(var14 - var12);
            Material var18 = MenuItems.material(var16.getString("material"), Material.BOOK);
            String var19 = this.replace(var1, var16.getString("name", var15));
            List var20 = this.replace(var1, var16.getStringList("summary"));
            var11.setItem(var17, MenuItems.item(var18, var19, var20));
            var10.action(var17, new MenuAction("WIKI_PAGE", var15, false));
         }
      }

      var11.setItem(
         4, MenuItems.item(Material.BOOK, "&b✦ GenPvP bilgi merkezi", List.of("&7Incelemek istedigin sistemi sec.", "", "&fToplam baslik: &b" + var4.size()))
      );
      if (var8 > 0) {
         var11.setItem(45, MenuItems.item(Material.ARROW, "&e‹ Önceki sayfa", List.of("&7Onceki basliklari goster.")));
         var10.action(45, new MenuAction("WIKI_INDEX", String.valueOf(var8 - 1), false));
      }

      var11.setItem(49, MenuItems.item(Material.NETHER_STAR, "&b✦ Ana menu", List.of("&7Sunucu menusune dön.")));
      var10.action(49, new MenuAction("MAIN_MENU", "", false));
      if (var8 + 1 < var7) {
         var11.setItem(53, MenuItems.item(Material.ARROW, "&eSonraki sayfa ›", List.of("&7Sonraki basliklari goster.")));
         var10.action(53, new MenuAction("WIKI_INDEX", String.valueOf(var8 + 1), false));
      }

      var1.openInventory(var11);
      this.plugin.sound().play(var1, "wiki-open");
   }

   public void openPage(Player var1, String var2) {
      if (var2 != null && var2.equalsIgnoreCase("generators")) {
         this.openGeneratorInfo(var1);
      } else {
         FileConfiguration var3 = this.plugin.wikiConfig();
         ConfigurationSection var4 = var3.getConfigurationSection("entries." + var2);
         if (var4 == null) {
            this.open(var1, 0);
         } else {
            List var5 = this.entryKeys(var3);
            int var6 = var5.indexOf(var2);
            String var7 = this.replace(var1, var4.getString("name", var2));
            String var8 = var3.getString("wiki.page-title", "&8Genpvp bilgi &8• &f%topic%").replace("%topic%", stripColors(var7));
            MenuHolder var9 = new MenuHolder("wiki-page", Math.max(0, var6));
            Inventory var10 = Bukkit.createInventory(var9, 54, ColorUtil.color(var8));
            this.fill(var3, var10);
            Material var11 = MenuItems.material(var4.getString("material"), Material.BOOK);
            ArrayList var12 = new ArrayList<>(this.replace(var1, var4.getStringList("content")));
            var12.add("");
            var12.add("&8Diger konular arasinda alt menuden gecis yapabilirsin.");
            var10.setItem(22, MenuItems.item(var11, var7, var12));
            var10.setItem(45, MenuItems.item(Material.OAK_DOOR, "&c‹ Wiki basliklari", List.of("&7Butun Wiki konularini goster.")));
            var9.action(45, new MenuAction("WIKI_INDEX", "0", false));
            if (var6 > 0) {
               String var13 = (String)var5.get(var6 - 1);
               var10.setItem(
                  48, MenuItems.item(Material.ARROW, "&e‹ Önceki konu", List.of(this.replace(var1, var3.getString("entries." + var13 + ".name", var13))))
               );
               var9.action(48, new MenuAction("WIKI_PAGE", var13, false));
            }

            var10.setItem(49, MenuItems.item(Material.NETHER_STAR, "&b✦ Ana menu", List.of("&7Sunucu menusune dön.")));
            var9.action(49, new MenuAction("MAIN_MENU", "", false));
            if (var6 >= 0 && var6 + 1 < var5.size()) {
               String var14 = (String)var5.get(var6 + 1);
               var10.setItem(
                  50, MenuItems.item(Material.ARROW, "&eSonraki konu ›", List.of(this.replace(var1, var3.getString("entries." + var14 + ".name", var14))))
               );
               var9.action(50, new MenuAction("WIKI_PAGE", var14, false));
            }

            var1.openInventory(var10);
            this.plugin.sound().play(var1, "wiki-page");
         }
      }
   }

   private void openGeneratorInfo(Player var1) {
      FileConfiguration var2 = this.plugin.wikiConfig();
      FileConfiguration var3 = this.coreGeneratorConfig();
      MenuHolder var4 = new MenuHolder("wiki-page", 0);
      Inventory var5 = Bukkit.createInventory(var4, 54, ColorUtil.color("&8Jeneratör Bilgileri"));
      this.fill(var2, var5);
      int var6 = Math.min(35, Math.max(1, this.plugin.generatorService().maxLevel()));
      double var7 = var3 == null
         ? this.plugin.generatorService().intervalSeconds()
         : var3.getDouble("generation.money-interval-seconds", this.plugin.generatorService().intervalSeconds());
      double var9 = var3 == null ? 300.0 : var3.getDouble("generation.shard-interval-seconds", 300.0);
      int var11 = var3 == null ? 1 : var3.getInt("generation.shards-per-cycle", 1);
      var5.setItem(
         4,
         MenuItems.item(
            Material.EMERALD,
            "&a✦ Jeneratör Seviyeleri",
            List.of(
               "&7Toplam &f" + var6 + " &7jeneratör seviyesi.",
               "&7Yukseltmeler yalnızca &apara &7kullanir.",
               "",
               "&8Bir seviyenin üstüne gelerek detaylarını gör."
            )
         )
      );

      for (int var12 = 1; var12 <= var6 && var12 <= GENERATOR_LEVEL_SLOTS.length; var12++) {
         String var13 = "levels." + var12 + ".";
         String var14 = var3 == null ? null : var3.getString(var13 + "model.material");
         Material var15 = MenuItems.material(var14, Material.STONE);
         double var16 = var3 == null ? var12 : var3.getDouble(var13 + "money-per-cycle", var12);
         double var18 = var3 == null ? 0.0 : var3.getDouble(var13 + "upgrade-price", 0.0);
         ArrayList var20 = new ArrayList();
         var20.add("");
         var20.add("&e› Uretim hizi");
         var20.add("&a│ &7Para: &a+$" + this.numberFormat.format(var16) + " &8(her " + this.numberFormat.format(var7) + "sn)");
         var20.add("&d│ &7Kristal: &d+" + var11 + " &8(her " + this.numberFormat.format(var9 / 60.0) + " dakikada)");
         var20.add("");
         var20.add("&e› Yukseltme maliyeti");
         if (var12 < var6 && !(var18 <= 0.0)) {
            var20.add("&a│ &7Para: &a$" + this.numberFormat.format(var18));
         } else {
            var20.add("&a│ &7Durum: &amaksimum seviye");
         }

         var20.add("");
         var20.add("&a› Seviye bilgisi ön izlemesidir.");
         String var21 = generatorName(var14, var12);
         var5.setItem(GENERATOR_LEVEL_SLOTS[var12 - 1], MenuItems.item(var15, var21, var20));
      }

      var5.setItem(45, MenuItems.item(Material.OAK_DOOR, "&c‹ Wiki basliklari", List.of("&7Wiki konu listesine dön.")));
      var4.action(45, new MenuAction("WIKI_INDEX", "0", false));
      var5.setItem(49, MenuItems.item(Material.NETHER_STAR, "&b✦ Ana menu", List.of("&7Sunucu menusune dön.")));
      var4.action(49, new MenuAction("MAIN_MENU", "", false));
      var1.openInventory(var5);
      this.plugin.sound().play(var1, "wiki-page");
   }

   private FileConfiguration coreGeneratorConfig() {
      try {
         Plugin var1 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenPvP");
         if (var1 == null) {
            return null;
         }

         Method var2 = var1.getClass().getMethod("getConfigManager");
         Object var3 = var2.invoke(var1);
         Method var4 = var3.getClass().getMethod("getGenerators");
         return var4.invoke(var3) instanceof FileConfiguration var6 ? var6 : null;
      } catch (ReflectiveOperationException var7) {
         return null;
      }
   }

   private static String generatorName(String var0, int var1) {
      String var2;
      if (var0 == null) {
         var2 = "Jeneratör";
      } else {
         String var3 = var0;
         byte var4 = -1;
         switch (var3.hashCode()) {
            case -2143360393:
               if (var3.equals("REDSTONE_ORE")) {
                  var4 = 4;
               }
               break;
            case -2117014516:
               if (var3.equals("DEEPSLATE_COAL_ORE")) {
                  var4 = 8;
               }
               break;
            case -1876445026:
               if (var3.equals("RAW_COPPER_BLOCK")) {
                  var4 = 19;
               }
               break;
            case -1606773547:
               if (var3.equals("DEEPSLATE_EMERALD_ORE")) {
                  var4 = 14;
               }
               break;
            case -1479888195:
               if (var3.equals("DEEPSLATE_IRON_ORE")) {
                  var4 = 10;
               }
               break;
            case -1474647453:
               if (var3.equals("GOLD_ORE")) {
                  var4 = 3;
               }
               break;
            case -1350340660:
               if (var3.equals("GILDED_BLACKSTONE")) {
                  var4 = 34;
               }
               break;
            case -1310813950:
               if (var3.equals("ANCIENT_DEBRIS")) {
                  var4 = 18;
               }
               break;
            case -1200901687:
               if (var3.equals("QUARTZ_BLOCK")) {
                  var4 = 32;
               }
               break;
            case -1119837590:
               if (var3.equals("NETHER_GOLD_ORE")) {
                  var4 = 16;
               }
               break;
            case -1074877747:
               if (var3.equals("RAW_IRON_BLOCK")) {
                  var4 = 20;
               }
               break;
            case -910594043:
               if (var3.equals("DEEPSLATE_DIAMOND_ORE")) {
                  var4 = 15;
               }
               break;
            case -866289145:
               if (var3.equals("EMERALD_ORE")) {
                  var4 = 6;
               }
               break;
            case -807349915:
               if (var3.equals("NETHER_QUARTZ_ORE")) {
                  var4 = 17;
               }
               break;
            case -773020571:
               if (var3.equals("RAW_GOLD_BLOCK")) {
                  var4 = 21;
               }
               break;
            case -278780510:
               if (var3.equals("DIAMOND_BLOCK")) {
                  var4 = 29;
               }
               break;
            case -192481989:
               if (var3.equals("AMETHYST_BLOCK")) {
                  var4 = 30;
               }
               break;
            case -170109641:
               if (var3.equals("DIAMOND_ORE")) {
                  var4 = 7;
               }
               break;
            case -163486694:
               if (var3.equals("COAL_ORE")) {
                  var4 = 0;
               }
               break;
            case -111024586:
               if (var3.equals("IRON_BLOCK")) {
                  var4 = 24;
               }
               break;
            case -72701037:
               if (var3.equals("LAPIS_BLOCK")) {
                  var4 = 27;
               }
               break;
            case 190832590:
               if (var3.equals("GOLD_BLOCK")) {
                  var4 = 25;
               }
               break;
            case 249759246:
               if (var3.equals("DEEPSLATE_COPPER_ORE")) {
                  var4 = 9;
               }
               break;
            case 473639627:
               if (var3.equals("IRON_ORE")) {
                  var4 = 2;
               }
               break;
            case 671426921:
               if (var3.equals("DEEPSLATE_REDSTONE_ORE")) {
                  var4 = 12;
               }
               break;
            case 689287836:
               if (var3.equals("COPPER_ORE")) {
                  var4 = 1;
               }
               break;
            case 707614322:
               if (var3.equals("EMERALD_BLOCK")) {
                  var4 = 28;
               }
               break;
            case 866792021:
               if (var3.equals("DEEPSLATE_GOLD_ORE")) {
                  var4 = 11;
               }
               break;
            case 968474055:
               if (var3.equals("COPPER_BLOCK")) {
                  var4 = 23;
               }
               break;
            case 1411455414:
               if (var3.equals("DEEPSLATE_LAPIS_ORE")) {
                  var4 = 13;
               }
               break;
            case 1427590928:
               if (var3.equals("NETHERITE_BLOCK")) {
                  var4 = 33;
               }
               break;
            case 1790904261:
               if (var3.equals("COAL_BLOCK")) {
                  var4 = 22;
               }
               break;
            case 1802791650:
               if (var3.equals("REDSTONE_BLOCK")) {
                  var4 = 26;
               }
               break;
            case 1841275752:
               if (var3.equals("LAPIS_ORE")) {
                  var4 = 5;
               }
               break;
            case 1882412797:
               if (var3.equals("BUDDING_AMETHYST")) {
                  var4 = 31;
               }
         }

         String var10000;
         label182: {
            String var5;
            StringBuilder var6;
            switch (var4) {
               case 0:
                  var10000 = "Kömür Cevheri";
                  break label182;
               case 1:
                  var10000 = "Bakır Cevheri";
                  break label182;
               case 2:
                  var10000 = "Demir Cevheri";
                  break label182;
               case 3:
                  var10000 = "Altın Cevheri";
                  break label182;
               case 4:
                  var10000 = "Redstone Cevheri";
                  break label182;
               case 5:
                  var10000 = "Lapis Cevheri";
                  break label182;
               case 6:
                  var10000 = "Zümrüt Cevheri";
                  break label182;
               case 7:
                  var10000 = "Elmas Cevheri";
                  break label182;
               case 8:
                  var10000 = "Derin Kayrak Kömür Cevheri";
                  break label182;
               case 9:
                  var10000 = "Derin Kayrak Bakır Cevheri";
                  break label182;
               case 10:
                  var10000 = "Derin Kayrak Demir Cevheri";
                  break label182;
               case 11:
                  var10000 = "Derin Kayrak Altın Cevheri";
                  break label182;
               case 12:
                  var10000 = "Derin Kayrak Redstone Cevheri";
                  break label182;
               case 13:
                  var10000 = "Derin Kayrak Lapis Cevheri";
                  break label182;
               case 14:
                  var10000 = "Derin Kayrak Zümrüt Cevheri";
                  break label182;
               case 15:
                  var10000 = "Derin Kayrak Elmas Cevheri";
                  break label182;
               case 16:
                  var10000 = "Nether Altın Cevheri";
                  break label182;
               case 17:
                  var10000 = "Nether Kuvars Cevheri";
                  break label182;
               case 18:
                  var10000 = "Antik Kalıntı";
                  break label182;
               case 19:
                  var10000 = "Ham Bakır Bloğu";
                  break label182;
               case 20:
                  var10000 = "Ham Demir Bloğu";
                  break label182;
               case 21:
                  var10000 = "Ham Altın Bloğu";
                  break label182;
               case 22:
                  var10000 = "Kömür Bloğu";
                  break label182;
               case 23:
                  var10000 = "Bakır Bloğu";
                  break label182;
               case 24:
                  var10000 = "Demir Bloğu";
                  break label182;
               case 25:
                  var10000 = "Altın Bloğu";
                  break label182;
               case 26:
                  var10000 = "Redstone Bloğu";
                  break label182;
               case 27:
                  var10000 = "Lapis Bloğu";
                  break label182;
               case 28:
                  var10000 = "Zümrüt Bloğu";
                  break label182;
               case 29:
                  var10000 = "Elmas Bloğu";
                  break label182;
               case 30:
                  var10000 = "Ametist Bloğu";
                  break label182;
               case 31:
                  var10000 = "Tomurcuklanan Ametist";
                  break label182;
               case 32:
                  var10000 = "Kuvars Bloğu";
                  break label182;
               case 33:
                  var10000 = "Netherit Bloğu";
                  break label182;
               case 34:
                  var10000 = "Yaldızlı Karataş";
                  break label182;
               default:
                  var5 = var0.replace('_', ' ').toLowerCase(Locale.ROOT);
                  if (var5.isEmpty()) {
                     var10000 = "Jeneratör";
                     break label182;
                  }

                  var6 = new StringBuilder();
            }

            for (String var10 : var5.split(" ")) {
               if (!var10.isEmpty()) {
                  if (var6.length() > 0) {
                     var6.append(' ');
                  }

                  var6.append(Character.toUpperCase(var10.charAt(0))).append(var10.substring(1));
               }
            }

            var10000 = var6.toString();
         }

         var2 = var10000;
      }

      return "&b✦ &f" + var2 + " &bJeneratörü &8• &fSeviye " + var1;
   }

   private static String smallCaps(String var0) {
      String var1 = "abcdefghijklmnopqrstuvwxyz";
      String var2 = "abcdefghijklmnopqrstuvwxyz";
      StringBuilder var3 = new StringBuilder();

      for (char var7 : var0.toCharArray()) {
         char var8 = Character.toLowerCase(var7);
         int var9 = var1.indexOf(var8);
         var3.append(var9 >= 0 ? var2.charAt(var9) : var7);
      }

      return var3.toString();
   }

   private List<String> entryKeys(FileConfiguration var1) {
      ConfigurationSection var2 = var1.getConfigurationSection("entries");
      if (var2 == null) {
         return new ArrayList<>();
      }

      ArrayList var3 = new ArrayList(var2.getKeys(false));
      var3.sort(Comparator.<String>comparingInt(var1x -> var1.getInt("entries." + var1x + ".order", 999)).thenComparing(Comparator.naturalOrder()));
      return var3;
   }

   private List<Integer> configuredSlots(FileConfiguration var1) {
      return DEFAULT_CONTENT_SLOTS;
   }

   private void fill(FileConfiguration var1, Inventory var2) {
      if (var1.getBoolean("wiki.filler.enabled", true)) {
         Material var3 = MenuItems.material(var1.getString("wiki.filler.material"), Material.GRAY_STAINED_GLASS_PANE);
         MenuItems.fill(var2, var3, var1.getString("wiki.filler.name", " "));
      }
   }

   private List<String> replace(Player var1, List<String> var2) {
      ArrayList var3 = new ArrayList();

      for (String var5 : var2) {
         var3.add(this.replace(var1, var5));
      }

      return var3;
   }

   private String replace(Player var1, String var2) {
      return var2 == null
         ? ""
         : var2.replace("%player%", var1.getName())
            .replace("%generator_max_level%", String.valueOf(this.plugin.generatorService().maxLevel()))
            .replace("%generator_limit%", String.valueOf(this.plugin.generatorService().limit(var1)))
            .replace("%generator_count%", String.valueOf(this.plugin.generatorService().count(var1)));
   }

   private static String stripColors(String var0) {
      return var0 == null ? "" : var0.replaceAll("(?i)&#[0-9A-F]{6}|(?i)&[0-9A-FK-OR]", "");
   }

   private static int[] buildGeneratorSlots() {
      int[] var0 = new int[35];

      for (int var1 = 0; var1 < 35; var1++) {
         var0[var1] = 9 + var1;
      }

      return var0;
   }
}
