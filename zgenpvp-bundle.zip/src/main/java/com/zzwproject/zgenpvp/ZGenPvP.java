package com.zzwproject.zgenpvp;

import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zgenpvp.access.DefenseAccessListener;
import com.zzwproject.zgenpvp.access.DefenseAccessManager;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.base.BaseEnergyManager;
import com.zzwproject.zgenpvp.base.BaseEnergyRepository;
import com.zzwproject.zgenpvp.base.BaseListener;
import com.zzwproject.zgenpvp.base.BaseManager;
import com.zzwproject.zgenpvp.base.BaseMenu;
import com.zzwproject.zgenpvp.base.BaseMenuListener;
import com.zzwproject.zgenpvp.base.BaseReplacementCooldownManager;
import com.zzwproject.zgenpvp.beacon.BeaconListener;
import com.zzwproject.zgenpvp.beacon.BeaconManager;
import com.zzwproject.zgenpvp.beacon.BeaconMenu;
import com.zzwproject.zgenpvp.beacon.BeaconMenuListener;
import com.zzwproject.zgenpvp.beacon.BeaconSpawnMenu;
import com.zzwproject.zgenpvp.beacon.BeaconSpawnMenuListener;
import com.zzwproject.zgenpvp.command.AlertCommand;
import com.zzwproject.zgenpvp.command.BeaconCommand;
import com.zzwproject.zgenpvp.command.HasteCommand;
import com.zzwproject.zgenpvp.command.InstabreakerCommand;
import com.zzwproject.zgenpvp.command.LevelCommand;
import com.zzwproject.zgenpvp.command.RaidBombCommand;
import com.zzwproject.zgenpvp.command.RespawnCommand;
import com.zzwproject.zgenpvp.command.ZGenPvPCommand;
import com.zzwproject.zgenpvp.config.ConfigManager;
import com.zzwproject.zgenpvp.database.DatabaseManager;
import com.zzwproject.zgenpvp.death.DeathListener;
import com.zzwproject.zgenpvp.death.DeathManager;
import com.zzwproject.zgenpvp.defense.DefenseListener;
import com.zzwproject.zgenpvp.defense.DefenseManager;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.effects.EffectBootstrap;
import com.zzwproject.zgenpvp.generator.GeneratorListener;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.generator.GeneratorMenu;
import com.zzwproject.zgenpvp.generator.GeneratorMenuListener;
import com.zzwproject.zgenpvp.generator.GeneratorRewardPickupListener;
import com.zzwproject.zgenpvp.generator.GeneratorTask;
import com.zzwproject.zgenpvp.generator.link.GeneratorChestAccessListener;
import com.zzwproject.zgenpvp.generator.link.GeneratorLinkItem;
import com.zzwproject.zgenpvp.generator.link.GeneratorLinkListener;
import com.zzwproject.zgenpvp.generator.link.GeneratorLinkManager;
import com.zzwproject.zgenpvp.generator.sellwand.SellWandListener;
import com.zzwproject.zgenpvp.generator.sellwand.SellWandManager;
import com.zzwproject.zgenpvp.haste.HasteItemListener;
import com.zzwproject.zgenpvp.haste.HasteItemManager;
import com.zzwproject.zgenpvp.hud.DefenseHudTask;
import com.zzwproject.zgenpvp.instabreaker.InstabreakerListener;
import com.zzwproject.zgenpvp.instabreaker.InstabreakerManager;
import com.zzwproject.zgenpvp.integration.ZShardHook;
import com.zzwproject.zgenpvp.integration.ZTeamHook;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.level.LevelManager;
import com.zzwproject.zgenpvp.level.LevelMenu;
import com.zzwproject.zgenpvp.level.LevelMenuListener;
import com.zzwproject.zgenpvp.level.XpRewardManager;
import com.zzwproject.zgenpvp.listener.PlayerConnectionListener;
import com.zzwproject.zgenpvp.listener.StructureToolGuardListener;
import com.zzwproject.zgenpvp.money.MoneyItemManager;
import com.zzwproject.zgenpvp.money.MoneyListener;
import com.zzwproject.zgenpvp.placeholder.ZGenPvPPlaceholder;
import com.zzwproject.zgenpvp.player.CombatRegenerationManager;
import com.zzwproject.zgenpvp.player.PlayerVitalsListener;
import com.zzwproject.zgenpvp.raid.RaidAlertManager;
import com.zzwproject.zgenpvp.raid.RaidBombListener;
import com.zzwproject.zgenpvp.raid.RaidBombManager;
import com.zzwproject.zgenpvp.raid.RaidWindowManager;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.BeaconRepository;
import com.zzwproject.zgenpvp.repository.DefenseRepository;
import com.zzwproject.zgenpvp.repository.GeneratorRepository;
import com.zzwproject.zgenpvp.repository.PlayerRepository;
import com.zzwproject.zgenpvp.turret.TurretListener;
import com.zzwproject.zgenpvp.turret.TurretManager;
import com.zzwproject.zgenpvp.turret.TurretMenu;
import com.zzwproject.zgenpvp.turret.TurretMenuListener;
import com.zzwproject.zgenpvp.turret.TurretTask;
import com.zzwproject.zgenpvp.util.MessageUtil;
import com.zzwproject.zgenpvp.util.SoundUtil;
import java.util.Objects;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;

public final class ZGenPvP extends LegacyPluginBase {
   private static ZGenPvP instance;
   private ConfigManager configManager;
   private MessageUtil messageUtil;
   private SoundUtil soundUtil;
   private EconomyManager economyManager;
   private ZShardHook zShardHook;
   private ZTeamHook zTeamHook;
   private DatabaseManager databaseManager;
   private PlayerRepository playerRepository;
   private BeaconRepository beaconRepository;
   private BaseRepository baseRepository;
   private DefenseRepository defenseRepository;
   private GeneratorRepository generatorRepository;
   private SpecialItemFactory itemFactory;
   private MoneyItemManager moneyItemManager;
   private LevelManager levelManager;
   private XpRewardManager xpRewardManager;
   private LevelMenu levelMenu;
   private DeathManager deathManager;
   private CombatRegenerationManager combatRegenerationManager;
   private BeaconManager beaconManager;
   private BeaconMenu beaconMenu;
   private BeaconSpawnMenu beaconSpawnMenu;
   private BaseManager baseManager;
   private BaseMenu baseMenu;
   private BaseEnergyRepository baseEnergyRepository;
   private BaseEnergyManager baseEnergyManager;
   private BaseReplacementCooldownManager baseReplacementCooldownManager;
   private GeneratorManager generatorManager;
   private GeneratorTask generatorTask;
   private GeneratorMenu generatorMenu;
   private GeneratorLinkItem generatorLinkItem;
   private GeneratorLinkManager generatorLinkManager;
   private SellWandManager sellWandManager;
   private DefenseManager defenseManager;
   private TurretManager turretManager;
   private TurretMenu turretMenu;
   private TurretTask turretTask;
   private DefenseAccessManager defenseAccessManager;
   private RaidBombManager raidBombManager;
   private RaidWindowManager raidWindowManager;
   private RaidAlertManager raidAlertManager;
   private InstabreakerManager instabreakerManager;
   private HasteItemManager hasteItemManager;
   private DefenseHudTask defenseHudTask;
   private ZGenPvPPlaceholder placeholderExpansion;

   @Override
   public void onEnable() {
      instance = this;
      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.configManager.load();
      this.messageUtil = new MessageUtil(this);
      this.soundUtil = new SoundUtil(this);
      this.economyManager = new EconomyManager(this);
      if (!this.economyManager.setup()) {
         this.getLogger().severe("Vault veya Vault uyumlu Economy Provider bulunamadı!");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         this.zShardHook = new ZShardHook(this);
         this.zShardHook.hook();
         this.zTeamHook = new ZTeamHook(this);
         this.zTeamHook.hook();

         try {
            this.databaseManager = new DatabaseManager(this);
            this.databaseManager.connect();
            this.databaseManager.createTables();
         } catch (Exception var4) {
            this.getLogger().severe("SQLite başlatılamadı!");
            var4.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
            return;
         }

         this.playerRepository = new PlayerRepository(this.databaseManager);
         this.beaconRepository = new BeaconRepository(this.databaseManager);
         this.baseRepository = new BaseRepository(this.databaseManager);
         this.defenseRepository = new DefenseRepository(this.databaseManager);
         this.generatorRepository = new GeneratorRepository(this.databaseManager);
         this.baseEnergyRepository = new BaseEnergyRepository(this.databaseManager);

         try {
            this.baseEnergyRepository.createTable();
         } catch (Exception var3) {
            this.getLogger().severe("Base enerji tablosu oluşturulamadı!");
            var3.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
            return;
         }

         this.levelManager = new LevelManager(this, this.playerRepository);
         this.xpRewardManager = new XpRewardManager(this, this.levelManager);
         this.deathManager = new DeathManager(this, this.economyManager, this.levelManager, this.xpRewardManager);
         this.combatRegenerationManager = new CombatRegenerationManager(this);
         this.itemFactory = new SpecialItemFactory(this);
         this.moneyItemManager = new MoneyItemManager(this);
         this.generatorLinkItem = new GeneratorLinkItem(this);
         this.beaconManager = new BeaconManager(this, this.beaconRepository, this.itemFactory);
         this.beaconMenu = new BeaconMenu(this, this.beaconManager);
         this.beaconSpawnMenu = new BeaconSpawnMenu(this, this.beaconManager);
         this.baseReplacementCooldownManager = new BaseReplacementCooldownManager(this);
         this.baseManager = new BaseManager(this, this.baseRepository, this.beaconRepository, this.economyManager, this.itemFactory);
         this.baseEnergyManager = new BaseEnergyManager(this, this.baseRepository, this.defenseRepository, this.baseEnergyRepository, this.economyManager);
         this.baseMenu = new BaseMenu(this, this.baseManager, this.baseEnergyManager);
         this.generatorManager = new GeneratorManager(
            this,
            this.generatorRepository,
            this.baseRepository,
            this.beaconRepository,
            this.playerRepository,
            this.economyManager,
            this.moneyItemManager,
            this.zShardHook
         );
         this.generatorManager.loadCache();
         this.generatorTask = new GeneratorTask(this, this.generatorManager);
         this.generatorMenu = new GeneratorMenu(this, this.generatorManager);
         this.generatorLinkManager = new GeneratorLinkManager(this, this.generatorManager, this.generatorRepository, this.baseRepository);
         this.sellWandManager = new SellWandManager(this, this.generatorRepository, this.economyManager, this.moneyItemManager, this.xpRewardManager);
         this.levelMenu = new LevelMenu(this, this.levelManager, this.generatorManager);
         this.defenseManager = new DefenseManager(
            this, this.defenseRepository, this.baseRepository, this.economyManager, this.itemFactory, this.xpRewardManager
         );
         this.defenseManager.loadCache();
         this.turretManager = new TurretManager(this, this.defenseRepository, this.baseRepository, this.economyManager, this.itemFactory, this.xpRewardManager);
         this.turretManager.loadCache();
         this.turretMenu = new TurretMenu(this, this.turretManager);
         this.turretTask = new TurretTask(this, this.turretManager);
         this.defenseAccessManager = new DefenseAccessManager(this, this.defenseRepository, this.baseRepository, this.economyManager, this.itemFactory);
         this.defenseAccessManager.loadCache();
         this.raidWindowManager = new RaidWindowManager(this);
         this.raidBombManager = new RaidBombManager(this, this.baseManager, this.defenseManager, this.turretManager, this.defenseAccessManager);
         this.raidAlertManager = new RaidAlertManager(this);
         this.raidBombManager.setRelationService((var1, var2x) -> {
            if (var1 == null || var2x == null) {
               return false;
            } else {
               return var1.equals(var2x) ? true : this.zTeamHook != null && this.zTeamHook.areTeammates(var1, var2x);
            }
         });
         this.instabreakerManager = new InstabreakerManager(this, this.baseManager, this.defenseManager, this.turretManager, this.defenseAccessManager);
         this.hasteItemManager = new HasteItemManager(this);
         this.defenseHudTask = new DefenseHudTask(this);

         for (Player var2 : Bukkit.getOnlinePlayers()) {
            this.playerRepository.touchPlayer(var2.getUniqueId(), var2.getName());
            var2.setFoodLevel(20);
            var2.setSaturation(20.0F);
            var2.setExhaustion(0.0F);
            this.levelManager.syncHud(var2);
         }

         this.registerListeners();
         this.registerCommands();
         this.setupPlaceholderAPI();
         this.generatorTask.start();
         this.baseEnergyManager.start();
         this.combatRegenerationManager.start();
         this.turretTask.start();
         this.defenseHudTask.start();
         this.printStartup();
         EffectBootstrap.enable(this);
      }
   }

   @Override
   public void onDisable() {
      if (this.placeholderExpansion != null) {
         this.placeholderExpansion.unregister();
         this.placeholderExpansion = null;
      }

      if (this.raidBombManager != null) {
         this.raidBombManager.shutdown();
      }

      if (this.raidWindowManager != null) {
         this.raidWindowManager.shutdown();
      }

      if (this.generatorTask != null) {
         this.generatorTask.stop();
      }

      if (this.baseEnergyManager != null) {
         this.baseEnergyManager.stop();
      }

      if (this.baseReplacementCooldownManager != null) {
         this.baseReplacementCooldownManager.shutdown();
      }

      if (this.combatRegenerationManager != null) {
         this.combatRegenerationManager.stop();
      }

      if (this.turretTask != null) {
         this.turretTask.stop();
      }

      if (this.defenseHudTask != null) {
         this.defenseHudTask.stop();
      }

      if (this.deathManager != null) {
         this.deathManager.shutdown();
      }

      if (this.xpRewardManager != null) {
         this.xpRewardManager.shutdown();
      }

      if (this.generatorLinkManager != null) {
         this.generatorLinkManager.shutdown();
      }

      if (this.generatorManager != null) {
         this.generatorManager.shutdown();
      }

      if (this.beaconManager != null) {
         this.beaconManager.shutdown();
      }

      if (this.databaseManager != null) {
         this.databaseManager.close();
      }

      instance = null;
      this.getLogger().info("ZGenPvP güvenli şekilde kapatıldı.");
      EffectBootstrap.disable(this);
   }

   private void registerListeners() {
      Bukkit.getPluginManager().registerEvents(new PlayerConnectionListener(this.playerRepository), this);
      Bukkit.getPluginManager().registerEvents(new PlayerVitalsListener(this), this);
      Bukkit.getPluginManager().registerEvents(this.combatRegenerationManager, this);
      Bukkit.getPluginManager().registerEvents(new DeathListener(this.deathManager), this);
      Bukkit.getPluginManager().registerEvents(new LevelMenuListener(this.levelMenu), this);
      Bukkit.getPluginManager().registerEvents(new MoneyListener(this, this.moneyItemManager), this);
      Bukkit.getPluginManager().registerEvents(new BeaconListener(this, this.beaconManager, this.beaconMenu, this.itemFactory), this);
      Bukkit.getPluginManager().registerEvents(new BeaconMenuListener(this, this.beaconManager, this.beaconMenu), this);
      Bukkit.getPluginManager().registerEvents(new BeaconSpawnMenuListener(this, this.beaconManager, this.beaconSpawnMenu), this);
      Bukkit.getPluginManager().registerEvents(new BaseListener(this, this.baseManager, this.baseMenu, this.itemFactory), this);
      Bukkit.getPluginManager().registerEvents(new BaseMenuListener(this, this.baseManager, this.baseMenu, this.baseEnergyManager), this);
      Bukkit.getPluginManager().registerEvents(new StructureToolGuardListener(this), this);
      Bukkit.getPluginManager().registerEvents(new GeneratorListener(this.generatorManager, this.generatorLinkItem, this.generatorMenu), this);
      Bukkit.getPluginManager().registerEvents(new GeneratorMenuListener(this.generatorManager, this.generatorMenu), this);
      Bukkit.getPluginManager().registerEvents(new GeneratorLinkListener(this.generatorManager, this.generatorLinkManager, this.generatorLinkItem), this);
      Bukkit.getPluginManager().registerEvents(new GeneratorChestAccessListener(this, this.generatorLinkManager), this);
      Bukkit.getPluginManager().registerEvents(new GeneratorRewardPickupListener(this, this.generatorManager), this);
      Bukkit.getPluginManager().registerEvents(new SellWandListener(this.sellWandManager), this);
      Bukkit.getPluginManager().registerEvents(new InstabreakerListener(this.instabreakerManager), this);
      Bukkit.getPluginManager().registerEvents(new HasteItemListener(this.hasteItemManager), this);
      Bukkit.getPluginManager().registerEvents(new DefenseListener(this, this.defenseManager, this.itemFactory), this);
      Bukkit.getPluginManager().registerEvents(new TurretListener(this, this.turretManager, this.turretMenu, this.itemFactory), this);
      Bukkit.getPluginManager().registerEvents(new TurretMenuListener(this, this.turretManager, this.turretMenu), this);
      Bukkit.getPluginManager().registerEvents(new DefenseAccessListener(this, this.defenseAccessManager, this.itemFactory), this);
      Bukkit.getPluginManager().registerEvents(new RaidBombListener(this, this.raidBombManager), this);
   }

   private void registerCommands() {
      ZGenPvPCommand var1 = new ZGenPvPCommand(this, this.itemFactory);
      PluginCommand var2 = Objects.requireNonNull(this.getCommand("zgenpvp"));
      var2.setExecutor(var1);
      var2.setTabCompleter(var1);
      Objects.requireNonNull(this.getCommand("beacon")).setExecutor(new BeaconCommand(this, this.beaconManager, this.beaconMenu));
      Objects.requireNonNull(this.getCommand("respawn")).setExecutor(new RespawnCommand(this, this.beaconSpawnMenu));
      Objects.requireNonNull(this.getCommand("level")).setExecutor(new LevelCommand(this, this.levelMenu));
      Objects.requireNonNull(this.getCommand("raidbomb")).setExecutor(new RaidBombCommand(this, this.raidBombManager));
      Objects.requireNonNull(this.getCommand("alert")).setExecutor(new AlertCommand(this.raidAlertManager));
      InstabreakerCommand var3 = new InstabreakerCommand(this.instabreakerManager);
      PluginCommand var4 = Objects.requireNonNull(this.getCommand("instabreaker"));
      var4.setExecutor(var3);
      var4.setTabCompleter(var3);
      HasteCommand var5 = new HasteCommand(this.hasteItemManager);
      PluginCommand var6 = Objects.requireNonNull(this.getCommand("acele"));
      var6.setExecutor(var5);
      var6.setTabCompleter(var5);
   }

   private void setupPlaceholderAPI() {
      if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") == null) {
         this.getLogger().info("PlaceholderAPI bulunamadı. Placeholder sistemi devre dışı.");
      } else {
         this.placeholderExpansion = new ZGenPvPPlaceholder(this, this.levelManager, this.generatorManager);
         if (this.placeholderExpansion.register()) {
            this.getLogger().info("PlaceholderAPI entegrasyonu aktif.");
         } else {
            this.placeholderExpansion = null;
            this.getLogger().warning("PlaceholderAPI expansion kaydedilemedi.");
         }
      }
   }

   public void reloadPlugin() {
      this.configManager.reload();
      if (this.zShardHook != null) {
         this.zShardHook.hook();
      }

      if (this.zTeamHook != null) {
         this.zTeamHook.hook();
      }

      if (this.generatorLinkManager != null) {
         this.generatorLinkManager.shutdown();
      }

      if (this.generatorManager != null) {
         this.generatorManager.reload();
      }

      if (this.generatorTask != null) {
         this.generatorTask.start();
      }

      if (this.baseEnergyManager != null) {
         this.baseEnergyManager.start();
      }

      if (this.baseReplacementCooldownManager != null) {
         this.baseReplacementCooldownManager.cleanupExpired();
      }

      if (this.raidWindowManager != null) {
         this.raidWindowManager.cleanupExpired();
      }

      if (this.combatRegenerationManager != null) {
         this.combatRegenerationManager.start();
      }

      for (Player var2 : Bukkit.getOnlinePlayers()) {
         var2.setFoodLevel(20);
         var2.setSaturation(20.0F);
         var2.setExhaustion(0.0F);
         this.levelManager.syncHud(var2);
      }

      if (this.defenseManager != null) {
         this.defenseManager.loadCache();
      }

      if (this.turretManager != null) {
         this.turretManager.loadCache();
      }

      if (this.turretTask != null) {
         this.turretTask.start();
         this.defenseHudTask.start();
      }

      if (this.defenseAccessManager != null) {
         this.defenseAccessManager.loadCache();
      }

      if (this.instabreakerManager != null) {
         this.instabreakerManager.reload();
      }

      if (this.hasteItemManager != null) {
         this.hasteItemManager.reload();
      }

      this.getLogger().info("ZGenPvP ayarları yenilendi.");
      EffectBootstrap.reload(this);
   }

   private void printStartup() {
      this.getLogger().info("========================================");
      Logger var1 = this.getLogger();
      String var2 = this.getDescription().getVersion();
      var1.info("ZGenPvP " + var2);
      var1 = this.getLogger();
      var2 = Bukkit.getMinecraftVersion();
      var1.info("Minecraft: " + var2);
      var1 = this.getLogger();
      var2 = System.getProperty("java.version");
      var1.info("Java: " + var2);
      this.getLogger().info("Database: " + (this.databaseManager.isConnected() ? "OK" : "ERROR"));
      this.getLogger().info("Vault: " + this.economyManager.getProviderName());
      var1 = this.getLogger();
      var2 = this.zShardHook.isAvailable() ? this.zShardHook.getProviderName() : "NOT CONNECTED";
      var1.info("ZShard: " + var2);
      var1 = this.getLogger();
      var2 = this.zTeamHook.isAvailable() ? this.zTeamHook.getProviderName() : "NOT CONNECTED";
      var1.info("ZTeam: " + var2);
      this.getLogger().info("PlaceholderAPI: " + (this.placeholderExpansion != null ? "ACTIVE" : "NOT CONNECTED"));
      this.getLogger().info("Level: " + this.state(this.levelManager.isEnabled()));
      this.getLogger().info("Death: " + this.state(this.deathManager.isEnabled()));
      this.getLogger().info("Beacon: " + this.state(this.beaconManager.isEnabled()));
      this.getLogger().info("Base: " + this.state(this.baseManager.isEnabled()));
      this.getLogger()
         .info("Base Replacement Cooldown: " + this.state(this.baseReplacementCooldownManager != null && this.baseReplacementCooldownManager.isEnabled()));
      this.getLogger().info("Generator: " + this.state(this.generatorManager.isEnabled()));
      this.getLogger().info("Generator Hopper Pipeline: " + this.state(this.generatorManager.isHopperOutputEnabled()));
      this.getLogger().info("Sell Wand: " + this.state(this.sellWandManager.isEnabled()));
      this.getLogger().info("Defense: " + this.state(this.defenseManager.isEnabled()));
      this.getLogger().info("Turret: " + this.state(this.turretManager.isEnabled()));
      this.getLogger().info("Door: " + this.state(this.defenseAccessManager.isEnabled(DefenseAccessType.DOOR)));
      this.getLogger().info("Trapdoor: " + this.state(this.defenseAccessManager.isEnabled(DefenseAccessType.TRAPDOOR)));
      this.getLogger().info("Raid Bomb: " + this.state(this.raidBombManager.isEnabled()));
      this.getLogger().info("Simple Base Raid Window: " + this.state(this.raidWindowManager != null && this.raidWindowManager.isEnabled()));
      this.getLogger().info("Instabreaker: " + this.state(this.instabreakerManager.isEnabled()));
      this.getLogger().info("Acele II: " + this.state(this.hasteItemManager.isEnabled()));
      this.getLogger().info("========================================");
   }

   private String state(boolean var1) {
      return var1 ? "ACTIVE" : "DISABLED";
   }

   public static ZGenPvP getInstance() {
      return instance;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public MessageUtil getMessageUtil() {
      return this.messageUtil;
   }

   public SoundUtil getSoundUtil() {
      return this.soundUtil;
   }

   public EconomyManager getEconomyManager() {
      return this.economyManager;
   }

   public ZShardHook getZShardHook() {
      return this.zShardHook;
   }

   public ZTeamHook getZTeamHook() {
      return this.zTeamHook;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public PlayerRepository getPlayerRepository() {
      return this.playerRepository;
   }

   public BeaconRepository getBeaconRepository() {
      return this.beaconRepository;
   }

   public BaseRepository getBaseRepository() {
      return this.baseRepository;
   }

   public DefenseRepository getDefenseRepository() {
      return this.defenseRepository;
   }

   public GeneratorRepository getGeneratorRepository() {
      return this.generatorRepository;
   }

   public SpecialItemFactory getItemFactory() {
      return this.itemFactory;
   }

   public MoneyItemManager getMoneyItemManager() {
      return this.moneyItemManager;
   }

   public LevelManager getLevelManager() {
      return this.levelManager;
   }

   public XpRewardManager getXpRewardManager() {
      return this.xpRewardManager;
   }

   public RaidAlertManager getRaidAlertManager() {
      return this.raidAlertManager;
   }

   public LevelMenu getLevelMenu() {
      return this.levelMenu;
   }

   public DeathManager getDeathManager() {
      return this.deathManager;
   }

   public CombatRegenerationManager getCombatRegenerationManager() {
      return this.combatRegenerationManager;
   }

   public BeaconManager getBeaconManager() {
      return this.beaconManager;
   }

   public BeaconMenu getBeaconMenu() {
      return this.beaconMenu;
   }

   public BeaconSpawnMenu getBeaconSpawnMenu() {
      return this.beaconSpawnMenu;
   }

   public BaseManager getBaseManager() {
      return this.baseManager;
   }

   public BaseMenu getBaseMenu() {
      return this.baseMenu;
   }

   public BaseEnergyManager getBaseEnergyManager() {
      return this.baseEnergyManager;
   }

   public BaseReplacementCooldownManager getBaseReplacementCooldownManager() {
      return this.baseReplacementCooldownManager;
   }

   public GeneratorMenu getGeneratorMenu() {
      return this.generatorMenu;
   }

   public GeneratorManager getGeneratorManager() {
      return this.generatorManager;
   }

   public GeneratorTask getGeneratorTask() {
      return this.generatorTask;
   }

   public GeneratorLinkItem getGeneratorLinkItem() {
      return this.generatorLinkItem;
   }

   public GeneratorLinkManager getGeneratorLinkManager() {
      return this.generatorLinkManager;
   }

   public SellWandManager getSellWandManager() {
      return this.sellWandManager;
   }

   public DefenseManager getDefenseManager() {
      return this.defenseManager;
   }

   public TurretManager getTurretManager() {
      return this.turretManager;
   }

   public TurretMenu getTurretMenu() {
      return this.turretMenu;
   }

   public TurretTask getTurretTask() {
      return this.turretTask;
   }

   public DefenseAccessManager getDefenseAccessManager() {
      return this.defenseAccessManager;
   }

   public RaidBombManager getRaidBombManager() {
      return this.raidBombManager;
   }

   public RaidWindowManager getRaidWindowManager() {
      return this.raidWindowManager;
   }

   public InstabreakerManager getInstabreakerManager() {
      return this.instabreakerManager;
   }

   public HasteItemManager getHasteItemManager() {
      return this.hasteItemManager;
   }
}
