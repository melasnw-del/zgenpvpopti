package com.zzwproject.zgenpvp.effects;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.io.File;
import java.util.Locale;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;

final class EffectSettings {
   private final ZGenPvP plugin;
   private YamlConfiguration config;

   EffectSettings(ZGenPvP var1) {
      this.plugin = var1;
      this.reload();
   }

   void reload() {
      File var1 = new File(this.plugin.getDataFolder(), "effects.yml");
      if (!var1.exists()) {
         this.plugin.saveResource("effects.yml", false);
      }

      this.config = YamlConfiguration.loadConfiguration(var1);
   }

   boolean enabled() {
      return this.config.getBoolean("effects.enabled", true);
   }

   boolean particlesEnabled() {
      return this.config.getBoolean("effects.particles-enabled", true);
   }

   boolean soundsEnabled() {
      return this.config.getBoolean("effects.sounds-enabled", true);
   }

   int viewDistance() {
      return this.clamp(this.config.getInt("effects.view-distance", 32), 8, 96);
   }

   double particleMultiplier() {
      return this.clamp(this.config.getDouble("effects.particle-multiplier", 1.0), 0.25, 2.0);
   }

   boolean enabled(EffectType var1, boolean var2) {
      return this.config.getBoolean(this.path(var1, var2) + ".enabled", true);
   }

   boolean particles(EffectType var1, boolean var2) {
      return this.particlesEnabled() && this.config.getBoolean(this.path(var1, var2) + ".particles", true);
   }

   boolean sound(EffectType var1, boolean var2) {
      return this.soundsEnabled() && this.config.getBoolean(this.path(var1, var2) + ".sound", true);
   }

   Particle primary(EffectType var1, boolean var2) {
      return this.particle(this.path(var1, var2) + ".primary-particle", this.defaultPrimary(var1, var2));
   }

   Particle secondary(EffectType var1, boolean var2) {
      return this.particle(this.path(var1, var2) + ".secondary-particle", this.defaultSecondary(var1, var2));
   }

   Sound soundValue(EffectType var1, boolean var2) {
      return this.sound(this.path(var1, var2) + ".sound-type", this.defaultSound(var1, var2));
   }

   float volume(EffectType var1, boolean var2) {
      return (float)this.clamp(this.config.getDouble(this.path(var1, var2) + ".volume", 0.85), 0.0, 2.0);
   }

   float pitch(EffectType var1, boolean var2) {
      return (float)this.clamp(this.config.getDouble(this.path(var1, var2) + ".pitch", var2 ? 1.15 : 1.0), 0.5, 2.0);
   }

   private String path(EffectType var1, boolean var2) {
      return "effects." + var1.path() + "." + (var2 ? "upgrade" : "placement");
   }

   private Particle particle(String var1, Particle var2) {
      String var3 = this.config.getString(var1, var2.name());
      if (var3 == null) {
         return var2;
      }

      try {
         return Particle.valueOf(var3.trim().toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException var5) {
         this.plugin.getLogger().warning("Effects.yml > " + var1 + " geçersiz: " + var3 + ". Varsayılan kullaniliyor: " + var2.name());
         return var2;
      }
   }

   private Sound sound(String var1, Sound var2) {
      String var3 = this.config.getString(var1, var2.name());
      if (var3 == null) {
         return var2;
      }

      try {
         return Sound.valueOf(var3.trim().toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException var5) {
         this.plugin.getLogger().warning("Effects.yml > " + var1 + " geçersiz: " + var3 + ". Varsayılan kullaniliyor: " + var2.name());
         return var2;
      }
   }

   private Particle defaultPrimary(EffectType var1, boolean var2) {
      if (var2) {
         return Particle.ENCHANT;
      }

      return switch (var1) {
         case GENERATOR -> Particle.HAPPY_VILLAGER;
         case BEACON -> Particle.END_ROD;
         case BASE -> Particle.CLOUD;
         case TURRET -> Particle.ELECTRIC_SPARK;
         case DEFENSE_BLOCK -> Particle.CRIT;
         case DEFENSE_DOOR, DEFENSE_TRAPDOOR -> Particle.ELECTRIC_SPARK;
      };
   }

   private Particle defaultSecondary(EffectType var1, boolean var2) {
      if (var2) {
         return Particle.END_ROD;
      }

      return switch (var1) {
         case GENERATOR, BEACON -> Particle.ENCHANT;
         case BASE -> Particle.END_ROD;
         case TURRET -> Particle.CLOUD;
         case DEFENSE_BLOCK -> Particle.ENCHANT;
         case DEFENSE_DOOR, DEFENSE_TRAPDOOR -> Particle.ENCHANT;
      };
   }

   private Sound defaultSound(EffectType var1, boolean var2) {
      if (var2) {
         return switch (var1) {
            case GENERATOR, TURRET -> Sound.BLOCK_BEACON_POWER_SELECT;
            case BEACON -> Sound.ENTITY_PLAYER_LEVELUP;
            case BASE, DEFENSE_BLOCK, DEFENSE_DOOR, DEFENSE_TRAPDOOR -> Sound.BLOCK_ANVIL_USE;
         };
      } else {
         return switch (var1) {
            case GENERATOR -> Sound.BLOCK_AMETHYST_BLOCK_CHIME;
            case BEACON -> Sound.BLOCK_BEACON_ACTIVATE;
            case BASE -> Sound.BLOCK_ANVIL_PLACE;
            case TURRET -> Sound.BLOCK_PISTON_EXTEND;
            case DEFENSE_BLOCK -> Sound.BLOCK_ANVIL_PLACE;
            case DEFENSE_DOOR -> Sound.BLOCK_IRON_DOOR_CLOSE;
            case DEFENSE_TRAPDOOR -> Sound.BLOCK_IRON_TRAPDOOR_CLOSE;
         };
      }
   }

   private int clamp(int var1, int var2, int var3) {
      return Math.max(var2, Math.min(var3, var1));
   }

   private double clamp(double var1, double var3, double var5) {
      return Math.max(var3, Math.min(var5, var1));
   }
}
