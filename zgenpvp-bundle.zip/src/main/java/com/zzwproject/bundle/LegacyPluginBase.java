package com.zzwproject.bundle;

import io.papermc.paper.plugin.configuration.PluginMeta;
import io.papermc.paper.plugin.lifecycle.event.LifecycleEventManager;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Server;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginLoader;

public class LegacyPluginBase implements Plugin {
   private final ModuleContext ctx;

   public LegacyPluginBase() {
      ModuleContext var1 = ModuleRegistry.get(this.getClass().getName());
      if (var1 == null) {
         throw new IllegalStateException("Bundle context not prepared for " + this.getClass().getName());
      }

      this.ctx = var1;
   }

   public File getDataFolder() {
      File var1 = this.ctx.owner.getDataFolder().getParentFile();
      File var2 = new File(var1, this.ctx.moduleName);
      if (!var2.exists()) {
         var2.mkdirs();
      }

      return var2;
   }

   public PluginDescriptionFile getDescription() {
      return this.ctx.description;
   }

   public FileConfiguration getConfig() {
      if (this.ctx.config == null) {
         this.reloadConfig();
      }

      return (FileConfiguration)this.ctx.config;
   }

   public void reloadConfig() {
      try {
         this.saveDefaultConfig();
         Class var1 = Class.forName("org.bukkit.configuration.file.YamlConfiguration", true, this.getClass().getClassLoader());
         Object var2 = var1.getMethod("loadConfiguration", File.class).invoke(null, new File(this.getDataFolder(), "config.yml"));

         try (InputStream var3 = this.getResource("config.yml")) {
            if (var3 != null) {
               Object var4 = var1.getMethod("loadConfiguration", Reader.class).invoke(null, new InputStreamReader(var3, StandardCharsets.UTF_8));

               for (Method var8 : var2.getClass().getMethods()) {
                  if (var8.getName().equals("setDefaults") && var8.getParameterCount() == 1 && var8.getParameterTypes()[0].isInstance(var4)) {
                     var8.invoke(var2, var4);
                     break;
                  }
               }
            }
         } catch (Throwable var11) {
         }

         this.ctx.config = var2;
      } catch (Throwable var12) {
         throw new IllegalStateException("Config yüklenemedi: " + this.ctx.moduleName, var12);
      }
   }

   public void saveConfig() {
      if (this.ctx.config != null) {
         try {
            Method var1 = this.ctx.config.getClass().getMethod("save", File.class);
            var1.invoke(this.ctx.config, new File(this.getDataFolder(), "config.yml"));
         } catch (Throwable var2) {
            this.getLogger().log(Level.SEVERE, "config.yml kaydedilemedi", var2);
         }
      }
   }

   public void saveDefaultConfig() {
      File var1 = new File(this.getDataFolder(), "config.yml");
      if (!var1.exists()) {
         try {
            this.saveResource("config.yml", false);
         } catch (IllegalArgumentException var3) {
         }
      }
   }

   public void saveResource(String var1, boolean var2) {
      if (var1 != null && !var1.isBlank()) {
         String var3 = var1.replace('\\', '/');
         if (var3.startsWith("/")) {
            var3 = var3.substring(1);
         }

         try (InputStream var4 = this.getResource(var3)) {
            if (var4 == null) {
               throw new IllegalArgumentException("Resource bulunamadı: " + var3 + " (" + this.ctx.moduleName + ")");
            }

            File var5 = new File(this.getDataFolder(), var3);
            File var6 = var5.getParentFile();
            if (var6 != null) {
               var6.mkdirs();
            }

            if (!var5.exists() || var2) {
               Files.copy(var4, var5.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
         } catch (IOException var9) {
            throw new IllegalStateException("Resource yazılamadı: " + var3, var9);
         }
      } else {
         throw new IllegalArgumentException("resourcePath");
      }
   }

   public InputStream getResource(String var1) {
      if (var1 == null) {
         return null;
      }

      String var2 = var1.replace('\\', '/');
      if (var2.startsWith("/")) {
         var2 = var2.substring(1);
      }

      return this.getClass().getClassLoader().getResourceAsStream(this.ctx.resourceRoot + var2);
   }

   public Reader getTextResource(String var1) {
      InputStream var2 = this.getResource(var1);
      return var2 == null ? null : new InputStreamReader(var2, StandardCharsets.UTF_8);
   }

   public boolean onCommand(org.bukkit.command.CommandSender var1, org.bukkit.command.Command var2, String var3, String[] var4) {
      return false;
   }

   public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender var1, org.bukkit.command.Command var2, String var3, String[] var4) {
      return null;
   }

   public PluginCommand getCommand(String var1) {
      return var1 == null ? null : this.ctx.commands.get(var1.toLowerCase(Locale.ROOT));
   }

   public PluginLoader getPluginLoader() {
      return this.ctx.owner.getPluginLoader();
   }

   public Server getServer() {
      return this.ctx.owner.getServer();
   }

   public boolean isEnabled() {
      return this.ctx.enabled;
   }

   public boolean isNaggable() {
      return this.ctx.naggable;
   }

   public void setNaggable(boolean var1) {
      this.ctx.naggable = var1;
   }

   public Logger getLogger() {
      return this.ctx.logger;
   }

   public String getName() {
      return this.ctx.moduleName;
   }

   public ClassLoader getClassLoader() {
      return this.getClass().getClassLoader();
   }

   public ChunkGenerator getDefaultWorldGenerator(String var1, String var2) {
      return null;
   }

   public BiomeProvider getDefaultBiomeProvider(String var1, String var2) {
      return null;
   }

   public void onLoad() {
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public String namespace() {
      return this.getName().toLowerCase(Locale.ROOT);
   }

   public PluginMeta getPluginMeta() {
      return this.ctx.description;
   }

   public LifecycleEventManager getLifecycleManager() {
      return this.ctx.owner.getLifecycleManager();
   }
}
