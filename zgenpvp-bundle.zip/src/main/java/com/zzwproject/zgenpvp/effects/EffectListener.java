package com.zzwproject.zgenpvp.effects;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import java.lang.reflect.Field;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

final class EffectListener implements Listener {
   private final ZGenPvP plugin;
   private final EffectPlayer effects;
   private final ConcurrentHashMap<UUID, EffectListener.UpgradeSnapshot> interactSnapshots = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<UUID, EffectListener.UpgradeSnapshot> menuSnapshots = new ConcurrentHashMap<>();

   EffectListener(ZGenPvP var1, EffectPlayer var2) {
      this.plugin = var1;
      this.effects = var2;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPlace(BlockPlaceEvent var1) {
      EffectType var2 = this.detectItem(var1.getItemInHand());
      if (var2 != null) {
         Player var3 = var1.getPlayer();
         Location var4 = var1.getBlockPlaced().getLocation();
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (this.isPlaced(var2, var4, var1.getBlockPlaced())) {
               this.effects.playPlacement(var2, var4);
            }
         });
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onInteractCapture(PlayerInteractEvent var1) {
      Block var2 = var1.getClickedBlock();
      if (var2 != null) {
         EffectListener.UpgradeSnapshot var3 = this.snapshotAt(var2);
         if (var3 != null) {
            this.interactSnapshots.put(var1.getPlayer().getUniqueId(), var3);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onInteractAfter(PlayerInteractEvent var1) {
      UUID var2 = var1.getPlayer().getUniqueId();
      EffectListener.UpgradeSnapshot var3 = this.interactSnapshots.remove(var2);
      if (var3 != null) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.playIfUpgraded(var3));
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onMenuCapture(InventoryClickEvent var1) {
      Player var2 = this.asPlayer(var1.getWhoClicked());
      if (var2 != null) {
         EffectListener.UpgradeSnapshot var3 = this.snapshotFromHolder(var1.getInventory());
         if (var3 != null) {
            this.menuSnapshots.put(var2.getUniqueId(), var3);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onMenuAfter(InventoryClickEvent var1) {
      Player var2 = this.asPlayer(var1.getWhoClicked());
      if (var2 != null) {
         EffectListener.UpgradeSnapshot var3 = this.menuSnapshots.remove(var2.getUniqueId());
         if (var3 != null) {
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.playIfUpgraded(var3));
         }
      }
   }

   private EffectType detectItem(ItemStack var1) {
      if (var1 == null) {
         return null;
      } else if (this.plugin.getGeneratorManager() != null && this.plugin.getGeneratorManager().isGeneratorItem(var1)) {
         return EffectType.GENERATOR;
      } else if (this.plugin.getItemFactory() == null) {
         return null;
      } else if (this.plugin.getItemFactory().isRespawnBeacon(var1)) {
         return EffectType.BEACON;
      } else if (this.plugin.getItemFactory().isBaseBlock(var1)) {
         return EffectType.BASE;
      } else if (this.plugin.getItemFactory().isTurret(var1)) {
         return EffectType.TURRET;
      } else if (this.plugin.getItemFactory().isDefenseBlock(var1)) {
         return EffectType.DEFENSE_BLOCK;
      } else if (this.plugin.getItemFactory().isDefenseDoor(var1)) {
         return EffectType.DEFENSE_DOOR;
      } else {
         return this.plugin.getItemFactory().isDefenseTrapdoor(var1) ? EffectType.DEFENSE_TRAPDOOR : null;
      }
   }

   private boolean isPlaced(EffectType var1, Location var2, Block var3) {
      return switch (var1) {
         case GENERATOR -> this.plugin.getGeneratorManager() != null && this.plugin.getGeneratorManager().getGenerator(var2).isPresent();
         case BEACON -> this.plugin.getBeaconManager() != null && this.plugin.getBeaconManager().getBeacon(var2).isPresent();
         case BASE -> this.plugin.getBaseManager() != null && this.plugin.getBaseManager().getBase(var2).isPresent();
         case TURRET -> this.plugin.getTurretManager() != null && this.plugin.getTurretManager().getTurret(var2).isPresent();
         case DEFENSE_BLOCK -> this.plugin.getDefenseManager() != null && this.plugin.getDefenseManager().getDefense(var2).isPresent();
         case DEFENSE_DOOR, DEFENSE_TRAPDOOR -> this.plugin.getDefenseAccessManager() != null && this.plugin.getDefenseAccessManager().get(var3).isPresent();
      };
   }

   private EffectListener.UpgradeSnapshot snapshotAt(Block var1) {
      Location var2 = var1.getLocation();
      if (this.plugin.getDefenseManager() != null) {
         Optional var3 = this.plugin.getDefenseManager().getDefense(var2);
         if (var3.isPresent()) {
            return this.snap(EffectType.DEFENSE_BLOCK, (DefenseData)var3.get());
         }
      }

      if (this.plugin.getTurretManager() != null) {
         Optional var7 = this.plugin.getTurretManager().getTurret(var2);
         if (var7.isPresent()) {
            return this.snap(EffectType.TURRET, (DefenseData)var7.get());
         }
      }

      if (this.plugin.getDefenseAccessManager() != null) {
         Optional var8 = this.plugin.getDefenseAccessManager().get(var1);
         if (var8.isPresent()) {
            DefenseData var4 = (DefenseData)var8.get();
            String var5 = var4.getType();
            EffectType var6 = var5 != null && var5.toUpperCase(Locale.ROOT).contains("TRAP") ? EffectType.DEFENSE_TRAPDOOR : EffectType.DEFENSE_DOOR;
            return this.snap(var6, var4);
         }
      }

      return null;
   }

   private EffectListener.UpgradeSnapshot snapshotFromHolder(Inventory var1) {
      if (var1 == null) {
         return null;
      }

      InventoryHolder var2 = var1.getHolder();
      if (var2 == null) {
         return null;
      }

      String var3 = var2.getClass().getName();

      try {
         if (var3.endsWith("GeneratorMenu$GeneratorMenuHolder")) {
            long var11 = this.readLong(var2, "generatorId");
            UUID var13 = (UUID)this.readField(var2, "ownerUuid");
            Optional<com.zzwproject.zgenpvp.model.GeneratorData> var14 = this.plugin.getGeneratorManager().getGenerator(var11, var13);
            return var14.<EffectListener.UpgradeSnapshot>map(
                  var0 -> new EffectListener.UpgradeSnapshot(EffectType.GENERATOR, var0.getLocation(), var0.getLevel())
               )
               .orElse(null);
         }

         if (var3.endsWith("TurretMenu$TurretMenuHolder")) {
            long var4 = this.readLong(var2, "turretId");

            for (DefenseData var8 : this.plugin.getTurretManager().getTurrets()) {
               if (var8.getId() == var4) {
                  return this.snap(EffectType.TURRET, var8);
               }
            }
         }

         if (var3.endsWith("BaseMenu$BaseMenuHolder")) {
            UUID var10 = (UUID)this.readField(var2, "ownerUuid");
            Optional var5 = this.plugin.getBaseManager().getBase(var10);
            if (var5.isPresent()) {
               BaseData var12 = (BaseData)var5.get();
               return new EffectListener.UpgradeSnapshot(EffectType.BASE, var12.getLocation(), var12.getLevel());
            }
         }
      } catch (ReflectiveOperationException var9) {
         this.plugin.getLogger().warning("V2 efekt sistemi menu bilgisi okunamadi: " + var9.getMessage());
      }

      return null;
   }

   private void playIfUpgraded(EffectListener.UpgradeSnapshot var1) {
      int var2 = this.currentLevel(var1);
      if (var2 > var1.level()) {
         this.effects.playUpgrade(var1.type(), var1.location(), var2);
      }
   }

   private int currentLevel(EffectListener.UpgradeSnapshot var1) {
      Location var2 = var1.location();

      return switch (var1.type()) {
         case GENERATOR -> this.plugin.getGeneratorManager().getGenerator(var2).map(GeneratorData::getLevel).orElse(-1);
         case BEACON -> -1;
         case BASE -> this.plugin.getBaseManager().getBase(var2).map(BaseData::getLevel).orElse(-1);
         case TURRET -> this.plugin.getTurretManager().getTurret(var2).map(DefenseData::getLevel).orElse(-1);
         case DEFENSE_BLOCK -> this.plugin.getDefenseManager().getDefense(var2).map(DefenseData::getLevel).orElse(-1);
         case DEFENSE_DOOR, DEFENSE_TRAPDOOR -> this.plugin.getDefenseAccessManager().get(var2.getBlock()).map(DefenseData::getLevel).orElse(-1);
      };
   }

   private EffectListener.UpgradeSnapshot snap(EffectType var1, DefenseData var2) {
      return new EffectListener.UpgradeSnapshot(var1, var2.getLocation(), var2.getLevel());
   }

   private Object readField(Object var1, String var2) throws ReflectiveOperationException {
      Field var3 = var1.getClass().getDeclaredField(var2);
      var3.setAccessible(true);
      return var3.get(var1);
   }

   private long readLong(Object var1, String var2) throws ReflectiveOperationException {
      Object var3 = this.readField(var1, var2);
      return ((Number)var3).longValue();
   }

   private Player asPlayer(HumanEntity var1) {
      return var1 instanceof Player ? (Player)var1 : null;
   }

   private record UpgradeSnapshot(EffectType type, Location location, int level) {
   }
}
