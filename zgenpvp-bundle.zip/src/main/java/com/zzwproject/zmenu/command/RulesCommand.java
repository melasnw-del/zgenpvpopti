package com.zzwproject.zmenu.command;

import com.zzwproject.zmenu.ZMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class RulesCommand implements CommandExecutor {
   private final ZMenu plugin;

   public RulesCommand(ZMenu var1) {
      this.plugin = var1;
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("zmenu.rules")) {
            this.plugin.message().send(var5, "no-permission");
            return true;
         } else {
            this.plugin.rules().open(var5, 0);
            return true;
         }
      } else {
         this.plugin.message().send(var1, "player-only");
         return true;
      }
   }
}
