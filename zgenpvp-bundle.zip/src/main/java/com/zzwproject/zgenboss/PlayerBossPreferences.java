package com.zzwproject.zgenboss;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PlayerBossPreferences {
   private static Object plugin;
   private static final Properties prefs = new Properties();
   private static File prefsFile;
   private static Object listenerProxy;
   private static Object openExecutorProxy;
   private static Object clickExecutorProxy;

   private PlayerBossPreferences() {
   }

   public static void bootstrap(Object var0) {
      plugin = var0;

      try {
         File var1 = (File)call(var0, "getDataFolder", new Class[0]);
         if (!var1.exists()) {
            var1.mkdirs();
         }

         prefsFile = new File(var1, "boss-preferences.properties");
         load();
         if (cfgBool("player-toggle.enabled", true)) {
            registerMenuHooks();
            log("Jeneratör Boss Aç/Kapat menü entegrasyonu aktif.");
         }
      } catch (Throwable var2) {
         warn("Boss tercih sistemi başlatılamadı: " + var2.getClass().getSimpleName() + ": " + var2.getMessage());
      }
   }

   public static boolean canSpawn(Object var0, Object var1, Object var2) {
      try {
         if (!cfgBool("player-toggle.enabled", true)) {
            return true;
         } else {
            long var3 = readLong(var1, "id", -1L);
            if (var3 < 0L) {
               return true;
            } else {
               return cfgBool("spawn-conditions.require-owner-online", true) && var2 == null ? false : isEnabled(var3);
            }
         }
      } catch (Throwable var5) {
         debug("canSpawn kontrolü atlandı: " + var5.getClass().getSimpleName());
         return true;
      }
   }

   private static void registerMenuHooks() throws Exception {
      ClassLoader var0 = plugin.getClass().getClassLoader();
      Class var1 = Class.forName("org.bukkit.Bukkit", true, var0);
      Class var2 = Class.forName("org.bukkit.event.Listener", true, var0);
      Class var3 = Class.forName("org.bukkit.event.EventPriority", true, var0);
      Class var4 = Class.forName("org.bukkit.plugin.EventExecutor", true, var0);
      Class var5 = Class.forName("org.bukkit.plugin.Plugin", true, var0);
      Class var6 = Class.forName("org.bukkit.event.inventory.InventoryOpenEvent", true, var0);
      Class var7 = Class.forName("org.bukkit.event.inventory.InventoryClickEvent", true, var0);
      InvocationHandler var8 = (var0x, var1x, var2x) -> objectMethod(var0x, var1x, var2x);
      listenerProxy = Proxy.newProxyInstance(var0, new Class[]{var2}, var8);
      openExecutorProxy = Proxy.newProxyInstance(var0, new Class[]{var4}, (var0x, var1x, var2x) -> {
         if (var1x.getName().equals("execute") && var2x != null && var2x.length >= 2) {
            handleOpen(var2x[1]);
         }

         return objectMethod(var0x, var1x, var2x);
      });
      clickExecutorProxy = Proxy.newProxyInstance(var0, new Class[]{var4}, (var0x, var1x, var2x) -> {
         if (var1x.getName().equals("execute") && var2x != null && var2x.length >= 2) {
            handleClick(var2x[1]);
         }

         return objectMethod(var0x, var1x, var2x);
      });
      Object var9 = var1.getMethod("getPluginManager").invoke(null);
      Enum var10 = Enum.valueOf(var3.asSubclass(Enum.class), "NORMAL");
      Method var11 = var9.getClass().getMethod("registerEvent", Class.class, var2, var3, var4, var5, boolean.class);
      var11.invoke(var9, var6, listenerProxy, var10, openExecutorProxy, plugin, false);
      var11.invoke(var9, var7, listenerProxy, var10, clickExecutorProxy, plugin, false);
   }

   private static Object objectMethod(Object var0, Method var1, Object[] var2) {
      if (var1.getDeclaringClass() == Object.class) {
         switch (var1.getName()) {
            case "toString":
               return "ZGenBossMenuListener";
            case "hashCode":
               return System.identityHashCode(var0);
            case "equals":
               return var0 == (var2 == null || var2.length == 0 ? null : var2[0]);
            default:
               return null;
         }
      }

      return null;
   }

   private static void handleOpen(Object var0) {
      try {
         Object var1 = call(var0, "getInventory", new Class[0]);
         Object var2 = call(var1, "getHolder", new Class[0]);
         if (!isGeneratorHolder(var2)) {
            return;
         }

         Object var3 = call(var0, "getPlayer", new Class[0]);
         renderToggle(var1, var2, var3);
      } catch (Throwable var4) {
         debug("Menü açılış entegrasyonu: " + var4.getClass().getSimpleName());
      }
   }

   private static void handleClick(Object var0) {
      try {
         Object var1 = call(var0, "getView", new Class[0]);
         Object var2 = call(var1, "getTopInventory", new Class[0]);
         Object var3 = call(var2, "getHolder", new Class[0]);
         if (!isGeneratorHolder(var3)) {
            return;
         }

         int var4 = ((Number)call(var0, "getRawSlot", new Class[0])).intValue();
         int var5 = cfgInt("player-toggle.menu-slot", 22);
         if (var4 != var5) {
            return;
         }

         call(var0, "setCancelled", new Class[]{boolean.class}, true);
         Object var6 = call(var0, "getWhoClicked", new Class[0]);
         long var7 = readLong(var3, "generatorId", -1L);
         Object var9 = readField(var3, "ownerUuid");
         Object var10 = call(var6, "getUniqueId", new Class[0]);
         if (var7 < 0L) {
            return;
         }

         if (cfgBool("player-toggle.owner-only", true) && var9 != null && !var9.equals(var10)) {
            send(var6, cfgString("player-toggle.messages.not-owner", "&dʙᴏꜱꜱ &8» &cBu ayarı sadece jeneratör sahibi değiştirebilir."));
            return;
         }

         boolean var11 = !isEnabled(var7);
         setEnabled(var7, var11);
         if (!var11 && cfgBool("player-toggle.remove-active-boss-on-disable", true)) {
            removeActiveBoss(var7);
         }

         renderToggle(var2, var3, var6);
         send(
            var6,
            cfgString(
               var11 ? "player-toggle.messages.enabled" : "player-toggle.messages.disabled",
               var11 ? "&dʙᴏꜱꜱ &8» &aBu jeneratörde boss doğması açıldı." : "&dʙᴏꜱꜱ &8» &cBu jeneratörde boss doğması kapatıldı."
            )
         );
      } catch (Throwable var12) {
         warn("Boss menü tıklaması işlenemedi: " + var12.getClass().getSimpleName() + ": " + var12.getMessage());
      }
   }

   private static void renderToggle(Object var0, Object var1, Object var2) throws Exception {
      int var3 = cfgInt("player-toggle.menu-slot", 22);
      int var4 = ((Number)call(var0, "getSize", new Class[0])).intValue();
      if (var3 >= 0 && var3 < var4) {
         long var5 = readLong(var1, "generatorId", -1L);
         if (var5 >= 0L) {
            boolean var7 = isEnabled(var5);
            String var8 = cfgString(var7 ? "player-toggle.menu-material-enabled" : "player-toggle.menu-material-disabled", var7 ? "LIME_DYE" : "GRAY_DYE");
            String var9 = cfgString(
               var7 ? "player-toggle.menu-name-enabled" : "player-toggle.menu-name-disabled",
               var7 ? "&a✦ ᴊᴇɴᴇʀᴀᴛöʀ ʙᴏꜱꜱᴜ &8• &aAçık" : "&c✦ ᴊᴇɴᴇʀᴀᴛöʀ ʙᴏꜱꜱᴜ &8• &cKapalı"
            );
            List var10 = cfgList(var7 ? "player-toggle.menu-lore-enabled" : "player-toggle.menu-lore-disabled");
            if (var10.isEmpty()) {
               var10 = var7
                  ? List.of("&f│ &7Durum: &aBoss çıkabilir", "&f│ &7Ayar: &fJeneratöre özel", "", "&e› Kapatmak için tıkla!")
                  : List.of("&f│ &7Durum: &cBoss çıkmaz", "&f│ &7Ayar: &fJeneratöre özel", "", "&e› Açmak için tıkla!");
            }

            Object var11 = createItem(var8, var9, var10);
            Class var12 = Class.forName("org.bukkit.inventory.ItemStack", true, plugin.getClass().getClassLoader());
            call(var0, "setItem", new Class[]{int.class, var12}, var3, var11);
         }
      }
   }

   private static Object createItem(String var0, String var1, List<String> var2) throws Exception {
      ClassLoader var3 = plugin.getClass().getClassLoader();
      Class var4 = Class.forName("org.bukkit.Material", true, var3);
      Enum var5 = Enum.valueOf(var4.asSubclass(Enum.class), var0.toUpperCase(Locale.ROOT));
      Class var6 = Class.forName("org.bukkit.inventory.ItemStack", true, var3);
      Object var7 = var6.getConstructor(var4).newInstance(var5);
      Object var8 = call(var7, "getItemMeta", new Class[0]);
      call(var8, "setDisplayName", new Class[]{String.class}, color(var1));
      ArrayList var9 = new ArrayList();

      for (String var11 : var2) {
         var9.add(color(var11));
      }

      call(var8, "setLore", new Class[]{List.class}, var9);
      Class var12 = Class.forName("org.bukkit.inventory.meta.ItemMeta", true, var3);
      call(var7, "setItemMeta", new Class[]{var12}, var8);
      return var7;
   }

   private static boolean isGeneratorHolder(Object var0) {
      if (var0 == null) {
         return false;
      }

      String var1 = var0.getClass().getName();
      return var1.equals("com.zzwproject.zgenpvp.generator.GeneratorMenu$GeneratorMenuHolder")
         || var1.endsWith("GeneratorMenu$GeneratorMenuHolder")
         || hasField(var0.getClass(), "generatorId") && hasField(var0.getClass(), "ownerUuid");
   }

   private static boolean isEnabled(long var0) {
      String var2 = prefs.getProperty(Long.toString(var0));
      return var2 == null ? cfgBool("player-toggle.default-enabled", true) : Boolean.parseBoolean(var2);
   }

   private static synchronized void setEnabled(long var0, boolean var2) {
      prefs.setProperty(Long.toString(var0), Boolean.toString(var2));
      save();
   }

   private static synchronized void load() {
      prefs.clear();
      if (prefsFile != null && prefsFile.isFile()) {
         try (BufferedInputStream var0 = new BufferedInputStream(new FileInputStream(prefsFile))) {
            prefs.load(var0);
         } catch (IOException var5) {
            warn("Boss tercihleri okunamadı: " + var5.getMessage());
         }
      }
   }

   private static synchronized void save() {
      if (prefsFile != null) {
         try {
            File var0 = prefsFile.getParentFile();
            if (var0 != null && !var0.exists()) {
               var0.mkdirs();
            }

            try (BufferedOutputStream var1 = new BufferedOutputStream(new FileOutputStream(prefsFile))) {
               prefs.store(var1, "ZGenBoss generator boss preferences - true/false");
            }
         } catch (IOException var6) {
            warn("Boss tercihleri kaydedilemedi: " + var6.getMessage());
         }
      }
   }

   private static void removeActiveBoss(long var0) {
      try {
         Field var2 = findField(plugin.getClass(), "activeByGenerator");
         Field var3 = findField(plugin.getClass(), "activeBosses");
         var2.setAccessible(true);
         var3.setAccessible(true);
         Map var4 = (Map)var2.get(plugin);
         Map var5 = (Map)var3.get(plugin);
         Object var6 = var4.remove(var0);
         if (var6 == null) {
            return;
         }

         Object var7 = var5.remove(var6);
         if (var7 == null) {
            return;
         }

         Object var8 = readField(var7, "entity");
         if (var8 != null) {
            call(var8, "remove", new Class[0]);
         }
      } catch (Throwable var9) {
         debug("Aktif boss kaldırılamadı: " + var9.getClass().getSimpleName());
      }
   }

   private static List<String> cfgList(String var0) {
      try {
         Object var1 = call(plugin, "getConfig", new Class[0]);
         if (call(var1, "getStringList", new Class[]{String.class}, var0) instanceof List var3) {
            ArrayList var4 = new ArrayList();

            for (Object var6 : var3) {
               var4.add(String.valueOf(var6));
            }

            return var4;
         }
      } catch (Throwable var7) {
      }

      return new ArrayList<>();
   }

   private static boolean cfgBool(String var0, boolean var1) {
      try {
         Object var2 = call(plugin, "getConfig", new Class[0]);
         return call(var2, "getBoolean", new Class[]{String.class, boolean.class}, var0, var1) instanceof Boolean var4 ? var4 : var1;
      } catch (Throwable var5) {
         return var1;
      }
   }

   private static int cfgInt(String var0, int var1) {
      try {
         Object var2 = call(plugin, "getConfig", new Class[0]);
         return call(var2, "getInt", new Class[]{String.class, int.class}, var0, var1) instanceof Number var4 ? var4.intValue() : var1;
      } catch (Throwable var5) {
         return var1;
      }
   }

   private static String cfgString(String var0, String var1) {
      try {
         Object var2 = call(plugin, "getConfig", new Class[0]);
         Object var3 = call(var2, "getString", new Class[]{String.class, String.class}, var0, var1);
         return var3 == null ? var1 : String.valueOf(var3);
      } catch (Throwable var4) {
         return var1;
      }
   }

   private static String color(String var0) {
      if (var0 == null) {
         return "";
      }

      Matcher var1 = Pattern.compile("&#([0-9A-Fa-f]{6})").matcher(var0);
      StringBuffer var2 = new StringBuffer();

      while (var1.find()) {
         String var3 = var1.group(1);
         StringBuilder var4 = new StringBuilder("§X");

         for (char var8 : var3.toCharArray()) {
            var4.append('§').append(var8);
         }

         var1.appendReplacement(var2, Matcher.quoteReplacement(var4.toString()));
      }

      var1.appendTail(var2);
      return var2.toString().replaceAll("&([0-9A-FK-ORa-fk-or])", "§$1");
   }

   private static void send(Object var0, String var1) {
      try {
         call(var0, "sendMessage", new Class[]{String.class}, color(var1));
      } catch (Throwable var3) {
      }
   }

   private static Object call(Object var0, String var1, Class<?>[] var2, Object... var3) throws Exception {
      Method var4 = var0.getClass().getMethod(var1, var2);
      var4.setAccessible(true);
      return var4.invoke(var0, var3);
   }

   private static Object readField(Object var0, String var1) throws Exception {
      Field var2 = findField(var0.getClass(), var1);
      var2.setAccessible(true);
      return var2.get(var0);
   }

   private static long readLong(Object var0, String var1, long var2) {
      try {
         try {
            Method var4 = var0.getClass().getMethod(var1);
            if (var4.invoke(var0) instanceof Number var6) {
               return var6.longValue();
            }
         } catch (NoSuchMethodException var7) {
         }

         return readField(var0, var1) instanceof Number var10 ? var10.longValue() : var2;
      } catch (Throwable var8) {
         return var2;
      }
   }

   private static Field findField(Class<?> var0, String var1) throws NoSuchFieldException {
      for (Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         try {
            return var2.getDeclaredField(var1);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static boolean hasField(Class<?> var0, String var1) {
      try {
         findField(var0, var1);
         return true;
      } catch (Throwable var3) {
         return false;
      }
   }

   private static void log(String var0) {
      try {
         Object var1 = call(plugin, "getLogger", new Class[0]);
         call(var1, "info", new Class[]{String.class}, var0);
      } catch (Throwable var2) {
      }
   }

   private static void warn(String var0) {
      try {
         Object var1 = call(plugin, "getLogger", new Class[0]);
         call(var1, "warning", new Class[]{String.class}, var0);
      } catch (Throwable var2) {
      }
   }

   private static void debug(String var0) {
      if (cfgBool("debug", false)) {
         log("[DEBUG] " + var0);
      }
   }
}