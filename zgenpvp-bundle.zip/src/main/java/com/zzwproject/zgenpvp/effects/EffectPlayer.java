package com.zzwproject.zgenpvp.effects;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

final class EffectPlayer {
   private final ZGenPvP plugin;
   private final EffectSettings settings;

   EffectPlayer(ZGenPvP var1, EffectSettings var2) {
      this.plugin = var1;
      this.settings = var2;
   }

   void playPlacement(EffectType var1, Location var2) {
      if (this.canPlay(var1, false, var2)) {
         Location var3 = this.centered(var2);
         this.playConfiguredSound(var1, false, var3);
         int var4 = var1 == EffectType.BEACON ? 12 : 9;

         for (int var5 = 0; var5 < var4; var5++) {
            int var6 = var5;
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.placementFrame(var1, var3, var6, var4), var5 * 2L);
         }

         this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.burst(var1, false, var3.clone().add(0.0, 0.55, 0.0)), var4 * 2L);
      }
   }

   void playUpgrade(EffectType var1, Location var2, int var3) {
      if (this.canPlay(var1, true, var2)) {
         Location var4 = this.centered(var2);
         this.playConfiguredSound(var1, true, var4);
         byte var5 = 11;

         for (int var6 = 0; var6 < var5; var6++) {
            int var7 = var6;
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.upgradeFrame(var1, var4, var7, var5, var3), var6 * 2L);
         }

         this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.burst(var1, true, var4.clone().add(0.0, 0.7, 0.0)), var5 * 2L);
      }
   }

   private boolean canPlay(EffectType var1, boolean var2, Location var3) {
      return this.settings.enabled() && this.settings.enabled(var1, var2) && var3 != null && var3.getWorld() != null;
   }

   private void placementFrame(EffectType var1, Location var2, int var3, int var4) {
      if (this.settings.enabled() && this.settings.enabled(var1, false) && this.settings.particles(var1, false)) {
         double var5 = (double)var3 / Math.max(1, var4 - 1);
         double var7 = 0.25 + 0.85 * var5;
         double var9 = var1 == EffectType.BEACON ? 0.08 + 1.55 * var5 : 0.08 + 0.34 * var5;
         Particle var11 = this.settings.primary(var1, false);
         Particle var12 = this.settings.secondary(var1, false);
         int var13 = this.scaledCount(var1 == EffectType.BEACON ? 10 : 8);

         for (int var14 = 0; var14 < var13; var14++) {
            double var15 = (Math.PI * 2) * var14 / var13 + var3 * 0.42;
            Location var17 = var2.clone().add(Math.cos(var15) * var7, var9, Math.sin(var15) * var7);
            this.spawnNearby(var17, var11, 1, 0.01, 0.01, 0.01, 0.0);
         }

         if ((var3 & 1) == 0) {
            this.spawnNearby(var2.clone().add(0.0, Math.min(1.7, var9 + 0.25), 0.0), var12, this.scaledCount(3), 0.22, 0.18, 0.22, 0.01);
         }
      }
   }

   private void upgradeFrame(EffectType var1, Location var2, int var3, int var4, int var5) {
      if (this.settings.enabled() && this.settings.enabled(var1, true) && this.settings.particles(var1, true)) {
         double var6 = (double)var3 / Math.max(1, var4 - 1);
         double var8 = 0.05 + var6 * 1.55;
         double var10 = 0.72 - var6 * 0.18;
         double var12 = var3 * 0.78;
         Particle var14 = this.settings.primary(var1, true);
         Particle var15 = this.settings.secondary(var1, true);
         Location var16 = var2.clone().add(Math.cos(var12) * var10, var8, Math.sin(var12) * var10);
         Location var17 = var2.clone().add(Math.cos(var12 + Math.PI) * var10, var8, Math.sin(var12 + Math.PI) * var10);
         this.spawnNearby(var16, var14, this.scaledCount(2), 0.02, 0.02, 0.02, 0.0);
         this.spawnNearby(var17, var14, this.scaledCount(2), 0.02, 0.02, 0.02, 0.0);
         if (var3 == var4 - 1 || var3 == var4 / 2) {
            int var18 = this.scaledCount(Math.min(16, 8 + Math.max(0, var5 / 5)));
            this.ring(var2.clone().add(0.0, var8, 0.0), var15, 0.8, var18);
         }
      }
   }

   private void burst(EffectType var1, boolean var2, Location var3) {
      if (this.settings.enabled() && this.settings.enabled(var1, var2) && this.settings.particles(var1, var2)) {
         Particle var4 = this.settings.primary(var1, var2);
         Particle var5 = this.settings.secondary(var1, var2);
         this.spawnNearby(var3, var4, this.scaledCount(12), 0.42, 0.35, 0.42, 0.03);
         this.spawnNearby(var3, var5, this.scaledCount(8), 0.3, 0.28, 0.3, 0.01);
      }
   }

   private void ring(Location var1, Particle var2, double var3, int var5) {
      var5 = Math.max(4, var5);

      for (int var6 = 0; var6 < var5; var6++) {
         double var7 = (Math.PI * 2) * var6 / var5;
         Location var9 = var1.clone().add(Math.cos(var7) * var3, 0.0, Math.sin(var7) * var3);
         this.spawnNearby(var9, var2, 1, 0.0, 0.0, 0.0, 0.0);
      }
   }

   private void playConfiguredSound(EffectType var1, boolean var2, Location var3) {
      if (this.settings.sound(var1, var2)) {
         Sound var4 = this.settings.soundValue(var1, var2);

         for (Player var6 : this.nearbyPlayers(var3)) {
            var6.playSound(var3, var4, this.settings.volume(var1, var2), this.settings.pitch(var1, var2));
         }
      }
   }

   private void spawnNearby(Location var1, Particle var2, int var3, double var4, double var6, double var8, double var10) {
      for (Player var13 : this.nearbyPlayers(var1)) {
         var13.spawnParticle(var2, var1, var3, var4, var6, var8, var10);
      }
   }

   private Iterable<? extends Player> nearbyPlayers(Location var1) {
      World var2 = var1.getWorld();
      if (var2 == null) {
         return List.of();
      }

      int var3 = this.settings.viewDistance();
      double var4 = (double)var3 * var3;
      ArrayList var6 = new ArrayList();

      for (Player var8 : var2.getPlayers()) {
         Location var9 = var8.getLocation();
         if (var9.getWorld() == var2 && var9.distanceSquared(var1) <= var4) {
            var6.add(var8);
         }
      }

      return var6;
   }

   private int scaledCount(int var1) {
      return Math.max(1, (int)Math.round(var1 * this.settings.particleMultiplier()));
   }

   private Location centered(Location var1) {
      return var1.clone().add(0.5, 0.05, 0.5);
   }
}
