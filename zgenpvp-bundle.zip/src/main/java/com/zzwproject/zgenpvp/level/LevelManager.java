package com.zzwproject.zgenpvp.level;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.repository.PlayerRepository;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class LevelManager {
   private final ZGenPvP plugin;
   private final PlayerRepository playerRepository;

   public LevelManager(ZGenPvP var1, PlayerRepository var2) {
      this.plugin = var1;
      this.playerRepository = var2;
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getLevels().getBoolean("enabled", true);
   }

   public int getLevel(UUID var1) {
      return this.playerRepository.getLevel(var1);
   }

   public double getXp(UUID var1) {
      return this.playerRepository.getXp(var1);
   }

   public int getMaxLevel() {
      return Math.max(1, this.plugin.getConfigManager().getLevels().getInt("max-level", 200));
   }

   public boolean isMaxLevel(UUID var1) {
      return this.getLevel(var1) >= this.getMaxLevel();
   }

   public boolean setLevel(UUID var1, int var2) {
      if (var1 == null) {
         return false;
      }

      int var3 = Math.max(1, Math.min(this.getMaxLevel(), var2));
      return this.playerRepository.updateProgress(var1, var3, 0.0);
   }

   public int addLevels(UUID var1, int var2) {
      if (var1 != null && var2 > 0) {
         int var3 = Math.max(1, Math.min(this.getMaxLevel(), this.getLevel(var1) + var2));
         return this.playerRepository.updateProgress(var1, var3, 0.0) ? var3 : -1;
      } else {
         return -1;
      }
   }

   public double getRequiredXp(int var1) {
      if (var1 >= this.getMaxLevel()) {
         return 0.0;
      }

      FileConfiguration var2 = this.plugin.getConfigManager().getLevels();
      String var3 = "progression.required-xp-overrides." + var1;
      if (var2.contains(var3)) {
         return Math.max(1.0, var2.getDouble(var3));
      }

      double var4 = Math.max(1.0, var2.getDouble("progression.base-required-xp", 500.0));
      double var6 = Math.max(0.0, var2.getDouble("progression.increase-per-level", 150.0));
      double var8 = Math.max(0.05, var2.getDouble("progression.required-xp-multiplier", 0.7));
      return Math.max(1.0, (var4 + Math.max(0, var1 - 1) * var6) * var8);
   }

   public double getRequiredXp(UUID var1) {
      return this.getRequiredXp(this.getLevel(var1));
   }

   public LevelManager.AddXpResult addXp(UUID var1, double var2) {
      if (this.isEnabled() && var1 != null && !(var2 <= 0.0)) {
         int var4 = this.getLevel(var1);
         double var5 = this.getXp(var1);
         if (var4 >= this.getMaxLevel()) {
            return new LevelManager.AddXpResult(false, var4, var4, var5, var5, 0.0);
         }

         int var7 = var4;
         double var8 = var5 + var2;

         int var10;
         for (var10 = this.getMaxLevel(); var7 < var10; var7++) {
            double var11 = this.getRequiredXp(var7);
            if (var11 <= 0.0 || var8 < var11) {
               break;
            }

            var8 -= var11;
         }

         if (var7 >= var10) {
            var7 = var10;
            var8 = 0.0;
         }

         boolean var13 = this.playerRepository.updateProgress(var1, var7, var8);
         return !var13 ? new LevelManager.AddXpResult(false, var4, var4, var5, var5, 0.0) : new LevelManager.AddXpResult(true, var4, var7, var5, var8, var2);
      } else {
         return LevelManager.AddXpResult.failed();
      }
   }

   public double removeCurrentXpPercent(UUID var1, double var2) {
      if (var1 != null && !(var2 <= 0.0)) {
         double var4 = this.getXp(var1);
         if (var4 <= 0.0) {
            return 0.0;
         }

         double var6 = Math.min(100.0, var2);
         double var8 = var4 * (var6 / 100.0);
         var8 = this.roundDown(var8, 2);
         var8 = Math.min(var4, Math.max(0.0, var8));
         if (var8 <= 0.0) {
            return 0.0;
         }

         double var10 = Math.max(0.0, var4 - var8);
         boolean var12 = this.playerRepository.updateProgress(var1, this.getLevel(var1), var10);
         return var12 ? var8 : 0.0;
      } else {
         return 0.0;
      }
   }

   public double getXpPercentage(UUID var1) {
      int var2 = this.getLevel(var1);
      if (var2 >= this.getMaxLevel()) {
         return 100.0;
      }

      double var3 = this.getRequiredXp(var2);
      return var3 <= 0.0 ? 100.0 : Math.min(100.0, Math.max(0.0, this.getXp(var1) / var3 * 100.0));
   }

   public void syncHud(Player var1) {
      if (var1 != null && var1.isOnline()) {
         UUID var2 = var1.getUniqueId();
         int var3 = Math.max(1, Math.min(this.getMaxLevel(), this.getLevel(var2)));
         double var4 = this.getRequiredXp(var3);
         double var6 = Math.max(0.0, this.getXp(var2));
         float var8;
         if (var3 < this.getMaxLevel() && !(var4 <= 0.0)) {
            var8 = (float)Math.max(0.0, Math.min(1.0, var6 / var4));
         } else {
            var8 = 1.0F;
         }

         var1.setLevel(var3);
         var1.setExp(var8);
      }
   }

   private double roundDown(double var1, int var3) {
      double var4 = Math.pow(10.0, Math.max(0, var3));
      return Math.floor(var1 * var4 + 1.0E-7) / var4;
   }

   public record AddXpResult(boolean success, int oldLevel, int newLevel, double oldXp, double newXp, double gainedXp) {
      public static LevelManager.AddXpResult failed() {
         return new LevelManager.AddXpResult(false, 0, 0, 0.0, 0.0, 0.0);
      }

      public boolean leveledUp() {
         return this.success && this.newLevel > this.oldLevel;
      }

      public int levelsGained() {
         return Math.max(0, this.newLevel - this.oldLevel);
      }
   }
}
