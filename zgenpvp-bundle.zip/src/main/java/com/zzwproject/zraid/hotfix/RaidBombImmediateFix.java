package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;

public final class RaidBombImmediateFix {
   private RaidBombImmediateFix() {
   }

   public static boolean handle(Object var0, Object var1) {
      if (!ConfigurableRaidRules.bombStartsSession(var0)) {
         return false;
      }

      if (var0 != null && var1 != null) {
         try {
            if (!truth(call(var0, "enabled"))) {
               return false;
            }

            Object var2 = call(var1, "getPlayer");
            if (var2 == null) {
               return false;
            }

            Object var3 = field(var0, "core");
            if (var3 == null) {
               return false;
            }

            Object var4 = call(var3, "getRaidBombManager");
            if (var4 == null) {
               return false;
            }

            Object var5 = call(var1, "getItemInHand");
            if (!truth(call(var4, "isRaidBomb", var5))) {
               return false;
            }

            Object var6 = call(var1, "getBlockPlaced");
            Object var7 = var6 == null ? null : call(var6, "getLocation");
            if (var7 == null) {
               return false;
            }

            Object var8 = call(var2, "getUniqueId");
            Object var9 = tryCall(var0, "sessionByLocation", var7);
            if (var9 != null) {
               if (!truth(tryCall(var0, "isRaider", var9, var8))) {
                  setCancelled(var1, true);
                  safeMsg(var0, var2, "Bu üsse başka bir raid grubu saldırıyor.");
                  return true;
               } else {
                  clearProtection(var0, var9);
                  return false;
               }
            } else {
               Object var10 = unwrap(call(var4, "getBombType", var5));
               if (var10 == null) {
                  return false;
               }

               Object var11 = null;
               boolean var12 = false;

               try {
                  Object var13 = call(var4, "findTargetBase", var2, var7, var10);
                  var12 = true;
                  var11 = unwrap(var13);
               } catch (Throwable var18) {
               }

               if (var12 && var11 == null) {
                  return false;
               }

               if (var11 == null) {
                  var11 = nearestEnemyBase(var3, var0, var8, var7);
               }

               if (var11 == null) {
                  setCancelled(var1, true);
                  safeMsg(var0, var2, "Yakında raid yapılabilecek bir düşman üssü bulunamadı.");
                  return true;
               }

               Object var20 = call(var11, "getOwnerUuid");
               if (truth(tryCall(var0, "isDefender", var20, var8))) {
                  return false;
               }

               try {
                  Object var14 = call(var0, "getConfig");
                  call(var14, "set", "session.duration-seconds", 900L);
                  call(var14, "set", "start.manual-pickaxe-start", Boolean.FALSE);
               } catch (Throwable var17) {
               }

               if (!truth(call(var0, "canStartRaid", var11, var2))) {
                  setCancelled(var1, true);
                  return true;
               }

               return false;
            }
         } catch (Throwable var19) {
            log(var0, "Raid bombası raid başlatma köprüsü hatası", var19);
            return false;
         }
      } else {
         return false;
      }
   }

   private static Object nearestEnemyBase(Object var0, Object var1, Object var2, Object var3) throws Exception {
      Object var4 = call(var0, "getBaseRepository");
      if (call(var4, "findAll") instanceof Iterable var6) {
         String var7 = worldName(var3);
         double var8 = number(call(var3, "getX"));
         double var10 = number(call(var3, "getZ"));
         Object var12 = null;
         double var13 = Double.MAX_VALUE;

         for (Object var16 : var6) {
            if (var16 != null) {
               Object var17 = tryCall(var16, "getOwnerUuid");
               if (!truth(tryCall(var1, "isDefender", var17, var2)) && var7.equalsIgnoreCase(String.valueOf(tryCall(var16, "getWorldName")))) {
                  double var18 = number(tryCall(var16, "getX"));
                  double var20 = number(tryCall(var16, "getZ"));
                  double var22 = var8 - var18;
                  double var24 = var10 - var20;
                  double var26 = Math.sqrt(var22 * var22 + var24 * var24);
                  double var28 = Math.max(1.0, number(tryCall(var16, "getRadius")));
                  if (var26 <= var28 + 10.0 && var26 < var13) {
                     var13 = var26;
                     var12 = var16;
                  }
               }
            }
         }

         return var12;
      } else {
         return null;
      }
   }

   private static void clearProtection(Object var0, Object var1) {
      try {
         Object var2 = field(var1, "snapshot");
         Object var3 = field(var2, "base");
         Object var4 = field(var3, "id");
         call(var0, "clearCoreProtection", var4);
      } catch (Throwable var5) {
      }
   }

   private static void setCancelled(Object var0, boolean var1) {
      try {
         call(var0, "setCancelled", var1);
      } catch (Throwable var3) {
      }
   }

   private static void safeMsg(Object var0, Object var1, String var2) {
      try {
         Method var3 = findMethod(var0.getClass(), "msg", 3, var1, var2, null);
         if (var3 != null) {
            Class var4 = var3.getParameterTypes()[2];
            Enum var5 = null;
            if (var4.isEnum()) {
               Enum var6 = Enum.valueOf(var4.asSubclass(Enum.class), "RED");
               var5 = var6;
            }

            var3.invoke(var0, var1, var2, var5);
            return;
         }
      } catch (Throwable var8) {
      }

      try {
         call(var1, "sendMessage", var2);
      } catch (Throwable var7) {
      }
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
   }

   private static String worldName(Object var0) throws Exception {
      Object var1 = call(var0, "getWorld");
      return var1 == null ? "" : String.valueOf(call(var1, "getName"));
   }

   private static boolean truth(Object var0) {
      return Boolean.TRUE.equals(var0);
   }

   private static double number(Object var0) {
      return var0 instanceof Number var1 ? var1.doubleValue() : 0.0;
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         return null;
      } else {
         Method var3 = findMethod(var0.getClass(), var1, var2.length, var2);
         if (var3 == null) {
            throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
         } else {
            return var3.invoke(var0, var2);
         }
      }
   }

   private static Method findMethod(Class<?> var0, String var1, int var2, Object... var3) {
      for (Class var4 = var0; var4 != null; var4 = var4.getSuperclass()) {
         for (Method var8 : var4.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getParameterCount() == var2) {
               Class[] var9 = var8.getParameterTypes();
               boolean var10 = true;

               for (int var11 = 0; var11 < var9.length; var11++) {
                  if (!fits(var9[var11], var11 < var3.length ? var3[var11] : null)) {
                     var10 = false;
                     break;
                  }
               }

               if (var10) {
                  try {
                     var8.setAccessible(true);
                  } catch (Throwable var12) {
                  }

                  return var8;
               }
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == long.class && var1 instanceof Long
               || var0 == int.class && var1 instanceof Integer
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      if (var0 == null) {
         return null;
      }

      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);

            try {
               var3.setAccessible(true);
            } catch (Throwable var5) {
            }

            return var3.get(var0);
         } catch (NoSuchFieldException var6) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static void log(Object var0, String var1, Throwable var2) {
      try {
         Object var3 = call(var0, "getLogger");
         call(var3, "warning", var1 + ": " + var2.getClass().getSimpleName() + " - " + var2.getMessage());
      } catch (Throwable var4) {
      }
   }
}
