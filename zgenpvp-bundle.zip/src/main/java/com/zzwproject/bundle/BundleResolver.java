package com.zzwproject.bundle;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;

public final class BundleResolver {
   private static final String[] BUNDLES = new String[]{
      "ZZWEconomyBundle", "ZZWTeamBundle", "ZZWGenBundle", "ZZWMapBundle", "ZZWCommunityBundle", "ZZWDiscordBundle", "ZZWBossBundle"
   };

   private BundleResolver() {
   }

   public static Object getPlugin(Object var0, String var1) {
      if (var0 != null && var1 != null && !var1.isBlank()) {
         Object var2 = directGet(var0, var1);
         if (var2 != null) {
            return var2;
         }

         for (String var6 : BUNDLES) {
            Object var7 = directGet(var0, var6);
            Object var8 = findModule(var7, var1);
            if (var8 != null) {
               return var8;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static boolean isPluginEnabled(Object var0, String var1) {
      Object var2 = getPlugin(var0, var1);
      if (var2 == null) {
         return false;
      }

      try {
         Method var3 = var2.getClass().getMethod("isEnabled");
         Object var4 = var3.invoke(var2);
         return Boolean.TRUE.equals(var4);
      } catch (Throwable var5) {
         return true;
      }
   }

   public static void disablePlugin(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         if (isEmbeddedModule(var1)) {
            try {
               Field var8 = findField(var1.getClass(), "context");
               if (var8 != null) {
                  var8.setAccessible(true);
                  Object var9 = var8.get(var1);
                  if (var9 != null) {
                     Field var10 = findField(var9.getClass(), "enabled");
                     if (var10 != null) {
                        var10.setAccessible(true);
                        var10.setBoolean(var9, false);
                     }
                  }
               }
            } catch (Throwable var6) {
            }
         } else {
            try {
               for (Method var5 : var0.getClass().getMethods()) {
                  if (var5.getName().equals("disablePlugin") && var5.getParameterCount() == 1) {
                     var5.invoke(var0, var1);
                     return;
                  }
               }
            } catch (Throwable var7) {
            }
         }
      }
   }

   private static Object directGet(Object var0, String var1) {
      try {
         Method var2 = var0.getClass().getMethod("getPlugin", String.class);
         return var2.invoke(var0, var1);
      } catch (Throwable var5) {
         try {
            Method var3 = var0.getClass().getDeclaredMethod("getPlugin", String.class);
            var3.setAccessible(true);
            return var3.invoke(var0, var1);
         } catch (Throwable var4) {
            return null;
         }
      }
   }

   private static Object findModule(Object var0, String var1) {
      if (var0 == null) {
         return null;
      }

      try {
         Field var2 = findField(var0.getClass(), "modules");
         if (var2 == null) {
            return null;
         }

         var2.setAccessible(true);
         Object var3 = var2.get(var0);
         if (!(var3 instanceof Collection)) {
            return null;
         }

         for (Object var6 : (Collection)var3) {
            if (var6 != null) {
               Field var7 = findField(var6.getClass(), "moduleName");
               Field var8 = findField(var6.getClass(), "instance");
               Field var9 = findField(var6.getClass(), "enabled");
               if (var7 != null && var8 != null) {
                  var7.setAccessible(true);
                  var8.setAccessible(true);
                  if (var9 != null) {
                     var9.setAccessible(true);
                  }

                  if (var7.get(var6) instanceof String var11 && var11.equalsIgnoreCase(var1)) {
                     if (var9 != null && !var9.getBoolean(var6)) {
                        return null;
                     }

                     return var8.get(var6);
                  }
               }
            }
         }
      } catch (Throwable var12) {
      }

      return null;
   }

   private static boolean isEmbeddedModule(Object var0) {
      for (Class var1 = var0.getClass(); var1 != null; var1 = var1.getSuperclass()) {
         if ("com.zzwproject.bundle.LegacyPluginBase".equals(var1.getName())) {
            return true;
         }
      }

      return false;
   }

   private static Field findField(Class<?> var0, String var1) {
      for (Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         try {
            return var2.getDeclaredField(var1);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }
}
