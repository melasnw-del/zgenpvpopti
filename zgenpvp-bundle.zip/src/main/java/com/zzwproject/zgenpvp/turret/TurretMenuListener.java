package com.zzwproject.zgenpvp.turret;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.DefenseData;
import java.text.DecimalFormat;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class TurretMenuListener implements Listener {
   private final ZGenPvP plugin;
   private final TurretManager turretManager;
   private final TurretMenu turretMenu;

   public TurretMenuListener(ZGenPvP plugin, TurretManager turretManager, TurretMenu turretMenu) {
      this.plugin = plugin;
      this.turretManager = turretManager;
      this.turretMenu = turretMenu;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent event) {
      Inventory top = event.getView().getTopInventory();
      if (this.turretMenu.isMenu(top)) {
         event.setCancelled(true);
         if (event.getWhoClicked() instanceof Player player) {
            Optional<DefenseData> optional = this.turretMenu.getTurret(top);
            if (optional.isEmpty()) {
               player.closeInventory();
            } else {
               DefenseData turret = optional.get();
               if (!this.turretManager.canManageTurret(player, turret)) {
                  player.closeInventory();
                  this.turretManager.sendOwnerInfo(player, turret);
               } else {
                  int rawSlot = event.getRawSlot();
                  if (rawSlot >= top.getSize()) {
                     this.handlePlayerInventoryClick(event, player, turret, top);
                  } else if (rawSlot >= 0) {
                     String action = this.turretMenu.getAction(event.getCurrentItem());
                     if (action != null) {
                        switch (action) {
                           case "OPEN_AMMO":
                              this.turretMenu.openAmmo(player, turret);
                              break;
                           case "BACK":
                              this.turretMenu.open(player, turret);
                              break;
                           case "UPGRADE_REPAIR":
                              if (event.isRightClick()) {
                                 this.repair(player, turret);
                                 this.turretMenu.open(player, turret);
                              } else {
                                 this.turretMenu.openUpgradeConfirm(player, turret);
                              }
                              break;
                           case "CONFIRM_UPGRADE":
                              boolean upgraded = this.turretManager.upgrade(player, turret);
                              if (upgraded) {
                                 this.plugin.getSoundUtil().play(player, "turret-upgrade");
                              }

                              this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.turretMenu.open(player, turret));
                              break;
                           case "CANCEL_UPGRADE":
                              this.turretMenu.open(player, turret);
                              break;
                           case "DEPOSIT_ALL":
                              this.turretManager.depositAllArrows(player, turret);
                              this.turretMenu.openAmmo(player, turret);
                              break;
                           case "BUY_ARROWS":
                              if (event.isRightClick()) {
                                 this.turretMenu.cyclePurchaseMode(player);
                              } else {
                                 this.turretManager.buyArrows(player, turret, this.turretMenu.getPurchaseMode(player));
                              }

                              this.turretMenu.openAmmo(player, turret);
                              break;
                           case "CLOSE":
                              player.closeInventory();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void handlePlayerInventoryClick(InventoryClickEvent event, Player player, DefenseData turret, Inventory top) {
      if (this.turretMenu.isAmmoMenu(top)) {
         if (event.getClickedInventory() != null) {
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && clicked.getType() == Material.ARROW) {
               int originalAmount = clicked.getAmount();
               int accepted = this.turretManager.addArrows(turret, originalAmount);
               if (accepted <= 0) {
                  this.plugin.getMessageUtil().sendActionBar(player, "turret.ammo-full");
                  this.plugin.getSoundUtil().play(player, "error");
               } else {
                  int remaining = originalAmount - accepted;
                  Inventory clickedInventory = event.getClickedInventory();
                  int clickedSlot = event.getSlot();
                  this.plugin
                     .getServer()
                     .getScheduler()
                     .runTask(
                        this.plugin,
                        () -> {
                           if (remaining <= 0) {
                              clickedInventory.setItem(clickedSlot, null);
                           } else {
                              ItemStack remainder = clicked.clone();
                              remainder.setAmount(remaining);
                              clickedInventory.setItem(clickedSlot, remainder);
                           }

                           this.plugin
                              .getMessageUtil()
                              .sendActionBar(
                                 player,
                                 "turret.ammo-deposited",
                                 "%amount%",
                                 String.valueOf(accepted),
                                 "%arrows%",
                                 String.valueOf(turret.getStoredArrows()),
                                 "%capacity%",
                                 String.valueOf(this.turretManager.getArrowCapacity(turret.getLevel()))
                              );
                           this.plugin.getSoundUtil().play(player, "button");
                           this.turretMenu.openAmmo(player, turret);
                        }
                     );
               }
            }
         }
      }
   }

   private void repair(Player player, DefenseData turret) {
      if (player != null && turret != null) {
         if (turret.getCurrentHp() >= turret.getMaxHp()) {
            this.plugin.getMessageUtil().sendActionBar(player, "turret.repair-not-needed");
         } else {
            double price = this.turretMenu.getRepairPrice(turret);
            if (price <= 0.0) {
               this.plugin.getMessageUtil().sendActionBar(player, "turret.repair-not-needed");
            } else if (!this.plugin.getEconomyManager().has(player, price)) {
               this.plugin.getMessageUtil().sendActionBar(player, "turret.repair-not-enough-money", "%price%", this.format(price));
               this.plugin.getSoundUtil().play(player, "error");
            } else if (!this.plugin.getEconomyManager().withdraw(player, price)) {
               this.plugin.getMessageUtil().sendActionBar(player, "general.economy-error");
               this.plugin.getSoundUtil().play(player, "error");
            } else if (!this.plugin.getDefenseRepository().updateHealth(turret.getId(), turret.getMaxHp())) {
               this.plugin.getEconomyManager().deposit(player, price);
               this.plugin.getMessageUtil().sendActionBar(player, "turret.repair-error");
               this.plugin.getSoundUtil().play(player, "error");
            } else {
               turret.setCurrentHp(turret.getMaxHp());
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(
                     player,
                     "turret.repaired",
                     "%price%",
                     this.format(price),
                     "%health%",
                     String.valueOf(turret.getCurrentHp()),
                     "%max_health%",
                     String.valueOf(turret.getMaxHp())
                  );
               this.plugin.getSoundUtil().play(player, "turret-upgrade");
            }
         }
      }
   }

   private String format(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent event) {
      Inventory top = event.getView().getTopInventory();
      if (this.turretMenu.isMenu(top)) {
         for (int rawSlot : event.getRawSlots()) {
            if (rawSlot >= 0 && rawSlot < top.getSize()) {
               event.setCancelled(true);
               return;
            }
         }
      }
   }
}
