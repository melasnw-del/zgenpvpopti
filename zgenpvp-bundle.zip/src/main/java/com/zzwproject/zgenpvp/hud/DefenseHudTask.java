package com.zzwproject.zgenpvp.hud;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public final class DefenseHudTask {
   private final ZGenPvP plugin;
   private final List<Player> sweep = new ArrayList<>();
   private int cursor;
   private BukkitTask task;
   private long nextRefreshAt;

   public DefenseHudTask(ZGenPvP var1) {
      this.plugin = var1;
   }

   public void start() {
      this.stop();
      long var1 = Math.max(1L, Math.min(10L, this.plugin.getConfigManager().getConfig().getLong("defense-hud.tick-interval-ticks", 2L)));
      this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tick, 10L, var1);
   }

   public void stop() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.sweep.clear();
      this.cursor = 0;
   }

   private void tick() {
      if (this.plugin.getConfigManager().getConfig().getBoolean("defense-hud.enabled", true)) {
         long var1 = System.currentTimeMillis();
         if (this.cursor >= this.sweep.size()) {
            if (var1 < this.nextRefreshAt) {
               return;
            }

            this.sweep.clear();
            this.sweep.addAll(Bukkit.getOnlinePlayers());
            this.cursor = 0;
            long var3 = Math.max(350L, this.plugin.getConfigManager().getConfig().getLong("defense-hud.refresh-milliseconds", 400L));
            this.nextRefreshAt = var1 + var3;
         }

         int var6 = Math.max(4, Math.min(32, this.plugin.getConfigManager().getConfig().getInt("defense-hud.players-per-tick", 24)));
         int var4 = 0;

         while (this.cursor < this.sweep.size() && var4++ < var6) {
            Player var5 = this.sweep.get(this.cursor++);
            if (var5 != null && var5.isOnline()) {
               this.showFor(var5);
            }
         }
      }
   }

   private void showFor(Player var1) {
      int var2 = Math.max(3, Math.min(12, this.plugin.getConfigManager().getConfig().getInt("defense-hud.max-distance", 7)));
      Block var3 = var1.getTargetBlockExact(var2);
      if (var3 != null) {
         Optional var4 = this.plugin.getDefenseManager().getDefense(var3.getLocation());
         if (var4.isPresent()) {
            this.showDefense(var1, "defense-hud.defense", (DefenseData)var4.get());
         } else {
            Optional var5 = this.plugin.getTurretManager().getTurret(var3.getLocation());
            if (var5.isPresent()) {
               this.showDefense(var1, "defense-hud.turret", (DefenseData)var5.get());
            } else {
               Optional var6 = this.plugin.getDefenseAccessManager().get(var3);
               if (var6.isPresent()) {
                  String var9 = ((DefenseData)var6.get()).getType() == null ? "" : ((DefenseData)var6.get()).getType().toUpperCase();
                  this.showDefense(var1, var9.contains("TRAP") ? "defense-hud.trapdoor" : "defense-hud.door", (DefenseData)var6.get());
               } else {
                  Optional var7 = this.plugin.getBaseManager().getBase(var3.getLocation());
                  if (var7.isPresent()) {
                     BaseData var8 = (BaseData)var7.get();
                     this.plugin
                        .getMessageUtil()
                        .sendActionBar(
                           var1,
                           "defense-hud.base",
                           "%level%",
                           String.valueOf(var8.getLevel()),
                           "%health%",
                           String.valueOf(var8.getCurrentHp()),
                           "%max_health%",
                           String.valueOf(var8.getMaxHp()),
                           "%name%",
                           var8.getName() == null ? "Base" : var8.getName()
                        );
                  }
               }
            }
         }
      }
   }

   private void showDefense(Player var1, String var2, DefenseData var3) {
      this.plugin
         .getMessageUtil()
         .sendActionBar(
            var1,
            var2,
            "%level%",
            String.valueOf(var3.getLevel()),
            "%health%",
            String.valueOf(var3.getCurrentHp()),
            "%max_health%",
            String.valueOf(var3.getMaxHp())
         );
   }
}
