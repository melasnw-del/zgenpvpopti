package com.zzwproject.zgenboss.hotfix;

public final class BossMessageFix {
   private static final String PREFIX = "&6ᴊᴇɴᴇʀᴀᴛöʀ ʙᴏꜱꜱ &8» &r";

   private BossMessageFix() {
   }

   public static String applyPrefix(String var0) {
      return replaceIgnoreCase(var0, "%prefix%", "&6ᴊᴇɴᴇʀᴀᴛöʀ ʙᴏꜱꜱ &8» &r");
   }

   public static String replaceIgnoreCase(String var0, CharSequence var1, CharSequence var2) {
      if (var0 != null && var1 != null) {
         String var3 = var1.toString();
         if (var3.isEmpty()) {
            return var0;
         }

         String var4 = var2 == null ? "" : var2.toString();
         int var5 = var0.length();
         int var6 = var3.length();
         int var7 = 0;
         StringBuilder var8 = null;
         int var9 = 0;

         while (var9 <= var5 - var6) {
            if (var0.regionMatches(true, var9, var3, 0, var6)) {
               if (var8 == null) {
                  var8 = new StringBuilder(var5 + 16);
               }

               var8.append(var0, var7, var9).append(var4);
               var9 += var6;
               var7 = var9;
            } else {
               var9++;
            }
         }

         if (var8 == null) {
            return var0;
         }

         var8.append(var0, var7, var5);
         return var8.toString();
      } else {
         return var0;
      }
   }
}
