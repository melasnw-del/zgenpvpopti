package com.zzwproject.zmenu.gui;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public final class MenuHolder implements InventoryHolder {
   private final String menuId;
   private final int page;
   private final Map<Integer, MenuAction> actions = new HashMap<>();

   public MenuHolder(String var1) {
      this(var1, 0);
   }

   public MenuHolder(String var1, int var2) {
      this.menuId = var1 == null ? "unknown" : var1;
      this.page = Math.max(0, var2);
   }

   public String menuId() {
      return this.menuId;
   }

   public int page() {
      return this.page;
   }

   public void action(int var1, MenuAction var2) {
      if (var1 >= 0 && var2 != null) {
         this.actions.put(var1, var2);
      }
   }

   public MenuAction action(int var1) {
      return this.actions.get(var1);
   }

   @NotNull
   public Inventory getInventory() {
      throw new UnsupportedOperationException("inventory is created by bukkit");
   }
}
