package com.zzwproject.bundle;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginDescriptionFile;

final class ModuleContext {
   final BundlePlugin owner;
   final String moduleName;
   final String mainClass;
   final PluginDescriptionFile description;
   final String resourceRoot;
   final Map<String, PluginCommand> commands = new HashMap<>();
   LegacyPluginBase instance;
   boolean enabled;
   boolean naggable = true;
   Object config;
   final Logger logger;

   ModuleContext(BundlePlugin var1, String var2, String var3, PluginDescriptionFile var4, String var5) {
      this.owner = var1;
      this.moduleName = var2;
      this.mainClass = var3;
      this.description = var4;
      this.resourceRoot = var5;
      this.logger = Logger.getLogger("Minecraft." + var2);
   }
}
