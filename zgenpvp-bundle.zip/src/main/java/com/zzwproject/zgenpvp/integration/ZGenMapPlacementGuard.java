package com.zzwproject.zgenpvp.integration;

import com.zzwproject.bundle.BundleResolver;
import java.lang.reflect.Method;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class ZGenMapPlacementGuard {
   private ZGenMapPlacementGuard() {
   }

   public static boolean isSpawnProtected(Location var0) {
      if (var0 != null && var0.getWorld() != null) {
         Plugin var1 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenMap");
         if (var1 == null) {
            return false;
         }

         if (!isManagedWorld(var1, var0.getWorld())) {
            return false;
         }

         Boolean var2 = queryGenerator(var1, var0);
         return var2 != null ? var2 : isSpawnProtectedByConfig(var1, var0);
      } else {
         return false;
      }
   }

   public static boolean canAdminBypass(Player var0) {
      return var0 != null && (var0.hasPermission("zgenmap.spawn.admin") || var0.hasPermission("zgenmap.admin") || var0.hasPermission("zgenpvp.admin"));
   }

   public static boolean canAdminBuildInSpawn(Player var0, Location var1) {
      return canAdminBypass(var0) && isSpawnProtected(var1);
   }

   public static boolean canAdminBreakInSpawn(Player var0, Block var1) {
      return var1 != null && canAdminBuildInSpawn(var0, var1.getLocation());
   }

   public static Object putLoaded(Map<Object, Object> var0, Object var1, Object var2) {
      return var0 != null && var2 != null ? var0.put(var1, var2) : null;
   }

   private static boolean isManagedWorld(Plugin var0, World var1) {
      try {
         Method var2 = var0.getClass().getMethod("getApi");
         Object var3 = var2.invoke(var0);
         if (var3 != null) {
            Method var4 = var3.getClass().getMethod("isManagedWorld", World.class);
            if (Boolean.TRUE.equals(var4.invoke(var3, var1))) {
               return true;
            }
         }
      } catch (Throwable var8) {
      }

      String var9 = "genpvp_city";

      try {
         Object var10 = var0.getClass().getMethod("getConfig").invoke(var0);
         if (var10 != null) {
            Method var11 = var10.getClass().getMethod("getString", String.class, String.class);
            if (var11.invoke(var10, "world.name", var9) instanceof String var6 && !var6.isBlank()) {
               var9 = var6;
            }
         }
      } catch (Throwable var7) {
      }

      return var1.getName().equalsIgnoreCase(var9);
   }

   private static Boolean queryGenerator(Plugin var0, Location var1) {
      try {
         Method var2 = var0.getClass().getMethod("getWorldManager");
         Object var3 = var2.invoke(var0);
         if (var3 == null) {
            return null;
         }

         Method var4 = var3.getClass().getMethod("getGenerator");
         Object var5 = var4.invoke(var3);
         if (var5 == null) {
            return null;
         }

         Method var6 = var5.getClass().getMethod("isSpawnBuildProtected", Location.class);
         return Boolean.TRUE.equals(var6.invoke(var5, var1));
      } catch (Throwable var7) {
         return null;
      }
   }

   private static boolean isSpawnProtectedByConfig(Plugin var0, Location var1) {
      int var2 = 44;

      try {
         Object var3 = var0.getClass().getMethod("getConfig").invoke(var0);
         if (var3 != null) {
            Method var4 = var3.getClass().getMethod("getInt", String.class, int.class);
            if (var4.invoke(var3, "spawn.build-protection-radius", var2) instanceof Integer var6) {
               var2 = Math.max(0, var6);
            }
         }
      } catch (Throwable var9) {
      }

      boolean var10 = true;

      try {
         Object var11 = var0.getClass().getMethod("getConfig").invoke(var0);
         if (var11 != null) {
            Method var13 = var11.getClass().getMethod("getBoolean", String.class, boolean.class);
            var10 = Boolean.TRUE.equals(var13.invoke(var11, "spawn.square-layout", true));
         }
      } catch (Throwable var8) {
      }

      long var12 = var1.getBlockX();
      long var14 = var1.getBlockZ();
      return var10 ? Math.max(Math.abs(var12), Math.abs(var14)) <= var2 : var12 * var12 + var14 * var14 <= (long)var2 * var2;
   }
}
