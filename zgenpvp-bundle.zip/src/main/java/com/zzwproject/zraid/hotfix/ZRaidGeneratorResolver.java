package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class ZRaidGeneratorResolver {
   private ZRaidGeneratorResolver() {
   }

   public static List<com.zzwproject.zgenpvp.model.GeneratorData> findAllByBase(Object var0, long var1) {
      LinkedHashMap var3 = new LinkedHashMap();
      if (var0 == null) {
         return new ArrayList(var3.values());
      }

      try {
         Object var4 = call(var0, "findAllByBase", new Class[]{long.class}, var1);
         if (var4 instanceof Iterable) {
            for (Object var7 : (Iterable)var4) {
               put(var3, var7);
            }
         }
      } catch (Throwable var29) {
      }

      try {
         Object var30 = getPlugin("ZGenPvP");
         if (var30 == null) {
            return new ArrayList(var3.values());
         }

         Object var31 = call0(var30, "getBaseRepository");
         Object var32 = call0(var31, "findAll");
         Object var33 = null;
         if (var32 instanceof Iterable) {
            for (Object var10 : (Iterable)var32) {
               if (lng(call0(var10, "getId"), -1L) == var1) {
                  var33 = var10;
                  break;
               }
            }
         }

         if (var33 == null) {
            return new ArrayList(var3.values());
         }

         Object var34 = call0(var33, "getOwnerUuid");
         String var35 = String.valueOf(call0(var33, "getWorldName"));
         int var36 = num(call0(var33, "getX"), 0);
         int var11 = num(call0(var33, "getZ"), 0);
         int var12 = Math.max(1, num(call0(var33, "getRadius"), 9));
         Object var13 = call0(var0, "findAll");
         if (var13 instanceof Iterable) {
            for (Object var16 : (Iterable)var13) {
               if (var16 != null) {
                  long var17 = lng(call0(var16, "getBaseId"), -1L);
                  Object var19 = call0(var16, "getOwnerUuid");
                  String var20 = String.valueOf(call0(var16, "getWorldName"));
                  int var21 = num(call0(var16, "getX"), Integer.MAX_VALUE);
                  int var22 = num(call0(var16, "getZ"), Integer.MAX_VALUE);
                  boolean var23 = var17 == var1;
                  boolean var24 = Objects.equals(var34, var19);
                  boolean var25 = var35.equalsIgnoreCase(var20);
                  boolean var26 = Math.abs(var21 - var36) <= var12 && Math.abs(var22 - var11) <= var12;
                  boolean var27 = var17 <= 0L;
                  if (var23 || var24 && var25 && (var27 || var26)) {
                     put(var3, var16);
                  }
               }
            }
         }
      } catch (Throwable var28) {
      }

      return new ArrayList(var3.values());
   }

   private static Object getPlugin(String var0) throws Exception {
      Class var1 = Class.forName("org.bukkit.Bukkit");
      Object var2 = var1.getMethod("getPluginManager").invoke(null);
      return var2.getClass().getMethod("getPlugin", String.class).invoke(var2, var0);
   }

   private static void put(Map<Long, Object> var0, Object var1) {
      if (var1 != null) {
         try {
            long var2 = lng(call0(var1, "getId"), System.identityHashCode(var1));
            var0.put(var2, var1);
         } catch (Throwable var4) {
         }
      }
   }

   private static Object call0(Object var0, String var1) throws Exception {
      Method var2 = var0.getClass().getMethod(var1);
      return var2.invoke(var0);
   }

   private static Object call(Object var0, String var1, Class<?>[] var2, Object... var3) throws Exception {
      Method var4 = var0.getClass().getMethod(var1, var2);
      return var4.invoke(var0, var3);
   }

   private static long lng(Object var0, long var1) {
      return var0 instanceof Number var3 ? var3.longValue() : var1;
   }

   private static int num(Object var0, int var1) {
      return var0 instanceof Number var2 ? var2.intValue() : var1;
   }
}
