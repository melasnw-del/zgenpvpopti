package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public final class RaidSimpleRules {
   private RaidSimpleRules() {
   }

   public static boolean handleGeneratorBreak(Object var0, Object var1) {
      if (ConfigurableRaidRules.blockGeneratorBeforeOwner(var0, var1)) {
         return true;
      }

      if (var0 != null && var1 != null) {
         try {
            if (!truth(call(var0, "enabled"))) {
               return false;
            }

            Object var2 = call(var1, "getPlayer");
            Object var3 = call(var1, "getBlock");
            if (var2 != null && var3 != null) {
               Object var4 = call(var3, "getLocation");
               Object var5 = field(var0, "core");
               Object var6 = call(var5, "getGeneratorManager");
               Object var7 = unwrap(call(var6, "getGenerator", var4));
               if (var7 == null) {
                  return false;
               }

               Object var8 = call(var2, "getUniqueId");
               long var9 = num(call(var7, "getId"));
               Object var11 = tryCall(var0, "sessionByGeneratorId", var9);
               if (var11 == null) {
                  var11 = tryCall(var0, "sessionByLocation", var4);
               }

               if (var11 == null) {
                  var11 = tryCall(var0, "sessionForParticipant", var8);
               }

               if (var11 == null) {
                  return false;
               }

               Object var12 = field(var11, "snapshot");
               Object var13 = field(var12, "owner");
               Object var14 = call(var7, "getOwnerUuid");
               long var15 = num(call(var7, "getBaseId"));
               long var17 = num(field(field(var12, "base"), "id"));
               boolean var19 = var15 == var17 || truth(tryCall(var0, "isDefender", var13, var14));
               if (!var19) {
                  return false;
               }

               if (truth(tryCall(var0, "isDefender", var13, var8))) {
                  cancel(var1);
                  stopMining(var2);
                  message(var0, var2, "&cRaid sırasında kendi jeneratörünü sökemezsin.");
                  return true;
               }

               if (!truth(tryCall(var0, "isRaider", var11, var8))) {
                  cancel(var1);
                  stopMining(var2);
                  message(var0, var2, "&cBu raide dahil değilsin.");
                  return true;
               }

               cancel(var1);
               tryCall(var1, "setDropItems", Boolean.FALSE);
               tryCall(var1, "setExpToDrop", 0);
               boolean var20 = truth(call(var0, "deleteGeneratorForRaid", var7));
               if (!var20) {
                  message(var0, var2, "&cJeneratör yok edilemedi. Tekrar dene.");
                  return true;
               }

               if (field(var11, "destroyedGenerators") instanceof Set var22) {
                  Set var23 = var22;
                  var23.add(var9);
               }

               int var25 = remainingGenerators(var0, var11);
               announce(var0, var11, "&eJeneratör yok edildi. &7Kalan: &f" + var25);
               if (var25 <= 0) {
                  RaidObjectiveFix.afterGenerator(var0, var11, var2);
               }

               return true;
            } else {
               return false;
            }
         } catch (Throwable var24) {
            log(var0, "Basitleştirilmiş raid jeneratör kuralı hatası", var24);
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean handleBeaconDamage(Object var0, Object var1) {
      return beaconRule(var0, var1, false);
   }

   public static boolean handleBeaconBreak(Object var0, Object var1) {
      return beaconRule(var0, var1, true);
   }

   private static boolean beaconRule(Object var0, Object var1, boolean var2) {
      if (var0 != null && var1 != null) {
         try {
            if (!truth(call(var0, "enabled"))) {
               return false;
            }

            Object var3 = call(var1, "getPlayer");
            Object var4 = call(var1, "getBlock");
            if (var3 != null && var4 != null) {
               Object var5 = call(var4, "getLocation");
               Object var6 = field(var0, "core");
               Object var7 = call(var6, "getBeaconManager");
               Object var8 = unwrap(call(var7, "getBeacon", var5));
               if (var8 == null) {
                  return false;
               }

               long var9 = num(call(var8, "getId"));
               Object var11 = call(var3, "getUniqueId");
               Object var12 = tryCall(var0, "sessionByBeaconId", var9);
               if (var12 == null) {
                  var12 = tryCall(var0, "sessionByLocation", var5);
               }

               if (var12 == null) {
                  var12 = tryCall(var0, "sessionForParticipant", var11);
               }

               if (var12 == null) {
                  return false;
               } else {
                  Object var13 = field(var12, "snapshot");
                  Object var14 = field(var13, "owner");
                  Object var15 = call(var8, "getOwnerUuid");
                  if (!truth(tryCall(var0, "isDefender", var14, var15))) {
                     return false;
                  } else if (truth(tryCall(var0, "isDefender", var14, var11))) {
                     cancel(var1);
                     stopMining(var3);
                     message(var0, var3, "&cRaid sırasında kendi fenerini sökemezsin.");
                     return true;
                  } else if (!truth(tryCall(var0, "isRaider", var12, var11))) {
                     cancel(var1);
                     stopMining(var3);
                     message(var0, var3, "&cBu raide dahil değilsin.");
                     return true;
                  } else {
                     tryCall(var1, "setCancelled", Boolean.FALSE);
                     return false;
                  }
               }
            } else {
               return false;
            }
         } catch (Throwable var16) {
            log(var0, "Basitleştirilmiş raid fener kuralı hatası", var16);
            return false;
         }
      } else {
         return false;
      }
   }

   public static void success(Object var0, Object var1, Object var2) {
      if (var0 != null && var1 != null) {
         try {
            if (!removeSession(var0, var1)) {
               return;
            }

            tryCall(var0, "stopAllMining", var1);
            removeBossbar(var1);
            Object var3 = field(var1, "snapshot");
            long var4 = num(field(field(var3, "base"), "id"));
            tryCall(var0, "deleteRecovery", var4);
            Object var6 = field(var1, "initiator");
            Object var7 = field(var3, "owner");
            Object var8 = onlinePlayer(var6);
            Object var9 = onlinePlayer(var7);
            if (var8 != null) {
               title(var0, var8, "&aRAID BAŞARILI!", "&7Rakibin jeneratörleri yok edildi.");
            }

            if (var9 != null) {
               title(var0, var9, "&cRAID KAYBEDİLDİ!", "&7Jeneratörlerin yok edildi.");
            }

            String var10 = nameOf(var0, var6);
            String var11 = nameOf(var0, var7);
            tryCall(var0, "broadcastOptional", "&8[&cRaid&8] &f" + var10 + " &7→ &f" + var11 + " &7raidini başarıyla tamamladı.");
            tryCall(var0, "creditBountyRaidWin", var6, var7);
         } catch (Throwable var12) {
            log(var0, "Raid başarı temizliği hatası", var12);
         }
      }
   }

   public static void fail(Object var0, Object var1, String var2) {
      if (var0 != null && var1 != null) {
         try {
            if (!removeSession(var0, var1)) {
               return;
            }

            tryCall(var0, "stopAllMining", var1);
            removeBossbar(var1);
            Object var3 = field(var1, "snapshot");
            long var4 = num(field(field(var3, "base"), "id"));
            tryCall(var0, "deleteRecovery", var4);

            String var6 = switch (String.valueOf(var2)) {
               case "owner-offline" -> "Üs sahibi çevrim dışı kaldı";
               case "raider-offline" -> "Raid grubu çevrim dışı kaldı";
               case "restart" -> "Sunucu yeniden başlatıldı";
               case "admin" -> "Yönetici tarafından durduruldu";
               default -> "Süre doldu";
            };

            for (Object var12 : onlinePlayers()) {
               Object var9 = tryCall(var12, "getUniqueId");
               if (truth(tryCall(var0, "isRaider", var1, var9))) {
                  title(var0, var12, "&cRAID BAŞARISIZ!", "&7" + var6 + ".");
               } else if (truth(tryCall(var0, "isDefender", field(var3, "owner"), var9))) {
                  title(var0, var12, "&aRAID SAVUNULDU!", "&7Raid sona erdi.");
               }
            }
         } catch (Throwable var10) {
            log(var0, "Raid başarısızlık temizliği hatası", var10);
         }
      }
   }

   public static void updateBossBar(Object var0, Object var1, long var2, int var4) {
      try {
         Object var5 = field(var1, "bossBar");
         Object var21 = field(var1, "defenderBossBar");
         if (var5 == null && var21 == null) {
            return;
         }

         long var6 = num(field(var1, "startedAt"));
         long var8 = num(field(var1, "endsAt"));
         long var10 = Math.max(1L, var8 - var6);
         long var12 = Math.max(0L, var8 - var2);
         double var22 = Math.max(0.0, Math.min(1.0, (double)var12 / var10));
         Object var14 = field(var1, "snapshot");
         String var15 = nameOf(var0, field(var14, "owner"));
         String var23 = nameOf(var0, field(var1, "initiator"));
         int var16 = remainingGenerators(var0, var1);
         String var17 = String.valueOf(tryCall(var0, "formatTime", var12));
         if (var5 != null) {
            tryCall(var5, "setProgress", var22);
            String var18 = "&a⚔ RAID BAŞLATILDI &8• &f" + var15 + " &8• &7Süre: &f" + var17 + " &8• &7Jeneratör: &f" + var16;
            tryCall(var5, "setTitle", String.valueOf(tryCall(var0, "color", var18)));
         }

         if (var21 != null) {
            tryCall(var21, "setProgress", var22);
            String var24 = "&c⚠ RAID YİYORSUN &8• &f" + var23 + " &8• &7Kalan Süre: &f" + var17;
            tryCall(var21, "setTitle", String.valueOf(tryCall(var0, "color", var24)));
         }
      } catch (Throwable var20) {
      }
   }

   public static void announce(Object var0, Object var1, String var2) {
      if (var2 != null && !var2.isBlank()) {
         String var3 = var2.replace('İ', 'I').replace('ı', 'i').toUpperCase(Locale.ROOT);
         if (!var3.contains("HEDEFLER") && !var3.contains("FINAL HEDEF") && !var3.contains("HEDEF OYUNCU")) {
            try {
               String var4 = String.valueOf(tryCall(var0, "color", var2));
               Object var5 = field(var1, "snapshot");
               Object var6 = field(var5, "owner");

               for (Object var8 : onlinePlayers()) {
                  Object var9 = tryCall(var8, "getUniqueId");
                  if (truth(tryCall(var0, "isRaider", var1, var9)) || truth(tryCall(var0, "isDefender", var6, var9))) {
                     tryCall(var8, "sendMessage", var4);
                  }
               }
            } catch (Throwable var10) {
            }
         }
      }
   }

   public static int remainingGenerators(Object var0, Object var1) {
      try {
         Object var2 = field(var1, "snapshot");
         Object var3 = field(var2, "base");
         long var4 = num(field(var3, "id"));
         Object var6 = field(var2, "owner");
         String var7 = String.valueOf(field(var3, "world"));
         int var8 = integer(field(var3, "x"));
         int var9 = integer(field(var3, "z"));
         int var10 = Math.max(1, integer(field(var3, "radius")));
         Object var11 = field(var0, "core");
         Object var12 = call(var11, "getGeneratorRepository");
         Object var50;
         try {
            var50 = call(call(var11, "getGeneratorManager"), "getCachedGenerators");
         } catch (Throwable var51) {
            var50 = call(var12, "findAll");
         }

         if (!(var50 instanceof Iterable var14)) {
            return 0;
         } else {
            int var15 = 0;

            for (Object var17 : var14) {
               if (var17 != null) {
                  long var18 = num(tryCall(var17, "getBaseId"));
                  Object var20 = tryCall(var17, "getOwnerUuid");
                  String var21 = String.valueOf(tryCall(var17, "getWorldName"));
                  int var22 = integer(tryCall(var17, "getX"));
                  int var23 = integer(tryCall(var17, "getZ"));
                  boolean var24 = var7.equalsIgnoreCase(var21) && Math.abs(var22 - var8) <= var10 && Math.abs(var23 - var9) <= var10;
                  boolean var25 = truth(tryCall(var0, "isDefender", var6, var20));
                  if (var18 == var4 || var25 && var24) {
                     var15++;
                  }
               }
            }

            return var15;
         }
      } catch (Throwable var26) {
         return Integer.MAX_VALUE;
      }
   }

   private static boolean removeSession(Object var0, Object var1) throws Exception {
      Object var2 = field(var1, "snapshot");
      long var3 = num(field(field(var2, "base"), "id"));
      if (field(var0, "sessions") instanceof Map var6) {
         Object var7 = var6.get(var3);
         if (var7 != var1) {
            return false;
         }

         Map var8 = var6;
         var8.remove(var3);
         return true;
      } else {
         return true;
      }
   }

   private static void removeBossbar(Object var0) {
      try {
         Object var1 = field(var0, "bossBar");
         if (var1 != null) {
            tryCall(var1, "removeAll");
         }

         Object var3 = field(var0, "defenderBossBar");
         if (var3 != null) {
            tryCall(var3, "removeAll");
         }
      } catch (Throwable var2) {
      }
   }

   private static void cancel(Object var0) {
      tryCall(var0, "setCancelled", Boolean.TRUE);
      tryCall(var0, "setDropItems", Boolean.FALSE);
      tryCall(var0, "setExpToDrop", 0);
   }

   private static void stopMining(Object var0) {
      try {
         ClassLoader var1 = var0.getClass().getClassLoader();
         Class var2 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var1);
         callStatic(var2, "stopMining", var0);
      } catch (Throwable var3) {
      }
   }

   private static void message(Object var0, Object var1, String var2) {
      try {
         tryCall(var1, "sendMessage", String.valueOf(tryCall(var0, "color", var2)));
      } catch (Throwable var4) {
      }
   }

   private static void title(Object var0, Object var1, String var2, String var3) {
      try {
         String var4 = String.valueOf(tryCall(var0, "color", var2));
         String var5 = String.valueOf(tryCall(var0, "color", var3));
         call(var1, "sendTitle", var4, var5, 10, 70, 20);
      } catch (Throwable var6) {
      }
   }

   private static String nameOf(Object var0, Object var1) {
      Object var2 = tryCall(var0, "nameOf", var1);
      return var2 == null ? "Bilinmeyen" : String.valueOf(var2);
   }

   private static Object onlinePlayer(Object var0) {
      try {
         return callStatic(Class.forName("org.bukkit.Bukkit"), "getPlayer", var0);
      } catch (Throwable var2) {
         return null;
      }
   }

   private static Collection<?> onlinePlayers() {
      try {
         if (callStatic(Class.forName("org.bukkit.Bukkit"), "getOnlinePlayers") instanceof Collection var1) {
            return var1;
         }
      } catch (Throwable var2) {
      }

      return List.of();
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
   }

   private static boolean truth(Object var0) {
      return Boolean.TRUE.equals(var0);
   }

   private static long num(Object var0) {
      return var0 instanceof Number var1 ? var1.longValue() : 0L;
   }

   private static int integer(Object var0) {
      return var0 instanceof Number var1 ? var1.intValue() : 0;
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      } else {
         Method var3 = findMethod(var0.getClass(), var1, var2);
         if (var3 == null) {
            throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
         } else {
            return var3.invoke(var0, var2);
         }
      }
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = findMethod(var0, var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getName() + "." + var1);
      } else {
         return var3.invoke(null, var2);
      }
   }

   private static Method findMethod(Class<?> var0, String var1, Object... var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
               Class[] var8 = var7.getParameterTypes();
               boolean var9 = true;

               for (int var10 = 0; var10 < var8.length; var10++) {
                  if (!fits(var8[var10], var2[var10])) {
                     var9 = false;
                     break;
                  }
               }

               if (var9) {
                  try {
                     var7.setAccessible(true);
                  } catch (Throwable var11) {
                  }

                  return var7;
               }
            }
         }
      }

      for (Method var15 : var0.getMethods()) {
         if (var15.getName().equals(var1) && var15.getParameterCount() == var2.length) {
            Class[] var16 = var15.getParameterTypes();
            boolean var17 = true;

            for (int var18 = 0; var18 < var16.length; var18++) {
               if (!fits(var16[var18], var2[var18])) {
                  var17 = false;
                  break;
               }
            }

            if (var17) {
               return var15;
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == int.class && var1 instanceof Integer
               || var0 == long.class && var1 instanceof Long
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);

            try {
               var3.setAccessible(true);
            } catch (Throwable var5) {
            }

            return var3.get(var0);
         } catch (NoSuchFieldException var6) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static void log(Object var0, String var1, Throwable var2) {
      try {
         Object var3 = call(var0, "getLogger");
         call(var3, "warning", var1 + ": " + var2.getClass().getSimpleName() + " - " + var2.getMessage());
      } catch (Throwable var4) {
      }
   }
}
