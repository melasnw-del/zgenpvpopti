package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import com.zzwproject.zgenpvp.model.BaseData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.bukkit.Location;

public final class BaseRepository {
   private final DatabaseManager databaseManager;
   private final ConcurrentMap<Long, BaseData> byId = new ConcurrentHashMap<>();
   private final ConcurrentMap<UUID, BaseData> byOwner = new ConcurrentHashMap<>();
   private final ConcurrentMap<String, BaseData> byLocation = new ConcurrentHashMap<>();

   public BaseRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public Optional<BaseData> findById(long var1) {
      BaseData var3 = this.byId.get(var1);
      if (var3 != null) {
         return Optional.of(var3);
      }

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement("SELECT * FROM bases WHERE id = ? LIMIT 1;")) {
         var4.setLong(1, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            if (var5.next()) {
               return Optional.of(this.canonicalize(this.read(var5)));
            }
         }
      } catch (SQLException var6) {
         var6.printStackTrace();
      }

      return Optional.empty();
   }

   public Optional<BaseData> findByOwner(UUID var1) {
      if (var1 == null) {
         return Optional.empty();
      }

      BaseData var2 = this.byOwner.get(var1);
      if (var2 != null) {
         return Optional.of(var2);
      }

      String var3 = "SELECT * FROM bases WHERE owner_uuid = ? LIMIT 1;";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setString(1, var1.toString());

         try (ResultSet var5 = var4.executeQuery()) {
            if (var5.next()) {
               return Optional.of(this.canonicalize(this.read(var5)));
            }
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
      }

      return Optional.empty();
   }

   public Optional<BaseData> findContaining(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         String var2 = var1.getWorld().getName();
         int var3 = var1.getBlockX();
         int var4 = var1.getBlockZ();

         for (BaseData var6 : this.byId.values()) {
            if (var2.equals(var6.getWorldName())) {
               double var7 = var3 - var6.getX();
               double var9 = var4 - var6.getZ();
               double var11 = var6.getRadius();
               if (var7 * var7 + var9 * var9 <= var11 * var11) {
                  return Optional.of(var6);
               }
            }
         }

         String var18 = "SELECT *\nFROM bases\nWHERE world = ?\n  AND ((? - x) * (? - x) + (? - z) * (? - z))\n      <= (radius * radius)\nORDER BY id ASC\nLIMIT 1;\n";

         try (PreparedStatement var19 = this.databaseManager.getConnection().prepareStatement(var18)) {
            var19.setString(1, var2);
            var19.setInt(2, var3);
            var19.setInt(3, var3);
            var19.setInt(4, var4);
            var19.setInt(5, var4);

            try (ResultSet var20 = var19.executeQuery()) {
               if (var20.next()) {
                  return Optional.of(this.canonicalize(this.read(var20)));
               }
            }
         } catch (SQLException var17) {
            var17.printStackTrace();
         }

         return Optional.empty();
      } else {
         return Optional.empty();
      }
   }

   public Optional<BaseData> findByLocation(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         String var2 = this.locationKey(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
         BaseData var3 = this.byLocation.get(var2);
         if (var3 != null) {
            return Optional.of(var3);
         }

         String var4 = "SELECT * FROM bases\nWHERE world = ? AND x = ? AND y = ? AND z = ?\nLIMIT 1;\n";

         try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
            var5.setString(1, var1.getWorld().getName());
            var5.setInt(2, var1.getBlockX());
            var5.setInt(3, var1.getBlockY());
            var5.setInt(4, var1.getBlockZ());

            try (ResultSet var6 = var5.executeQuery()) {
               if (var6.next()) {
                  return Optional.of(this.canonicalize(this.read(var6)));
               }
            }
         } catch (SQLException var13) {
            var13.printStackTrace();
         }

         return Optional.empty();
      } else {
         return Optional.empty();
      }
   }

   public long create(long var1, UUID var3, String var4, Location var5, int var6, int var7, int var8, int var9) {
      if (var3 != null && var5 != null && var5.getWorld() != null) {
         String var10 = "INSERT INTO bases (\n    beacon_id, owner_uuid, name,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    radius, block_limit, created_at\n) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);\n";

         try (PreparedStatement var11 = this.databaseManager.getConnection().prepareStatement(var10, 1)) {
            if (var1 > 0L) {
               var11.setLong(1, var1);
            } else {
               var11.setNull(1, 4);
            }

            var11.setString(2, var3.toString());
            var11.setString(3, var4);
            var11.setString(4, var5.getWorld().getName());
            var11.setInt(5, var5.getBlockX());
            var11.setInt(6, var5.getBlockY());
            var11.setInt(7, var5.getBlockZ());
            var11.setInt(8, var6);
            var11.setInt(9, var7);
            var11.setInt(10, var7);
            var11.setInt(11, var8);
            var11.setInt(12, var9);
            var11.setLong(13, System.currentTimeMillis());
            var11.executeUpdate();

            try (ResultSet var12 = var11.getGeneratedKeys()) {
               if (var12.next()) {
                  long var13 = var12.getLong(1);
                  this.canonicalize(
                     new BaseData(
                        var13, var1, var3, var4, var5.getWorld().getName(), var5.getBlockX(), var5.getBlockY(), var5.getBlockZ(), var6, var7, var7, var8, var9
                     )
                  );
                  return var13;
               }
            }
         } catch (SQLException var21) {
            var21.printStackTrace();
         }

         return -1L;
      } else {
         return -1L;
      }
   }

   public boolean updateName(UUID var1, String var2) {
      if (var1 == null) {
         return false;
      }

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("UPDATE bases SET name = ? WHERE owner_uuid = ?;")) {
         var3.setString(1, var2);
         var3.setString(2, var1.toString());
         boolean var4 = var3.executeUpdate() > 0;
         if (var4) {
            this.invalidateOwner(var1);
         }

         return var4;
      } catch (SQLException var8) {
         var8.printStackTrace();
         return false;
      }
   }

   public boolean updateLevel(UUID var1, int var2, int var3, int var4, int var5) {
      if (var1 == null) {
         return false;
      }

      String var6 = "UPDATE bases\nSET level = ?, current_hp = ?, max_hp = ?, radius = ?, block_limit = ?\nWHERE owner_uuid = ?;\n";

      try (PreparedStatement var7 = this.databaseManager.getConnection().prepareStatement(var6)) {
         var7.setInt(1, var2);
         var7.setInt(2, var3);
         var7.setInt(3, var3);
         var7.setInt(4, var4);
         var7.setInt(5, var5);
         var7.setString(6, var1.toString());
         boolean var8 = var7.executeUpdate() > 0;
         if (var8) {
            this.invalidateOwner(var1);
         }

         return var8;
      } catch (SQLException var12) {
         var12.printStackTrace();
         return false;
      }
   }

   public boolean updateHealth(long var1, int var3) {
      int var4 = Math.max(0, var3);

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement("UPDATE bases SET current_hp = ? WHERE id = ?;")) {
         var5.setInt(1, var4);
         var5.setLong(2, var1);
         boolean var6 = var5.executeUpdate() > 0;
         if (var6) {
            BaseData var7 = this.byId.get(var1);
            if (var7 != null) {
               var7.setCurrentHp(var4);
            }
         }

         return var6;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return false;
      }
   }

   public boolean deleteByOwner(UUID var1) {
      if (var1 == null) {
         return false;
      }

      try (PreparedStatement var2 = this.databaseManager.getConnection().prepareStatement("DELETE FROM bases WHERE owner_uuid = ?;")) {
         var2.setString(1, var1.toString());
         boolean var3 = var2.executeUpdate() > 0;
         if (var3) {
            this.invalidateOwner(var1);
         }

         return var3;
      } catch (SQLException var7) {
         var7.printStackTrace();
         return false;
      }
   }

   public List<BaseData> findAll() {
      ArrayList var1 = new ArrayList();
      String var2 = "SELECT * FROM bases ORDER BY id ASC;";

      try (
         PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2);
         ResultSet var4 = var3.executeQuery();
      ) {
         while (var4.next()) {
            var1.add(this.canonicalize(this.read(var4)));
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return var1;
   }

   public void clearCache() {
      this.byId.clear();
      this.byOwner.clear();
      this.byLocation.clear();
   }

   private BaseData canonicalize(BaseData var1) {
      BaseData var2 = this.byId.putIfAbsent(var1.getId(), var1);
      BaseData var3 = var2 == null ? var1 : var2;
      this.byOwner.put(var3.getOwnerUuid(), var3);
      this.byLocation.put(this.locationKey(var3.getWorldName(), var3.getX(), var3.getY(), var3.getZ()), var3);
      return var3;
   }

   private void invalidateOwner(UUID var1) {
      BaseData var2 = this.byOwner.remove(var1);
      if (var2 != null) {
         this.byId.remove(var2.getId(), var2);
         this.byLocation.remove(this.locationKey(var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()), var2);
      }
   }

   private String locationKey(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }

   private BaseData read(ResultSet var1) throws SQLException {
      return new BaseData(
         var1.getLong("id"),
         var1.getLong("beacon_id"),
         UUID.fromString(var1.getString("owner_uuid")),
         var1.getString("name"),
         var1.getString("world"),
         var1.getInt("x"),
         var1.getInt("y"),
         var1.getInt("z"),
         var1.getInt("level"),
         var1.getInt("current_hp"),
         var1.getInt("max_hp"),
         var1.getInt("radius"),
         var1.getInt("block_limit")
      );
   }
}
