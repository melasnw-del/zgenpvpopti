package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;

public final class RaidBombTargetFix {
   private RaidBombTargetFix() {
   }

   public static Optional<?> findTarget(Object var0, Object var1, Object var2, Object var3) {
      try {
         if (var0 != null && var1 != null && var2 != null && var3 != null) {
            Object var4 = field(var0, "plugin");
            Object var5 = call(var4, "getConfigManager");
            Object var6 = call(var5, "getRaid");
            boolean var7 = bool(call(var6, "getBoolean", "placement.deny-own-base", Boolean.TRUE), true);
            boolean var8 = bool(call(var6, "getBoolean", "placement.require-enemy-base", Boolean.TRUE), true);
            Object var9 = call(var1, "getUniqueId");
            Object var10 = call(var4, "getBaseRepository");
            Object var11 = unwrap(call(var10, "findContaining", var2));
            if (var11 != null) {
               Object var12 = call(var11, "getOwnerUuid");
               boolean var13 = bool(callPrivate(var0, "isFriendly", var9, var12), false);
               if ((!var8 || !var13) && (!var7 || !var13)) {
                  return Optional.of(var11);
               }
            }

            if (var8) {
               return Optional.empty();
            }

            int var37 = ((Number)callPrivate(var0, "getRadius", var3)).intValue();
            String var38 = String.valueOf(call(call(var2, "getWorld"), "getName"));
            int var14 = ((Number)call(var2, "getBlockX")).intValue();
            int var15 = ((Number)call(var2, "getBlockZ")).intValue();
            Object var16 = null;
            double var17 = Double.MAX_VALUE;
            Object var19 = call(var10, "findAll");
            if (var19 instanceof Iterable) {
               for (Object var22 : (Iterable)var19) {
                  if (var22 != null && var38.equalsIgnoreCase(String.valueOf(call(var22, "getWorldName")))) {
                     Object var23 = call(var22, "getOwnerUuid");
                     boolean var24 = bool(callPrivate(var0, "isFriendly", var9, var23), false);
                     if (!var7 || !var24) {
                        int var25 = ((Number)call(var22, "getX")).intValue();
                        int var26 = ((Number)call(var22, "getZ")).intValue();
                        int var27 = ((Number)call(var22, "getRadius")).intValue();
                        double var28 = var14 - var25;
                        double var30 = var15 - var26;
                        double var32 = var28 * var28 + var30 * var30;
                        double var34 = Math.max(1, var27) + Math.max(1, var37);
                        if (var32 <= var34 * var34 && var32 < var17) {
                           var16 = var22;
                           var17 = var32;
                        }
                     }
                  }
               }
            }

            return Optional.ofNullable(var16);
         } else {
            return Optional.empty();
         }
      } catch (Throwable var36) {
         return Optional.empty();
      }
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
   }

   private static boolean bool(Object var0, boolean var1) {
      return var0 instanceof Boolean ? (Boolean)var0 : var1;
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object callPrivate(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) throws NoSuchMethodException {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && fits(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && fits(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      throw new NoSuchMethodException(var0.getName() + "." + var1);
   }

   private static boolean fits(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isInstance(var1[var2])) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
