package com.zzwproject.zsafety;

import com.zzwproject.bundle.LegacyPluginBase;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.logging.Level;

public final class ZArmorGuard extends LegacyPluginBase {
   private final List<Object> refs = new ArrayList<>();

   @Override
   public void onEnable() {
      try {
         this.registerEvent("org.bukkit.event.inventory.InventoryClickEvent", this::onClick, "LOWEST", false);

         try {
            this.registerEvent("org.bukkit.event.inventory.InventoryCreativeEvent", this::onClick, "LOWEST", false);
         } catch (Throwable var2) {
         }

         this.registerEvent("org.bukkit.event.inventory.InventoryDragEvent", this::onDrag, "LOWEST", false);
         this.registerEvent("org.bukkit.event.inventory.InventoryCloseEvent", this::onClose, "MONITOR", false);
         this.registerEvent("org.bukkit.event.player.PlayerJoinEvent", this::onJoin, "MONITOR", false);
         this.getLogger().info("[ZArmorGuard] Bazuka/mermi zirh slotu korumasi aktif.");
      } catch (Throwable var3) {
         this.getLogger().log(Level.SEVERE, "[ZArmorGuard] Baslatma hatasi", unwrap(var3));
      }
   }

   @Override
   public void onDisable() {
      this.refs.clear();
   }

   private void onClick(Object var1) {
      try {
         Object var2 = safeCall(var1, "getWhoClicked");
         Object var3 = safeCall(var1, "getCursor");
         Object var4 = safeCall(var1, "getCurrentItem");
         String var5 = text(safeCall(var1, "getClick"));
         String var6 = text(safeCall(var1, "getAction"));
         int var7 = number(safeCall(var1, "getRawSlot"), -1);
         boolean var8 = this.isArmorSlot(var1, var7);
         Object var9 = null;
         if (var5.contains("NUMBER_KEY")) {
            int var10 = number(safeCall(var1, "getHotbarButton"), -1);
            Object var11 = safeCall(var2, "getInventory");
            if (var10 >= 0) {
               var9 = safeCall(var11, "getItem", var10);
            }
         } else if (var5.contains("SWAP_OFFHAND")) {
            Object var14 = safeCall(var2, "getInventory");
            var9 = safeCall(var14, "getItemInOffHand");
         }

         boolean var15 = this.isRestricted(var3);
         boolean var16 = this.isRestricted(var4);
         boolean var12 = this.isRestricted(var9);
         if (var8 && (var15 || var12 || var16)) {
            this.cancel(var1);
            return;
         }

         if ((var5.contains("SHIFT") || var6.contains("MOVE_TO_OTHER_INVENTORY")) && var16) {
            this.cancel(var1);
            return;
         }

         if (this.isPlayerInventoryView(var1) && var7 >= 5 && var7 <= 8 && (var15 || var12 || var16)) {
            this.cancel(var1);
         }
      } catch (Throwable var13) {
      }
   }

   private void onDrag(Object var1) {
      try {
         Object var2 = safeCall(var1, "getOldCursor");
         if (!this.isRestricted(var2)) {
            return;
         }

         if (!(safeCall(var1, "getRawSlots") instanceof Iterable var4)) {
            return;
         }

         Object var5 = safeCall(var1, "getView");

         for (Object var7 : var4) {
            int var8 = number(var7, -1);
            String var9 = text(safeCall(var5, "getSlotType", var8));
            if (var9.contains("ARMOR") || this.isPlayerInventoryView(var1) && var8 >= 5 && var8 <= 8) {
               this.cancel(var1);
               return;
            }
         }
      } catch (Throwable var10) {
      }
   }

   private void onClose(Object var1) {
      try {
         this.sanitize(safeCall(var1, "getPlayer"));
      } catch (Throwable var3) {
      }
   }

   private void onJoin(Object var1) {
      try {
         this.sanitize(safeCall(var1, "getPlayer"));
      } catch (Throwable var3) {
      }
   }

   private boolean isArmorSlot(Object var1, int var2) {
      try {
         String var3 = text(safeCall(var1, "getSlotType"));
         if (var3.contains("ARMOR")) {
            return true;
         }
      } catch (Throwable var4) {
      }

      return this.isPlayerInventoryView(var1) && var2 >= 5 && var2 <= 8;
   }

   private boolean isPlayerInventoryView(Object var1) {
      try {
         Object var2 = safeCall(var1, "getView");
         String var3 = text(safeCall(var2, "getType"));
         if (!var3.contains("CRAFTING") && !var3.contains("PLAYER")) {
            Object var4 = safeCall(var1, "getWhoClicked");
            Object var5 = safeCall(var1, "getClickedInventory");
            Object var6 = safeCall(var4, "getInventory");
            return var5 != null && var5 == var6;
         } else {
            return true;
         }
      } catch (Throwable var7) {
         return false;
      }
   }

   private void sanitize(Object var1) {
      if (var1 != null) {
         try {
            Object var2 = safeCall(var1, "getInventory");
            if (var2 == null) {
               return;
            }

            this.sanitizeSlot(var1, var2, "getHelmet", "setHelmet");
            this.sanitizeSlot(var1, var2, "getChestplate", "setChestplate");
            this.sanitizeSlot(var1, var2, "getLeggings", "setLeggings");
            this.sanitizeSlot(var1, var2, "getBoots", "setBoots");
         } catch (Throwable var3) {
         }
      }
   }

   private void sanitizeSlot(Object var1, Object var2, String var3, String var4) {
      try {
         Object var5 = safeCall(var2, var3);
         if (!this.isRestricted(var5)) {
            return;
         }

         call(var2, var4, null);
         int var6 = number(safeCall(var2, "firstEmpty"), -1);
         if (var6 >= 0) {
            call(var2, "setItem", var6, var5);
         } else {
            Object var7 = safeCall(var1, "getLocation");
            Object var8 = safeCall(var1, "getWorld");
            safeCall(var8, "dropItemNaturally", var7, var5);
         }
      } catch (Throwable var9) {
      }
   }

   private boolean isRestricted(Object var1) {
      if (var1 == null) {
         return false;
      }

      try {
         Class var2 = Class.forName("dev.lone.itemsadder.api.CustomStack");
         Object var3 = null;

         try {
            var3 = callStatic(var2, "byItemStack", var1);
         } catch (Throwable var11) {
         }

         if (var3 == null) {
            for (Method var7 : var2.getMethods()) {
               if (var7.getName().equals("getInstance") && var7.getParameterCount() == 1 && var7.getParameterTypes()[0].isInstance(var1)) {
                  try {
                     var3 = var7.invoke(null, var1);
                  } catch (Throwable var10) {
                  }

                  if (var3 != null) {
                     break;
                  }
               }
            }
         }

         if (var3 != null) {
            for (String var22 : new String[]{"getNamespacedID", "getNamespacedId", "getId"}) {
               Object var8 = safeCall(var3, var22);
               String var9 = text(var8).toLowerCase(Locale.ROOT);
               if (var9.equals("zzwraid:bazooka") || var9.equals("bazooka") || var9.equals("zzwraid:bazooka_ammo") || var9.equals("bazooka_ammo")) {
                  return true;
               }
            }
         }
      } catch (Throwable var13) {
      }

      try {
         String var14 = String.valueOf(var1).toLowerCase(Locale.ROOT);
         if (var14.contains("zzwraid:bazooka") || var14.contains("bazooka_ammo")) {
            return true;
         }

         Object var15 = safeCall(var1, "getItemMeta");
         if (var15 != null) {
            String var17 = text(safeCall(var15, "getDisplayName")).toLowerCase(Locale.ROOT);
            Object var19 = safeCall(var15, "getLore");
            String var21 = String.valueOf(var19).toLowerCase(Locale.ROOT);
            String var23 = text(safeCall(safeCall(var1, "getType"), "name"));
            if (var23.equalsIgnoreCase("STICK") && var17.contains("bazuka")
               || var23.equalsIgnoreCase("PAPER") && (var17.contains("bazuka merm") || var21.contains("bazuka merm"))) {
               return true;
            }
         }
      } catch (Throwable var12) {
      }

      return false;
   }

   private void cancel(Object var1) {
      try {
         call(var1, "setCancelled", true);
      } catch (Throwable var3) {
      }
   }

   private void registerEvent(String var1, Consumer<Object> var2, String var3, boolean var4) throws Exception {
      ClassLoader var5 = this.getClass().getClassLoader();
      Class var6 = Class.forName("org.bukkit.event.Listener");
      Class var7 = Class.forName("org.bukkit.plugin.EventExecutor");
      Class var8 = Class.forName(var1);
      Class var9 = Class.forName("org.bukkit.event.EventPriority");
      Enum var10 = Enum.valueOf(var9, var3);
      Object var11 = Proxy.newProxyInstance(var5, new Class[]{var6}, (var0, var1x, var2x) -> {
         if (var1x.getName().equals("toString")) {
            return "ZArmorGuardListener";
         } else if (var1x.getName().equals("hashCode")) {
            return System.identityHashCode(var0);
         } else {
            return var1x.getName().equals("equals") ? var0 == var2x[0] : null;
         }
      });
      Object var12 = Proxy.newProxyInstance(var5, new Class[]{var7}, (var2x, var3x, var4x) -> {
         if (var3x.getName().equals("execute") && var4x != null && var4x.length >= 2 && var8.isInstance(var4x[1])) {
            var2.accept(var4x[1]);
         }

         return null;
      });
      this.refs.add(var11);
      this.refs.add(var12);
      Class var13 = Class.forName("org.bukkit.Bukkit");
      Object var14 = callStatic(var13, "getPluginManager");
      Method var15 = findMethod(var14.getClass(), "registerEvent", new Object[]{var8, var11, var10, var12, this, var4});
      if (var15 == null) {
         throw new NoSuchMethodException("registerEvent");
      }

      var15.setAccessible(true);
      var15.invoke(var14, var8, var11, var10, var12, this, var4);
   }

   private static Object safeCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         return null;
      }

      Method var3 = findMethod(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);

      try {
         return var3.invoke(var0, var2);
      } catch (InvocationTargetException var5) {
         throw new RuntimeException(var5.getCause());
      }
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = findMethod(var0, var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);

      try {
         return var3.invoke(null, var2);
      } catch (InvocationTargetException var5) {
         throw new RuntimeException(var5.getCause());
      }
   }

   private static Method findMethod(Class<?> var0, String var1, Object[] var2) {
      for (Method var6 : var0.getMethods()) {
         if (matches(var6, var1, var2)) {
            return var6;
         }
      }

      for (Class var8 = var0; var8 != null; var8 = var8.getSuperclass()) {
         for (Method var7 : var8.getDeclaredMethods()) {
            if (matches(var7, var1, var2)) {
               return var7;
            }
         }
      }

      return null;
   }

   private static boolean matches(Method var0, String var1, Object[] var2) {
      if (var0.getName().equals(var1) && var0.getParameterCount() == var2.length) {
         Class[] var3 = var0.getParameterTypes();

         for (int var4 = 0; var4 < var3.length; var4++) {
            Object var5 = var2[var4];
            if (var5 == null) {
               if (var3[var4].isPrimitive()) {
                  return false;
               }
            } else if (!wrap(var3[var4]).isInstance(var5)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static int number(Object var0, int var1) {
      return var0 instanceof Number var2 ? var2.intValue() : var1;
   }

   private static String text(Object var0) {
      return var0 == null ? "" : String.valueOf(var0);
   }

   private static Throwable unwrap(Throwable var0) {
      while (var0 instanceof InvocationTargetException var1 && var1.getCause() != null) {
         var0 = var1.getCause();
      }

      return var0;
   }
}
