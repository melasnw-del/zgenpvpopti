package com.zzwproject.zgenpvp.base;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class BaseEnergyRepository {
   private final DatabaseManager databaseManager;
   private final ConcurrentMap<Long, Double> cache = new ConcurrentHashMap<>();

   public BaseEnergyRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public void createTable() throws SQLException {
      try (PreparedStatement var1 = this.databaseManager
            .getConnection()
            .prepareStatement(
               "CREATE TABLE IF NOT EXISTS base_energy (\n    base_id INTEGER PRIMARY KEY,\n    energy REAL NOT NULL DEFAULT 0,\n    updated_at INTEGER NOT NULL,\n    FOREIGN KEY (base_id) REFERENCES bases(id) ON DELETE CASCADE\n);\n"
            )) {
         var1.executeUpdate();
      }
   }

   public double getOrCreate(long var1, double var3) {
      Double var5 = this.cache.get(var1);
      if (var5 != null) {
         return Math.max(0.0, var5);
      }

      Double var6 = this.load(var1);
      if (var6 != null) {
         double var15 = Math.max(0.0, var6);
         this.cache.put(var1, var15);
         return var15;
      }

      double var7 = Math.max(0.0, var3);

      try (PreparedStatement var9 = this.databaseManager
            .getConnection()
            .prepareStatement("INSERT OR IGNORE INTO base_energy (base_id, energy, updated_at)\nVALUES (?, ?, ?);\n")) {
         var9.setLong(1, var1);
         var9.setDouble(2, var7);
         var9.setLong(3, System.currentTimeMillis());
         var9.executeUpdate();
      } catch (SQLException var14) {
         var14.printStackTrace();
      }

      Double var16 = this.load(var1);
      double var10 = var16 == null ? var7 : Math.max(0.0, var16);
      this.cache.put(var1, var10);
      return var10;
   }

   public Double get(long var1) {
      Double var3 = this.cache.get(var1);
      if (var3 != null) {
         return var3;
      }

      Double var4 = this.load(var1);
      if (var4 != null) {
         var4 = Math.max(0.0, var4);
         this.cache.put(var1, var4);
      }

      return var4;
   }

   public boolean set(long var1, double var3) {
      double var5 = Math.max(0.0, var3);

      try (PreparedStatement var7 = this.databaseManager
            .getConnection()
            .prepareStatement(
               "INSERT INTO base_energy (base_id, energy, updated_at)\nVALUES (?, ?, ?)\nON CONFLICT(base_id) DO UPDATE SET\n    energy = excluded.energy,\n    updated_at = excluded.updated_at;\n"
            )) {
         var7.setLong(1, var1);
         var7.setDouble(2, var5);
         var7.setLong(3, System.currentTimeMillis());
         boolean var8 = var7.executeUpdate() > 0;
         if (var8) {
            this.cache.put(var1, var5);
         }

         return var8;
      } catch (SQLException var12) {
         var12.printStackTrace();
         return false;
      }
   }

   public boolean delete(long var1) {
      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("DELETE FROM base_energy WHERE base_id = ?;")) {
         var3.setLong(1, var1);
         var3.executeUpdate();
         this.cache.remove(var1);
         return true;
      } catch (SQLException var8) {
         var8.printStackTrace();
         return false;
      }
   }

   public void clearCache() {
      this.cache.clear();
   }

   private Double load(long var1) {
      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("SELECT energy FROM base_energy WHERE base_id = ? LIMIT 1;\n")) {
         var3.setLong(1, var1);

         try (ResultSet var4 = var3.executeQuery()) {
            return var4.next() ? var4.getDouble("energy") : null;
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
         return null;
      }
   }
}
