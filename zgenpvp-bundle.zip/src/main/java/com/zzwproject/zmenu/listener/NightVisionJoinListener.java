package com.zzwproject.zmenu.listener;

import com.zzwproject.zmenu.ZMenu;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class NightVisionJoinListener implements Listener {
   private final ZMenu p;

   public NightVisionJoinListener(ZMenu var1) {
      this.p = var1;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent var1) {
      if (this.p.getConfig().getBoolean("night-vision.reapply-on-join", true)) {
         this.p.getServer().getScheduler().runTaskLater(this.p, () -> this.p.nightVision().reapply(var1.getPlayer()), 10L);
      }
   }
}
