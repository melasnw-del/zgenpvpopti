package com.zzwproject.zgenpvp.money;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public final class MoneyListener implements Listener {
   private final ZGenPvP plugin;
   private final MoneyItemManager moneyItemManager;

   public MoneyListener(ZGenPvP plugin, MoneyItemManager moneyItemManager) {
      this.plugin = plugin;
      this.moneyItemManager = moneyItemManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInteract(PlayerInteractEvent event) {
      if (event.getAction().isRightClick()) {
         EquipmentSlot hand = event.getHand();
         if (hand != null) {
            Player player = event.getPlayer();
            PlayerInventory inventory = player.getInventory();
            ItemStack clickedMoney = hand == EquipmentSlot.HAND ? inventory.getItemInMainHand() : inventory.getItemInOffHand();
            if (this.moneyItemManager.isMoneyItem(clickedMoney)) {
               event.setCancelled(true);
               List<MoneyListener.MoneySlot> moneySlots = this.collectMoneySlots(inventory);
               if (!moneySlots.isEmpty()) {
                  double totalValue = 0.0;

                  for (MoneyListener.MoneySlot moneySlot : moneySlots) {
                     totalValue += moneySlot.value;
                  }

                  if (Double.isFinite(totalValue) && !(totalValue <= 0.0)) {
                     boolean success = this.plugin.getEconomyManager().deposit(player, totalValue);
                     if (!success) {
                        this.plugin.getMessageUtil().sendActionBar(player, "&cPara bakiyene aktarılamadı. &7Banknotların silinmedi.");
                        this.plugin.getSoundUtil().play(player, "error");
                     } else {
                        this.removeCollectedMoney(inventory, moneySlots);
                        this.plugin
                           .getMessageUtil()
                           .sendActionBar(player, "&a+$%amount% &8• &fᴛüᴍ ꜰɪᴢɪᴋꜱᴇʟ ᴘᴀʀᴀɴ ʙᴀᴋɪʏᴇɴᴇ ᴀᴋᴛᴀʀɪʟᴅɪ.", "%amount%", this.format(totalValue));
                        this.plugin.getSoundUtil().play(player, "money-deposit");
                     }
                  } else {
                     this.plugin.getMessageUtil().sendActionBar(player, "&cPara bakiyene aktarılamadı. &7Banknotların silinmedi.");
                     this.plugin.getSoundUtil().play(player, "error");
                  }
               }
            }
         }
      }
   }

   private List<MoneyListener.MoneySlot> collectMoneySlots(PlayerInventory inventory) {
      List<MoneyListener.MoneySlot> result = new ArrayList<>();
      ItemStack[] contents = inventory.getContents();

      for (int slot = 0; slot < contents.length; slot++) {
         ItemStack item = contents[slot];
         if (this.moneyItemManager.isMoneyItem(item)) {
            double value = this.moneyItemManager.getStackValue(item);
            if (Double.isFinite(value) && !(value <= 0.0)) {
               result.add(new MoneyListener.MoneySlot(slot, item.clone(), value));
            }
         }
      }

      return result;
   }

   private void removeCollectedMoney(PlayerInventory inventory, List<MoneyListener.MoneySlot> moneySlots) {
      for (MoneyListener.MoneySlot moneySlot : moneySlots) {
         ItemStack current = inventory.getItem(moneySlot.slot);
         if (this.moneyItemManager.isMoneyItem(current)) {
            if (this.isSameMoneyStack(current, moneySlot.item)) {
               inventory.setItem(moneySlot.slot, null);
            } else {
               double unitValue = this.moneyItemManager.getMoneyValue(current);
               double expectedUnitValue = this.moneyItemManager.getMoneyValue(moneySlot.item);
               if (Double.compare(unitValue, expectedUnitValue) == 0) {
                  int removeAmount = moneySlot.item.getAmount();
                  int currentAmount = current.getAmount();
                  if (currentAmount <= removeAmount) {
                     inventory.setItem(moneySlot.slot, null);
                  } else {
                     ItemStack remainder = current.clone();
                     remainder.setAmount(currentAmount - removeAmount);
                     inventory.setItem(moneySlot.slot, remainder);
                  }
               }
            }
         }
      }
   }

   private boolean isSameMoneyStack(ItemStack first, ItemStack second) {
      return first != null && second != null ? first.getAmount() == second.getAmount() && first.isSimilar(second) : false;
   }

   private String format(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }

   private static final class MoneySlot {
      private final int slot;
      private final ItemStack item;
      private final double value;

      private MoneySlot(int slot, ItemStack item, double value) {
         this.slot = slot;
         this.item = item;
         this.value = value;
      }
   }
}
