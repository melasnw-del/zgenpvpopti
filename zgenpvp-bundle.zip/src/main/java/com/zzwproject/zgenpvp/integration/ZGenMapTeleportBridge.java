package com.zzwproject.zgenpvp.integration;

import java.lang.reflect.Method;
import java.util.function.BooleanSupplier;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class ZGenMapTeleportBridge {
   private ZGenMapTeleportBridge() {
   }

   public static boolean start(
      Player var0,
      String var1,
      Location var2,
      int var3,
      String var4,
      String var5,
      boolean var6,
      boolean var7,
      boolean var8,
      double var9,
      Runnable var11,
      Runnable var12
   ) {
      try {
         Plugin var13 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var13 != null && var13.isEnabled()) {
            Object var14 = var13.getClass().getMethod("getApi").invoke(var13);
            if (var14 == null) {
               return false;
            }

            Method var15 = var14.getClass()
               .getMethod(
                  "startTeleport",
                  Player.class,
                  String.class,
                  Location.class,
                  int.class,
                  String.class,
                  String.class,
                  boolean.class,
                  boolean.class,
                  boolean.class,
                  double.class,
                  Runnable.class,
                  Runnable.class
               );
            Object var16 = var15.invoke(var14, var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var11, var12);
            return Boolean.TRUE.equals(var16);
         } else {
            return false;
         }
      } catch (Throwable var17) {
         return false;
      }
   }

   public static boolean startValidated(
      Player var0,
      String var1,
      Location var2,
      int var3,
      String var4,
      String var5,
      boolean var6,
      boolean var7,
      boolean var8,
      double var9,
      BooleanSupplier var11,
      Runnable var12,
      Runnable var13
   ) {
      try {
         Plugin var14 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var14 != null && var14.isEnabled()) {
            Object var15 = var14.getClass().getMethod("getApi").invoke(var14);
            if (var15 == null) {
               return false;
            }

            Method var16 = var15.getClass()
               .getMethod(
                  "startTeleportValidated",
                  Player.class,
                  String.class,
                  Location.class,
                  int.class,
                  String.class,
                  String.class,
                  boolean.class,
                  boolean.class,
                  boolean.class,
                  double.class,
                  BooleanSupplier.class,
                  Runnable.class,
                  Runnable.class
               );
            Object var17 = var16.invoke(var15, var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var11, var12, var13);
            return Boolean.TRUE.equals(var17);
         } else {
            return false;
         }
      } catch (Throwable var18) {
         return false;
      }
   }

   public static boolean isTeleporting(Player var0) {
      try {
         Plugin var1 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var1 != null && var1.isEnabled()) {
            Object var2 = var1.getClass().getMethod("getApi").invoke(var1);
            Method var3 = var2.getClass().getMethod("isTeleporting", Player.class);
            return Boolean.TRUE.equals(var3.invoke(var2, var0));
         } else {
            return false;
         }
      } catch (Throwable var4) {
         return false;
      }
   }

   public static String getChannel(Player var0) {
      try {
         Plugin var1 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var1 != null && var1.isEnabled()) {
            Object var2 = var1.getClass().getMethod("getApi").invoke(var1);
            Method var3 = var2.getClass().getMethod("getTeleportChannel", Player.class);
            Object var4 = var3.invoke(var2, var0);
            return var4 == null ? null : String.valueOf(var4);
         } else {
            return null;
         }
      } catch (Throwable var5) {
         return null;
      }
   }

   public static void cancel(Player var0) {
      try {
         Plugin var1 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var1 == null || !var1.isEnabled()) {
            return;
         }

         Object var2 = var1.getClass().getMethod("getApi").invoke(var1);
         Method var3 = var2.getClass().getMethod("cancelTeleport", Player.class);
         var3.invoke(var2, var0);
      } catch (Throwable var4) {
      }
   }
}
