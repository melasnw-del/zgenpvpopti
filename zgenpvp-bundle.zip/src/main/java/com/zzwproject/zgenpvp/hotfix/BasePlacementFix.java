package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Method;
import java.util.Optional;
import java.util.UUID;

public final class BasePlacementFix {
   private BasePlacementFix() {
   }

   public static boolean allow(Object var0, Object var1, Object var2) {
      if (var0 != null && var1 != null && var2 != null) {
         try {
            Object var3 = call(var0, "getConfigManager");
            Object var4 = call(var3, "getConfig");
            boolean var5 = bool(call(var4, "getBoolean", "base.require-beacon", Boolean.TRUE), true);
            if (!var5) {
               return true;
            }

            UUID var6 = (UUID)call(var1, "getUniqueId");
            Object var7 = call(var0, "getBeaconRepository");
            Object var8 = call(var7, "findByOwner", var6);
            Object var9 = unwrap(var8);
            if (var9 == null) {
               message(var0, var1, "base.beacon-required", "Önce bir beacon kurmalısın.");
               return false;
            }

            boolean var10 = bool(call(var4, "getBoolean", "base.placement.require-same-world-as-beacon", Boolean.TRUE), true);
            Object var11 = call(var9, "getLocation");
            Object var12 = call(var2, "getWorld");
            Object var13 = call(var11, "getWorld");
            if (var10 && !sameWorld(var12, var13)) {
               message(var0, var1, "base.beacon-world", "Base beacon ile aynı dünyada olmalı.");
               return false;
            }

            double var14 = number(call(var4, "getDouble", "base.placement.max-distance-from-beacon", -1.0), -1.0);
            if (var14 >= 0.0 && sameWorld(var12, var13)) {
               int var16 = ((Number)call(var2, "getBlockX")).intValue();
               int var17 = ((Number)call(var2, "getBlockY")).intValue();
               int var18 = ((Number)call(var2, "getBlockZ")).intValue();
               int var19 = ((Number)call(var11, "getBlockX")).intValue();
               int var20 = ((Number)call(var11, "getBlockY")).intValue();
               int var21 = ((Number)call(var11, "getBlockZ")).intValue();
               double var22 = var16 - var19;
               double var24 = var17 - var20;
               double var26 = var18 - var21;
               if (var22 * var22 + var24 * var24 + var26 * var26 > var14 * var14) {
                  message(var0, var1, "base.beacon-distance", "Base beacon'a daha yakın kurulmalı.");
                  return false;
               }
            }

            return true;
         } catch (Throwable var28) {
            return true;
         }
      } else {
         return false;
      }
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional ? ((Optional)var0).orElse(null) : var0;
   }

   private static boolean sameWorld(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            return String.valueOf(call(var0, "getName")).equalsIgnoreCase(String.valueOf(call(var1, "getName")));
         } catch (Throwable var3) {
            return var0 == var1;
         }
      } else {
         return false;
      }
   }

   private static void message(Object var0, Object var1, String var2, String var3) {
      try {
         Object var4 = call(var0, "getMessageUtil");
         call(var4, "sendActionBar", var1, var2, new String[0]);
      } catch (Throwable var6) {
         try {
            call(var1, "sendMessage", var3);
         } catch (Throwable var5) {
         }
      }
   }

   private static boolean bool(Object var0, boolean var1) {
      return var0 instanceof Boolean ? (Boolean)var0 : var1;
   }

   private static double number(Object var0, double var1) {
      return var0 instanceof Number ? ((Number)var0).doubleValue() : var1;
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = find(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && compatible(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && compatible(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      return null;
   }

   private static boolean compatible(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else {
            Class var3 = wrap(var0[var2]);
            if (!var3.isInstance(var1[var2]) && (!Number.class.isAssignableFrom(var3) || !(var1[var2] instanceof Number))) {
               return false;
            }
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
