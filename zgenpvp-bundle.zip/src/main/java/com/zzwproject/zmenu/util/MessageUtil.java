package com.zzwproject.zmenu.util;

import com.zzwproject.zmenu.ZMenu;
import org.bukkit.command.CommandSender;

public final class MessageUtil {
   private final ZMenu p;

   public MessageUtil(ZMenu var1) {
      this.p = var1;
   }

   public void send(CommandSender var1, String var2, String... var3) {
      String var4 = this.p.messages().getString(var2);
      if (var4 != null) {
         var1.sendMessage(ColorUtil.color(this.replace(var4, var3)));
      }
   }

   public String replace(String var1, String... var2) {
      String var3 = var1 == null ? "" : var1;
      var3 = var3.replace("%prefix%", this.p.messages().getString("prefix", ""));

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(var2[var4], var2[var4 + 1]);
      }

      return var3;
   }
}
