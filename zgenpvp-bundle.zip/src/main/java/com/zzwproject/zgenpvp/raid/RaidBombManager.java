package com.zzwproject.zgenpvp.raid;

import com.zzwproject.compat.AdventureCompat;
import com.zzwproject.hotfix.BombCountdownHook;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.access.DefenseAccessManager;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.base.BaseManager;
import com.zzwproject.zgenpvp.defense.DefenseManager;
import com.zzwproject.zgenpvp.hotfix.RaidBombTargetFix;
import com.zzwproject.zgenpvp.integration.RaidBombSessionStarter;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.raid.hotfix.BombDisplayFix;
import com.zzwproject.zgenpvp.turret.TurretManager;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class RaidBombManager {
   private final ZGenPvP plugin;
   private final BaseManager baseManager;
   private final DefenseManager defenseManager;
   private final TurretManager turretManager;
   private final DefenseAccessManager defenseAccessManager;
   private final RaidProtectionManager protectionManager;
   private final NamespacedKey raidBombKey;
   private final NamespacedKey raidBombTierKey;
   private final Map<UUID, Long> cooldowns = new HashMap<>();
   private final Map<String, RaidBombManager.ActiveBomb> activeBombs = new HashMap<>();
   private final Map<Long, String> activeBaseBombs = new HashMap<>();
   private RaidRelationService relationService = (var0, var1x) -> var0 != null && var1x != null && var0.equals(var1x);

   public RaidBombManager(ZGenPvP var1, BaseManager var2, DefenseManager var3, TurretManager var4, DefenseAccessManager var5) {
      this.plugin = var1;
      this.baseManager = var2;
      this.defenseManager = var3;
      this.turretManager = var4;
      this.defenseAccessManager = var5;
      this.protectionManager = new RaidProtectionManager(var1);
      this.raidBombKey = new NamespacedKey(var1, "raid_bomb");
      this.raidBombTierKey = new NamespacedKey(var1, "raid_bomb_tier");
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getRaid().getBoolean("enabled", true);
   }

   public RaidProtectionManager getProtectionManager() {
      return this.protectionManager;
   }

   public void setRelationService(RaidRelationService var1) {
      if (var1 == null) {
         this.relationService = (var0, var1x) -> var0 != null && var1x != null && var0.equals(var1x);
      } else {
         this.relationService = var1;
      }
   }

   public boolean isFriendly(UUID var1, UUID var2) {
      return this.relationService.isFriendly(var1, var2);
   }

   public ItemStack createBomb(RaidBombType var1) {
      return this.createBomb(var1, 1);
   }

   public ItemStack createBomb(RaidBombType var1, int var2) {
      if (var1 == null) {
         return null;
      }

      FileConfiguration var3 = this.plugin.getConfigManager().getRaid();
      String var4 = var1.getConfigPath();
      String var5 = var3.getString(var4 + ".item.material", "TNT");
      Material var6 = Material.matchMaterial(var5 == null ? "TNT" : var5);
      if (var6 == null) {
         var6 = Material.TNT;
      }

      ItemStack var7 = new ItemStack(var6, Math.max(1, Math.min(64, var2)));
      ItemMeta var8 = var7.getItemMeta();
      if (var8 == null) {
         return var7;
      }

      int var9 = this.getDamage(var1);
      int var10 = this.getRadius(var1);
      int var11 = this.getFuseSeconds(var1);
      String var12 = var3.getString(var4 + ".item.name", "&c" + var1.getDisplayName());
      var12 = this.replace(
         var12, "%tier%", String.valueOf(var1.getId()), "%damage%", String.valueOf(var9), "%radius%", String.valueOf(var10), "%fuse%", String.valueOf(var11)
      );
      var8.displayName(this.component(var12));
      ArrayList var13 = new ArrayList();

      for (String var15 : var3.getStringList(var4 + ".item.lore")) {
         var13.add(
            this.component(
               this.replace(
                  var15,
                  "%tier%",
                  String.valueOf(var1.getId()),
                  "%damage%",
                  String.valueOf(var9),
                  "%radius%",
                  String.valueOf(var10),
                  "%fuse%",
                  String.valueOf(var11)
               )
            )
         );
      }

      var8.lore(var13);
      int var17 = var3.getInt(var4 + ".item.custom-model-data", 0);
      if (var17 > 0) {
         var8.setCustomModelData(var17);
      }

      var8.getPersistentDataContainer().set(this.raidBombKey, PersistentDataType.BYTE, (byte)1);
      var8.getPersistentDataContainer().set(this.raidBombTierKey, PersistentDataType.INTEGER, var1.getId());
      var7.setItemMeta(var8);
      return var7;
   }

   public boolean isRaidBomb(ItemStack var1) {
      return this.getBombType(var1).isPresent();
   }

   public Optional<RaidBombType> getBombType(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         ItemMeta var2 = var1.getItemMeta();
         Byte var3 = (Byte)var2.getPersistentDataContainer().get(this.raidBombKey, PersistentDataType.BYTE);
         if (var3 != null && var3 == 1) {
            Integer var4 = (Integer)var2.getPersistentDataContainer().get(this.raidBombTierKey, PersistentDataType.INTEGER);
            return var4 == null ? Optional.empty() : RaidBombType.fromId(var4);
         } else {
            return Optional.empty();
         }
      } else {
         return Optional.empty();
      }
   }

   public boolean giveBomb(Player var1, RaidBombType var2, int var3) {
      if (var1 != null && var2 != null) {
         ItemStack var4 = this.createBomb(var2, var3);
         if (var4 == null) {
            return false;
         }

         Map<Integer, ItemStack> var5 = var1.getInventory().addItem(new ItemStack[]{var4});

         for (ItemStack var7 : var5.values()) {
            var1.getWorld().dropItemNaturally(var1.getLocation(), var7);
         }

         this.sendMessage(var1, "messages.received", "%amount%", String.valueOf(var3), "%tier%", var2.getDisplayName());
         return true;
      } else {
         return false;
      }
   }

   public void queuePlant(Player var1, Location var2, RaidBombType var3) {
      if (var1 != null && var2 != null && var3 != null) {
         Bukkit.getScheduler().runTask(this.plugin, () -> this.plant(var1, var2, var3));
      }
   }

   public boolean plant(Player var1, Location var2, RaidBombType var3) {
      if (!this.isEnabled()) {
         this.sendMessage(var1, "messages.disabled");
         return false;
      }

      if (!var1.hasPermission("zgenpvp.raidbomb.use")) {
         this.sendMessage(var1, "messages.no-permission");
         return false;
      }

      if (var2 != null && var2.getWorld() != null) {
         var2 = var2.getBlock().getLocation();
         FileConfiguration var4 = this.plugin.getConfigManager().getRaid();
         var4.getBoolean("placement.deny-own-base", true);
         Optional var5 = this.findTargetBase(var1, var2, var3);
         if (var4.getBoolean("placement.require-enemy-base", true) && var5.isEmpty()) {
            this.sendMessage(var1, "messages.not-enemy-base");
            return false;
         }

         if (var5.isEmpty()) {
            this.sendMessage(var1, "messages.not-enemy-base");
            return false;
         }

         BaseData var6 = (BaseData)var5.get();
         if (this.protectionManager.isProtected(var6.getId())) {
            this.sendMessage(var1, "messages.protected", "%seconds%", String.valueOf(this.protectionManager.getRemainingSeconds(var6.getId())));
            return false;
         }

         if (var4.getBoolean("placement.one-active-bomb-per-base", true) && this.activeBaseBombs.containsKey(var6.getId())) {
            this.sendMessage(var1, "messages.base-active-bomb");
            return false;
         }

         long var7 = this.getRemainingCooldownMillis(var1.getUniqueId());
         if (var7 > 0L) {
            long var15 = Math.max(1L, (long)Math.ceil(var7 / 1000.0));
            this.sendMessage(var1, "messages.cooldown", "%seconds%", String.valueOf(var15));
            return false;
         }

         String var9 = this.locationKey(var2);
         if (var4.getBoolean("placement.prevent-overlap", true) && this.activeBombs.containsKey(var9)) {
            this.sendMessage(var1, "messages.already-active");
            return false;
         }

         if (!this.consumeBomb(var1, var3)) {
            this.sendMessage(var1, "messages.bomb-missing");
            return false;
         }

         long var10 = Math.max(0L, var4.getLong("cooldown-seconds", 20L));
         if (var10 > 0L) {
            this.cooldowns.put(var1.getUniqueId(), System.currentTimeMillis() + var10 * 1000L);
         }

         BlockDisplay var12 = this.spawnDisplay(var2);
         BombDisplayFix.apply(var12, var3);
         RaidBombManager.ActiveBomb var13 = new RaidBombManager.ActiveBomb(var1.getUniqueId(), var2.clone(), var3, var12, var6.getId(), var6.getOwnerUuid());
         this.activeBombs.put(var9, var13);
         this.activeBaseBombs.put(var6.getId(), var9);
         this.startFuse(var13);
         this.sendMessage(var1, "messages.planted", "%seconds%", String.valueOf(this.getFuseSeconds(var3)));
         return true;
      } else {
         return false;
      }
   }

   private void startFuse(final RaidBombManager.ActiveBomb var1) {
      final int var2 = this.getFuseSeconds(var1.type());
      BukkitTask var3 = (new BukkitRunnable() {
         private int seconds = var2;

         public void run() {
            if (this.seconds <= 0) {
               this.cancel();
               RaidBombManager.this.removeActiveBomb(var1);
               RaidBombManager.this.explode(var1);
            } else {
               RaidBombManager.this.spawnFuseEffect(var1.location());
               Player var1x = Bukkit.getPlayer(var1.ownerUuid());
               if (var1x != null && var1x.isOnline()) {
                  RaidBombManager.this.sendActionBar(var1x, "messages.countdown-actionbar", "%seconds%", String.valueOf(this.seconds));
               }

               this.seconds--;
               BombCountdownHook.tick(RaidBombManager.this, var1, this.seconds);
            }
         }
      }).runTaskTimer(this.plugin, 0L, 20L);
      var1.setTask(var3);
   }

   private void explode(RaidBombManager.ActiveBomb var1) {
      Location var2 = var1.location();
      World var3 = var2.getWorld();
      if (var3 != null) {
         this.spawnExplosionEffect(var2);
         Player var4 = Bukkit.getPlayer(var1.ownerUuid());
         if (var4 != null && var4.isOnline()) {
            Optional var5 = this.baseManager.getBase(var1.targetOwnerUuid());
            if (!var5.isEmpty()) {
               BaseData var6 = (BaseData)var5.get();
               if (var6.getId() == var1.targetBaseId()) {
                  RaidBombManager.DamageResult var7 = this.damageStructures(var4, var2, var1.type(), var6);
                  int var8 = var7.affected();
                  FileConfiguration var9 = this.plugin.getConfigManager().getRaid();
                  if (var7.raidTriggerHits() > 0 && this.plugin.getRaidWindowManager() != null) {
                     this.plugin.getRaidWindowManager().beginRaid(var6, var4);
                  }

                  if (var7.raidTriggerHits() > 0) {
                     RaidBombSessionStarter.start(var4, var6);
                  }

                  boolean var10 = var9.getBoolean("protection.start-only-if-damage", true);
                  boolean var11 = !var10 || var8 > 0;
                  if (var11) {
                     Optional var12 = this.baseManager.getBase(var1.targetOwnerUuid());
                     if (var12.isPresent() && ((BaseData)var12.get()).getId() == var1.targetBaseId()) {
                        this.protectionManager.startProtection(var1.targetBaseId());
                        long var13 = this.protectionManager.getRemainingSeconds(var1.targetBaseId());
                        if (var9.getBoolean("protection.notify-attacker", false)) {
                           this.sendMessage(var4, "messages.protection-started-attacker", "%seconds%", String.valueOf(var13));
                        }

                        if (var9.getBoolean("protection.notify-owner", false)) {
                           Player var15 = Bukkit.getPlayer(var1.targetOwnerUuid());
                           if (var15 != null && var15.isOnline()) {
                              this.sendMessage(var15, "messages.protection-started-owner", "%seconds%", String.valueOf(var13));
                           }
                        }
                     }
                  }

                  Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                     if (var4.isOnline()) {
                        this.sendActionBar(var4, "messages.explosion-actionbar", "%structures%", String.valueOf(var8));
                     }
                  }, 5L);
               }
            }
         }
      }
   }

   private RaidBombManager.DamageResult damageStructures(Player var1, Location var2, RaidBombType var3, BaseData var4) {
      int var5 = this.getRadius(var3);
      int var6 = this.getDamage(var3);
      int var7 = 0;
      int var8 = 0;
      UUID var9 = var4.getOwnerUuid();
      HashSet var10 = new HashSet();
      HashSet var11 = new HashSet();
      HashSet var12 = new HashSet();
      HashSet var13 = new HashSet();
      FileConfiguration var14 = this.plugin.getConfigManager().getRaid();
      World var15 = var2.getWorld();
      if (var15 == null) {
         return new RaidBombManager.DamageResult(0, 0);
      }

      int var16 = var2.getBlockX();
      int var17 = var2.getBlockY();
      int var18 = var2.getBlockZ();
      int var19 = var5 * var5;

      for (int var20 = -var5; var20 <= var5; var20++) {
         int var21 = var16 + var20;

         for (int var22 = -var5; var22 <= var5; var22++) {
            if (var20 * var20 + var22 * var22 <= var19) {
               int var23 = var18 + var22;
               if (var15.isChunkLoaded(var21 >> 4, var23 >> 4)) {
                  for (int var24 = -var5; var24 <= var5; var24++) {
                     if (var20 * var20 + var24 * var24 + var22 * var22 <= var19) {
                        Block var25 = var15.getBlockAt(var21, var17 + var24, var23);
                        Location var26 = var25.getLocation();
                        if (var14.getBoolean("targets.defense", true)) {
                           Optional var27 = this.defenseManager.getDefense(var26);
                           if (var27.isPresent()) {
                              DefenseData var35 = (DefenseData)var27.get();
                              if (var35.getOwnerUuid().equals(var9) && var10.add(var35.getId())) {
                                 this.defenseManager.damage(var1, var35, var6, false);
                                 var7++;
                                 var8++;
                              }
                              continue;
                           }
                        }

                        if (var14.getBoolean("targets.turret", true)) {
                           Optional var31 = this.turretManager.getTurret(var26);
                           if (var31.isPresent()) {
                              DefenseData var34 = (DefenseData)var31.get();
                              if (var34.getOwnerUuid().equals(var9) && var11.add(var34.getId())) {
                                 this.turretManager.damage(var1, var34, var6, false);
                                 var7++;
                                 var8++;
                              }
                              continue;
                           }
                        }

                        Optional var32 = this.defenseAccessManager.get(var25);
                        if (var32.isPresent()) {
                           DefenseData var28 = (DefenseData)var32.get();
                           DefenseAccessType var29 = this.defenseAccessManager.getType(var28);
                           boolean var30 = var29 == DefenseAccessType.DOOR
                              ? var14.getBoolean("targets.door", true)
                              : var14.getBoolean("targets.trapdoor", true);
                           if (var30 && var28.getOwnerUuid().equals(var9) && var12.add(var28.getId())) {
                              this.defenseAccessManager.damage(var1, var28, var6, false);
                              var7++;
                              var8++;
                           }
                        } else if (var14.getBoolean("targets.base", true) && var14.getBoolean("base.enabled", true)) {
                           Optional var33 = this.baseManager.getBase(var26);
                           if (var33.isPresent()) {
                              BaseData var36 = (BaseData)var33.get();
                              if (var36.getId() == var4.getId() && var13.add(var36.getId()) && this.damageBase(var1, var36, var25, var6)) {
                                 var7++;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return new RaidBombManager.DamageResult(var7, var8);
   }

   private boolean damageBase(Player var1, BaseData var2, Block var3, int var4) {
      if (this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
         return false;
      }

      FileConfiguration var5 = this.plugin.getConfigManager().getRaid();
      double var6 = Math.max(0.0, var5.getDouble("base.damage-multiplier", 0.25));
      int var8 = Math.max(1, (int)Math.floor(var4 * var6));
      int var9 = Math.max(0, var2.getCurrentHp() - var8);
      if (var9 > 0) {
         return this.plugin.getBaseRepository().updateHealth(var2.getId(), var9);
      }

      boolean var10 = this.plugin.getBaseRepository().deleteByOwner(var2.getOwnerUuid());
      if (!var10) {
         return false;
      }

      var3.setType(Material.AIR, false);
      OfflinePlayer var11 = Bukkit.getOfflinePlayer(var2.getOwnerUuid());
      String var12 = var11.getName() == null ? "Bilinmeyen" : var11.getName();
      String var13 = this.plugin.getMessageUtil().get("base.destroyed-broadcast", "%attacker%", var1.getName(), "%owner%", var12);
      Bukkit.broadcastMessage(var13);
      if (var11.isOnline()) {
         Player var14 = var11.getPlayer();
         if (var14 != null) {
            this.plugin.getMessageUtil().send(var14, "base.destroyed-owner", "%attacker%", var1.getName());
         }
      }

      this.plugin.getSoundUtil().play(var1, "base-break");
      this.plugin.getXpRewardManager().reward(var1, XpRewardType.BASE_DESTROY);
      this.protectionManager.removeProtection(var2.getId());
      return true;
   }

   private Optional<BaseData> findTargetBase(Player var1, Location var2, RaidBombType var3) {
      return (Optional<BaseData>)RaidBombTargetFix.findTarget(this, var1, var2, var3);
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!var1.getWorldName().equals(var2.getWorld().getName())) {
            return false;
         }

         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = var1.getRadius();
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   private List<Block> getBlocksInRadius(Location var1, int var2) {
      ArrayList var3 = new ArrayList();
      World var4 = var1.getWorld();
      if (var4 == null) {
         return var3;
      }

      int var5 = var1.getBlockX();
      int var6 = var1.getBlockY();
      int var7 = var1.getBlockZ();
      double var8 = var2 * var2;

      for (int var10 = -var2; var10 <= var2; var10++) {
         for (int var11 = -var2; var11 <= var2; var11++) {
            for (int var12 = -var2; var12 <= var2; var12++) {
               double var13 = var10 * var10 + var11 * var11 + var12 * var12;
               if (!(var13 > var8)) {
                  var3.add(var4.getBlockAt(var5 + var10, var6 + var11, var7 + var12));
               }
            }
         }
      }

      return var3;
   }

   private BlockDisplay spawnDisplay(Location var1) {
      World var2 = var1.getWorld();
      if (var2 == null) {
         return null;
      }

      FileConfiguration var3 = this.plugin.getConfigManager().getRaid();
      String var4 = var3.getString("display.material", "TNT");
      Material var5 = Material.matchMaterial(var4 == null ? "TNT" : var4);
      if (var5 == null || !var5.isBlock()) {
         var5 = Material.TNT;
      }

      Material var6 = var5;
      Location var7 = var1.getBlock().getLocation().add(0.0, 0.01, 0.0);
      return (BlockDisplay)var2.spawn(var7, BlockDisplay.class, var2x -> {
         var2x.setBlock(var6.createBlockData());
         var2x.setPersistent(false);
         var2x.setGlowing(var3.getBoolean("display.glowing", true));
         var2x.setInvulnerable(true);
      });
   }

   private void spawnFuseEffect(Location var1) {
      this.spawnEffect(var1.clone().add(0.5, 0.6, 0.5), "effects.fuse", Particle.SMOKE, Sound.BLOCK_NOTE_BLOCK_HAT);
   }

   private void spawnExplosionEffect(Location var1) {
      this.spawnEffect(var1.clone().add(0.5, 0.5, 0.5), "effects.explosion", Particle.EXPLOSION, Sound.ENTITY_GENERIC_EXPLODE);
   }

   private void spawnEffect(Location var1, String var2, Particle var3, Sound var4) {
      World var5 = var1.getWorld();
      if (var5 != null) {
         FileConfiguration var6 = this.plugin.getConfigManager().getRaid();
         Particle var7 = this.resolveParticle(var6.getString(var2 + ".particle"), var3);
         int var8 = Math.max(0, var6.getInt(var2 + ".particle-count", 5));
         if (var8 > 0) {
            var5.spawnParticle(var7, var1, var8, 0.25, 0.25, 0.25, 0.0);
         }

         Sound var9 = this.resolveSound(var6.getString(var2 + ".sound"), var4);
         float var10 = (float)var6.getDouble(var2 + ".volume", 1.0);
         float var11 = (float)var6.getDouble(var2 + ".pitch", 1.0);
         var5.playSound(var1, var9, SoundCategory.BLOCKS, var10, var11);
      }
   }

   private Sound resolveSound(String var1, Sound var2) {
      if (var1 != null && !var1.isBlank()) {
         String var3 = var1.trim();
         NamespacedKey var4 = NamespacedKey.fromString(var3.toLowerCase());
         if (var4 != null) {
            Sound var5 = (Sound)Registry.SOUND_EVENT.get(var4);
            if (var5 != null) {
               return var5;
            }
         }

         String var9 = this.normalizeRegistryName(var3);

         for (Sound var7 : Registry.SOUND_EVENT) {
            NamespacedKey var8 = Registry.SOUND_EVENT.getKey(var7);
            if (var8 != null && this.normalizeRegistryName(var8.toString()).equals(var9)) {
               return var7;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private Particle resolveParticle(String var1, Particle var2) {
      if (var1 != null && !var1.isBlank()) {
         String var3 = var1.trim();
         NamespacedKey var4 = NamespacedKey.fromString(var3.toLowerCase());
         if (var4 != null) {
            Particle var5 = (Particle)Registry.PARTICLE_TYPE.get(var4);
            if (var5 != null) {
               return var5;
            }
         }

         String var9 = this.normalizeRegistryName(var3);

         for (Particle var7 : Registry.PARTICLE_TYPE) {
            NamespacedKey var8 = Registry.PARTICLE_TYPE.getKey(var7);
            if (var8 != null && this.normalizeRegistryName(var8.toString()).equals(var9)) {
               return var7;
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private String normalizeRegistryName(String var1) {
      return var1 == null ? "" : var1.toLowerCase().replace("minecraft:", "").replaceAll("[^a-z0-9]", "");
   }

   private boolean consumeBomb(Player var1, RaidBombType var2) {
      FileConfiguration var3 = this.plugin.getConfigManager().getRaid();
      if (var1.getGameMode() == GameMode.CREATIVE && !var3.getBoolean("consume-item-in-creative", false)) {
         return true;
      }

      PlayerInventory var4 = var1.getInventory();

      for (int var5 = 0; var5 < var4.getSize(); var5++) {
         ItemStack var6 = var4.getItem(var5);
         Optional var7 = this.getBombType(var6);
         if (!var7.isEmpty() && var7.get() == var2) {
            if (var6.getAmount() <= 1) {
               var4.setItem(var5, (ItemStack)null);
            } else {
               var6.setAmount(var6.getAmount() - 1);
               var4.setItem(var5, var6);
            }

            return true;
         }
      }

      return false;
   }

   private long getRemainingCooldownMillis(UUID var1) {
      Long var2 = this.cooldowns.get(var1);
      if (var2 == null) {
         return 0L;
      } else {
         long var3 = var2 - System.currentTimeMillis();
         if (var3 <= 0L) {
            this.cooldowns.remove(var1);
            return 0L;
         } else {
            return var3;
         }
      }
   }

   public boolean hasActiveBombAt(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.activeBombs.containsKey(this.locationKey(var1)) : false;
   }

   private void removeActiveBomb(RaidBombManager.ActiveBomb var1) {
      String var2 = this.locationKey(var1.location());
      this.activeBombs.remove(var2);
      String var3 = this.activeBaseBombs.get(var1.targetBaseId());
      if (var2.equals(var3)) {
         this.activeBaseBombs.remove(var1.targetBaseId());
      }

      if (var1.display() != null && var1.display().isValid()) {
         var1.display().remove();
      }
   }

   public void shutdown() {
      for (RaidBombManager.ActiveBomb var2 : List.copyOf(this.activeBombs.values())) {
         if (var2.task() != null) {
            var2.task().cancel();
         }

         if (var2.display() != null && var2.display().isValid()) {
            var2.display().remove();
         }
      }

      this.activeBombs.clear();
      this.activeBaseBombs.clear();
      this.cooldowns.clear();
      this.protectionManager.shutdown();
   }

   public int getDamage(RaidBombType var1) {
      return Math.max(1, this.plugin.getConfigManager().getRaid().getInt(var1.getConfigPath() + ".damage", var1.getFallbackDamage()));
   }

   public int getRadius(RaidBombType var1) {
      return Math.max(1, this.plugin.getConfigManager().getRaid().getInt(var1.getConfigPath() + ".radius", var1.getFallbackRadius()));
   }

   public int getFuseSeconds(RaidBombType var1) {
      return Math.max(1, this.plugin.getConfigManager().getRaid().getInt(var1.getConfigPath() + ".fuse-seconds", 5));
   }

   public void sendMessage(CommandSender var1, String var2, String... var3) {
      if (var1 != null) {
         String var4 = this.plugin.getConfigManager().getRaid().getString(var2);
         if (var4 != null && !var4.isBlank()) {
            String var5 = this.plugin.getConfigManager().getMessages().getString("prefix", "&#FF8A00ᴢɢᴇɴᴘᴠᴘ &8» &r");
            var4 = var4.replace("%prefix%", var5);
            var4 = this.replace(var4, var3);
            var1.sendMessage(this.component(var4));
         }
      }
   }

   public void sendHelp(CommandSender var1) {
      for (String var3 : this.plugin.getConfigManager().getRaid().getStringList("messages.help")) {
         var1.sendMessage(this.component(var3));
      }
   }

   private void sendActionBar(Player var1, String var2, String... var3) {
      String var4 = this.plugin.getConfigManager().getRaid().getString(var2);
      if (var4 != null && !var4.isBlank()) {
         var1.sendActionBar(this.component(this.replace(var4, var3)));
      }
   }

   private Component component(String var1) {
      return AdventureCompat.deserializeLegacy(ColorUtil.color(var1 == null ? "" : var1));
   }

   private String replace(String var1, String... var2) {
      if (var1 == null) {
         return "";
      }

      String var3 = var1;

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(var2[var4], var2[var4 + 1]);
      }

      return var3;
   }

   private String locationKey(Location var1) {
      String var2 = var1.getWorld().getName();
      return var2 + ":" + var1.getBlockX() + ":" + var1.getBlockY() + ":" + var1.getBlockZ();
   }

   private static final class ActiveBomb {
      private final UUID ownerUuid;
      private final Location location;
      private final RaidBombType type;
      private final BlockDisplay display;
      private final long targetBaseId;
      private final UUID targetOwnerUuid;
      private BukkitTask task;

      private ActiveBomb(UUID var1, Location var2, RaidBombType var3, BlockDisplay var4, long var5, UUID var7) {
         this.ownerUuid = var1;
         this.location = var2;
         this.type = var3;
         this.display = var4;
         this.targetBaseId = var5;
         this.targetOwnerUuid = var7;
      }

      public UUID ownerUuid() {
         return this.ownerUuid;
      }

      public Location location() {
         return this.location;
      }

      public RaidBombType type() {
         return this.type;
      }

      public BlockDisplay display() {
         return this.display;
      }

      public long targetBaseId() {
         return this.targetBaseId;
      }

      public UUID targetOwnerUuid() {
         return this.targetOwnerUuid;
      }

      public BukkitTask task() {
         return this.task;
      }

      public void setTask(BukkitTask var1) {
         this.task = var1;
      }
   }

   private record DamageResult(int affected, int raidTriggerHits) {
   }
}
