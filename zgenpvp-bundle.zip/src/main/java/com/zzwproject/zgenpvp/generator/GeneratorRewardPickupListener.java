package com.zzwproject.zgenpvp.generator;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.util.UUID;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GeneratorRewardPickupListener implements Listener {
   private final ZGenPvP plugin;
   private final GeneratorManager generatorManager;

   public GeneratorRewardPickupListener(ZGenPvP plugin, GeneratorManager generatorManager) {
      this.plugin = plugin;
      this.generatorManager = generatorManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onEntityPickup(EntityPickupItemEvent event) {
      if (event.getEntity() instanceof Player player) {
         if (!this.canPickup(player, event.getItem())) {
            event.setCancelled(true);
            this.plugin.getMessageUtil().sendActionBar(player, "generator.reward-private");
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onAttemptPickup(PlayerAttemptPickupItemEvent event) {
      if (!this.canPickup(event.getPlayer(), event.getItem())) {
         event.setCancelled(true);
         event.setFlyAtPlayer(false);
         this.plugin.getMessageUtil().sendActionBar(event.getPlayer(), "generator.reward-private");
      }
   }

   private boolean canPickup(Player player, Item item) {
      UUID ownerUuid = this.resolveOwner(item);
      return ownerUuid == null ? true : this.generatorManager.canPickupGeneratorDrop(ownerUuid, player.getUniqueId());
   }

   private UUID resolveOwner(Item item) {
      if (item == null) {
         return null;
      }

      String ownerRaw = (String)item.getPersistentDataContainer().get(this.generatorManager.getGeneratorRewardOwnerKey(), PersistentDataType.STRING);
      if (ownerRaw == null) {
         ItemStack stack = item.getItemStack();
         ItemMeta meta = stack.hasItemMeta() ? stack.getItemMeta() : null;
         if (meta != null) {
            ownerRaw = (String)meta.getPersistentDataContainer().get(this.generatorManager.getGeneratorRewardOwnerKey(), PersistentDataType.STRING);
         }
      }

      if (ownerRaw != null && !ownerRaw.isBlank()) {
         try {
            return UUID.fromString(ownerRaw);
         } catch (IllegalArgumentException exception) {
            return null;
         }
      } else {
         return null;
      }
   }
}
