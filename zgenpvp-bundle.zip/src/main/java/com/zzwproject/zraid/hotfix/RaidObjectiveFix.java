package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;

public final class RaidObjectiveFix {
   private RaidObjectiveFix() {
   }

   public static void handleDeath(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            if (!truth(call(var0, "enabled"))) {
               return;
            }

            Object var2 = call(var1, "getEntity");
            if (var2 == null) {
               return;
            }

            Object var3 = tryCall(var2, "getKiller");
            if (var3 == null) {
               return;
            }

            Object var4 = call(var2, "getUniqueId");
            Object var5 = call(var3, "getUniqueId");
            if (!(field(var0, "sessions") instanceof Map var7)) {
               return;
            }

            for (Object var9 : new ArrayList(var7.values())) {
               if (var9 != null) {
                  Object var10 = field(var9, "snapshot");
                  Object var11 = field(var10, "owner");
                  if (eq(var11, var4) && truth(tryCall(var0, "isRaider", var9, var5))) {
                     if (boolField(var9, "ownerKilled")) {
                        return;
                     }

                     setField(var9, "ownerKilled", true);
                     setField(var9, "ownerKilledAt", System.currentTimeMillis());
                     setField(var9, "ownerOfflineSince", 0L);
                     int var12 = ConfigurableRaidRules.requireAllGenerators(var0) ? integer(tryCall(var0, "remainingGeneratorCount", var9)) : 0;
                     if (var12 <= 0) {
                        setField(var9, "beaconUnlockedAnnounced", true);
                        tryCall(var0, "announceObjective", var9, "Üs sahibi öldürüldü ve tüm jeneratörler yok edildi. Respawn Beacon artık hedef.");
                     } else {
                        tryCall(var0, "announceObjective", var9, "Üs sahibi öldürüldü. Kalan jeneratör: " + var12);
                     }

                     updateBossbar(var0, var9, var12);
                     return;
                  }
               }
            }
         } catch (Throwable var13) {
            log(var0, "Raid owner-kill objective hotfix hatası", var13);
         }
      }
   }

   public static void afterGenerator(Object var0, Object var1, Object var2) {
      if (var0 != null && var1 != null) {
         try {
            if (!ConfigurableRaidRules.requireAllGenerators(var0)) {
               updateBossbar(var0, var1, 0);
               return;
            }

            int var3 = integer(tryCall(var0, "remainingGeneratorCount", var1));
            boolean var4 = boolField(var1, "ownerKilled");
            if (var3 <= 0) {
               if (var4) {
                  if (!boolField(var1, "beaconUnlockedAnnounced")) {
                     setField(var1, "beaconUnlockedAnnounced", true);
                     tryCall(var0, "announceObjective", var1, "Tüm jeneratörler yok edildi. Respawn Beacon artık hedef.");
                  }
               } else {
                  tryCall(var0, "announceObjective", var1, "Tüm jeneratörler yok edildi. Şimdi üs sahibini öldür.");
               }
            }

            updateBossbar(var0, var1, var3);
         } catch (Throwable var5) {
            log(var0, "Raid generator objective hotfix hatası", var5);
         }
      }
   }

   public static boolean handleBeacon(Object var0, Object var1, boolean var2) {
      if (var0 != null && var1 != null) {
         try {
            if (!truth(call(var0, "enabled"))) {
               return false;
            }

            Object var3 = call(var1, "getPlayer");
            Object var4 = call(var1, "getBlock");
            if (var3 != null && var4 != null) {
               Object var5 = call(var4, "getLocation");
               Object var6 = field(var0, "core");
               Object var7 = call(var6, "getBeaconManager");
               Object var8 = unwrap(call(var7, "getBeacon", var5));
               if (var8 == null) {
                  return false;
               }

               long var9 = num(call(var8, "getId"));
               Object var11 = tryCall(var0, "sessionByBeaconId", var9);
               if (var11 == null) {
                  var11 = tryCall(var0, "sessionByLocation", var5);
               }

               if (var11 == null) {
                  return false;
               }

               Object var12 = call(var3, "getUniqueId");
               Object var13 = field(field(var11, "snapshot"), "owner");
               cancel(var1, var2);
               if (truth(tryCall(var0, "isDefender", var13, var12))) {
                  stopMining(var0, var3, var4);
                  message(var0, var3, "&cRaid sırasında kendi Respawn Beacon'ını kıramazsın.");
                  return true;
               }

               if (!truth(tryCall(var0, "isRaider", var11, var12))) {
                  stopMining(var0, var3, var4);
                  message(var0, var3, "&cBu raid oturumuna dahil değilsin.");
                  return true;
               }

               if (ConfigurableRaidRules.requireOwnerKill(var0) && !boolField(var11, "ownerKilled")) {
                  stopMining(var0, var3, var4);
                  message(var0, var3, "&cÖnce üs sahibini öldürmelisin.");
                  return true;
               }

               int var14 = integer(tryCall(var0, "remainingGeneratorCount", var11));
               if (ConfigurableRaidRules.requireAllGenerators(var0) && var14 > 0) {
                  stopMining(var0, var3, var4);
                  message(var0, var3, "&cÖnce tüm jeneratörleri yok etmelisin. Kalan: &f" + var14);
                  return true;
               }

               if (!ConfigurableRaidRules.customBeaconHealth(var0)) {
                  if (var2) {
                     cancel(var1, true);
                     tryCall(var0, "completeBeaconObjective", var11, var3, var8, var4);
                     return true;
                  } else {
                     return false;
                  }
               } else {
                  if (var2) {
                     stopMining(var0, var3, var4);
                     int var26 = Math.max(0, intField(var11, "beaconRaidHp"));
                     message(var0, var3, "&eRespawn Beacon raid HP: &f" + var26);
                     return true;
                  }

                  if (ConfigurableRaidRules.beaconRequiresPickaxe(var0) && !isPickaxe(var0, var3)) {
                     stopMining(var0, var3, var4);
                     message(var0, var3, "&cRespawn Beacon'a hasar vermek için kazma kullanmalısın.");
                     return true;
                  }

                  Object var15 = var11;
                  Object var16 = var3;
                  Object var17 = var8;
                  Object var18 = var4;
                  int var19 = Math.max(20, integer(tryCall(var0, "cfgI", "objectives.beacon-raid-hp", 100)));
                  int var20 = Math.max(1, integer(tryCall(var0, "cfgI", "objectives.beacon-damage-per-pulse", 25)));
                  if (intField(var15, "beaconRaidHp") <= 0) {
                     setField(var15, "beaconRaidHp", var19);
                  }

                  IntSupplier var21 = () -> {
                     try {
                        return Math.max(0, intField(var15, "beaconRaidHp"));
                     } catch (Throwable var2x) {
                        return 0;
                     }
                  };
                  IntSupplier var22 = () -> var19;
                  BooleanSupplier var23 = () -> {
                     try {
                        if (field(var0, "sessions") instanceof Map var4x) {
                           Object var5x = field(field(var15, "snapshot"), "base");
                           long var6x = num(field(var5x, "id"));
                           if (var4x.get(var6x) != var15) {
                              return false;
                           }

                           Object var8x = call(var18, "getType");
                           return var8x != null && "BEACON".equalsIgnoreCase(String.valueOf(var8x));
                        } else {
                           return false;
                        }
                     } catch (Throwable var9x) {
                        return false;
                     }
                  };
                  Runnable var24 = () -> {
                     try {
                        if (!var23.getAsBoolean()) {
                           return;
                        }

                        int var8x = Math.max(0, intField(var15, "beaconRaidHp") - var20);
                        setField(var15, "beaconRaidHp", var8x);
                        if (var8x <= 0) {
                           tryCall(var0, "completeBeaconObjective", var15, var16, var17, var18);
                        } else {
                           message(var0, var16, "&eRespawn Beacon raid HP: &f" + var8x + "&7/&f" + var19);
                           updateBossbar(var0, var15, 0);
                        }
                     } catch (Throwable var9x) {
                        log(var0, "Raid beacon pulse hotfix hatası", var9x);
                     }
                  };
                  startEnemyMining(var0, var6, var3, var4, "zraid-beacon:" + var9, var21, var22, var23, var24);
                  return true;
               }
            } else {
               return false;
            }
         } catch (Throwable var25) {
            log(var0, "Raid beacon objective hotfix hatası", var25);
            return false;
         }
      } else {
         return false;
      }
   }

   private static void updateBossbar(Object var0, Object var1, int var2) {
      try {
         long var3 = num(field(var1, "endsAt"));
         long var5 = Math.max(0L, var3 - System.currentTimeMillis());
         tryCall(var0, "updateBossBar", var1, var5, Math.max(0, var2));
      } catch (Throwable var7) {
      }
   }

   private static void startEnemyMining(
      Object var0, Object var1, Object var2, Object var3, String var4, IntSupplier var5, IntSupplier var6, BooleanSupplier var7, Runnable var8
   ) throws Exception {
      Class var9 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var0.getClass().getClassLoader());
      callStatic(var9, "startEnemyMining", var1, var2, var3, var4, var5, var6, var7, var8);
   }

   private static boolean isPickaxe(Object var0, Object var1) {
      try {
         Class var2 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var0.getClass().getClassLoader());
         return truth(callStatic(var2, "isPickaxe", var1));
      } catch (Throwable var3) {
         return false;
      }
   }

   private static void stopMining(Object var0, Object var1, Object var2) {
      try {
         Class var3 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var0.getClass().getClassLoader());

         try {
            callStatic(var3, "stopMining", var1, var2);
         } catch (Throwable var5) {
            callStatic(var3, "stopMining", var1);
         }
      } catch (Throwable var6) {
      }
   }

   private static void cancel(Object var0, boolean var1) {
      tryCall(var0, "setCancelled", true);
      if (var1) {
         tryCall(var0, "setDropItems", false);
         tryCall(var0, "setExpToDrop", 0);
      }
   }

   private static void message(Object var0, Object var1, String var2) {
      try {
         Object var3 = tryCall(var0, "color", var2);
         tryCall(var1, "sendMessage", var3 != null ? String.valueOf(var3) : var2.replace('&', '§'));
      } catch (Throwable var4) {
      }
   }

   private static boolean boolField(Object var0, String var1) throws Exception {
      return truth(field(var0, var1));
   }

   private static int intField(Object var0, String var1) throws Exception {
      return integer(field(var0, var1));
   }

   private static boolean eq(Object var0, Object var1) {
      return var0 == var1 || var0 != null && var0.equals(var1);
   }

   private static boolean truth(Object var0) {
      return var0 instanceof Boolean var1 ? var1 : var0 != null && Boolean.parseBoolean(String.valueOf(var0));
   }

   private static long num(Object var0) {
      return var0 instanceof Number var1 ? var1.longValue() : Long.parseLong(String.valueOf(var0));
   }

   private static int integer(Object var0) {
      return var0 instanceof Number var1 ? var1.intValue() : (var0 == null ? 0 : Integer.parseInt(String.valueOf(var0)));
   }

   private static Object unwrap(Object var0) {
      if (var0 == null) {
         return null;
      } else {
         return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static void setField(Object var0, String var1, Object var2) throws Exception {
      for (Class var3 = var0.getClass(); var3 != null; var3 = var3.getSuperclass()) {
         try {
            Field var4 = var3.getDeclaredField(var1);
            var4.setAccessible(true);
            var4.set(var0, var2);
            return;
         } catch (NoSuchFieldException var5) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         return null;
      }

      Method var3 = findMethod(var0.getClass(), var1, false, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = findMethod(var0, var1, true, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(null, var2);
   }

   private static Method findMethod(Class<?> var0, String var1, boolean var2, Object... var3) {
      for (Class var4 = var0; var4 != null; var4 = var4.getSuperclass()) {
         for (Method var8 : var4.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && (!var2 || Modifier.isStatic(var8.getModifiers())) && var8.getParameterCount() == var3.length) {
               Class[] var9 = var8.getParameterTypes();
               boolean var10 = true;

               for (int var11 = 0; var11 < var9.length; var11++) {
                  if (!fits(var9[var11], var3[var11])) {
                     var10 = false;
                     break;
                  }
               }

               if (var10) {
                  return var8;
               }
            }
         }
      }

      for (Method var15 : var0.getMethods()) {
         if (var15.getName().equals(var1) && (!var2 || Modifier.isStatic(var15.getModifiers())) && var15.getParameterCount() == var3.length) {
            Class[] var16 = var15.getParameterTypes();
            boolean var17 = true;

            for (int var18 = 0; var18 < var16.length; var18++) {
               if (!fits(var16[var18], var3[var18])) {
                  var17 = false;
                  break;
               }
            }

            if (var17) {
               return var15;
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == int.class && var1 instanceof Integer
               || var0 == long.class && var1 instanceof Long
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }

   private static void log(Object var0, String var1, Throwable var2) {
      try {
         Object var3 = tryCall(var0, "getLogger");
         if (var3 != null) {
            tryCall(var3, "warning", "[ZRaid Hotfix] " + var1 + " - " + (var2 == null ? "" : var2.getClass().getSimpleName() + ": " + var2.getMessage()));
         }
      } catch (Throwable var4) {
      }
   }
}
