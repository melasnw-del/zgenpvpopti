package com.zzwproject.zgenpvp.integration;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.ZGenPvP;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class ZShardHook {
   private final ZGenPvP plugin;
   private Plugin zShardPlugin;
   private Object api;
   private Method addShardsMethod;
   private Method removeShardsMethod;
   private Method getBalanceMethod;
   private Method createShardItemMethod;

   public ZShardHook(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   public boolean hook() {
      this.reset();
      Plugin provider = (Plugin)BundleResolver.getPlugin(this.plugin.getServer().getPluginManager(), "ZShard");
      if (provider != null && provider.isEnabled()) {
         Object resolvedApi = this.resolveApi(provider);
         if (resolvedApi == null) {
            this.plugin.getLogger().warning("ZShard bulundu ancak API nesnesi alınamadı.");
            return false;
         } else {
            Method add = this.findMethod(resolvedApi, "addShards");
            if (add == null) {
               this.plugin.getLogger().warning("ZShard API içinde addShards(UUID, long) metodu bulunamadı.");
               return false;
            } else {
               this.zShardPlugin = provider;
               this.api = resolvedApi;
               this.addShardsMethod = add;
               this.removeShardsMethod = this.findMethod(resolvedApi, "removeShards");
               this.getBalanceMethod = this.findBalanceMethod(resolvedApi);
               this.createShardItemMethod = this.findCreateShardItemMethod(resolvedApi);
               this.plugin.getLogger().info("ZShard başarıyla bağlandı: " + provider.getDescription().getVersion());
               return true;
            }
         }
      } else {
         this.plugin.getLogger().info("ZShard bulunamadı. Shard entegrasyonu bekleme modunda.");
         return false;
      }
   }

   public boolean addShards(UUID uuid, long amount) {
      return this.isAvailable() && uuid != null && amount > 0L ? this.invokeMutation(this.addShardsMethod, uuid, amount) : false;
   }

   public boolean removeShards(UUID uuid, long amount) {
      return this.isAvailable() && this.removeShardsMethod != null && uuid != null && amount > 0L
         ? this.invokeMutation(this.removeShardsMethod, uuid, amount)
         : false;
   }

   public long getBalance(UUID uuid) {
      if (this.isAvailable() && this.getBalanceMethod != null && uuid != null) {
         try {
            if (this.getBalanceMethod.invoke(this.api, uuid) instanceof Number number) {
               return Math.max(0L, number.longValue());
            }
         } catch (IllegalAccessException | InvocationTargetException exception) {
            this.plugin.getLogger().warning("ZShard bakiyesi okunamadı: " + exception.getMessage());
         }

         return 0L;
      } else {
         return 0L;
      }
   }

   public boolean isPhysicalItemAvailable() {
      return this.isAvailable() && this.createShardItemMethod != null;
   }

   public ItemStack createShardItem(long value) {
      if (this.isPhysicalItemAvailable() && value > 0L) {
         try {
            Class<?> parameter = this.createShardItemMethod.getParameterTypes()[0];
            Object converted = this.convertNumber(value, parameter);
            if (this.createShardItemMethod.invoke(this.api, converted) instanceof ItemStack item) {
               return item.clone();
            }
         } catch (IllegalAccessException | InvocationTargetException | ArithmeticException exception) {
            this.plugin.getLogger().warning("ZShard fiziksel itemi oluşturulamadı: " + exception.getMessage());
         }

         return null;
      } else {
         return null;
      }
   }

   public boolean isAvailable() {
      return this.zShardPlugin != null && this.zShardPlugin.isEnabled() && this.api != null && this.addShardsMethod != null;
   }

   public String getProviderName() {
      return !this.isAvailable() ? "Bağlı Değil" : this.zShardPlugin.getName() + " " + this.zShardPlugin.getDescription().getVersion();
   }

   private Object resolveApi(Plugin provider) {
      String[] getterNames = new String[]{"getApi", "getAPI", "getShardApi", "getShardAPI"};

      for (String getterName : getterNames) {
         try {
            Method getter = provider.getClass().getMethod(getterName);
            Object result = getter.invoke(provider);
            if (result != null) {
               return result;
            }
         } catch (NoSuchMethodException var9) {
         } catch (IllegalAccessException | InvocationTargetException exception) {
            this.plugin.getLogger().warning("ZShard API getter çalıştırılamadı: " + getterName + " -> " + exception.getMessage());
         }
      }

      return provider;
   }

   private Method findMethod(Object target, String name) {
      for (Method method : target.getClass().getMethods()) {
         if (method.getName().equals(name)) {
            Class<?>[] parameters = method.getParameterTypes();
            if (parameters.length == 2 && UUID.class.isAssignableFrom(parameters[0]) && this.isSupportedNumber(parameters[1])) {
               return method;
            }
         }
      }

      return null;
   }

   private Method findBalanceMethod(Object target) {
      String[] names = new String[]{"getBalance", "getShards", "getShardBalance"};

      for (String name : names) {
         try {
            return target.getClass().getMethod(name, UUID.class);
         } catch (NoSuchMethodException var8) {
         }
      }

      return null;
   }

   private Method findCreateShardItemMethod(Object target) {
      for (Method method : target.getClass().getMethods()) {
         if (method.getName().equals("createShardItem")) {
            Class<?>[] parameters = method.getParameterTypes();
            if (parameters.length == 1 && this.isSupportedNumber(parameters[0]) && ItemStack.class.isAssignableFrom(method.getReturnType())) {
               return method;
            }
         }
      }

      return null;
   }

   private boolean invokeMutation(Method method, UUID uuid, long amount) {
      try {
         Class<?> numberType = method.getParameterTypes()[1];
         Object convertedAmount = this.convertNumber(amount, numberType);
         return method.invoke(this.api, uuid, convertedAmount) instanceof Boolean value ? value : true;
      } catch (IllegalAccessException | InvocationTargetException exception) {
         this.plugin.getLogger().warning("ZShard API işlemi başarısız: " + exception.getMessage());
         return false;
      }
   }

   private boolean isSupportedNumber(Class<?> type) {
      return type == long.class || type == Long.class || type == int.class || type == Integer.class;
   }

   private Object convertNumber(long amount, Class<?> type) {
      return type != int.class && type != Integer.class ? amount : Math.toIntExact(amount);
   }

   private void reset() {
      this.zShardPlugin = null;
      this.api = null;
      this.addShardsMethod = null;
      this.removeShardsMethod = null;
      this.getBalanceMethod = null;
      this.createShardItemMethod = null;
   }
}
