package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class BeaconMenu {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final NamespacedKey actionKey;

   public BeaconMenu(ZGenPvP var1, BeaconManager var2) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.actionKey = new NamespacedKey(var1, "beacon_menu_action");
   }

   public void open(Player var1) {
      if (var1 != null) {
         BeaconData var2 = this.beaconManager.getBeacon(var1.getUniqueId()).orElse(null);
         if (var2 == null) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
         } else {
            this.open(var1, var2);
         }
      }
   }

   public void open(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         BeaconData var3 = this.beaconManager.getBeacon(var2.getId()).filter(var1x -> var1x.getId() == var2.getId()).orElse(null);
         if (var3 == null) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
         } else if (!this.beaconManager.canUseBeacon(var1, var3)) {
            this.beaconManager.sendOwnerInfo(var1, var3);
         } else {
            FileConfiguration var4 = this.plugin.getConfigManager().getMenus();
            int var5 = this.normalizeSize(var4.getInt("beacon.size", 27));
            BeaconMenu.BeaconMenuHolder var6 = new BeaconMenu.BeaconMenuHolder(var3.getId(), var3.getOwnerUuid());
            Inventory var7 = Bukkit.createInventory(var6, var5, this.getMainTitle());
            var6.setInventory(var7);
            this.fill(var7, "beacon.filler");
            OfflinePlayer var8 = Bukkit.getOfflinePlayer(var3.getOwnerUuid());
            String var9 = var8.getName() == null ? "Bilinmeyen" : var8.getName();
            this.setItem(
               var7,
               "beacon.info",
               null,
               "%beacon_name%",
               var3.getName(),
               "%owner%",
               var9,
               "%world%",
               var3.getWorldName(),
               "%x%",
               String.valueOf(var3.getX()),
               "%y%",
               String.valueOf(var3.getY()),
               "%z%",
               String.valueOf(var3.getZ())
            );
            this.setItem(var7, "beacon.teleport", "TELEPORT", "%beacon_name%", var3.getName(), "%owner%", var9);
            if (this.beaconManager.isOwner(var1, var3)) {
               this.setItem(var7, "beacon.rename", "RENAME", "%beacon_name%", var3.getName(), "%owner%", var9);
               this.setItem(var7, "beacon.remove", "REMOVE", "%beacon_name%", var3.getName(), "%owner%", var9);
            }

            var1.openInventory(var7);
            this.plugin.getSoundUtil().play(var1, "beacon-menu-open");
         }
      }
   }

   public void openConfirmation(Player var1) {
      if (var1 != null) {
         BeaconData var2 = this.beaconManager.getBeacon(var1.getUniqueId()).orElse(null);
         if (var2 == null) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
         } else {
            this.openConfirmation(var1, var2);
         }
      }
   }

   public void openConfirmation(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         BeaconData var3 = this.beaconManager.getBeacon(var2.getId()).filter(var1x -> var1x.getId() == var2.getId()).orElse(null);
         if (var3 == null) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
         } else if (!this.beaconManager.isOwner(var1, var3)) {
            this.beaconManager.sendOwnerInfo(var1, var3);
         } else {
            FileConfiguration var4 = this.plugin.getConfigManager().getMenus();
            int var5 = this.normalizeSize(var4.getInt("beacon-confirm.size", 27));
            BeaconMenu.ConfirmationHolder var6 = new BeaconMenu.ConfirmationHolder(var3.getId(), var3.getOwnerUuid());
            Inventory var7 = Bukkit.createInventory(var6, var5, this.getConfirmationTitle());
            var6.setInventory(var7);
            this.fill(var7, "beacon-confirm.filler");
            this.setRequiredConfirmationItem(
               var7,
               "beacon-confirm.yes",
               "CONFIRM_YES",
               11,
               Material.LIME_CONCRETE,
               "&a✦ Evet",
               List.of("", "&7Feneri envanterine geri al.", "", "&aTıklayarak onayla.")
            );
            this.setRequiredConfirmationItem(
               var7,
               "beacon-confirm.no",
               "CONFIRM_NO",
               15,
               Material.RED_CONCRETE,
               "&c✕ Hayir",
               List.of("", "&7Kaldirma işlemini iptal et.", "", "&cTıklayarak geri dön.")
            );
            var1.openInventory(var7);
         }
      }
   }

   public boolean isMainMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BeaconMenu.BeaconMenuHolder;
   }

   public boolean isConfirmationMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BeaconMenu.ConfirmationHolder;
   }

   public Optional<BeaconData> getBeacon(Inventory var1) {
      if (var1 == null) {
         return Optional.empty();
      } else if (var1.getHolder() instanceof BeaconMenu.BeaconMenuHolder var4) {
         return this.findBeacon(var4.beaconId(), var4.ownerUuid());
      } else {
         return var1.getHolder() instanceof BeaconMenu.ConfirmationHolder var2 ? this.findBeacon(var2.beaconId(), var2.ownerUuid()) : Optional.empty();
      }
   }

   private Optional<BeaconData> findBeacon(long var1, UUID var3) {
      return this.beaconManager.getBeacon(var1).filter(var3x -> var3x.getId() == var1 && var3x.getOwnerUuid().equals(var3));
   }

   public String getMainTitle() {
      return ColorUtil.color(this.plugin.getConfigManager().getMenus().getString("beacon.title", "&8Yeniden doğma feneri"));
   }

   public String getConfirmationTitle() {
      return ColorUtil.color(this.plugin.getConfigManager().getMenus().getString("beacon-confirm.title", "&8Beaconi kaldir?"));
   }

   public String getAction(ItemStack var1) {
      return var1 != null && var1.hasItemMeta() ? (String)var1.getItemMeta().getPersistentDataContainer().get(this.actionKey, PersistentDataType.STRING) : null;
   }

   private void fill(Inventory var1, String var2) {
      FileConfiguration var3 = this.plugin.getConfigManager().getMenus();
      if (var3.getBoolean(var2 + ".enabled", true)) {
         ItemStack var4 = this.createItem(var2, null);

         for (int var5 = 0; var5 < var1.getSize(); var5++) {
            var1.setItem(var5, var4);
         }
      }
   }

   private void setItem(Inventory var1, String var2, String var3, String... var4) {
      FileConfiguration var5 = this.plugin.getConfigManager().getMenus();
      int var6 = var5.getInt(var2 + ".slot", -1);
      if (var6 >= 0 && var6 < var1.getSize()) {
         var1.setItem(var6, this.createItem(var2, var3, var4));
      }
   }

   private void setRequiredConfirmationItem(Inventory var1, String var2, String var3, int var4, Material var5, String var6, List<String> var7) {
      FileConfiguration var8 = this.plugin.getConfigManager().getMenus();
      int var9 = var8.getInt(var2 + ".slot", var4);
      if (var9 < 0 || var9 >= var1.getSize()) {
         var9 = var4;
      }

      String var10 = var8.getString(var2 + ".material");
      ItemStack var11;
      if (var10 != null && !var10.isBlank()) {
         var11 = this.createItem(var2, var3);
         if (var11 == null || var11.getType().isAir()) {
            var11 = this.createFallbackActionItem(var5, var6, var7, var3);
         }
      } else {
         var11 = this.createFallbackActionItem(var5, var6, var7, var3);
      }

      var1.setItem(var9, var11);
   }

   private ItemStack createFallbackActionItem(Material var1, String var2, List<String> var3, String var4) {
      ItemStack var5 = new ItemStack(var1);
      ItemMeta var6 = var5.getItemMeta();
      if (var6 == null) {
         return var5;
      }

      var6.setDisplayName(ColorUtil.color(var2));
      ArrayList var7 = new ArrayList();

      for (String var9 : var3) {
         var7.add(ColorUtil.color(var9));
      }

      var6.setLore(var7);
      var6.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, var4);
      var5.setItemMeta(var6);
      return var5;
   }

   private ItemStack createItem(String var1, String var2, String... var3) {
      FileConfiguration var4 = this.plugin.getConfigManager().getMenus();
      String var5 = var4.getString(var1 + ".material", "STONE");
      Material var6 = Material.matchMaterial(var5 == null ? "STONE" : var5);
      if (var6 == null || var6.isAir()) {
         var6 = Material.STONE;
      }

      ItemStack var7 = new ItemStack(var6);
      ItemMeta var8 = var7.getItemMeta();
      if (var8 == null) {
         return var7;
      }

      String var9 = this.replace(var4.getString(var1 + ".name", " "), var3);
      var8.setDisplayName(ColorUtil.color(var9));
      ArrayList var10 = new ArrayList();

      for (String var12 : var4.getStringList(var1 + ".lore")) {
         var10.add(ColorUtil.color(this.replace(var12, var3)));
      }

      var8.setLore(var10);
      if (var2 != null) {
         var8.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, var2);
      }

      var7.setItemMeta(var8);
      return var7;
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private int normalizeSize(int var1) {
      if (var1 < 9) {
         return 9;
      }

      if (var1 > 54) {
         return 54;
      }

      int var2 = var1 % 9;
      if (var2 != 0) {
         var1 += 9 - var2;
      }

      return Math.min(54, var1);
   }

   private static final class BeaconMenuHolder implements InventoryHolder {
      private final long beaconId;
      private final UUID ownerUuid;
      private Inventory inventory;

      private BeaconMenuHolder(long var1, UUID var3) {
         this.beaconId = var1;
         this.ownerUuid = var3;
      }

      private long beaconId() {
         return this.beaconId;
      }

      private UUID ownerUuid() {
         return this.ownerUuid;
      }

      private void setInventory(Inventory var1) {
         this.inventory = var1;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }

   private static final class ConfirmationHolder implements InventoryHolder {
      private final long beaconId;
      private final UUID ownerUuid;
      private Inventory inventory;

      private ConfirmationHolder(long var1, UUID var3) {
         this.beaconId = var1;
         this.ownerUuid = var3;
      }

      private long beaconId() {
         return this.beaconId;
      }

      private UUID ownerUuid() {
         return this.ownerUuid;
      }

      private void setInventory(Inventory var1) {
         this.inventory = var1;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }
}
