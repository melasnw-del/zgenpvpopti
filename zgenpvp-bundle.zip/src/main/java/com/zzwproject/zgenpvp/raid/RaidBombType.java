package com.zzwproject.zgenpvp.raid;

import java.util.Optional;

public enum RaidBombType {
   TIER_1(1, 150, 4),
   TIER_2(2, 300, 5),
   TIER_3(3, 500, 6);

   private final int id;
   private final int fallbackDamage;
   private final int fallbackRadius;

   RaidBombType(int id, int fallbackDamage, int fallbackRadius) {
      this.id = id;
      this.fallbackDamage = fallbackDamage;
      this.fallbackRadius = fallbackRadius;
   }

   public int getId() {
      return this.id;
   }

   public int getFallbackDamage() {
      return this.fallbackDamage;
   }

   public int getFallbackRadius() {
      return this.fallbackRadius;
   }

   public String getConfigPath() {
      return "tiers." + this.id;
   }

   public String getDisplayName() {
      return "raid bombasi " + this.id;
   }

   public static Optional<RaidBombType> fromId(int id) {
      for (RaidBombType type : values()) {
         if (type.id == id) {
            return Optional.of(type);
         }
      }

      return Optional.empty();
   }
}
