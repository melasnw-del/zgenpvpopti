package com.zzwproject.zgenpvp.base;

import com.zzwproject.compat.ItemMetaCompat;
import com.zzwproject.compat.Paper12111Compat;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

public final class BaseMenu {
   private final ZGenPvP plugin;
   private final BaseManager baseManager;
   private final BaseEnergyManager energyManager;
   private final NamespacedKey actionKey;

   public BaseMenu(ZGenPvP var1, BaseManager var2, BaseEnergyManager var3) {
      this.plugin = var1;
      this.baseManager = var2;
      this.energyManager = var3;
      this.actionKey = new NamespacedKey(var1, "base_menu_action");
   }

   public void open(Player var1) {
      if (var1 != null) {
         this.baseManager.getBase(var1.getUniqueId()).ifPresent(var2 -> this.open(var1, var2));
      }
   }

   public void open(Player var1, BaseData var2) {
      BaseData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         Inventory var4 = this.createInventory(var3, BaseMenu.Screen.MAIN, this.cfgInt("base.size", 27), this.cfgString("base.title", "&8ʙᴀꜱᴇ ʙʟᴏɢᴜ"));
         this.fill(var4, "base.filler");
         OfflinePlayer var5 = Bukkit.getOfflinePlayer(var3.getOwnerUuid());
         String var6 = var5.getName() == null ? "Bilinmeyen" : var5.getName();
         int var7 = this.plugin.getConfigManager().getConfig().getInt("base.max-level", 10);
         int var8 = Math.min(var7, var3.getLevel() + 1);
         int var9 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_BLOCK")
            + this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_TANK");
         int var10 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "TURRET");
         int var11 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_DOOR");
         int var12 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_TRAPDOOR");
         int var13 = this.plugin.getGeneratorRepository().findAllByBase(var3.getId()).size();
         BaseEnergyManager.EnergySnapshot var14 = this.energyManager.getSnapshot(var3);
         this.setItem(
            var4,
            "base.info",
            (String)null,
            var3.getOwnerUuid(),
            "%base_name%",
            var3.getName(),
            "%owner%",
            var6,
            "%level%",
            String.valueOf(var3.getLevel()),
            "%max_level%",
            String.valueOf(var7),
            "%health%",
            String.valueOf(var3.getCurrentHp()),
            "%max_health%",
            String.valueOf(var3.getMaxHp()),
            "%radius%",
            String.valueOf(var3.getRadius()),
            "%block_limit%",
            String.valueOf(var3.getBlockLimit()),
            "%world%",
            var3.getWorldName(),
            "%x%",
            String.valueOf(var3.getX()),
            "%y%",
            String.valueOf(var3.getY()),
            "%z%",
            String.valueOf(var3.getZ())
         );
         this.setItem(
            var4,
            "base.owner",
            (String)null,
            var3.getOwnerUuid(),
            "%owner%",
            var6,
            "%world%",
            var3.getWorldName(),
            "%x%",
            String.valueOf(var3.getX()),
            "%y%",
            String.valueOf(var3.getY()),
            "%z%",
            String.valueOf(var3.getZ())
         );
         this.setItem(
            var4,
            "base.linked",
            "OPEN_LINKED",
            (UUID)null,
            "%defense_count%",
            String.valueOf(var9),
            "%turret_count%",
            String.valueOf(var10),
            "%door_count%",
            String.valueOf(var11),
            "%trapdoor_count%",
            String.valueOf(var12),
            "%generator_count%",
            String.valueOf(var13),
            "%total_count%",
            String.valueOf(var9 + var10 + var11 + var12 + var13)
         );
         this.setItem(
            var4,
            "base.upgrade",
            "OPEN_UPGRADE_CONFIRM",
            (UUID)null,
            "%level%",
            String.valueOf(var3.getLevel()),
            "%next_level%",
            String.valueOf(var8),
            "%next_health%",
            String.valueOf(this.baseManager.getHealth(var8)),
            "%next_radius%",
            String.valueOf(this.baseManager.getRadius(var8)),
            "%next_limit%",
            String.valueOf(this.baseManager.getBlockLimit(var8)),
            "%price%",
            this.format(this.baseManager.getUpgradePrice(var3.getLevel()))
         );
         this.setItem(
            var4,
            "base.power",
            "OPEN_POWER",
            (UUID)null,
            "%status%",
            var14.active() ? "Aktif" : "Bitti",
            "%energy%",
            this.format(var14.energy()),
            "%max_energy%",
            this.format(var14.maxEnergy()),
            "%consumption%",
            this.format(var14.consumptionPerHour()),
            "%remaining%",
            this.energyManager.formatDuration(var14.remainingHours()),
            "%max_duration%",
            this.energyManager.formatDuration(var14.maxHours()),
            "%full_price%",
            this.format(var14.fullPrice())
         );
         this.setItem(var4, "base.rename", "RENAME", (UUID)null, "%base_name%", var3.getName());
         this.setItem(var4, "base.remove", "OPEN_REMOVE_CONFIRM", (UUID)null, "%base_name%", var3.getName());
         Paper12111Compat.openInventory(var1, var4);
         this.plugin.getSoundUtil().play(var1, "base-menu-open");
      }
   }

   public void openPower(Player var1, BaseData var2) {
      BaseData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         Inventory var4 = this.createInventory(
            var3, BaseMenu.Screen.POWER, this.cfgInt("base.power-menu.size", 27), this.cfgString("base.power-menu.title", "&8ʙᴀꜱᴇ ɢᴜᴄᴜ")
         );
         this.fill(var4, "base.power-menu.filler");
         BaseEnergyManager.EnergySnapshot var5 = this.energyManager.getSnapshot(var3);
         this.setItem(
            var4,
            "base.power-menu.info",
            (String)null,
            (UUID)null,
            "%status%",
            var5.active() ? "Aktif" : "Bitti",
            "%energy%",
            this.format(var5.energy()),
            "%max_energy%",
            this.format(var5.maxEnergy()),
            "%consumption%",
            this.format(var5.consumptionPerHour()),
            "%remaining%",
            this.energyManager.formatDuration(var5.remainingHours()),
            "%max_duration%",
            this.energyManager.formatDuration(var5.maxHours()),
            "%full_price%",
            this.format(var5.fullPrice())
         );
         this.setPowerPurchase(var4, var3, "base.power-menu.one-hour", "OPEN_POWER_CONFIRM_1", 1.0);
         this.setPowerPurchase(var4, var3, "base.power-menu.six-hours", "OPEN_POWER_CONFIRM_6", 6.0);
         this.setPowerPurchase(var4, var3, "base.power-menu.twelve-hours", "OPEN_POWER_CONFIRM_12", 12.0);
         this.setPowerPurchase(var4, var3, "base.power-menu.twenty-four-hours", "OPEN_POWER_CONFIRM_24", 24.0);
         BaseEnergyManager.PurchasePreview var6 = this.energyManager.previewFull(var3);
         this.setItem(
            var4, "base.power-menu.full", "OPEN_POWER_CONFIRM_FULL", (UUID)null, "%add_fu%", this.format(var6.addFu()), "%price%", this.format(var6.price())
         );
         this.setItem(var4, "base.power-menu.back", "BACK_MAIN", (UUID)null);
         Paper12111Compat.openInventory(var1, var4);
         this.plugin.getSoundUtil().play(var1, "base-power-menu-open");
      }
   }

   private void setPowerPurchase(Inventory var1, BaseData var2, String var3, String var4, double var5) {
      BaseEnergyManager.PurchasePreview var7 = this.energyManager.previewHours(var2, var5);
      this.setItem(var1, var3, var4, (UUID)null, "%hours%", this.format(var5), "%add_fu%", this.format(var7.addFu()), "%price%", this.format(var7.price()));
   }

   public void openLinked(Player var1, BaseData var2) {
      BaseData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         Inventory var4 = this.createInventory(
            var3, BaseMenu.Screen.LINKED, this.cfgInt("base.linked-menu.size", 27), this.cfgString("base.linked-menu.title", "&8ʙᴀɢʟɪ ʙʟᴏᴋʟᴀʀ")
         );
         this.fill(var4, "base.linked-menu.filler");
         int var5 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_BLOCK")
            + this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_TANK");
         int var6 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "TURRET");
         int var7 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_DOOR");
         int var8 = this.plugin.getDefenseRepository().countByBaseAndType(var3.getId(), "DEFENSE_TRAPDOOR");
         int var9 = this.plugin.getGeneratorRepository().findAllByBase(var3.getId()).size();
         this.setItem(var4, "base.linked-menu.defense", "OPEN_LINKED_DEFENSE_BLOCK", (UUID)null, "%count%", String.valueOf(var5));
         this.setItem(var4, "base.linked-menu.turret", "OPEN_LINKED_TURRET", (UUID)null, "%count%", String.valueOf(var6));
         this.setItem(var4, "base.linked-menu.door", "OPEN_LINKED_DEFENSE_DOOR", (UUID)null, "%count%", String.valueOf(var7));
         this.setItem(var4, "base.linked-menu.trapdoor", "OPEN_LINKED_DEFENSE_TRAPDOOR", (UUID)null, "%count%", String.valueOf(var8));
         this.setItem(var4, "base.linked-menu.generator", "OPEN_LINKED_GENERATOR", (UUID)null, "%count%", String.valueOf(var9));
         this.setItem(var4, "base.linked-menu.back", "BACK_MAIN", (UUID)null);
         Paper12111Compat.openInventory(var1, var4);
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public void openUpgradeConfirm(Player var1, BaseData var2) {
      BaseData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         int var4 = this.plugin.getConfigManager().getConfig().getInt("base.max-level", 10);
         int var5 = Math.min(var4, var3.getLevel() + 1);
         Inventory var6 = this.createInventory(
            var3,
            BaseMenu.Screen.UPGRADE_CONFIRM,
            this.cfgInt("base.upgrade-confirm.size", 27),
            this.cfgString("base.upgrade-confirm.title", "&8Üs &8• &fYükseltme Onayı")
         );
         this.fill(var6, "base.upgrade-confirm.filler");
         this.setItem(
            var6,
            "base.upgrade-confirm.confirm",
            "CONFIRM_UPGRADE",
            (UUID)null,
            "%level%",
            String.valueOf(var3.getLevel()),
            "%next_level%",
            String.valueOf(var5),
            "%next_health%",
            String.valueOf(this.baseManager.getHealth(var5)),
            "%next_radius%",
            String.valueOf(this.baseManager.getRadius(var5)),
            "%next_limit%",
            String.valueOf(this.baseManager.getBlockLimit(var5)),
            "%price%",
            this.format(this.baseManager.getUpgradePrice(var3.getLevel()))
         );
         this.setItem(
            var6,
            "base.upgrade-confirm.info",
            (String)null,
            (UUID)null,
            "%level%",
            String.valueOf(var3.getLevel()),
            "%next_level%",
            String.valueOf(var5),
            "%next_health%",
            String.valueOf(this.baseManager.getHealth(var5)),
            "%next_radius%",
            String.valueOf(this.baseManager.getRadius(var5)),
            "%next_limit%",
            String.valueOf(this.baseManager.getBlockLimit(var5)),
            "%price%",
            this.format(this.baseManager.getUpgradePrice(var3.getLevel()))
         );
         this.setItem(var6, "base.upgrade-confirm.cancel", "BACK_MAIN", (UUID)null);
         Paper12111Compat.openInventory(var1, var6);
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public void openPowerConfirm(Player var1, BaseData var2, String var3) {
      BaseData var4 = this.resolve(var1, var2);
      if (var4 != null) {
         boolean var5 = "FULL".equalsIgnoreCase(var3);
         double var10000;
         if (var5) {
            var10000 = 0.0;
         } else {
            switch (var3) {
               case "1":
                  var10000 = 1.0;
                  break;
               case "6":
                  var10000 = 6.0;
                  break;
               case "12":
                  var10000 = 12.0;
                  break;
               case "24":
                  var10000 = 24.0;
                  break;
               default:
                  var10000 = 0.0;
            }
         }

         double var6 = var10000;
         BaseEnergyManager.PurchasePreview var11 = var5 ? this.energyManager.previewFull(var4) : this.energyManager.previewHours(var4, var6);
         String var12 = var5 ? "CONFIRM_POWER_FULL" : "CONFIRM_POWER_" + var3;
         Inventory var10 = this.createInventory(
            var4,
            BaseMenu.Screen.POWER_CONFIRM,
            this.cfgInt("base.power-confirm.size", 27),
            this.cfgString("base.power-confirm.title", "&8Üs &8• &fEnerji Onayı")
         );
         this.fill(var10, "base.power-confirm.filler");
         this.setItem(
            var10,
            "base.power-confirm.confirm",
            var12,
            (UUID)null,
            "%mode%",
            var5 ? "Tam dolum" : var3 + " saat",
            "%add_fu%",
            this.format(var11.addFu()),
            "%price%",
            this.format(var11.price())
         );
         this.setItem(
            var10,
            "base.power-confirm.info",
            (String)null,
            (UUID)null,
            "%mode%",
            var5 ? "Tam dolum" : var3 + " saat",
            "%add_fu%",
            this.format(var11.addFu()),
            "%price%",
            this.format(var11.price())
         );
         this.setItem(var10, "base.power-confirm.cancel", "BACK_POWER", (UUID)null);
         Paper12111Compat.openInventory(var1, var10);
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public void openLinkedList(Player var1, BaseData var2, String var3, int var4) {
      BaseData var5 = this.resolve(var1, var2);
      if (var5 != null) {
         String var6 = var3 == null ? "DEFENSE_BLOCK" : var3.toUpperCase();
         ArrayList var7 = new ArrayList();
         if ("GENERATOR".equals(var6)) {
            for (GeneratorData var9 : this.plugin.getGeneratorRepository().findAllByBase(var5.getId())) {
               var7.add(new BaseMenu.LinkedEntry(var9.getId(), "GENERATOR", var9.getLevel(), 0, 0, var9.getWorldName(), var9.getX(), var9.getY(), var9.getZ()));
            }
         } else {
            for (DefenseData var19 : this.plugin.getDefenseRepository().findAllByBase(var5.getId())) {
               boolean var10 = var6.equalsIgnoreCase(var19.getType()) || "DEFENSE_BLOCK".equals(var6) && "DEFENSE_TANK".equalsIgnoreCase(var19.getType());
               if (var10) {
                  String var11 = "DEFENSE_TANK".equalsIgnoreCase(var19.getType()) ? "DEFENSE_BLOCK" : var19.getType();
                  var7.add(
                     new BaseMenu.LinkedEntry(
                        var19.getId(),
                        var11,
                        var19.getLevel(),
                        var19.getCurrentHp(),
                        var19.getMaxHp(),
                        var19.getWorldName(),
                        var19.getX(),
                        var19.getY(),
                        var19.getZ()
                     )
                  );
               }
            }
         }

         var7.sort(Comparator.comparingLong(BaseMenu.LinkedEntry::id));
         byte var18 = 36;
         int var20 = Math.max(1, (int)Math.ceil((double)var7.size() / var18));
         int var21 = Math.max(0, Math.min(var4, var20 - 1));
         String var22 = this.cfgString("base.linked-list.title", "&8Bağlı Yapılar &8• &f%type% &8(%page%/%pages%)")
            .replace("%type%", this.prettyType(var6))
            .replace("%page%", String.valueOf(var21 + 1))
            .replace("%pages%", String.valueOf(var20));
         Inventory var12 = this.createInventory(var5, BaseMenu.Screen.LINKED_LIST, 54, var22, var6, var21);
         this.fill(var12, "base.linked-list.filler");
         int[] var13 = new int[]{
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35
         };
         int var14 = var21 * var18;

         for (int var15 = 0; var15 < var18 && var14 + var15 < var7.size(); var15++) {
            BaseMenu.LinkedEntry var16 = (BaseMenu.LinkedEntry)var7.get(var14 + var15);
            var12.setItem(var13[var15], this.createLinkedEntryItem(var16));
         }

         this.setItem(var12, "base.linked-list.back", "BACK_LINKED", (UUID)null);
         if (!"TURRET".equals(var6)) {
            this.setItem(
               var12,
               "base.linked-list.bulk-upgrade",
               "BULK_UPGRADE_" + var6,
               (UUID)null,
               "%count%",
               String.valueOf(var7.size()),
               "%type%",
               this.prettyType(var6)
            );
         }

         this.setItem(
            var12,
            "base.linked-list.info",
            (String)null,
            (UUID)null,
            "%count%",
            String.valueOf(var7.size()),
            "%type%",
            this.prettyType(var6),
            "%page%",
            String.valueOf(var21 + 1),
            "%pages%",
            String.valueOf(var20)
         );
         if (var21 > 0) {
            this.setItem(var12, "base.linked-list.previous", "LINKED_PAGE_" + var6 + "_" + (var21 - 1), (UUID)null);
         }

         if (var21 + 1 < var20) {
            this.setItem(var12, "base.linked-list.next", "LINKED_PAGE_" + var6 + "_" + (var21 + 1), (UUID)null);
         }

         Paper12111Compat.openInventory(var1, var12);
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public String getLinkedType(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BaseMenu.BaseMenuHolder var2 ? var2.linkedType : null;
   }

   public int getLinkedPage(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BaseMenu.BaseMenuHolder var2 ? var2.page : 0;
   }

   private ItemStack createLinkedEntryItem(BaseMenu.LinkedEntry var1) {
      Material var2 = switch (var1.type()) {
         case "TURRET" -> Material.BLAST_FURNACE;
         case "DEFENSE_DOOR" -> Material.IRON_DOOR;
         case "DEFENSE_TRAPDOOR" -> Material.IRON_TRAPDOOR;
         case "GENERATOR" -> Material.DEEPSLATE_REDSTONE_ORE;
         default -> Material.MOSSY_COBBLESTONE;
      };
      ItemStack var6 = new ItemStack(var2);
      ItemMeta var7 = var6.getItemMeta();
      if (var7 != null) {
         var7.setDisplayName(ColorUtil.color("&f" + this.prettyType(var1.type()) + " &8#" + var1.id()));
         ArrayList var5 = new ArrayList();
         var5.add(ColorUtil.color("&7Seviye: &e" + var1.level()));
         if (var1.maxHp() > 0) {
            var5.add(ColorUtil.color("&7Can: &a" + var1.hp() + "&7/&f" + var1.maxHp()));
         }

         var5.add(ColorUtil.color("&7Konum: &f" + var1.world() + " &8(&f" + var1.x() + ", " + var1.y() + ", " + var1.z() + "&8)"));
         var7.setLore(var5);
         ItemMetaCompat.apply(var6, var7);
      }

      return var6;
   }

   private String prettyType(String var1) {
      return switch (var1) {
         case "TURRET" -> "Taret";
         case "DEFENSE_DOOR" -> "Defans Kapısı";
         case "DEFENSE_TRAPDOOR" -> "Tuzak Kapısı";
         case "GENERATOR" -> "Jeneratör";
         default -> "Defans Bloğu";
      };
   }

   public void openRemoveConfirm(Player var1, BaseData var2) {
      BaseData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         if (!var3.getOwnerUuid().equals(var1.getUniqueId())) {
            this.baseManager.sendOwnerInfo(var1, var3);
         } else {
            Inventory var4 = this.createInventory(
               var3,
               BaseMenu.Screen.REMOVE_CONFIRM,
               this.cfgInt("base.remove-confirm.size", 27),
               this.cfgString("base.remove-confirm.title", "&cʙᴀꜱᴇ ʙʟᴏɢᴜɴᴜ ᴋɪʀ?")
            );
            this.fill(var4, "base.remove-confirm.filler");
            this.setItem(var4, "base.remove-confirm.confirm", "CONFIRM_REMOVE", (UUID)null, "%base_name%", var3.getName());
            this.setItem(var4, "base.remove-confirm.cancel", "BACK_MAIN", (UUID)null);
            Paper12111Compat.openInventory(var1, var4);
            this.plugin.getSoundUtil().play(var1, "button");
         }
      }
   }

   public boolean isMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BaseMenu.BaseMenuHolder;
   }

   public BaseMenu.Screen getScreen(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BaseMenu.BaseMenuHolder var3 ? var3.screen : null;
   }

   public Optional<BaseData> getBase(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BaseMenu.BaseMenuHolder var3
         ? this.baseManager.getBase(var3.ownerUuid).filter(var1x -> var1x.getId() == var3.baseId)
         : Optional.empty();
   }

   public String getAction(ItemStack var1) {
      return var1 != null && !var1.getType().isAir() && var1.hasItemMeta()
         ? (String)var1.getItemMeta().getPersistentDataContainer().get(this.actionKey, PersistentDataType.STRING)
         : null;
   }

   public String getTitle() {
      return ColorUtil.color(this.cfgString("base.title", "&8ʙᴀꜱᴇ ʙʟᴏɢᴜ"));
   }

   private BaseData resolve(Player var1, BaseData var2) {
      if (var1 != null && var2 != null) {
         BaseData var3 = this.baseManager.getBase(var2.getOwnerUuid()).filter(var1x -> var1x.getId() == var2.getId()).orElse(null);
         if (var3 == null) {
            var1.closeInventory();
            return null;
         } else if (!this.baseManager.canManageBase(var1, var3)) {
            this.baseManager.sendOwnerInfo(var1, var3);
            return null;
         } else {
            return var3;
         }
      } else {
         return null;
      }
   }

   private Inventory createInventory(BaseData var1, BaseMenu.Screen var2, int var3, String var4) {
      return this.createInventory(var1, var2, var3, var4, null, 0);
   }

   private Inventory createInventory(BaseData var1, BaseMenu.Screen var2, int var3, String var4, String var5, int var6) {
      BaseMenu.BaseMenuHolder var7 = new BaseMenu.BaseMenuHolder(var1.getId(), var1.getOwnerUuid(), var2, var5, var6);
      Inventory var8 = Bukkit.createInventory(var7, this.normalizeSize(var3), ColorUtil.color(var4));
      var7.inventory = var8;
      return var8;
   }

   private void fill(Inventory var1, String var2) {
      if (this.plugin.getConfigManager().getMenus().getBoolean(var2 + ".enabled", false)) {
         ItemStack var3 = this.createItem(var2, (String)null, (UUID)null);

         for (int var4 = 0; var4 < var1.getSize(); var4++) {
            var1.setItem(var4, var3);
         }
      }
   }

   private void setItem(Inventory var1, String var2, String var3, UUID var4, String... var5) {
      int var6 = this.cfgInt(var2 + ".slot", -1);
      if (var6 >= 0 && var6 < var1.getSize()) {
         var1.setItem(var6, this.createItem(var2, var3, var4, var5));
      }
   }

   private ItemStack createItem(String var1, String var2, UUID var3, String... var4) {
      String var5 = this.cfgString(var1 + ".material", "STONE");
      Material var6 = Material.matchMaterial(var5);
      if (var6 == null || var6.isAir()) {
         var6 = Material.STONE;
      }

      ItemStack var7 = new ItemStack(var6);
      ItemMeta var8 = var7.getItemMeta();
      if (var8 == null) {
         return var7;
      }

      var8.setDisplayName(ColorUtil.color(this.replace(this.cfgString(var1 + ".name", " "), var4)));
      ArrayList var9 = new ArrayList();

      for (String var11 : this.plugin.getConfigManager().getMenus().getStringList(var1 + ".lore")) {
         var9.add(ColorUtil.color(this.replace(var11, var4)));
      }

      var8.setLore(var9);
      if (var3 != null && var8 instanceof SkullMeta var12) {
         Paper12111Compat.setOwningPlayer(var12, Bukkit.getOfflinePlayer(var3));
      }

      if (var2 != null) {
         var8.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, var2);
      }

      ItemMetaCompat.apply(var7, var8);
      return var7;
   }

   private String replace(String var1, String... var2) {
      String var3 = var1 == null ? "" : var1;

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(var2[var4], var2[var4 + 1]);
      }

      return var3;
   }

   private int normalizeSize(int var1) {
      int var2 = Math.max(9, Math.min(54, var1));
      if (var2 % 9 != 0) {
         var2 += 9 - var2 % 9;
      }

      return Math.min(54, var2);
   }

   private String cfgString(String var1, String var2) {
      return this.plugin.getConfigManager().getMenus().getString(var1, var2);
   }

   private int cfgInt(String var1, int var2) {
      return this.plugin.getConfigManager().getMenus().getInt(var1, var2);
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private static final class BaseMenuHolder implements InventoryHolder {
      private final long baseId;
      private final UUID ownerUuid;
      private final BaseMenu.Screen screen;
      private final String linkedType;
      private final int page;
      private Inventory inventory;

      private BaseMenuHolder(long var1, UUID var3, BaseMenu.Screen var4, String var5, int var6) {
         this.baseId = var1;
         this.ownerUuid = var3;
         this.screen = var4;
         this.linkedType = var5;
         this.page = var6;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }

   private record LinkedEntry(long id, String type, int level, int hp, int maxHp, String world, int x, int y, int z) {
   }

   public enum Screen {
      MAIN,
      POWER,
      LINKED,
      LINKED_LIST,
      UPGRADE_CONFIRM,
      POWER_CONFIRM,
      REMOVE_CONFIRM;
   }
}
