package com.zzwproject.zgenpvp.generator.link;

import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.model.GeneratorData;
import java.util.Optional;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class GeneratorLinkListener implements Listener {
   private final GeneratorManager generatorManager;
   private final GeneratorLinkManager linkManager;
   private final GeneratorLinkItem linkItem;

   public GeneratorLinkListener(GeneratorManager var1, GeneratorLinkManager var2, GeneratorLinkItem var3) {
      this.generatorManager = var1;
      this.linkManager = var2;
      this.linkItem = var3;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND) {
         if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ItemStack var2 = var1.getItem();
            if (!this.linkItem.isLinker(var2)) {
               var2 = var1.getPlayer().getInventory().getItemInMainHand();
            }

            if (this.linkItem.isLinker(var2)) {
               Block var3 = var1.getClickedBlock();
               if (var3 != null) {
                  var1.setCancelled(true);
                  Optional var4 = this.generatorManager.getGenerator(var3.getLocation());
                  if (var4.isPresent()) {
                     this.linkManager.selectGenerator(var1.getPlayer(), (GeneratorData)var4.get());
                  } else {
                     if (this.linkManager.isAllowedContainer(var3.getType())) {
                        this.linkManager.selectChest(var1.getPlayer(), var3);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onLinkerPlace(BlockPlaceEvent var1) {
      if (this.linkItem.isLinker(var1.getItemInHand())) {
         var1.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBreak(BlockBreakEvent var1) {
      Block var2 = var1.getBlock();
      if (this.linkManager.isAllowedContainer(var2.getType())) {
         if (this.linkManager.isLinkedChest(var2.getLocation())) {
            if (!this.linkManager.canBreakLinkedChest(var1.getPlayer(), var2.getLocation())) {
               var1.setCancelled(true);
            } else {
               int var3 = this.linkManager.getLinkedGeneratorCount(var2.getLocation());
               if (!this.linkManager.unlinkChest(var2.getLocation())) {
                  var1.setCancelled(true);
               } else {
                  this.linkManager.returnLinkers(var1.getPlayer(), var3, var2.getLocation());
                  var1.setCancelled(false);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onEntityExplosion(EntityExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.linkManager.isAllowedContainer(var1x.getType()) && this.linkManager.isLinkedChest(var1x.getLocation()));
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBlockExplosion(BlockExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.linkManager.isAllowedContainer(var1x.getType()) && this.linkManager.isLinkedChest(var1x.getLocation()));
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonExtend(BlockPistonExtendEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.linkManager.isAllowedContainer(var3.getType()) && this.linkManager.isLinkedChest(var3.getLocation())) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonRetract(BlockPistonRetractEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.linkManager.isAllowedContainer(var3.getType()) && this.linkManager.isLinkedChest(var3.getLocation())) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      this.linkManager.clearSelection(var1.getPlayer().getUniqueId());
   }
}
