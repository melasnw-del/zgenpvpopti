package com.zzwproject.zprogressfx;

import java.util.regex.Pattern;

public final class LevelTextFix {
   private static final Pattern TITLE = Pattern.compile("seviye\\s+atlad[iı]n!?", 66);
   private static final Pattern SUB = Pattern.compile("yeni\\s+seviyen\\s*:", 66);

   private LevelTextFix() {
   }

   public static String fixTitle(String var0) {
      return var0 == null ? null : TITLE.matcher(var0).replaceAll("SEVİYE ATLADIN!");
   }

   public static String fixSubtitle(String var0) {
      return var0 == null ? null : SUB.matcher(var0).replaceAll("Yeni seviyen:");
   }
}
