package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.instabreaker.InstabreakerManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

public final class InstabreakerCommand implements TabExecutor {
   private final InstabreakerManager manager;

   public InstabreakerCommand(InstabreakerManager manager) {
      this.manager = manager;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("zgenpvp.instabreaker.admin")) {
         this.manager.sendMessage(sender, "messages.no-permission");
         return true;
      }

      if (args.length == 0) {
         this.manager.sendHelp(sender);
         return true;
      }

      if (args[0].equalsIgnoreCase("reload")) {
         this.manager.reload();
         this.manager.sendMessage(sender, "messages.reload");
         return true;
      }

      if (!args[0].equalsIgnoreCase("give")) {
         this.manager.sendHelp(sender);
         return true;
      }

      if (args.length < 2) {
         this.manager.sendHelp(sender);
         return true;
      }

      Player target = Bukkit.getPlayerExact(args[1]);
      if (target == null) {
         this.manager.sendMessage(sender, "messages.player-not-found");
         return true;
      }

      int amount = 1;
      if (args.length >= 3) {
         try {
            amount = Integer.parseInt(args[2]);
         } catch (NumberFormatException exception) {
            this.manager.sendMessage(sender, "messages.invalid-amount");
            return true;
         }
      }

      if (amount < 1 || amount > 64) {
         this.manager.sendMessage(sender, "messages.invalid-amount");
         return true;
      }

      if (!this.manager.give(target, amount)) {
         return true;
      }

      this.manager.sendMessage(sender, "messages.admin-given", "%player%", target.getName(), "%amount%", String.valueOf(amount));
      return true;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> suggestions = new ArrayList<>();
      if (!sender.hasPermission("zgenpvp.instabreaker.admin")) {
         return suggestions;
      }

      if (args.length == 1) {
         suggestions.add("give");
         suggestions.add("reload");
         return this.filter(suggestions, args[0]);
      }

      if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
         for (Player player : Bukkit.getOnlinePlayers()) {
            suggestions.add(player.getName());
         }

         return this.filter(suggestions, args[1]);
      } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
         suggestions.add("1");
         suggestions.add("5");
         suggestions.add("10");
         return this.filter(suggestions, args[2]);
      } else {
         return suggestions;
      }
   }

   private List<String> filter(List<String> values, String input) {
      String lower = input == null ? "" : input.toLowerCase(Locale.ROOT);
      return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower)).toList();
   }
}
