package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Method;

public final class CityMapHardGuard {
   private CityMapHardGuard() {
   }

   public static void setCancelledSafely(Object var0, boolean var1) {
      try {
         if (!var1 && isGeneratedProtected(var0)) {
            return;
         }

         call(var0, "setCancelled", var1);
      } catch (Throwable var3) {
      }
   }

   private static boolean isGeneratedProtected(Object var0) {
      try {
         Object var1 = tryCall(var0, "getBlock");
         if (var1 == null) {
            return false;
         }

         Class var10 = Class.forName("org.bukkit.Bukkit");
         Object var11 = var10.getMethod("getPluginManager").invoke(null);
         Object var4 = call(var11, "getPlugin", "ZGenMap");
         if (var4 == null) {
            return false;
         }

         Object var5 = call(var4, "getWorldManager");
         Object var6 = call(var1, "getWorld");
         if (!Boolean.TRUE.equals(call(var5, "isManagedWorld", var6))) {
            return false;
         }

         Object var7 = call(var5, "getGenerator");
         return var7 == null ? true : Boolean.TRUE.equals(call(var7, "isGeneratedProtectedBlock", var1));
      } catch (Throwable var9) {
         try {
            Object var2 = tryCall(var0, "getBlock");
            if (var2 != null && Boolean.TRUE.equals(tryCall(var0, "isCancelled"))) {
               String var3 = String.valueOf(call(var2, "getType"));
               if ("GRAY_WOOL".equals(var3) || "LIGHT_GRAY_CONCRETE".equals(var3)) {
                  return true;
               }
            }
         } catch (Throwable var8) {
         }

         return false;
      }
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) throws Exception {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && fit(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && fit(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      throw new NoSuchMethodException(var1);
   }

   private static boolean fit(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isInstance(var1[var2])) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else {
         return var0 == int.class ? Integer.class : var0;
      }
   }
}
