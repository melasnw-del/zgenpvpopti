package com.zzwproject.zgenpvp.integration;

import java.lang.reflect.Method;

public final class RaidBombSessionStarter {
   private RaidBombSessionStarter() {
   }

   public static boolean start(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         Object var2 = null;

         try {
            Class var3 = Class.forName("org.bukkit.Bukkit");
            Object var4 = var3.getMethod("getPluginManager").invoke(null);
            var2 = var4.getClass().getMethod("getPlugin", String.class).invoke(var4, "ZRaid");
            if (var2 == null) {
               message(var0, "§cZRaid aktif değil; raid oturumu başlatılamadı.");
               return false;
            }

            try {
               Object var5 = var2.getClass().getMethod("isEnabled").invoke(var2);
               if (!Boolean.TRUE.equals(var5)) {
                  message(var0, "§cZRaid devre dışı; raid oturumu başlatılamadı.");
                  return false;
               }
            } catch (Throwable var7) {
            }

            Method var9 = findStartRaid(var2.getClass(), var1, var0);
            if (var9 == null) {
               message(var0, "§cRaid bağlantısı kurulamadı. Konsolu kontrol et.");
               warn(var2, "RaidBombSessionStarter: startRaid metodu bulunamadı.");
               return false;
            } else {
               var9.setAccessible(true);
               Object var6 = var9.invoke(var2, var1, var0, "bomb");
               return var6 != null;
            }
         } catch (Throwable var8) {
            message(var0, "§cRaid oturumu başlatılamadı. Konsolu kontrol et.");
            if (var2 != null) {
               warn(var2, "Raid bombası -> ZRaid köprü hatası: " + var8.getClass().getSimpleName() + ": " + var8.getMessage());
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private static Method findStartRaid(Class<?> var0, Object var1, Object var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals("startRaid") && var7.getParameterCount() == 3) {
               Class[] var8 = var7.getParameterTypes();
               if (var8[0].isInstance(var1) && var8[1].isInstance(var2) && var8[2] == String.class) {
                  return var7;
               }
            }
         }
      }

      return null;
   }

   private static void message(Object var0, String var1) {
      try {
         var0.getClass().getMethod("sendMessage", String.class).invoke(var0, var1);
      } catch (Throwable var3) {
      }
   }

   private static void warn(Object var0, String var1) {
      try {
         Object var2 = var0.getClass().getMethod("getLogger").invoke(var0);
         var2.getClass().getMethod("warning", String.class).invoke(var2, var1);
      } catch (Throwable var3) {
      }
   }
}
