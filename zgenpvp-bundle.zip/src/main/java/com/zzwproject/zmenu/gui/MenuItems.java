package com.zzwproject.zmenu.gui;

import com.zzwproject.zmenu.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class MenuItems {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

   private MenuItems() {
   }

   public static ItemStack item(Material var0, String var1, List<String> var2) {
      ItemStack var3 = new ItemStack(var0 == null ? Material.STONE : var0);
      ItemMeta var4 = var3.getItemMeta();
      var4.displayName(component(var1));
      ArrayList var5 = new ArrayList();
      if (var2 != null) {
         for (String var7 : var2) {
            var5.add(component(var7));
         }
      }

      var4.lore(var5);
      var4.addItemFlags(ItemFlag.values());
      var3.setItemMeta(var4);
      return var3;
   }

   private static Component component(String var0) {
      return LEGACY.deserialize(ColorUtil.color(var0 == null ? "" : var0)).decoration(TextDecoration.ITALIC, false);
   }

   public static void fill(Inventory var0, Material var1, String var2) {
      ItemStack var3 = item(var1, var2, List.of());

      for (int var4 = 0; var4 < var0.getSize(); var4++) {
         var0.setItem(var4, var3);
      }
   }

   public static Material material(String var0, Material var1) {
      Material var2 = var0 == null ? null : Material.matchMaterial(var0);
      return var2 == null ? var1 : var2;
   }

   public static int normalizeSize(int var0) {
      int var1 = Math.max(9, Math.min(54, var0));
      return (var1 + 8) / 9 * 9;
   }
}
