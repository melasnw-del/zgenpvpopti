package com.zzwproject.compat;

import java.util.List;
import java.util.Locale;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemMetaCompat {
   private ItemMetaCompat() {
   }

   public static void apply(ItemStack var0, ItemMeta var1) {
      if (var0 != null) {
         if (var1 != null) {
            try {
               boolean var2 = containsPreview(var1.getDisplayName());
               if (!var2) {
                  List<String> var3 = var1.getLore();
                  if (var3 != null) {
                     for (String var5 : var3) {
                        if (containsPreview(var5)) {
                           var2 = true;
                           break;
                        }
                     }
                  }
               }

               if (var2) {
                  var1.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
               }
            } catch (Throwable var6) {
            }
         }

         var0.setItemMeta(var1);
      }
   }

   private static boolean containsPreview(String var0) {
      if (var0 == null) {
         return false;
      }

      String var1 = var0.toLowerCase(Locale.ROOT);
      return var1.contains("önizleme") || var1.contains("onizleme") || var1.contains("preview");
   }
}
