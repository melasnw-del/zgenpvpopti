package com.zzwproject.zmenu.command;

import com.zzwproject.zmenu.ZMenu;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;

public final class ZMenuCommand implements CommandExecutor, TabCompleter {
   private final ZMenu plugin;

   public ZMenuCommand(ZMenu var1) {
      this.plugin = var1;
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (!var1.hasPermission("zmenu.admin")) {
         this.plugin.message().send(var1, "no-permission");
         return true;
      } else if (var4.length > 0 && var4[0].equalsIgnoreCase("reload")) {
         this.plugin.reloadPlugin();
         this.plugin.message().send(var1, "reloaded");
         return true;
      } else {
         var1.sendMessage("§bMenü §8• §fYönetim");
         return true;
      }
   }

   public List<String> onTabComplete(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (var1.hasPermission("zmenu.admin") && var4.length == 1) {
         return "reload".startsWith(var4[0].toLowerCase()) ? List.of("reload") : List.of();
      } else {
         return List.of();
      }
   }
}
