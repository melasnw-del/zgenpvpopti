package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;

public final class BeaconBreakGuard {
   private BeaconBreakGuard() {
   }

   public static boolean handle(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            ClassLoader var2 = var0.getClass().getClassLoader();
            Class var3 = Class.forName("com.zzwproject.zgenpvp.integration.RaidSessionBridge", true, var2);
            if (truth(callStatic(var3, "handleBeaconBreak", var1))) {
               return true;
            }

            Object var4 = call(var1, "getBlock");
            Object var5 = call(var1, "getPlayer");
            if (var4 != null && var5 != null) {
               Object var6 = call(var4, "getType");
               if (var6 != null && "BEACON".equalsIgnoreCase(String.valueOf(var6))) {
                  Object var7 = field(var0, "beaconManager");
                  Object var8 = unwrap(call(var7, "getBeacon", call(var4, "getLocation")));
                  if (var8 == null) {
                     return false;
                  }

                  Class var9 = Class.forName("com.zzwproject.zgenpvp.integration.TeamPermissionBridge", true, var2);
                  boolean var10 = truth(callStatic(var9, "beaconBreakAllowed", var7, var5, var8));
                  if (var10) {
                     return false;
                  }

                  Object var11 = field(var0, "plugin");
                  boolean var12 = coreCfgB(var11, "raid-protection.block-enemy-beacon-break-outside-raid", true);
                  if (!var12) {
                     return false;
                  }

                  tryCall(var1, "setCancelled", true);
                  tryCall(var1, "setDropItems", false);
                  tryCall(var1, "setExpToDrop", 0);

                  try {
                     Class var13 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var2);
                     callStatic(var13, "stopMining", var5);
                  } catch (Throwable var14) {
                  }

                  tryCall(var7, "sendOwnerInfo", var5, var8);
                  return true;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } catch (Throwable var15) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean coreCfgB(Object var0, String var1, boolean var2) {
      try {
         Object var3 = call(var0, "getConfigManager");
         Object var4 = call(var3, "getConfig");
         return call(var4, "getBoolean", var1, var2) instanceof Boolean var6 ? var6 : var2;
      } catch (Throwable var7) {
         return var2;
      }
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
   }

   private static boolean truth(Object var0) {
      return var0 instanceof Boolean var1 ? var1 : var0 != null && Boolean.parseBoolean(String.valueOf(var0));
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, false, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0, var1, true, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(null, var2);
   }

   private static Method find(Class<?> var0, String var1, boolean var2, Object... var3) {
      for (Class var4 = var0; var4 != null; var4 = var4.getSuperclass()) {
         for (Method var8 : var4.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && (!var2 || Modifier.isStatic(var8.getModifiers())) && var8.getParameterCount() == var3.length) {
               boolean var9 = true;
               Class[] var10 = var8.getParameterTypes();

               for (int var11 = 0; var11 < var10.length; var11++) {
                  if (!fits(var10[var11], var3[var11])) {
                     var9 = false;
                     break;
                  }
               }

               if (var9) {
                  return var8;
               }
            }
         }
      }

      for (Method var15 : var0.getMethods()) {
         if (var15.getName().equals(var1) && (!var2 || Modifier.isStatic(var15.getModifiers())) && var15.getParameterCount() == var3.length) {
            boolean var16 = true;
            Class[] var17 = var15.getParameterTypes();

            for (int var18 = 0; var18 < var17.length; var18++) {
               if (!fits(var17[var18], var3[var18])) {
                  var16 = false;
                  break;
               }
            }

            if (var16) {
               return var15;
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean || var0 == int.class && var1 instanceof Integer || var0 == long.class && var1 instanceof Long;
      }
   }
}
