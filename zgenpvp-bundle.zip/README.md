# ZZWGenBundle — Maven kaynak

- Sürüm: `2.0.7-city-raid-safety-hotfix6`
- Ana sınıf: `com.zzwproject.bundle.BundlePlugin`
- Hedef: Paper 1.21.11, Java 21
- Derleme: `mvn clean package` -> `target/ZGenPvP-2.0.7-city-raid-safety-hotfix6.jar`

Yapı:
- `src/main/java/com/zzwproject/...` -> bundle, compat, hotfix, zgenpvp, zraid, zgenboss, zoverclock, zplacementguard, beaconfix, zprogressfx, zmenu, zbazooka, zsafety
- `src/main/resources/` -> plugin.yml, bundle-modules.txt, yml'ler ve `legacy/<Modül>/` klasörleri

`org/sqlite` (sqlite-jdbc) ve `META-INF` kaynak değildir; pom'daki shade eklentisi jar'a kendisi ekler.
