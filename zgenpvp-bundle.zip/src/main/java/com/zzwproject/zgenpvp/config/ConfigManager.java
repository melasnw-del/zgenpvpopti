package com.zzwproject.zgenpvp.config;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.GeneratorConfigFix;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class ConfigManager {
   private final ZGenPvP plugin;
   private FileConfiguration config;
   private FileConfiguration messages;
   private FileConfiguration menus;
   private FileConfiguration items;
   private FileConfiguration generators;
   private FileConfiguration defenses;
   private FileConfiguration sounds;
   private FileConfiguration levels;
   private FileConfiguration death;
   private FileConfiguration raid;
   private FileConfiguration alerts;

   public ConfigManager(ZGenPvP var1) {
      this.plugin = var1;
   }

   public void load() {
      this.ensureResource("messages.yml");
      this.ensureResource("menus.yml");
      this.ensureResource("items.yml");
      this.ensureResource("generators.yml");
      this.ensureResource("defenses.yml");
      this.ensureResource("sounds.yml");
      this.ensureResource("levels.yml");
      this.ensureResource("death.yml");
      this.ensureResource("raid.yml");
      this.ensureResource("alerts.yml");
      this.reload();
   }

   public void reload() {
      this.plugin.reloadConfig();
      this.config = this.plugin.getConfig();
      boolean var1 = this.migrateIndependentGeneratorDefaults(this.config);
      if (this.applyBundledDefaults(this.config, "config.yml")) {
         var1 = true;
      }

      if (var1) {
         this.plugin.saveConfig();
      }

      this.messages = this.loadFileWithDefaults("messages.yml");
      this.menus = this.loadFileWithDefaults("menus.yml");
      this.items = this.loadFileWithDefaults("items.yml");
      this.generators = this.loadFileWithDefaults("generators.yml");
      this.defenses = this.loadFileWithDefaults("defenses.yml");
      this.sounds = this.loadFileWithDefaults("sounds.yml");
      this.levels = this.loadFileWithDefaults("levels.yml");
      this.death = this.loadFileWithDefaults("death.yml");
      this.raid = this.loadFileWithDefaults("raid.yml");
      this.alerts = this.loadFileWithDefaults("alerts.yml");
      this.migratePerformanceDefaults();
   }

   private void migratePerformanceDefaults() {
      if (this.defenses != null) {
         long var1 = this.defenses.getLong("turret.scan-interval-ticks", 10L);
         if (var1 == 5L) {
            this.defenses.set("turret.scan-interval-ticks", 10L);
            File var3 = new File(this.plugin.getDataFolder(), "defenses.yml");

            try {
               this.defenses.save(var3);
               this.plugin.getLogger().info("HOTFIX5: Taret tarama araligi performans icin 10 ticke guncellendi.");
            } catch (Exception var5) {
               this.plugin.getLogger().warning("HOTFIX5 defenses.yml performans ayari kaydedilemedi: " + var5.getMessage());
            }
         }
      }
   }

   private boolean migrateIndependentGeneratorDefaults(FileConfiguration var1) {
      return GeneratorConfigFix.migrateIndependentDefaults(this, var1);
   }

   private void ensureResource(String var1) {
      File var2 = new File(this.plugin.getDataFolder(), var1);
      if (!var2.exists()) {
         this.plugin.saveResource(var1, false);
      }
   }

   private FileConfiguration loadFileWithDefaults(String var1) {
      File var2 = new File(this.plugin.getDataFolder(), var1);
      YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
      if (this.applyBundledDefaults(var3, var1)) {
         try {
            var3.save(var2);
         } catch (Exception var5) {
            this.plugin.getLogger().warning(var1 + " yeni varsayılanlarla kaydedilemedi: " + var5.getMessage());
         }
      }

      return var3;
   }

   private boolean applyBundledDefaults(FileConfiguration var1, String var2) {
      try (InputStream var3 = this.plugin.getResource(var2)) {
         if (var3 == null) {
            return false;
         }

         YamlConfiguration var6 = YamlConfiguration.loadConfiguration(new InputStreamReader(var3, StandardCharsets.UTF_8));
         HashSet var7 = new HashSet(var1.getKeys(true));
         boolean var8 = false;

         for (String var10 : var6.getKeys(true)) {
            Object var11 = var6.get(var10);
            if (!(var11 instanceof ConfigurationSection) && !var7.contains(var10)) {
               var1.set(var10, var11);
               var8 = true;
            }
         }

         return var8;
      } catch (Exception var14) {
         this.plugin.getLogger().warning(var2 + " varsayılanları yüklenemedi: " + var14.getMessage());
         return false;
      }
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public FileConfiguration getMessages() {
      return this.messages;
   }

   public FileConfiguration getMenus() {
      return this.menus;
   }

   public FileConfiguration getItems() {
      return this.items;
   }

   public FileConfiguration getGenerators() {
      return this.generators;
   }

   public FileConfiguration getDefenses() {
      return this.defenses;
   }

   public FileConfiguration getSounds() {
      return this.sounds;
   }

   public FileConfiguration getLevels() {
      return this.levels;
   }

   public FileConfiguration getDeath() {
      return this.death;
   }

   public FileConfiguration getRaid() {
      return this.raid;
   }

   public FileConfiguration getAlerts() {
      return this.alerts;
   }
}
