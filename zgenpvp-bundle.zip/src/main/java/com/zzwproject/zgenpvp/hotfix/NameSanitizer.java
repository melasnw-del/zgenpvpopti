package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.UUID;

public final class NameSanitizer {
   private NameSanitizer() {
   }

   public static String sanitize(UUID var0, String var1) {
      if (var1 == null) {
         return "";
      }

      if (var0 != null && var1.toLowerCase(Locale.ROOT).contains("%player%")) {
         String var2 = null;

         try {
            Class var3 = Class.forName("org.bukkit.Bukkit");
            Method var4 = var3.getMethod("getOfflinePlayer", UUID.class);
            Object var5 = var4.invoke(null, var0);
            if (var5 != null) {
               Method var6 = var5.getClass().getMethod("getName");
               Object var7 = var6.invoke(var5);
               if (var7 != null) {
                  var2 = String.valueOf(var7);
               }
            }
         } catch (Throwable var8) {
         }

         if (var2 == null || var2.isBlank()) {
            var2 = "Oyuncu";
         }

         return PlaceholderFix.replaceIgnoreCase(var1, "%player%", var2);
      } else {
         return var1;
      }
   }
}
