package com.zzwproject.zmenu.gui;

import com.zzwproject.zmenu.ZMenu;
import com.zzwproject.zmenu.util.ColorUtil;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class RulesMenu {
   private static final List<Integer> DEFAULT_SLOTS = List.of(10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34);
   private final ZMenu plugin;

   public RulesMenu(ZMenu var1) {
      this.plugin = var1;
   }

   public void open(Player var1, int var2) {
      FileConfiguration var3 = this.plugin.rulesConfig();
      List var4 = this.ruleKeys(var3);
      List var5 = var3.getIntegerList("rules.content-slots");
      if (var5.isEmpty()) {
         var5 = DEFAULT_SLOTS;
      }

      int var6 = Math.max(1, var5.size());
      int var7 = Math.max(1, (var4.size() + var6 - 1) / var6);
      int var8 = Math.max(0, Math.min(var2, var7 - 1));
      String var9 = var3.getString("rules.title", "&8Genpvp &8• &ckurallar")
         .replace("%page%", String.valueOf(var8 + 1))
         .replace("%pages%", String.valueOf(var7));
      MenuHolder var10 = new MenuHolder("rules", var8);
      Inventory var11 = Bukkit.createInventory(var10, 54, ColorUtil.color(var9));
      if (var3.getBoolean("rules.filler.enabled", true)) {
         MenuItems.fill(
            var11, MenuItems.material(var3.getString("rules.filler.material"), Material.BLACK_STAINED_GLASS_PANE), var3.getString("rules.filler.name", " ")
         );
      }

      var11.setItem(
         4, MenuItems.item(Material.WRITABLE_BOOK, var3.getString("rules.header.name", "&c✦ Sunucu kuralları"), var3.getStringList("rules.header.lore"))
      );
      int var12 = var8 * var6;
      int var13 = Math.min(var4.size(), var12 + var6);

      for (int var14 = var12; var14 < var13; var14++) {
         String var15 = (String)var4.get(var14);
         String var16 = "entries." + var15;
         int var17 = (Integer)var5.get(var14 - var12);
         if (var17 >= 0 && var17 < var11.getSize()) {
            var11.setItem(
               var17,
               MenuItems.item(
                  MenuItems.material(var3.getString(var16 + ".material"), Material.PAPER),
                  var3.getString(var16 + ".name", var15),
                  var3.getStringList(var16 + ".lore")
               )
            );
         }
      }

      if (var8 > 0) {
         var11.setItem(45, MenuItems.item(Material.ARROW, "&eOnceki sayfa", List.of("&7Sayfa " + var8 + "&7/" + var7)));
         var10.action(45, new MenuAction("RULES_PAGE", String.valueOf(var8 - 1), false));
      }

      var11.setItem(49, MenuItems.item(Material.OAK_DOOR, "&cAna menuye dön", List.of("&7Sunucu menusunu aç.")));
      var10.action(49, new MenuAction("MAIN_MENU", "", false));
      if (var8 + 1 < var7) {
         var11.setItem(53, MenuItems.item(Material.ARROW, "&eSonraki sayfa", List.of("&7Sayfa " + (var8 + 2) + "&7/" + var7)));
         var10.action(53, new MenuAction("RULES_PAGE", String.valueOf(var8 + 1), false));
      }

      var1.openInventory(var11);
      this.plugin.sound().play(var1, "menu-open");
   }

   private List<String> ruleKeys(FileConfiguration var1) {
      ConfigurationSection var2 = var1.getConfigurationSection("entries");
      if (var2 == null) {
         return new ArrayList<>();
      }

      ArrayList var3 = new ArrayList(var2.getKeys(false));
      var3.sort(Comparator.<String>comparingInt(var1x -> var1.getInt("entries." + var1x + ".order", 999)).thenComparing(var0 -> (String)var0));
      return var3;
   }
}
