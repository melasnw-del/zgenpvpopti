package com.zzwproject.zgenpvp.generator;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.generator.link.GeneratorLinkItem;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.RaidSessionBridge;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.model.GeneratorData;
import java.util.Optional;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class GeneratorListener implements Listener {
   private final GeneratorManager generatorManager;
   private final GeneratorLinkItem generatorLinkItem;
   private final GeneratorMenu generatorMenu;

   public GeneratorListener(GeneratorManager var1, GeneratorLinkItem var2, GeneratorMenu var3) {
      this.generatorManager = var1;
      this.generatorLinkItem = var2;
      this.generatorMenu = var3;
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      if (this.generatorManager.isGeneratorItem(var1.getItemInHand())) {
         int var2 = this.generatorManager.getGeneratorItemLevel(var1.getItemInHand());
         boolean var3 = this.generatorManager.place(var1.getPlayer(), var1.getBlockPlaced().getLocation(), var2);
         if (!var3) {
            var1.setCancelled(true);
         }
      }

      StructureSupportGuard.restore(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND && !this.generatorLinkItem.isLinker(var1.getItem())) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.generatorManager.getGenerator(var2.getLocation());
            if (!var3.isEmpty()) {
               GeneratorData var4 = (GeneratorData)var3.get();
               Player var5 = var1.getPlayer();
               if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
                  var1.setCancelled(true);
                  this.generatorMenu.open(var5, var4);
               } else if (var1.getAction() == Action.LEFT_CLICK_BLOCK
                  && !var4.getOwnerUuid().equals(var5.getUniqueId())
                  && this.generatorManager.areTeammates(var4.getOwnerUuid(), var5.getUniqueId())) {
                  var1.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onOwnerHandDamage(BlockDamageEvent var1) {
      Optional var2 = this.generatorManager.getGenerator(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         GeneratorData var3 = (GeneratorData)var2.get();
         Player var4 = var1.getPlayer();
         if (var3.getOwnerUuid().equals(var4.getUniqueId()) && var4.getInventory().getItemInMainHand().getType().isAir()) {
            var1.setCancelled(false);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBreak(BlockBreakEvent var1) {
      if (!RaidSessionBridge.handleGeneratorBreak(var1)) {
         Optional var2 = this.generatorManager.getGenerator(var1.getBlock().getLocation());
         if (!var2.isEmpty()) {
            GeneratorData var3 = (GeneratorData)var2.get();
            Player var4 = var1.getPlayer();
            if (ZGenPvP.getInstance().getInstabreakerManager() != null
               && ZGenPvP.getInstance().getInstabreakerManager().isInstabreaker(var4.getInventory().getItemInMainHand())) {
               var1.setCancelled(true);
               var1.setDropItems(false);
               var1.setExpToDrop(0);
               return;
            }

            boolean var5 = TeamPermissionBridge.generatorOwnerOrAllowed(var3.getOwnerUuid(), var4.getUniqueId());
            boolean var6 = !var5 && this.generatorManager.areTeammates(var3.getOwnerUuid(), var4.getUniqueId());
            if (var6) {
               var1.setCancelled(true);
            } else {
               var1.setDropItems(false);
               var1.setExpToDrop(0);
               boolean var7 = var5 ? this.generatorManager.removeByOwner(var4, var3) : this.generatorManager.removeByEnemy(var4, var3);
               if (!var7) {
                  var1.setCancelled(true);
               } else {
                  var1.getBlock().setType(Material.AIR, false);
                  var1.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onEntityExplosion(EntityExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.generatorManager.getGenerator(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBlockExplosion(BlockExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.generatorManager.getGenerator(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonExtend(BlockPistonExtendEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.generatorManager.getGenerator(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonRetract(BlockPistonRetractEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.generatorManager.getGenerator(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onLiquidFlow(BlockFromToEvent var1) {
      if (this.generatorManager.getGenerator(var1.getToBlock().getLocation()).isPresent()) {
         var1.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEntityChangeBlock(EntityChangeBlockEvent var1) {
      if (this.generatorManager.getGenerator(var1.getBlock().getLocation()).isPresent()) {
         var1.setCancelled(true);
      }
   }

   @EventHandler
   public void onChunkLoad(ChunkLoadEvent var1) {
      Chunk var2 = var1.getChunk();
      this.generatorManager.refreshChunk(var2);
   }
}
