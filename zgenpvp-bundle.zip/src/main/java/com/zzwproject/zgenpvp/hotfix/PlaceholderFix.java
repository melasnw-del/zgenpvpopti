package com.zzwproject.zgenpvp.hotfix;

public final class PlaceholderFix {
   private static final String PREFIX = "&#FF8A00ɢᴇɴᴘᴠᴘ &8» &r";

   private PlaceholderFix() {
   }

   public static String replace(String var0, String[] var1) {
      if (var0 == null) {
         return "";
      }

      String var2 = replaceIgnoreCase(var0, "%prefix%", "&#FF8A00ɢᴇɴᴘᴠᴘ &8» &r");
      if (var1 == null) {
         return var2;
      }

      for (byte var3 = 0; var3 + 1 < var1.length; var3 += 2) {
         String var4 = var1[var3];
         String var5 = var1[var3 + 1];
         if (var4 != null && !var4.isEmpty()) {
            var2 = replaceIgnoreCase(var2, var4, var5 == null ? "" : var5);
         }
      }

      return var2;
   }

   public static String replaceIgnoreCase(String var0, String var1, String var2) {
      if (var0 != null && var1 != null && !var1.isEmpty()) {
         if (var2 == null) {
            var2 = "";
         }

         int var3 = var1.length();
         int var4 = var0.length();
         StringBuilder var5 = null;
         int var6 = 0;
         int var7 = 0;

         while (var7 <= var4 - var3) {
            if (var0.regionMatches(true, var7, var1, 0, var3)) {
               if (var5 == null) {
                  var5 = new StringBuilder(var4 + Math.max(0, var2.length() - var3) * 2);
               }

               var5.append(var0, var6, var7).append(var2);
               var7 += var3;
               var6 = var7;
            } else {
               var7++;
            }
         }

         if (var5 == null) {
            return var0;
         }

         var5.append(var0, var6, var4);
         return var5.toString();
      } else {
         return var0;
      }
   }
}
