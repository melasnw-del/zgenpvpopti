package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.beacon.BeaconManager;
import com.zzwproject.zgenpvp.beacon.BeaconMenu;
import com.zzwproject.zgenpvp.beacon.BeaconSpawnMenu;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class BeaconCommand implements CommandExecutor, TabCompleter {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final BeaconSpawnMenu beaconSpawnMenu;

   public BeaconCommand(ZGenPvP var1, BeaconManager var2, BeaconSpawnMenu var3) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.beaconSpawnMenu = var3;
   }

   public BeaconCommand(ZGenPvP var1, BeaconManager var2, BeaconMenu var3) {
      this(var1, var2, var1.getBeaconSpawnMenu());
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("zgenpvp.beacon")) {
            this.plugin.getMessageUtil().send(var5, "general.no-permission");
            return true;
         } else if (!this.beaconManager.isEnabled()) {
            this.plugin.getMessageUtil().send(var5, "general.module-disabled");
            return true;
         } else if (this.beaconManager.getOwnedBeacons(var5.getUniqueId()).isEmpty()) {
            this.plugin.getMessageUtil().send(var5, "beacon.not-found");
            return true;
         } else {
            this.beaconSpawnMenu.openManagement(var5);
            return true;
         }
      } else {
         this.plugin.getMessageUtil().send(var1, "general.only-player");
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      return List.of();
   }
}
