package com.zzwproject.zgenboss;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zgenboss.hotfix.BossCombatFix;
import com.zzwproject.zgenboss.hotfix.BossLevelBalance;
import com.zzwproject.zgenboss.hotfix.BossMessageFix;
import com.zzwproject.zgenboss.hotfix.GenPvPLootFix;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

public final class ZGenBoss extends LegacyPluginBase implements Listener {
   private static final String[] BOSS_IDS = new String[]{
      "core_guardian",
      "shadow_hunter",
      "flame_keeper",
      "dune_guardian",
      "prison_hunter",
      "end_watcher",
      "wither_knight",
      "swamp_alchemist",
      "drowned_raider",
      "cave_stalker",
      "brute_enforcer",
      "ravager_prime"
   };
   private Plugin zGenPvP;
   private final Map<Long, Long> nextSpawnAt = new HashMap<>();
   private final Map<UUID, ZGenBoss.BossInstance> activeBosses = new HashMap<>();
   private final Map<Long, UUID> activeByGenerator = new HashMap<>();
   private long activeTickCounter = 0L;

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      this.zGenPvP = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenPvP");
      if (this.zGenPvP != null && this.zGenPvP.isEnabled()) {
         Bukkit.getPluginManager().registerEvents(this, this);
         long var1 = Math.max(20L, this.getConfig().getLong("system.scan-interval-ticks", 200L));
         Bukkit.getScheduler().runTaskTimer(this, this::scanMaxLevelGenerators, 60L, var1);
         Bukkit.getScheduler().runTaskTimer(this, this::tickActiveBosses, 40L, 10L);
         PlayerBossPreferences.bootstrap(this);
      } else {
         this.getLogger().severe("ZGenPvP bulunamadı. ZGenBoss devre dışı bırakılıyor.");
      }
   }

   @Override
   public void onDisable() {
      if (this.getConfig().getBoolean("system.remove-active-bosses-on-disable", true)) {
         for (ZGenBoss.BossInstance var2 : new ArrayList<>(this.activeBosses.values())) {
            try {
               if (var2.entity != null && var2.entity.isValid() && !var2.entity.isDead()) {
                  var2.entity.remove();
               }
            } catch (Throwable var4) {
            }
         }
      }

      this.activeBosses.clear();
      this.activeByGenerator.clear();
      this.nextSpawnAt.clear();
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var2.getName().equalsIgnoreCase("zboss")) {
         return false;
      } else if (!var1.hasPermission("zgenboss.admin")) {
         var1.sendMessage(color("&cBu komut için yetkin yok."));
         return true;
      } else if (var4.length == 0 || var4[0].equalsIgnoreCase("status")) {
         var1.sendMessage(color("&8[&dZGenBoss&8] &faktif boss: &d" + this.activeBosses.size() + " &8| &ftakip edilen jeneratör: &d" + this.nextSpawnAt.size()));
         return true;
      } else if (var4[0].equalsIgnoreCase("reload")) {
         this.reloadConfig();
         var1.sendMessage(color("&8[&dZGenBoss&8] &aAyarlar yeniden yüklendi."));
         return true;
      } else {
         var1.sendMessage(color("&7Kullanım: &f/zboss status &8| &f/zboss reload"));
         return true;
      }
   }

   private void scanMaxLevelGenerators() {
      if (this.getConfig().getBoolean("system.enabled", true)) {
         if (this.zGenPvP != null && this.zGenPvP.isEnabled()) {
            try {
               Object var1 = this.zGenPvP.getClass().getMethod("getGeneratorManager").invoke(this.zGenPvP);
               Object var2 = this.zGenPvP.getClass().getMethod("getGeneratorRepository").invoke(this.zGenPvP);
               int var3 = ((Number)var1.getClass().getMethod("getMaxLevel").invoke(var1)).intValue();
               Object var4x;
               try {
                  var4x = var1.getClass().getMethod("getCachedGenerators").invoke(var1);
               } catch (Throwable var14) {
                  var4x = var2.getClass().getMethod("findAll").invoke(var2);
               }

               if (!(var4x instanceof Iterable var5)) {
                  return;
               }

               HashSet var6 = new HashSet();
               long var7 = System.currentTimeMillis();

               for (Object var10 : var5) {
                  ZGenBoss.GeneratorRef var11 = this.readGenerator(var10);
                  if (var11 != null && var11.level >= 1) {
                     var6.add(var11.id);
                     this.nextSpawnAt.computeIfAbsent(var11.id, var3x -> var7 + this.randomSpawnDelayMillis());
                     if (!this.activeByGenerator.containsKey(var11.id) && var7 >= this.nextSpawnAt.getOrDefault(var11.id, Long.MAX_VALUE)) {
                        if (!this.canSpawnFor(var11)) {
                           this.nextSpawnAt.put(var11.id, var7 + Math.max(30000L, this.getConfig().getLong("system.retry-delay-seconds", 60L) * 1000L));
                        } else {
                           ZGenBoss.BossType var12 = this.chooseBossType();
                           var12 = (ZGenBoss.BossType)BossLevelBalance.selectBossType(this, var11, var12);
                           if (var12 == null) {
                              this.nextSpawnAt.put(var11.id, var7 + 120000L);
                           } else if (!this.spawnBoss(var11, var12)) {
                              this.nextSpawnAt.put(var11.id, var7 + 60000L);
                           }
                        }
                     }
                  }
               }

               this.nextSpawnAt.keySet().removeIf(var2x -> !var6.contains(var2x) && !this.activeByGenerator.containsKey(var2x));
            } catch (Throwable var13) {
               this.getLogger().warning("Jeneratör taramasi başarısız: " + var13.getClass().getSimpleName() + ": " + var13.getMessage());
            }
         }
      }
   }

   private ZGenBoss.GeneratorRef readGenerator(Object var1) {
      try {
         Class var2 = var1.getClass();
         long var3 = ((Number)var2.getMethod("getId").invoke(var1)).longValue();
         UUID var5 = (UUID)var2.getMethod("getOwnerUuid").invoke(var1);
         String var6 = String.valueOf(var2.getMethod("getWorldName").invoke(var1));
         int var7 = ((Number)var2.getMethod("getX").invoke(var1)).intValue();
         int var8 = ((Number)var2.getMethod("getY").invoke(var1)).intValue();
         int var9 = ((Number)var2.getMethod("getZ").invoke(var1)).intValue();
         int var10 = ((Number)var2.getMethod("getLevel").invoke(var1)).intValue();
         return new ZGenBoss.GeneratorRef(var3, var5, var6, var7, var8, var9, var10);
      } catch (Throwable var11) {
         return null;
      }
   }

   private boolean canSpawnFor(ZGenBoss.GeneratorRef var1) {
      int var2 = Math.max(1, this.getConfig().getInt("limits.max-active-global", 8));
      if (this.activeBosses.size() >= var2) {
         return false;
      }

      int var3 = Math.max(1, this.getConfig().getInt("limits.max-active-per-owner", 2));
      long var4 = this.activeBosses.values().stream().filter(var1x -> var1x.ownerUuid.equals(var1.ownerUuid)).count();
      if (var4 >= var3) {
         return false;
      }

      Player var6 = Bukkit.getPlayer(var1.ownerUuid);
      if (!PlayerBossPreferences.canSpawn(this, var1, var6)) {
         return false;
      }

      World var7 = Bukkit.getWorld(var1.worldName);
      if (var7 == null) {
         return false;
      }

      double var8 = Math.max(4.0, this.getConfig().getDouble("spawn-conditions.player-radius", 24.0));
      double var10 = var8 * var8;
      Location var12 = new Location(var7, var1.x + 0.5, var1.y + 1.0, var1.z + 0.5);

      for (Player var14 : Bukkit.getOnlinePlayers()) {
         if (var14.isOnline() && var14.getWorld() != null && var14.getWorld().getName().equals(var7.getName())) {
            try {
               if (var14.getLocation().distanceSquared(var12) <= var10) {
                  return true;
               }
            } catch (Throwable var16) {
            }
         }
      }

      return false;
   }

   private boolean spawnBoss(ZGenBoss.GeneratorRef var1, ZGenBoss.BossType var2) {
      World var3 = Bukkit.getWorld(var1.worldName);
      if (var3 == null) {
         return false;
      }

      Location var4 = this.findSpawnLocation(var3, var1.x, var1.y, var1.z);
      if (var4 == null) {
         return false;
      }

      try {
         Class var5 = Class.forName("org.bukkit.entity.EntityType");
         Object var6 = enumValue(var5, var2.entityType);
         if (var6 == null) {
            return false;
         }

         Method var7 = var3.getClass().getMethod("spawnEntity", Location.class, var5);
         if (var7.invoke(var3, var4, var6) instanceof LivingEntity var9) {
            this.setAttribute(var9, new String[]{"MAX_HEALTH", "GENERIC_MAX_HEALTH"}, var2.health);
            this.setAttribute(var9, new String[]{"ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE"}, var2.damage);
            this.setAttribute(var9, new String[]{"MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED"}, var2.speed);
            this.setAttribute(var9, new String[]{"KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE"}, var2.knockbackResistance);

            try {
               var9.setHealth(var2.health);
            } catch (Throwable var13) {
            }

            invokeIfPresent(var9, "setRemoveWhenFarAway", new Class[]{boolean.class}, false);
            invokeIfPresent(var9, "setCanPickupItems", new Class[]{boolean.class}, false);
            invokeIfPresent(var9, "setPersistent", new Class[]{boolean.class}, true);
            invokeIfPresent(var9, "setAI", new Class[]{boolean.class}, true);
            invokeIfPresent(var9, "setAware", new Class[]{boolean.class}, true);
            invokeIfPresent(var9, "setCustomNameVisible", new Class[]{boolean.class}, true);
            invokeIfPresent(var9, "setGlowing", new Class[]{boolean.class}, this.getConfig().getBoolean("visuals.glowing", true));
            long var10 = System.currentTimeMillis();
            ZGenBoss.BossInstance var12 = new ZGenBoss.BossInstance(
               var9, var1.id, var1.ownerUuid, var1, var2, var10, var10 + Math.max(4, var2.pulseIntervalSeconds) * 1000L
            );
            BossLevelBalance.applySpawn(this, var12);
            this.activeBosses.put(var9.getUniqueId(), var12);
            this.activeByGenerator.put(var1.id, var9.getUniqueId());
            this.nextSpawnAt.put(var1.id, Long.MAX_VALUE);
            this.updateNameTag(var12);
            this.playSpawnAnimation(var12);
            this.announceNear(
               var4,
               this.getConfig().getDouble("messages.announce-radius", 32.0),
               this.getConfig().getString("messages.spawn", "&d✦ &f%boss% &7Mini bossu ortaya çıktı!"),
               var12
            );
            return true;
         } else {
            return false;
         }
      } catch (Throwable var14) {
         this.getLogger().warning("Boss olusturulamadi (" + var2.id + "): " + var14.getClass().getSimpleName() + ": " + var14.getMessage());
         return false;
      }
   }

   private Location findSpawnLocation(World var1, int var2, int var3, int var4) {
      int var5 = Math.max(3, this.getConfig().getInt("spawn-conditions.max-upward-search", 8));

      for (int var6 = 1; var6 <= var5; var6++) {
         if (this.isAir(var1, var2, var3 + var6, var4) && this.isAir(var1, var2, var3 + var6 + 1, var4)) {
            return new Location(var1, var2 + 0.5, var3 + var6, var4 + 0.5);
         }
      }

      return new Location(var1, var2 + 0.5, var3 + var5 + 1.0, var4 + 0.5);
   }

   private boolean isAir(World var1, int var2, int var3, int var4) {
      try {
         Object var5 = var1.getClass().getMethod("getBlockAt", int.class, int.class, int.class).invoke(var1, var2, var3, var4);
         Object var6 = var5.getClass().getMethod("getType").invoke(var5);
         Object var7 = var6.getClass().getMethod("isAir").invoke(var6);
         return Boolean.TRUE.equals(var7);
      } catch (Throwable var8) {
         return true;
      }
   }

   private void tickActiveBosses() {
      if (this.getConfig().getBoolean("system.enabled", true)) {
         this.activeTickCounter += 10L;
         long var1 = System.currentTimeMillis();
         long var3 = Math.max(60, this.getConfig().getInt("limits.max-lifetime-seconds", 300)) * 1000L;

         for (ZGenBoss.BossInstance var6 : new ArrayList<>(this.activeBosses.values())) {
            LivingEntity var7 = var6.entity;
            if (var7 != null && var7.isValid() && !var7.isDead()) {
               if (var1 - var6.spawnedAt >= var3) {
                  Location var8 = var7.getLocation();
                  this.playParticle(var8, "CLOUD", 18, 0.5, 0.7, 0.5, 0.02);
                  this.playSound(var8, "minecraft:entity.enderman.teleport", 0.6F, 0.8F);
                  var7.remove();
                  this.cleanupBoss(var6, true);
               } else {
                  this.updateNameTag(var6);
                  this.ensureBossTarget(var6);
                  int var10 = Math.max(10, this.getConfig().getInt("visuals.aura-every-ticks", 20));
                  if (this.getConfig().getBoolean("visuals.aura-enabled", true) && this.activeTickCounter % var10 == 0L) {
                     Location var9 = var7.getLocation().clone().add(0.0, 0.65, 0.0);
                     this.playParticle(var9, var6.type.particle, Math.max(1, var6.type.auraCount), var6.type.auraSpread, 0.45, var6.type.auraSpread, 0.01);
                  }

                  if (var1 >= var6.nextPulseAt) {
                     if (this.getConfig().getBoolean("visuals.pulse-enabled", true)) {
                        this.playPulse(var6);
                     }

                     var6.nextPulseAt = var1 + Math.max(4, var6.type.pulseIntervalSeconds) * 1000L;
                  }
               }
            } else {
               this.cleanupBoss(var6, false);
            }
         }
      }
   }

   private void ensureBossTarget(ZGenBoss.BossInstance var1) {
      BossCombatFix.ensureTarget(this, var1);
   }

   private boolean isNonCombatGameMode(Player var1) {
      try {
         Object var2 = var1.getClass().getMethod("getGameMode").invoke(var1);
         if (var2 == null) {
            return false;
         }

         String var3 = String.valueOf(var2);
         return var3.equalsIgnoreCase("CREATIVE") || var3.equalsIgnoreCase("SPECTATOR");
      } catch (Throwable var4) {
         return false;
      }
   }

   private void updateNameTag(ZGenBoss.BossInstance var1) {
      try {
         if (!this.getConfig().getBoolean("visuals.name-tag-enabled", true)) {
            if (!"".equals(var1.lastNameTag)) {
               invokeIfPresent(var1.entity, "setCustomNameVisible", new Class[]{boolean.class}, false);
               var1.lastNameTag = "";
            }

            return;
         }

         double var2 = Math.max(0.0, var1.entity.getHealth());
         String var4 = this.getConfig().getString("visuals.name-tag-format", "&d%boss% &8• &c❤ &f%health%&7/%max_health%");
         String var5 = BossMessageFix.replaceIgnoreCase(
            BossMessageFix.replaceIgnoreCase(BossMessageFix.replaceIgnoreCase(var4, "%boss%", var1.type.displayName), "%health%", formatNumber(var2)),
            "%max_health%",
            formatNumber(BossLevelBalance.scaledHealth(this, var1))
         );
         String var7 = color(var5);
         if (var7.equals(var1.lastNameTag)) {
            return;
         }

         invokeIfPresent(var1.entity, "setCustomName", new Class[]{String.class}, var7);
         invokeIfPresent(var1.entity, "setCustomNameVisible", new Class[]{boolean.class}, true);
         var1.lastNameTag = var7;
      } catch (Throwable var6) {
      }
   }

   private void playSpawnAnimation(ZGenBoss.BossInstance var1) {
      if (this.getConfig().getBoolean("visuals.spawn-animation-enabled", true)) {
         Location var2 = var1.entity.getLocation().clone().add(0.0, 0.8, 0.0);
         this.playParticle(var2, var1.type.particle, 45, 0.8, 0.9, 0.8, 0.04);
         this.playParticle(var2, "END_ROD", 20, 0.6, 0.8, 0.6, 0.02);
         this.playSound(var2, var1.type.spawnSound, 1.0F, 0.9F);
         Bukkit.getScheduler().runTaskLater(this, () -> {
            if (var1.entity.isValid() && !var1.entity.isDead()) {
               Location var2x = var1.entity.getLocation().clone().add(0.0, 1.0, 0.0);
               this.playParticle(var2x, var1.type.particle, 28, 0.55, 0.7, 0.55, 0.02);
               this.playSound(var2x, "minecraft:block.beacon.power_select", 0.65F, 1.25F);
            }
         }, 8L);
      }
   }

   private void playPulse(ZGenBoss.BossInstance var1) {
      Location var2 = var1.entity.getLocation().clone().add(0.0, 0.8, 0.0);
      this.playParticle(var2, var1.type.particle, Math.max(12, var1.type.auraCount * 3), 1.0, 0.75, 1.0, 0.03);
      this.playParticle(var2, "ENCHANT", 12, 0.8, 0.8, 0.8, 0.02);
      this.playSound(var2, var1.type.pulseSound, 0.55F, 1.15F);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBossDeath(EntityDeathEvent var1) {
      ZGenBoss.BossInstance var2 = this.activeBosses.get(var1.getEntity().getUniqueId());
      if (var2 != null) {
         this.getConfig().getBoolean("rewards.clear-vanilla-drops", true);
         if (true) {
            var1.getDrops().clear();
            var1.setDroppedExp(0);
         }

         Location var3 = var1.getEntity().getLocation();
         if (this.getConfig().getBoolean("visuals.death-animation-enabled", true)) {
            this.playParticle(var3.clone().add(0.0, 0.8, 0.0), "TOTEM_OF_UNDYING", 28, 0.7, 0.8, 0.7, 0.08);
            this.playParticle(var3.clone().add(0.0, 0.8, 0.0), var2.type.particle, 35, 0.9, 0.8, 0.9, 0.05);
            this.playSound(var3, var2.type.deathSound, 0.9F, 1.0F);
         }

         Player var4 = var1.getEntity().getKiller();
         if (var4 != null && var4.isOnline()) {
            if (this.getConfig().getBoolean("rewards.enabled", true)) {
               this.grantRewards(var4, var2);
            } else {
               var2.lastRewardName = "kapali";
            }

            if (this.getConfig().getBoolean("messages.enabled", true)) {
               String var5 = this.getConfig().getString("messages.killed", "&a✦ &f%boss% &7Yenildi. &födül: &a%reward%");
               var4.sendMessage(
                  color(
                     BossMessageFix.replaceIgnoreCase(
                        BossMessageFix.replaceIgnoreCase(var5, "%boss%", var2.type.displayName),
                        "%reward%",
                        var2.lastRewardName == null ? "odul" : var2.lastRewardName
                     )
                  )
               );
            }
         }

         this.announceNear(
            var3,
            this.getConfig().getDouble("messages.announce-radius", 32.0),
            this.getConfig().getString("messages.death", "&a✦ &f%boss% &7Mini bossu yenildi."),
            var2
         );
         this.cleanupBoss(var2, true);
      }
   }

   private void grantRewards(Player var1, ZGenBoss.BossInstance var2) {
      ArrayList var3 = new ArrayList();
      this.grantLevelXpReward(var1, var2, var3);
      var2.lastRewardName = var3.isEmpty() ? "GenPvP özel loot" : String.join(" §8• §a", var3);
      GenPvPLootFix.grant(this, var1, var2);
   }

   private void grantMoneyReward(Player var1, ZGenBoss.BossInstance var2, List<String> var3) {
      if (this.getConfig().getBoolean("rewards.money.enabled", true)) {
         double var4 = Math.max(0.0, this.getConfig().getDouble("rewards.money.min", 150.0));
         double var6 = Math.max(var4, this.getConfig().getDouble("rewards.money.max", 350.0));
         double var8 = randomDouble(var4, var6) * var2.type.rewardMultiplier;
         var8 = Math.max(0.0, Math.round(var8));
         if (!(var8 <= 0.0)) {
            try {
               Object var10 = this.zGenPvP.getClass().getMethod("getEconomyManager").invoke(this.zGenPvP);
               Object var11 = var10.getClass().getMethod("deposit", Player.class, double.class).invoke(var10, var1, var8);
               if (var11 instanceof Boolean && !Boolean.TRUE.equals(var11)) {
                  this.getLogger().warning("Boss para ödülü yatırılamadı: " + var1.getName());
               } else {
                  var3.add("$" + formatNumber(var8));
               }
            } catch (Throwable var12) {
               this.getLogger().warning("Boss para ödülü hatasi: " + var12.getClass().getSimpleName() + ": " + var12.getMessage());
            }
         }
      }
   }

   private void grantShardReward(Player var1, ZGenBoss.BossInstance var2, List<String> var3) {
      if (this.getConfig().getBoolean("rewards.shard.enabled", true)) {
         int var4 = Math.max(0, this.getConfig().getInt("rewards.shard.min", 1));
         int var5 = Math.max(var4, this.getConfig().getInt("rewards.shard.max", 3));
         long var6 = Math.max(0L, Math.round(randomIntAllowZero(var4, var5) * var2.type.rewardMultiplier));
         if (var6 > 0L) {
            try {
               Object var8 = this.zGenPvP.getClass().getMethod("getZShardHook").invoke(this.zGenPvP);
               Object var9 = var8.getClass().getMethod("isAvailable").invoke(var8);
               if (!Boolean.TRUE.equals(var9)) {
                  return;
               }

               Object var10 = var8.getClass().getMethod("addShards", UUID.class, long.class).invoke(var8, var1.getUniqueId(), var6);
               if (Boolean.TRUE.equals(var10)) {
                  var3.add(var6 + " kristal");
               }
            } catch (Throwable var11) {
               this.getLogger().warning("Boss kristal ödülü hatasi: " + var11.getClass().getSimpleName() + ": " + var11.getMessage());
            }
         }
      }
   }

   private void grantLevelXpReward(Player var1, ZGenBoss.BossInstance var2, List<String> var3) {
      if (this.getConfig().getBoolean("rewards.level-xp.enabled", true)) {
         double var4 = Math.max(0.0, this.getConfig().getDouble("rewards.level-xp.min", 20.0));
         double var6 = Math.max(var4, this.getConfig().getDouble("rewards.level-xp.max", 45.0));
         double var8 = Math.max(0.0, Math.round(randomDouble(var4, var6) * var2.type.rewardMultiplier));
         if (!(var8 <= 0.0)) {
            try {
               Object var10 = this.zGenPvP.getClass().getMethod("getLevelManager").invoke(this.zGenPvP);
               Object var11 = var10.getClass().getMethod("isEnabled").invoke(var10);
               if (!Boolean.TRUE.equals(var11)) {
                  return;
               }

               var10.getClass().getMethod("addXp", UUID.class, double.class).invoke(var10, var1.getUniqueId(), var8);

               try {
                  var10.getClass().getMethod("syncHud", Player.class).invoke(var10, var1);
               } catch (Throwable var13) {
               }

               var3.add(formatNumber(var8) + " xp");
            } catch (Throwable var14) {
               this.getLogger().warning("Boss XP ödülü hatasi: " + var14.getClass().getSimpleName() + ": " + var14.getMessage());
            }
         }
      }
   }

   private ItemStack createRareEnchantBook(String var1) {
      try {
         String[] var2 = var1.split(":");
         if (var2.length < 2) {
            return null;
         } else {
            String var3 = var2[0].trim().toLowerCase(Locale.ROOT);
            int var4 = Math.max(1, Integer.parseInt(var2[1].trim()));
            Material var5 = Material.valueOf("ENCHANTED_BOOK");
            ItemStack var6 = new ItemStack(var5, 1);
            ItemMeta var7 = var6.getItemMeta();
            if (var7 == null) {
               return null;
            } else {
               Object var8 = this.resolveEnchantment(var3);
               if (var8 == null) {
                  return null;
               } else {
                  Class var9 = Class.forName("org.bukkit.enchantments.Enchantment");
                  Method var10 = var7.getClass().getMethod("addStoredEnchant", var9, int.class, boolean.class);
                  if (var10.invoke(var7, var8, var4, true) instanceof Boolean var12 && !var12) {
                     return null;
                  } else {
                     var7.displayName(Component.text("nadir efsun kitabi").decoration(TextDecoration.ITALIC, false).decoration(TextDecoration.BOLD, false));
                     var7.lore(
                        List.of(
                           Component.text("mini boss ödülü").decoration(TextDecoration.ITALIC, false),
                           Component.text("efsun: " + smallCaps(var3.replace('_', ' ')) + " " + var4).decoration(TextDecoration.ITALIC, false)
                        )
                     );
                     var6.setItemMeta(var7);
                     return var6;
                  }
               }
            }
         }
      } catch (Throwable var13) {
         this.getLogger().warning("Nadir efsun kitabi olusturulamadi: " + var1 + " -> " + var13.getClass().getSimpleName());
         return null;
      }
   }

   private Object resolveEnchantment(String var1) {
      try {
         Class var2 = Class.forName("org.bukkit.NamespacedKey");
         Object var3 = var2.getMethod("minecraft", String.class).invoke(null, var1);

         try {
            Class var4 = Class.forName("org.bukkit.Registry");
            Field var5 = var4.getField("ENCHANTMENT");
            Object var6 = var5.get(null);
            Object var7 = var6.getClass().getMethod("get", var2).invoke(var6, var3);
            if (var7 != null) {
               return var7;
            }
         } catch (Throwable var8) {
         }

         Class var10 = Class.forName("org.bukkit.enchantments.Enchantment");
         return var10.getMethod("getByKey", var2).invoke(null, var3);
      } catch (Throwable var9) {
         return null;
      }
   }

   private ZGenBoss.RewardEntry chooseReward(List<String> var1) {
      ArrayList<ZGenBoss.RewardEntry> var2 = new ArrayList<>();
      double var3 = 0.0;

      for (String var6 : var1) {
         ZGenBoss.RewardEntry var7 = ZGenBoss.RewardEntry.parse(var6);
         if (var7 != null && !(var7.weight <= 0.0)) {
            var2.add(var7);
            var3 += var7.weight;
         }
      }

      if (!var2.isEmpty() && !(var3 <= 0.0)) {
         double var11 = ThreadLocalRandom.current().nextDouble(var3);
         double var12 = 0.0;

         for (ZGenBoss.RewardEntry var10 : var2) {
            var12 += var10.weight;
            if (var11 <= var12) {
               return var10;
            }
         }

         return (ZGenBoss.RewardEntry)var2.get(var2.size() - 1);
      } else {
         return null;
      }
   }

   private void giveOrDrop(Player var1, ItemStack var2) {
      try {
         Inventory var3 = var1.getInventory();
         HashMap<Integer, ItemStack> var4 = var3.addItem(new ItemStack[]{var2});
         if (var4 == null || var4.isEmpty()) {
            return;
         }

         for (ItemStack var6 : var4.values()) {
            World var7 = var1.getWorld();
            var7.getClass().getMethod("dropItemNaturally", Location.class, ItemStack.class).invoke(var7, var1.getLocation(), var6);
         }
      } catch (Throwable var8) {
         this.getLogger().warning("Ödül oyuncuya verilemedi: " + var8.getMessage());
      }
   }

   private void cleanupBoss(ZGenBoss.BossInstance var1, boolean var2) {
      this.activeBosses.remove(var1.entity.getUniqueId());
      this.activeByGenerator.remove(var1.generatorId);
      if (var2) {
         this.nextSpawnAt.put(var1.generatorId, System.currentTimeMillis() + this.randomSpawnDelayMillis());
      }
   }

   private ZGenBoss.BossType chooseBossType() {
      ArrayList<ZGenBoss.BossType> var1 = new ArrayList<>();
      int var2 = 0;

      for (String var6 : BOSS_IDS) {
         ZGenBoss.BossType var7 = this.readBossType(var6);
         if (var7 != null && var7.enabled && var7.weight > 0) {
            var1.add(var7);
            var2 += var7.weight;
         }
      }

      if (!var1.isEmpty() && var2 > 0) {
         int var8 = ThreadLocalRandom.current().nextInt(var2);
         int var9 = 0;

         for (ZGenBoss.BossType var11 : var1) {
            var9 += var11.weight;
            if (var8 < var9) {
               return var11;
            }
         }

         return (ZGenBoss.BossType)var1.get(var1.size() - 1);
      } else {
         return null;
      }
   }

   private ZGenBoss.BossType readBossType(String var1) {
      FileConfiguration var2 = this.getConfig();
      String var3 = "bosses." + var1 + ".";
      return !var2.contains(var3 + "entity")
         ? null
         : new ZGenBoss.BossType(
            var1,
            var2.getBoolean(var3 + "enabled", true),
            var2.getInt(var3 + "weight", 10),
            var2.getString(var3 + "entity", "ZOMBIE"),
            var2.getString(var3 + "display-name", smallCaps(var1.replace('_', ' '))),
            Math.max(10.0, var2.getDouble(var3 + "health", 60.0)),
            Math.max(1.0, var2.getDouble(var3 + "damage", 4.0)),
            clamp(var2.getDouble(var3 + "speed", 0.25), 0.1, 0.45),
            clamp(var2.getDouble(var3 + "knockback-resistance", 0.25), 0.0, 1.0),
            var2.getString(var3 + "particle", "END_ROD"),
            Math.max(1, var2.getInt(var3 + "aura-count", 5)),
            clamp(var2.getDouble(var3 + "aura-spread", 0.35), 0.05, 2.0),
            Math.max(4, var2.getInt(var3 + "pulse-interval-seconds", 8)),
            clamp(var2.getDouble(var3 + "reward-multiplier", 1.0), 0.25, 3.0),
            var2.getString(var3 + "spawn-sound", "minecraft:entity.evoker.prepare_summon"),
            var2.getString(var3 + "pulse-sound", "minecraft:block.amethyst_block.chime"),
            var2.getString(var3 + "death-sound", "minecraft:entity.experience_orb.pickup")
         );
   }

   private long randomSpawnDelayMillis() {
      int var1 = this.getConfig().getInt("spawn-timing.min-minutes", 5);
      int var2 = this.getConfig().getInt("spawn-timing.max-minutes", 10);
      if (var1 == 20 && var2 == 35) {
         var1 = 5;
         var2 = 10;
      }

      int var3 = Math.max(1, var1);
      int var4 = Math.max(var3, var2);
      long var5 = var3 * 60000L;
      long var7 = var4 * 60000L;
      return var5 == var7 ? var5 : ThreadLocalRandom.current().nextLong(var5, var7 + 1L);
   }

   private void setAttribute(LivingEntity var1, String[] var2, double var3) {
      try {
         Class var5 = Class.forName("org.bukkit.attribute.Attribute");
         Object var6 = null;

         for (String var10 : var2) {
            try {
               var6 = var5.getField(var10).get(null);
               if (var6 != null) {
                  break;
               }
            } catch (Throwable var12) {
            }
         }

         if (var6 == null) {
            return;
         }

         Object var14 = var1.getClass().getMethod("getAttribute", var5).invoke(var1, var6);
         if (var14 == null) {
            return;
         }

         var14.getClass().getMethod("setBaseValue", double.class).invoke(var14, var3);
      } catch (Throwable var13) {
      }
   }

   private void playParticle(Location var1, String var2, int var3, double var4, double var6, double var8, double var10) {
      if (this.getConfig().getBoolean("visuals.particles-enabled", true)) {
         if (var1 != null && var1.getWorld() != null) {
            try {
               Class var12 = Class.forName("org.bukkit.Particle");
               Object var13 = enumValue(var12, var2);
               if (var13 == null) {
                  var13 = enumValue(var12, "END_ROD");
               }

               if (var13 == null) {
                  return;
               }

               Method var14 = var1.getWorld()
                  .getClass()
                  .getMethod("spawnParticle", var12, Location.class, int.class, double.class, double.class, double.class, double.class);
               var14.invoke(var1.getWorld(), var13, var1, var3, var4, var6, var8, var10);
            } catch (Throwable var15) {
            }
         }
      }
   }

   private void playSound(Location var1, String var2, float var3, float var4) {
      if (this.getConfig().getBoolean("visuals.sounds-enabled", true)) {
         if (var1 != null && var1.getWorld() != null && var2 != null && !var2.isBlank()) {
            try {
               var1.getWorld()
                  .getClass()
                  .getMethod("playSound", Location.class, String.class, float.class, float.class)
                  .invoke(var1.getWorld(), var1, var2, var3, var4);
            } catch (Throwable var6) {
            }
         }
      }
   }

   private void announceNear(Location var1, double var2, String var4, ZGenBoss.BossInstance var5) {
      if (this.getConfig().getBoolean("messages.enabled", true)) {
         if (var1 != null && var1.getWorld() != null && var4 != null && !var4.isBlank()) {
            double var6 = Math.max(4.0, var2) * Math.max(4.0, var2);
            String var8 = color(
               BossMessageFix.replaceIgnoreCase(
                  BossMessageFix.replaceIgnoreCase(var4, "%boss%", var5.type.displayName), "%owner%", this.ownerName(var5.ownerUuid)
               )
            );

            for (Player var10 : Bukkit.getOnlinePlayers()) {
               if (var10.isOnline() && var10.getWorld() != null && var10.getWorld().getName().equals(var1.getWorld().getName())) {
                  try {
                     if (var10.getLocation().distanceSquared(var1) <= var6) {
                        var10.sendMessage(var8);
                     }
                  } catch (Throwable var12) {
                  }
               }
            }
         }
      }
   }

   private String ownerName(UUID var1) {
      Player var2 = Bukkit.getPlayer(var1);
      return var2 == null ? "oyuncu" : var2.getName();
   }

   private static Object enumValue(Class<?> var0, String var1) {
      if (var1 == null) {
         return null;
      }

      try {
         Method var2 = var0.getMethod("valueOf", String.class);
         return var2.invoke(null, var1.trim().toUpperCase(Locale.ROOT));
      } catch (Throwable var3) {
         return null;
      }
   }

   private static void invokeIfPresent(Object var0, String var1, Class<?>[] var2, Object... var3) {
      try {
         var0.getClass().getMethod(var1, var2).invoke(var0, var3);
      } catch (Throwable var5) {
      }
   }

   private static int randomInt(int var0, int var1) {
      int var2 = Math.max(1, Math.min(var0, var1));
      int var3 = Math.max(var2, Math.max(var0, var1));
      return var2 == var3 ? var2 : ThreadLocalRandom.current().nextInt(var2, var3 + 1);
   }

   private static int randomIntAllowZero(int var0, int var1) {
      int var2 = Math.max(0, Math.min(var0, var1));
      int var3 = Math.max(var2, Math.max(var0, var1));
      return var2 == var3 ? var2 : ThreadLocalRandom.current().nextInt(var2, var3 + 1);
   }

   private static double randomDouble(double var0, double var2) {
      double var4 = Math.max(0.0, Math.min(var0, var2));
      double var6 = Math.max(var4, Math.max(var0, var2));
      return Math.abs(var4 - var6) < 1.0E-4 ? var4 : ThreadLocalRandom.current().nextDouble(var4, var6);
   }

   private static double clamp(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   private static String formatNumber(double var0) {
      return Math.abs(var0 - Math.rint(var0)) < 0.01 ? String.valueOf((long)Math.rint(var0)) : String.format(Locale.US, "%.1f", var0);
   }

   private static String color(String var0) {
      var0 = BossMessageFix.applyPrefix(var0);
      return var0 == null ? "" : var0.replace('&', '§');
   }

   private static String stripLegacy(String var0) {
      if (var0 == null) {
         return "";
      }

      StringBuilder var1 = new StringBuilder();
      boolean var2 = false;

      for (int var3 = 0; var3 < var0.length(); var3++) {
         char var4 = var0.charAt(var3);
         if ((var4 == '&' || var4 == 167) && var3 + 1 < var0.length()) {
            var3++;
         } else if (!var2) {
            var1.append(var4);
         }
      }

      return var1.toString();
   }

   private static String smallCaps(String var0) {
      if (var0 == null) {
         return "";
      }

      String var1 = "abcdefghijklmnopqrstuvwxyz";
      String var2 = "abcdefghijklmnopqrstuvwxyz";
      StringBuilder var3 = new StringBuilder(var0.length());

      for (char var7 : var0.toLowerCase(Locale.ROOT).toCharArray()) {
         int var8 = var1.indexOf(var7);
         var3.append(var8 >= 0 ? var2.charAt(var8) : var7);
      }

      return var3.toString();
   }

   private static final class BossInstance {
      final LivingEntity entity;
      final long generatorId;
      final UUID ownerUuid;
      final ZGenBoss.GeneratorRef generator;
      final ZGenBoss.BossType type;
      final long spawnedAt;
      long nextPulseAt;
      String lastRewardName;
      String lastNameTag;

      BossInstance(LivingEntity var1, long var2, UUID var4, ZGenBoss.GeneratorRef var5, ZGenBoss.BossType var6, long var7, long var9) {
         this.entity = var1;
         this.generatorId = var2;
         this.ownerUuid = var4;
         this.generator = var5;
         this.type = var6;
         this.spawnedAt = var7;
         this.nextPulseAt = var9;
      }
   }

   private static final class BossType {
      final String id;
      final boolean enabled;
      final int weight;
      final String entityType;
      final String displayName;
      final double health;
      final double damage;
      final double speed;
      final double knockbackResistance;
      final String particle;
      final int auraCount;
      final double auraSpread;
      final int pulseIntervalSeconds;
      final double rewardMultiplier;
      final String spawnSound;
      final String pulseSound;
      final String deathSound;

      BossType(
         String var1,
         boolean var2,
         int var3,
         String var4,
         String var5,
         double var6,
         double var8,
         double var10,
         double var12,
         String var14,
         int var15,
         double var16,
         int var18,
         double var19,
         String var21,
         String var22,
         String var23
      ) {
         this.id = var1;
         this.enabled = var2;
         this.weight = var3;
         this.entityType = var4;
         this.displayName = var5;
         this.health = var6;
         this.damage = var8;
         this.speed = var10;
         this.knockbackResistance = var12;
         this.particle = var14;
         this.auraCount = var15;
         this.auraSpread = var16;
         this.pulseIntervalSeconds = var18;
         this.rewardMultiplier = var19;
         this.spawnSound = var21;
         this.pulseSound = var22;
         this.deathSound = var23;
      }
   }

   private record GeneratorRef(long id, UUID ownerUuid, String worldName, int x, int y, int z, int level) {
   }

   private static final class RewardEntry {
      final String material;
      final double weight;
      final int minAmount;
      final int maxAmount;
      final String displayName;

      RewardEntry(String var1, double var2, int var4, int var5, String var6) {
         this.material = var1;
         this.weight = var2;
         this.minAmount = var4;
         this.maxAmount = var5;
         this.displayName = var6;
      }

      static ZGenBoss.RewardEntry parse(String var0) {
         if (var0 != null && !var0.isBlank()) {
            String[] var1 = var0.split("\\|", 5);
            if (var1.length < 5) {
               return null;
            }

            try {
               return new ZGenBoss.RewardEntry(
                  var1[0].trim(), Double.parseDouble(var1[1].trim()), Integer.parseInt(var1[2].trim()), Integer.parseInt(var1[3].trim()), var1[4].trim()
               );
            } catch (NumberFormatException var3) {
               return null;
            }
         } else {
            return null;
         }
      }
   }
}
