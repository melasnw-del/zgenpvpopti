package com.zzwproject.zgenpvp.haste;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class HasteItemManager {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private final ZGenPvP plugin;
   private final NamespacedKey hasteItemKey;
   private FileConfiguration config;

   public HasteItemManager(ZGenPvP plugin) {
      this.plugin = plugin;
      this.hasteItemKey = new NamespacedKey(plugin, "haste_item");
      this.load();
   }

   public void load() {
      File file = new File(this.plugin.getDataFolder(), "haste.yml");
      if (!file.exists()) {
         this.plugin.saveResource("haste.yml", false);
      }

      this.reload();
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "haste.yml");
      this.config = YamlConfiguration.loadConfiguration(file);
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public boolean isEnabled() {
      return this.config.getBoolean("enabled", true);
   }

   public int getDurationSeconds() {
      return Math.max(1, this.config.getInt("duration-seconds", 60));
   }

   public int getAmplifier() {
      return Math.max(0, this.config.getInt("amplifier", 1));
   }

   public ItemStack createItem(int amount) {
      String materialName = this.config.getString("item.material", "SUGAR");
      Material material = Material.matchMaterial(materialName == null ? "SUGAR" : materialName);
      if (material == null || material.isAir()) {
         material = Material.SUGAR;
      }

      int finalAmount = Math.max(1, Math.min(material.getMaxStackSize(), amount));
      ItemStack item = new ItemStack(material, finalAmount);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.getPersistentDataContainer().set(this.hasteItemKey, PersistentDataType.BYTE, (byte)1);
      String name = this.config.getString("item.name", "&eAcele 2");
      meta.displayName(this.component(this.replace(name, "%duration%", String.valueOf(this.getDurationSeconds()))));
      List<Component> lore = new ArrayList<>();

      for (String line : this.config.getStringList("item.lore")) {
         lore.add(this.component(this.replace(line, "%duration%", String.valueOf(this.getDurationSeconds()))));
      }

      meta.lore(lore);
      int customModelData = this.config.getInt("item.custom-model-data", 0);
      if (customModelData > 0) {
         meta.setCustomModelData(customModelData);
      }

      item.setItemMeta(meta);
      return item;
   }

   public boolean isHasteItem(ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         Byte value = (Byte)item.getItemMeta().getPersistentDataContainer().get(this.hasteItemKey, PersistentDataType.BYTE);
         return value != null && value == 1;
      } else {
         return false;
      }
   }

   public boolean give(Player player, int amount) {
      if (player != null && amount >= 1 && amount <= 64) {
         ItemStack item = this.createItem(amount);
         Map<Integer, ItemStack> overflow = player.getInventory().addItem(new ItemStack[]{item});

         for (ItemStack leftover : overflow.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
         }

         this.sendMessage(player, "messages.received", "%amount%", String.valueOf(amount));
         return true;
      } else {
         return false;
      }
   }

   public boolean use(Player player) {
      if (player == null) {
         return false;
      }

      if (!this.isEnabled()) {
         this.sendMessage(player, "messages.disabled");
         return false;
      }

      if (!player.hasPermission("zgenpvp.haste.use")) {
         this.sendMessage(player, "messages.no-permission");
         return false;
      }

      ItemStack item = player.getInventory().getItemInMainHand();
      if (!this.isHasteItem(item)) {
         return false;
      }

      int amplifier = this.getAmplifier();
      PotionEffect existing = player.getPotionEffect(PotionEffectType.HASTE);
      if (existing != null) {
         if (this.config.getBoolean("protect-stronger-effects", true) && existing.getAmplifier() > amplifier) {
            this.sendMessage(player, "messages.stronger-effect");
            return false;
         }

         if (existing.getAmplifier() == amplifier && !this.config.getBoolean("allow-refresh", true)) {
            this.sendMessage(player, "messages.already-active");
            return false;
         }
      }

      int durationSeconds = this.getDurationSeconds();
      PotionEffect effect = new PotionEffect(PotionEffectType.HASTE, durationSeconds * 20, amplifier, false, true, true);
      boolean applied = player.addPotionEffect(effect, true);
      if (!applied) {
         this.sendMessage(player, "messages.failed");
         return false;
      } else {
         this.consumeItem(player);
         this.playSuccessEffect(player.getLocation());
         this.sendMessage(player, "messages.used", "%duration%", String.valueOf(durationSeconds));
         this.sendActionBar(player, "messages.used-actionbar", "%duration%", String.valueOf(durationSeconds));
         return true;
      }
   }

   private void consumeItem(Player player) {
      if (player.getGameMode() != GameMode.CREATIVE || this.config.getBoolean("consume-in-creative", false)) {
         ItemStack item = player.getInventory().getItemInMainHand();
         if (this.isHasteItem(item)) {
            if (item.getAmount() <= 1) {
               player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            } else {
               item.setAmount(item.getAmount() - 1);
               player.getInventory().setItemInMainHand(item);
            }
         }
      }
   }

   private void playSuccessEffect(Location location) {
      if (location != null && location.getWorld() != null) {
         World world = location.getWorld();
         Location effectLocation = location.clone().add(0.0, 1.0, 0.0);
         Particle particle = this.resolveParticle(this.config.getString("effects.success.particle", "HAPPY_VILLAGER"));
         int count = Math.max(0, this.config.getInt("effects.success.particle-count", 15));
         if (particle != null && count > 0) {
            world.spawnParticle(particle, effectLocation, count, 0.35, 0.5, 0.35, 0.05);
         }

         String sound = this.normalizeSound(this.config.getString("effects.success.sound", "ENTITY_PLAYER_LEVELUP"));
         float volume = (float)this.config.getDouble("effects.success.volume", 1.0);
         float pitch = (float)this.config.getDouble("effects.success.pitch", 1.5);
         world.playSound(effectLocation, sound, volume, pitch);
      }
   }

   private Particle resolveParticle(String configured) {
      if (configured != null && !configured.isBlank()) {
         String raw = configured.trim().toLowerCase(Locale.ROOT);
         if (!raw.contains(":")) {
            raw = "minecraft:" + raw;
         }

         NamespacedKey key = NamespacedKey.fromString(raw);
         if (key == null) {
            return Particle.HAPPY_VILLAGER;
         }

         Particle particle = (Particle)Registry.PARTICLE_TYPE.get(key);
         return particle == null ? Particle.HAPPY_VILLAGER : particle;
      } else {
         return Particle.HAPPY_VILLAGER;
      }
   }

   private String normalizeSound(String configured) {
      if (configured != null && !configured.isBlank()) {
         String sound = configured.trim().toLowerCase(Locale.ROOT);
         return sound.contains(":") ? sound : "minecraft:" + sound.replace('_', '.');
      } else {
         return "minecraft:entity.player.levelup";
      }
   }

   public void sendMessage(CommandSender var1, String var2, String... var3) {
      if (var1 != null) {
         String var4 = this.config.getString(var2);
         if (var4 != null && !var4.isBlank()) {
            String var5 = this.config.getString("messages.prefix", "&eAcele II &8» &r");
            if (var5 == null) {
               var5 = "";
            }

            var4 = var4.replace("%prefix%", var5).replace("%Prefix%", var5);
            var4 = this.replace(var4, var3);
            var1.sendMessage(this.component(var4));
         }
      }
   }

   public void sendHelp(CommandSender sender) {
      for (String line : this.config.getStringList("messages.help")) {
         sender.sendMessage(this.component(line));
      }
   }

   private void sendActionBar(Player player, String path, String... replacements) {
      String message = this.config.getString(path);
      if (message != null && !message.isBlank()) {
         player.sendActionBar(this.component(this.replace(message, replacements)));
      }
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private Component component(String input) {
      return LegacyComponentSerializer.legacySection().deserialize(this.colorize(input));
   }

   private String colorize(String input) {
      if (input == null) {
         return "";
      }

      Matcher matcher = HEX_PATTERN.matcher(input);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         StringBuilder replacement = new StringBuilder("§X");

         for (char character : hex.toCharArray()) {
            replacement.append('§').append(character);
         }

         matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement.toString()));
      }

      matcher.appendTail(buffer);
      return buffer.toString().replace('&', '§');
   }
}
