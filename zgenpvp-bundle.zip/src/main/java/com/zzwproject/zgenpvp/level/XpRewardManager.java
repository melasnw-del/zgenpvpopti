package com.zzwproject.zgenpvp.level;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.integration.RaidSessionBridge;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class XpRewardManager {
   private final ZGenPvP plugin;
   private final LevelManager levelManager;
   private final Map<XpRewardManager.KillKey, Long> killCooldowns = new HashMap<>();
   private final Map<XpRewardType, XpRewardManager.RewardSettings> rewardSettings = new EnumMap<>(XpRewardType.class);
   private final Map<UUID, XpRewardManager.CachedMultiplier> multiplierCache = new HashMap<>();
   private boolean linkedBonusEnabled;
   private boolean permissionFallbackEnabled;
   private double vipFallbackBonus;
   private double mvipFallbackBonus;
   private double sponsorFallbackBonus;
   private long multiplierCacheMillis;
   private Plugin zBotPlugin;
   private Method linkedBonusMethod;
   private boolean zBotWarningLogged;

   public XpRewardManager(ZGenPvP var1, LevelManager var2) {
      this.plugin = var1;
      this.levelManager = var2;
      this.reload();
   }

   public boolean reward(Player var1, XpRewardType var2) {
      return RaidSessionBridge.suppressStructureXp(var1, var2) ? false : this.reward(var1, var2, 1.0);
   }

   public boolean reward(Player var1, XpRewardType var2, double var3) {
      if (RaidSessionBridge.suppressStructureXp(var1, var2)) {
         return false;
      }

      if (var1 != null && var2 != null && this.levelManager.isEnabled()) {
         XpRewardManager.RewardSettings var5 = this.rewardSettings.get(var2);
         if (var5 != null && var5.enabled()) {
            double var6 = var5.xp();
            var6 *= Math.max(0.0, var3) * this.getRankMultiplier(var1);
            if (var6 <= 0.0) {
               return false;
            }

            LevelManager.AddXpResult var8 = this.levelManager.addXp(var1.getUniqueId(), var6);
            if (!var8.success()) {
               return false;
            }

            this.levelManager.syncHud(var1);
            if (var8.leveledUp()) {
               this.showLevelUp(var1, var8.newLevel());
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private double getRankMultiplier(Player var1) {
      if (!this.linkedBonusEnabled) {
         return 1.0;
      }

      UUID var2 = var1.getUniqueId();
      long var3 = System.currentTimeMillis();
      XpRewardManager.CachedMultiplier var5 = this.multiplierCache.get(var2);
      if (var5 != null && var5.expiresAt() > var3) {
         return var5.multiplier();
      }

      double var6 = this.resolveRankMultiplier(var1);
      this.multiplierCache.put(var2, new XpRewardManager.CachedMultiplier(var6, var3 + this.multiplierCacheMillis));
      return var6;
   }

   private double resolveRankMultiplier(Player var1) {
      if (this.linkedBonusMethod != null && this.zBotPlugin != null && this.zBotPlugin.isEnabled()) {
         try {
            if (this.linkedBonusMethod.invoke(null, var1.getUniqueId()) instanceof Number var3) {
               return 1.0 + Math.max(0.0, var3.doubleValue());
            }
         } catch (ReflectiveOperationException | LinkageError var4) {
            if (!this.zBotWarningLogged) {
               this.zBotWarningLogged = true;
               this.plugin.getLogger().warning("Zbot xp bonusu okunamadi; permission fallback kullanılacak: " + var4.getMessage());
            }
         }
      }

      if (!this.permissionFallbackEnabled) {
         return 1.0;
      } else if (var1.hasPermission("zgenpvp.xp.multiplier.sponsor")) {
         return 1.0 + this.sponsorFallbackBonus;
      } else if (var1.hasPermission("zgenpvp.xp.multiplier.mvip")) {
         return 1.0 + this.mvipFallbackBonus;
      } else {
         return var1.hasPermission("zgenpvp.xp.multiplier.vip") ? 1.0 + this.vipFallbackBonus : 1.0;
      }
   }

   public void reload() {
      FileConfiguration var1 = this.plugin.getConfigManager().getLevels();
      this.rewardSettings.clear();

      for (XpRewardType var5 : XpRewardType.values()) {
         String var6 = "rewards." + var5.getConfigPath();
         this.rewardSettings
            .put(var5, new XpRewardManager.RewardSettings(var1.getBoolean(var6 + ".enabled", true), Math.max(0.0, var1.getDouble(var6 + ".xp", 0.0))));
      }

      this.linkedBonusEnabled = var1.getBoolean("linked-account-bonus.enabled", true);
      this.permissionFallbackEnabled = var1.getBoolean("linked-account-bonus.permission-fallback.enabled", false);
      this.vipFallbackBonus = Math.max(0.0, var1.getDouble("linked-account-bonus.permission-fallback.vip", 0.5));
      this.mvipFallbackBonus = Math.max(0.0, var1.getDouble("linked-account-bonus.permission-fallback.mvip", 1.0));
      this.sponsorFallbackBonus = Math.max(0.0, var1.getDouble("linked-account-bonus.permission-fallback.sponsor", 2.0));
      this.multiplierCacheMillis = Math.max(1000L, var1.getLong("linked-account-bonus.cache-seconds", 5L) * 1000L);
      this.multiplierCache.clear();
      this.linkedBonusMethod = null;
      this.zBotPlugin = null;
      this.zBotWarningLogged = false;
      if (this.linkedBonusEnabled) {
         try {
            Plugin var8 = (Plugin)BundleResolver.getPlugin(this.plugin.getServer().getPluginManager(), "zBot");
            if (var8 == null || !var8.isEnabled()) {
               return;
            }

            Class var9 = Class.forName("com.zzwproject.zbot.api.ZBotAPI", true, var8.getClass().getClassLoader());
            this.linkedBonusMethod = var9.getMethod("getLinkedBonusMultiplier", UUID.class);
            this.zBotPlugin = var8;
         } catch (ReflectiveOperationException | LinkageError var7) {
            this.plugin.getLogger().warning("Zbot xp bonus bağlantisi hazırlanamadı; permission fallback kullanılacak: " + var7.getMessage());
            this.zBotWarningLogged = true;
         }
      }
   }

   public boolean rewardPlayerKill(Player var1, Player var2) {
      if (var1 != null && var2 != null && !var1.getUniqueId().equals(var2.getUniqueId())) {
         FileConfiguration var3 = this.plugin.getConfigManager().getLevels();
         String var4 = "rewards.player-kill";
         if (!var3.getBoolean(var4 + ".enabled", true)) {
            return false;
         }

         long var5 = Math.max(0L, var3.getLong(var4 + ".same-player-cooldown-seconds", 300L));
         XpRewardManager.KillKey var7 = new XpRewardManager.KillKey(var1.getUniqueId(), var2.getUniqueId());
         long var8 = System.currentTimeMillis();
         Long var10 = this.killCooldowns.get(var7);
         if (var10 != null) {
            if (var10 > var8) {
               return false;
            }

            this.killCooldowns.remove(var7);
         }

         boolean var11 = this.reward(var1, XpRewardType.PLAYER_KILL);
         if (var11 && var5 > 0L) {
            this.killCooldowns.put(var7, var8 + var5 * 1000L);
         }

         return var11;
      } else {
         return false;
      }
   }

   private void showLevelUp(Player var1, int var2) {
      FileConfiguration var3 = this.plugin.getConfigManager().getLevels();
      if (var3.getBoolean("level-up-effect.enabled", true)) {
         String var4 = var3.getString("level-up-effect.title", "&#FF8A00Level up!");
         String var5 = var3.getString("level-up-effect.subtitle", "&fSeviye %level%");
         var1.sendTitle(
            ColorUtil.color(this.replace(var4, "%level%", String.valueOf(var2))),
            ColorUtil.color(this.replace(var5, "%level%", String.valueOf(var2))),
            3,
            28,
            7
         );
         if (var3.getBoolean("level-up-effect.sound.enabled", true)) {
            String var6 = var3.getString("level-up-effect.sound.sound", "ENTITY_PLAYER_LEVELUP");
            float var7 = (float)var3.getDouble("level-up-effect.sound.volume", 1.0);
            float var8 = (float)var3.getDouble("level-up-effect.sound.pitch", 1.2);
            var1.playSound(var1.getLocation(), this.normalizeSound(var6), var7, var8);
         }
      }
   }

   public void shutdown() {
      this.killCooldowns.clear();
      this.multiplierCache.clear();
   }

   private String normalizeSound(String var1) {
      if (var1 != null && !var1.isBlank()) {
         String var2 = var1.trim().toLowerCase();
         return var2.contains(":") ? var2 : var2.replace('_', '.');
      } else {
         return "entity.player.levelup";
      }
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private record CachedMultiplier(double multiplier, long expiresAt) {
   }

   private record KillKey(UUID killer, UUID victim) {
   }

   private record RewardSettings(boolean enabled, double xp) {
   }
}
