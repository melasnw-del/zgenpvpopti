package com.zzwproject.zgenpvp.turret;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class TurretMenu {
   private static final int[] PURCHASE_MODES = new int[]{1, 16, 32, 64, -1};
   private final ZGenPvP plugin;
   private final TurretManager turretManager;
   private final NamespacedKey actionKey;
   private final Map<UUID, Integer> purchaseModeIndexes = new HashMap<>();

   public TurretMenu(ZGenPvP plugin, TurretManager turretManager) {
      this.plugin = plugin;
      this.turretManager = turretManager;
      this.actionKey = new NamespacedKey(plugin, "turret_menu_action");
   }

   public void open(Player player, DefenseData requestedTurret) {
      DefenseData turret = this.resolve(player, requestedTurret);
      if (turret != null) {
         Inventory inventory = this.createInventory(
            turret,
            TurretMenu.Screen.MAIN,
            this.plugin.getConfigManager().getMenus().getInt("turret.size", 27),
            this.title("turret.title", "&cTaret &8• &fSeviye %level%", turret)
         );
         this.fill(inventory, "turret.filler");
         int level = turret.getLevel();
         int maxLevel = this.turretManager.getMaxLevel();
         int nextLevel = Math.min(maxLevel, level + 1);
         int capacity = this.turretManager.getArrowCapacity(level);
         double upgradePrice = level >= maxLevel ? 0.0 : this.turretManager.getUpgradePrice(level);
         double repairPrice = this.getRepairPrice(turret);
         this.setItem(
            inventory,
            "turret.ammo-button",
            "OPEN_AMMO",
            "%level%",
            String.valueOf(level),
            "%arrows%",
            String.valueOf(turret.getStoredArrows()),
            "%capacity%",
            String.valueOf(capacity),
            "%status%",
            turret.getStoredArrows() > 0 ? "Dolu" : "bos"
         );
         this.setItem(
            inventory,
            "turret.info",
            null,
            "%level%",
            String.valueOf(level),
            "%max_level%",
            String.valueOf(maxLevel),
            "%health%",
            String.valueOf(turret.getCurrentHp()),
            "%max_health%",
            String.valueOf(turret.getMaxHp()),
            "%damage%",
            this.format(this.turretManager.getDamage(level)),
            "%range%",
            this.format(this.turretManager.getRange(level)),
            "%interval%",
            this.format(this.turretManager.getAttackIntervalSeconds(level)),
            "%arrows%",
            String.valueOf(turret.getStoredArrows()),
            "%capacity%",
            String.valueOf(capacity)
         );
         this.setItem(
            inventory,
            "turret.upgrade",
            "UPGRADE_REPAIR",
            "%level%",
            String.valueOf(level),
            "%next_level%",
            String.valueOf(nextLevel),
            "%next_health%",
            String.valueOf(this.turretManager.getHealth(nextLevel)),
            "%next_damage%",
            this.format(this.turretManager.getDamage(nextLevel)),
            "%next_range%",
            this.format(this.turretManager.getRange(nextLevel)),
            "%next_interval%",
            this.format(this.turretManager.getAttackIntervalSeconds(nextLevel)),
            "%next_capacity%",
            String.valueOf(this.turretManager.getArrowCapacity(nextLevel)),
            "%price%",
            this.format(upgradePrice),
            "%repair_price%",
            this.format(repairPrice)
         );
         player.openInventory(inventory);
         this.plugin.getSoundUtil().play(player, "turret-menu-open");
      }
   }

   public void openAmmo(Player player, DefenseData requestedTurret) {
      DefenseData turret = this.resolve(player, requestedTurret);
      if (turret != null) {
         Inventory inventory = this.createInventory(
            turret,
            TurretMenu.Screen.AMMO,
            this.plugin.getConfigManager().getMenus().getInt("turret.ammo-menu.size", 27),
            this.title("turret.ammo-menu.title", "&cTaret &8- &bok deposu", turret)
         );
         this.fill(inventory, "turret.ammo-menu.filler");
         int capacity = this.turretManager.getArrowCapacity(turret.getLevel());
         int free = Math.max(0, capacity - turret.getStoredArrows());
         int mode = this.getPurchaseMode(player);
         int buyAmount = mode < 0 ? free : Math.min(mode, free);
         double buyPrice = buyAmount * this.turretManager.getArrowPrice();
         this.setItem(
            inventory,
            "turret.ammo-menu.buy",
            "BUY_ARROWS",
            "%mode%",
            mode < 0 ? "Full" : mode + "x",
            "%buy_amount%",
            String.valueOf(buyAmount),
            "%buy_price%",
            this.format(buyPrice),
            "%arrow_price%",
            this.format(this.turretManager.getArrowPrice()),
            "%arrows%",
            String.valueOf(turret.getStoredArrows()),
            "%capacity%",
            String.valueOf(capacity)
         );
         this.setItem(
            inventory,
            "turret.ammo-menu.deposit",
            "DEPOSIT_ALL",
            "%arrows%",
            String.valueOf(turret.getStoredArrows()),
            "%capacity%",
            String.valueOf(capacity),
            "%arrow_price%",
            this.format(this.turretManager.getArrowPrice())
         );
         this.setItem(inventory, "turret.ammo-menu.back", "BACK");
         player.openInventory(inventory);
         this.plugin.getSoundUtil().play(player, "turret-menu-open");
      }
   }

   public void openUpgradeConfirm(Player player, DefenseData requestedTurret) {
      DefenseData turret = this.resolve(player, requestedTurret);
      if (turret != null) {
         int level = turret.getLevel();
         int maxLevel = this.turretManager.getMaxLevel();
         if (level >= maxLevel) {
            this.plugin.getMessageUtil().sendActionBar(player, "turret.max-level");
            this.open(player, turret);
         } else {
            int nextLevel = level + 1;
            double price = this.turretManager.getUpgradePrice(level);
            Inventory inventory = this.createInventory(
               turret,
               TurretMenu.Screen.UPGRADE_CONFIRM,
               this.plugin.getConfigManager().getMenus().getInt("turret.upgrade-confirm.size", 27),
               ColorUtil.color(this.plugin.getConfigManager().getMenus().getString("turret.upgrade-confirm.title", "&cYukseltmeyi onayla"))
            );
            this.fill(inventory, "turret.upgrade-confirm.filler");
            this.setItem(
               inventory,
               "turret.upgrade-confirm.confirm",
               "CONFIRM_UPGRADE",
               "%price%",
               this.format(price),
               "%level%",
               String.valueOf(level),
               "%next_level%",
               String.valueOf(nextLevel)
            );
            this.setItem(
               inventory,
               "turret.upgrade-confirm.info",
               null,
               "%level%",
               String.valueOf(level),
               "%next_level%",
               String.valueOf(nextLevel),
               "%health%",
               String.valueOf(this.turretManager.getHealth(level)),
               "%next_health%",
               String.valueOf(this.turretManager.getHealth(nextLevel)),
               "%damage%",
               this.format(this.turretManager.getDamage(level)),
               "%next_damage%",
               this.format(this.turretManager.getDamage(nextLevel)),
               "%range%",
               this.format(this.turretManager.getRange(level)),
               "%next_range%",
               this.format(this.turretManager.getRange(nextLevel)),
               "%interval%",
               this.format(this.turretManager.getAttackIntervalSeconds(level)),
               "%next_interval%",
               this.format(this.turretManager.getAttackIntervalSeconds(nextLevel)),
               "%capacity%",
               String.valueOf(this.turretManager.getArrowCapacity(level)),
               "%next_capacity%",
               String.valueOf(this.turretManager.getArrowCapacity(nextLevel)),
               "%price%",
               this.format(price)
            );
            this.setItem(inventory, "turret.upgrade-confirm.cancel", "CANCEL_UPGRADE");
            player.openInventory(inventory);
            this.plugin.getSoundUtil().play(player, "button");
         }
      }
   }

   public int getPurchaseMode(Player player) {
      int index = this.purchaseModeIndexes.getOrDefault(player.getUniqueId(), 1);
      index = Math.max(0, Math.min(PURCHASE_MODES.length - 1, index));
      return PURCHASE_MODES[index];
   }

   public void cyclePurchaseMode(Player player) {
      int index = this.purchaseModeIndexes.getOrDefault(player.getUniqueId(), 1);
      this.purchaseModeIndexes.put(player.getUniqueId(), (index + 1) % PURCHASE_MODES.length);
   }

   public double getRepairPrice(DefenseData turret) {
      if (turret != null && turret.getMaxHp() > 0) {
         int missingHealth = Math.max(0, turret.getMaxHp() - turret.getCurrentHp());
         if (missingHealth <= 0) {
            return 0.0;
         }

         double fullRepairPrice = Math.max(
            0.0, this.plugin.getConfigManager().getDefenses().getDouble("turret.levels." + turret.getLevel() + ".repair-price", 1500.0)
         );
         double damageRatio = (double)missingHealth / turret.getMaxHp();
         return Math.ceil(fullRepairPrice * damageRatio);
      } else {
         return 0.0;
      }
   }

   public boolean isMenu(Inventory inventory) {
      return inventory != null && inventory.getHolder() instanceof TurretMenu.TurretMenuHolder;
   }

   public boolean isAmmoMenu(Inventory inventory) {
      return inventory != null && inventory.getHolder() instanceof TurretMenu.TurretMenuHolder holder && holder.screen == TurretMenu.Screen.AMMO;
   }

   public boolean isUpgradeConfirmMenu(Inventory inventory) {
      return inventory != null && inventory.getHolder() instanceof TurretMenu.TurretMenuHolder holder && holder.screen == TurretMenu.Screen.UPGRADE_CONFIRM;
   }

   public Optional<DefenseData> getTurret(Inventory inventory) {
      return inventory != null && inventory.getHolder() instanceof TurretMenu.TurretMenuHolder holder
         ? this.findTurret(holder.turretId, holder.ownerUuid)
         : Optional.empty();
   }

   public String getAction(ItemStack item) {
      return item != null && !item.getType().isAir() && item.hasItemMeta()
         ? (String)item.getItemMeta().getPersistentDataContainer().get(this.actionKey, PersistentDataType.STRING)
         : null;
   }

   private Inventory createInventory(DefenseData turret, TurretMenu.Screen screen, int size, String title) {
      int normalizedSize = this.normalizeSize(size);
      TurretMenu.TurretMenuHolder holder = new TurretMenu.TurretMenuHolder(turret.getId(), turret.getOwnerUuid(), screen);
      Inventory inventory = Bukkit.createInventory(holder, normalizedSize, title);
      holder.setInventory(inventory);
      return inventory;
   }

   private DefenseData resolve(Player player, DefenseData requestedTurret) {
      if (player != null && requestedTurret != null) {
         DefenseData turret = this.findTurret(requestedTurret.getId(), requestedTurret.getOwnerUuid()).orElse(null);
         if (turret == null) {
            player.closeInventory();
            return null;
         } else if (!this.turretManager.canManageTurret(player, turret)) {
            this.turretManager.sendOwnerInfo(player, turret);
            return null;
         } else {
            return turret;
         }
      } else {
         return null;
      }
   }

   private Optional<DefenseData> findTurret(long turretId, UUID ownerUuid) {
      return ownerUuid == null
         ? Optional.empty()
         : this.turretManager
            .getTurrets()
            .stream()
            .filter(turret -> turret.getId() == turretId)
            .filter(turret -> ownerUuid.equals(turret.getOwnerUuid()))
            .findFirst();
   }

   private String title(String path, String fallback, DefenseData turret) {
      return ColorUtil.color(this.replace(this.plugin.getConfigManager().getMenus().getString(path, fallback), "%level%", String.valueOf(turret.getLevel())));
   }

   private void fill(Inventory inventory, String path) {
      if (this.plugin.getConfigManager().getMenus().getBoolean(path + ".enabled", false)) {
         ItemStack filler = this.createItem(path, null);

         for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
         }
      }
   }

   private void setItem(Inventory inventory, String path, String action, String... replacements) {
      int slot = this.plugin.getConfigManager().getMenus().getInt(path + ".slot", -1);
      if (slot >= 0 && slot < inventory.getSize()) {
         inventory.setItem(slot, this.createItem(path, action, replacements));
      }
   }

   private ItemStack createItem(String path, String action, String... replacements) {
      String materialName = this.plugin.getConfigManager().getMenus().getString(path + ".material", "STONE");
      Material material = Material.matchMaterial(materialName == null ? "STONE" : materialName);
      if (material == null || material.isAir()) {
         material = Material.STONE;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.setDisplayName(ColorUtil.color(this.replace(this.plugin.getConfigManager().getMenus().getString(path + ".name", " "), replacements)));
      List<String> lore = new ArrayList<>();

      for (String line : this.plugin.getConfigManager().getMenus().getStringList(path + ".lore")) {
         lore.add(ColorUtil.color(this.replace(line, replacements)));
      }

      meta.setLore(lore);
      if (action != null) {
         meta.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, action);
      }

      item.setItemMeta(meta);
      return item;
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private int normalizeSize(int size) {
      int normalized = Math.max(9, Math.min(54, size));
      if (normalized % 9 != 0) {
         normalized += 9 - normalized % 9;
      }

      return Math.min(normalized, 54);
   }

   private String format(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }

   private enum Screen {
      MAIN,
      AMMO,
      UPGRADE_CONFIRM;
   }

   private static final class TurretMenuHolder implements InventoryHolder {
      private final long turretId;
      private final UUID ownerUuid;
      private final TurretMenu.Screen screen;
      private Inventory inventory;

      private TurretMenuHolder(long turretId, UUID ownerUuid, TurretMenu.Screen screen) {
         this.turretId = turretId;
         this.ownerUuid = ownerUuid;
         this.screen = screen;
      }

      private void setInventory(Inventory inventory) {
         this.inventory = inventory;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }
}
