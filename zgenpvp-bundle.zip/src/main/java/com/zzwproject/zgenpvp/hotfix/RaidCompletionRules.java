package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class RaidCompletionRules {
   private RaidCompletionRules() {
   }

   public static boolean allowedOwner(Object var0, Object var1) {
      try {
         return !required("requireOwnerKill", var0, true) ? true : Boolean.TRUE.equals(field(var1, "ownerKilled"));
      } catch (Throwable var3) {
         return false;
      }
   }

   public static int remainingForCompletion(Object var0, Object var1) {
      try {
         if (!required("requireAllGenerators", var0, true)) {
            return 0;
         }

         Object var2 = call(var0, "remainingGeneratorCount", var1);
         return var2 instanceof Number ? ((Number)var2).intValue() : Integer.MAX_VALUE;
      } catch (Throwable var3) {
         return Integer.MAX_VALUE;
      }
   }

   public static boolean allowed(Object var0, Object var1) {
      return allowedOwner(var0, var1) && remainingForCompletion(var0, var1) <= 0;
   }

   private static boolean required(String var0, Object var1, boolean var2) {
      try {
         Class var3 = Class.forName("com.zzwproject.zraid.hotfix.ConfigurableRaidRules");

         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var0) && var7.getParameterCount() == 1) {
               var7.setAccessible(true);
               return Boolean.TRUE.equals(var7.invoke(null, var1));
            }
         }
      } catch (Throwable var8) {
      }

      return var2;
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      for (Class var3 = var0.getClass(); var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
               var7.setAccessible(true);
               return var7.invoke(var0, var2);
            }
         }
      }

      throw new NoSuchMethodException(var1);
   }
}
