package com.zzwproject.zgenpvp.player;

import com.zzwproject.zgenpvp.ZGenPvP;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLevelChangeEvent;

public final class PlayerVitalsListener implements Listener {
   private final ZGenPvP plugin;

   public PlayerVitalsListener(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      this.keepFull(player);
      this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.plugin.getLevelManager().syncHud(player));
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onFood(FoodLevelChangeEvent event) {
      if (event.getEntity() instanceof Player player) {
         if (this.plugin.getConfigManager().getConfig().getBoolean("player.hunger.disabled", true)) {
            event.setCancelled(true);
            this.keepFull(player);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onExperience(PlayerExpChangeEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("player.vanilla-xp-disabled", true)) {
         event.setAmount(0);
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.plugin.getLevelManager().syncHud(event.getPlayer()));
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onVanillaLevelChange(PlayerLevelChangeEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("player.vanilla-xp-disabled", true)) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.plugin.getLevelManager().syncHud(event.getPlayer()));
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPrepareEnchant(PrepareItemEnchantEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("player.vanilla-xp-disabled", true)) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEnchant(EnchantItemEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("player.vanilla-xp-disabled", true)) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onAnvilResult(InventoryClickEvent event) {
      if (this.plugin.getConfigManager().getConfig().getBoolean("player.vanilla-xp-disabled", true)) {
         if (event.getView().getTopInventory().getType() == InventoryType.ANVIL) {
            if (event.getRawSlot() == 2) {
               event.setCancelled(true);
               if (event.getWhoClicked() instanceof Player player) {
                  this.plugin.getMessageUtil().sendActionBar(player, "player.vanilla-xp-disabled");
               }
            }
         }
      }
   }

   public void keepFull(Player player) {
      if (player != null) {
         if (this.plugin.getConfigManager().getConfig().getBoolean("player.hunger.disabled", true)) {
            player.setFoodLevel(20);
            player.setSaturation(20.0F);
            player.setExhaustion(0.0F);
         }
      }
   }
}
