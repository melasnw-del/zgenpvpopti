package com.zzwproject.zgenpvp.integration;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.ZGenPvP;
import java.lang.reflect.Method;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class ZTeamHook {
   private final ZGenPvP plugin;
   private Plugin zTeamPlugin;
   private Object api;
   private boolean available;
   private boolean teamSettingsAvailable;
   private String providerName = "none";

   public ZTeamHook(ZGenPvP var1) {
      this.plugin = var1;
   }

   public boolean hook() {
      this.clear();
      Plugin var1 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZTeam");
      if (var1 != null && var1.isEnabled()) {
         try {
            this.zTeamPlugin = var1;

            try {
               this.api = var1.getClass().getMethod("getAPI").invoke(var1);
            } catch (NoSuchMethodException var3) {
               this.api = var1.getClass().getMethod("getApi").invoke(var1);
            }

            this.available = this.api != null;
            this.teamSettingsAvailable = this.available;
            this.providerName = var1.getName();
            return this.available;
         } catch (Throwable var4) {
            this.clear();
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean areTeammates(UUID var1, UUID var2) {
      return var1 != null && var2 != null && !var1.equals(var2) ? this.invokeDouble("areTeammates", var1, var2) : false;
   }

   public boolean isFriendlyFireEnabled(UUID var1) {
      return false;
   }

   public boolean canFriendlyFire(UUID var1, UUID var2) {
      return !this.areTeammates(var1, var2);
   }

   public boolean canCollectGeneratorMoney(UUID var1, UUID var2) {
      return this.permission(var1, var2, "GENERATOR_REWARD_COLLECT");
   }

   public boolean canCollectGeneratorShards(UUID var1, UUID var2) {
      return this.permission(var1, var2, "GENERATOR_REWARD_COLLECT");
   }

   public boolean canUpgradeGenerator(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canLinkGeneratorChest(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canAccessGeneratorChest(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canPickupGeneratorDrop(UUID var1, UUID var2) {
      return this.permission(var1, var2, "GENERATOR_REWARD_COLLECT");
   }

   public boolean canUseSellWandOnGeneratorChest(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canManageBase(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canUseBeacon(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   public boolean canManageDefenses(UUID var1, UUID var2) {
      return this.permission(var1, var2, "DEFENSE_ACCESS");
   }

   // $VF: Duplicated exception handlers to handle obfuscated exceptions
   private boolean permission(UUID var1, UUID var2, String var3) {
      if (var1 == null || var2 == null) {
         return false;
      }

      if (var1.equals(var2)) {
         return true;
      }

      if (!this.areTeammates(var1, var2)) {
         return false;
      }

      if (this.available && this.api != null) {
         try {
            if (this.api.getClass().getMethod("getTeam", UUID.class).invoke(this.api, var1) instanceof Optional var5 && var5.isPresent()) {
               Object var6 = var5.get();
               UUID var7 = (UUID)var6.getClass().getMethod("getLeaderUuid").invoke(var6);
            }
         } catch (Throwable var11) {
            return false;
         }

         try {
            Class var12 = Class.forName("com.zzwproject.zteam.model.MemberSetting", true, this.api.getClass().getClassLoader());
            Enum var13 = Enum.valueOf(var12.asSubclass(Enum.class), var3);
            Method var14 = this.api.getClass().getMethod("getMemberSetting", UUID.class, var12);
            return var14.invoke(this.api, var2, var13) instanceof Boolean var9 && var9;
         } catch (Throwable var10) {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean invokeDouble(String var1, UUID var2, UUID var3) {
      if (this.available && this.api != null) {
         try {
            return this.api.getClass().getMethod(var1, UUID.class, UUID.class).invoke(this.api, var2, var3) instanceof Boolean var5 && var5;
         } catch (Throwable var6) {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isAvailable() {
      return this.available;
   }

   public boolean isTeamSettingsAvailable() {
      return this.teamSettingsAvailable;
   }

   public String getProviderName() {
      return this.providerName;
   }

   public Plugin getZTeamPlugin() {
      return this.zTeamPlugin;
   }

   private void clear() {
      this.zTeamPlugin = null;
      this.api = null;
      this.available = false;
      this.teamSettingsAvailable = false;
      this.providerName = "none";
   }
}
