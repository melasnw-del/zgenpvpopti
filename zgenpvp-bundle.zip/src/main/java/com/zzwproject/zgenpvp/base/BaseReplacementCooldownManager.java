package com.zzwproject.zgenpvp.base;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public final class BaseReplacementCooldownManager {
   private final ZGenPvP plugin;
   private final File dataFile;
   private final Map<UUID, Long> expiresAt = new HashMap<>();

   public BaseReplacementCooldownManager(ZGenPvP var1) {
      this.plugin = var1;
      this.dataFile = new File(var1.getDataFolder(), "base-replacement-cooldowns.yml");
      this.load();
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("base.replacement-cooldown.enabled", true);
   }

   public long getDurationSeconds() {
      long var1 = Math.max(0L, this.plugin.getConfigManager().getConfig().getLong("base.replacement-cooldown.minutes", 60L));
      return var1 * 60L;
   }

   public boolean canPlace(Player var1) {
      if (var1 == null || !this.isEnabled()) {
         return true;
      } else {
         return var1.hasPermission("zgenpvp.base.replacement.bypass") ? true : this.getRemainingSeconds(var1.getUniqueId()) <= 0L;
      }
   }

   public long getRemainingSeconds(UUID var1) {
      if (var1 != null && this.isEnabled()) {
         Long var2 = this.expiresAt.get(var1);
         if (var2 == null) {
            return 0L;
         } else {
            long var3 = var2 - System.currentTimeMillis();
            if (var3 <= 0L) {
               this.expiresAt.remove(var1);
               this.save();
               return 0L;
            } else {
               return (var3 + 999L) / 1000L;
            }
         }
      } else {
         return 0L;
      }
   }

   public void start(UUID var1) {
      if (var1 != null && this.isEnabled()) {
         long var2 = this.getDurationSeconds();
         if (var2 <= 0L) {
            this.clear(var1);
         } else {
            long var4 = System.currentTimeMillis() + var2 * 1000L;
            this.expiresAt.put(var1, var4);
            this.save();
         }
      }
   }

   public void clear(UUID var1) {
      if (var1 != null && this.expiresAt.remove(var1) != null) {
         this.save();
      }
   }

   public String formatRemaining(long var1) {
      long var3 = Math.max(0L, var1);
      long var5 = var3 / 3600L;
      long var7 = var3 % 3600L / 60L;
      long var9 = var3 % 60L;
      if (var5 > 0L) {
         return var5 + "s " + var7 + "dk";
      } else {
         return var7 > 0L ? var7 + "dk " + var9 + "sn" : var9 + "sn";
      }
   }

   public void cleanupExpired() {
      long var1 = System.currentTimeMillis();
      boolean var3 = false;
      Iterator var4 = this.expiresAt.entrySet().iterator();

      while (var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         if (var5.getValue() == null || (Long)var5.getValue() <= var1) {
            var4.remove();
            var3 = true;
         }
      }

      if (var3) {
         this.save();
      }
   }

   public void shutdown() {
      this.cleanupExpired();
      this.save();
      this.expiresAt.clear();
   }

   private void load() {
      this.expiresAt.clear();
      if (this.dataFile.exists()) {
         YamlConfiguration var1 = YamlConfiguration.loadConfiguration(this.dataFile);
         ConfigurationSection var2 = var1.getConfigurationSection("cooldowns");
         if (var2 != null) {
            long var3 = System.currentTimeMillis();

            for (String var6 : var2.getKeys(false)) {
               try {
                  UUID var7 = UUID.fromString(var6);
                  long var8 = var2.getLong(var6, 0L);
                  if (var8 > var3) {
                     this.expiresAt.put(var7, var8);
                  }
               } catch (IllegalArgumentException var10) {
               }
            }
         }
      }
   }

   private void save() {
      try {
         File var1 = this.dataFile.getParentFile();
         if (var1 != null && !var1.exists()) {
            var1.mkdirs();
         }

         YamlConfiguration var2 = new YamlConfiguration();
         long var3 = System.currentTimeMillis();

         for (Entry var6 : this.expiresAt.entrySet()) {
            Long var7 = (Long)var6.getValue();
            if (var7 != null && var7 > var3) {
               var2.set("cooldowns." + var6.getKey(), var7);
            }
         }

         var2.save(this.dataFile);
      } catch (IOException var8) {
         this.plugin.getLogger().log(Level.SEVERE, "Base yeniden kurma cooldown verisi kaydedilemedi.", var8);
      }
   }
}
