package com.zzwproject.bundle;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

final class ModuleRegistry {
   private static final Map<String, ModuleContext> BY_MAIN = new ConcurrentHashMap<>();

   static void put(ModuleContext var0) {
      BY_MAIN.put(var0.mainClass, var0);
   }

   static ModuleContext get(String var0) {
      return BY_MAIN.get(var0);
   }

   static void remove(ModuleContext var0) {
      BY_MAIN.remove(var0.mainClass, var0);
   }
}
