package com.zzwproject.zgenpvp.turret;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.v2.EnergySupport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.AbstractArrow.PickupStatus;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class TurretTask implements Listener {
   private final ZGenPvP plugin;
   private final TurretManager turretManager;
   private final Map<Long, Long> lastShots = new HashMap<>();
   private final Map<Long, TurretTask.TurretVisual> visuals = new HashMap<>();
   private final NamespacedKey turretArrowKey;
   private final NamespacedKey turretOwnerKey;
   private final NamespacedKey turretIdKey;
   private BukkitTask task;
   private boolean listenerRegistered;

   public TurretTask(ZGenPvP var1, TurretManager var2) {
      this.plugin = var1;
      this.turretManager = var2;
      this.turretArrowKey = new NamespacedKey(var1, "turret_arrow");
      this.turretOwnerKey = new NamespacedKey(var1, "turret_owner");
      this.turretIdKey = new NamespacedKey(var1, "turret_id");
   }

   public void start() {
      this.stop();
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
      this.listenerRegistered = true;
      long var1 = Math.max(2L, this.plugin.getConfigManager().getDefenses().getLong("turret.scan-interval-ticks", 8L));
      this.task = this.plugin.getServer().getScheduler().runTaskTimer(this.plugin, this::tick, var1, var1);
   }

   public void stop() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.lastShots.clear();
      this.removeAllVisuals();
      if (this.listenerRegistered) {
         HandlerList.unregisterAll(this);
         this.listenerRegistered = false;
      }
   }

   private void tick() {
      if (!this.turretManager.isEnabled()) {
         this.removeAllVisuals();
      } else {
         long var1 = System.currentTimeMillis();
         HashSet var3 = new HashSet();

         for (DefenseData var5 : this.turretManager.getTurrets()) {
            var3.add(var5.getId());
            Location var6 = var5.getLocation();
            if (var6 != null && var6.getWorld() != null) {
               World var7 = var6.getWorld();
               if (!var7.isChunkLoaded(var6.getBlockX() >> 4, var6.getBlockZ() >> 4)) {
                  this.removeVisual(var5.getId());
               } else if (!this.hasNearbyViewer(var6)) {
                  this.removeVisual(var5.getId());
               } else {
                  Player var8 = this.findTarget(var5, var6);
                  this.refreshVisual(var5, var8, var1);
                  if (var5.getStoredArrows() > 0 && var8 != null) {
                     long var9 = Math.max(100L, (long)(this.turretManager.getAttackIntervalSeconds(var5.getLevel()) * 1000.0));
                     if (!EnergySupport.isPowered(this.plugin, var5)) {
                        var9 *= 2L;
                     }

                     long var11 = this.lastShots.getOrDefault(var5.getId(), 0L);
                     if (var1 - var11 >= var9 && this.fire(var5, var6, var8)) {
                        this.lastShots.put(var5.getId(), var1);
                     }
                  }
               }
            } else {
               this.removeVisual(var5.getId());
            }
         }

         this.cleanupMissingVisuals(var3);
         this.lastShots.keySet().removeIf(var1x -> !var3.contains(var1x));
      }
   }

   private boolean hasNearbyViewer(Location var1) {
      World var2 = var1.getWorld();
      if (var2 == null) {
         return false;
      }

      double var3 = Math.max(24.0, this.plugin.getConfigManager().getDefenses().getDouble("turret.visual.render-distance", 64.0));
      double var5 = var3 * var3;

      for (Player var8 : var2.getPlayers()) {
         if (var8.isOnline() && !var8.isDead() && var8.getLocation().distanceSquared(var1) <= var5) {
            return true;
         }
      }

      return false;
   }

   private Player findTarget(DefenseData var1, Location var2) {
      World var3 = var2.getWorld();
      if (var3 == null) {
         return null;
      }

      double var4 = this.turretManager.getRange(var1.getLevel());
      Location var6 = var2.clone().add(0.5, this.headHeight(var1.getLevel()), 0.5);
      boolean var7 = this.plugin.getConfigManager().getDefenses().getBoolean("turret.target.ignore-creative", true);
      boolean var8 = this.plugin.getConfigManager().getDefenses().getBoolean("turret.target.ignore-spectator", true);
      boolean var9 = this.plugin.getConfigManager().getDefenses().getBoolean("turret.target.require-line-of-sight", true);
      Player var10 = null;
      double var11 = Double.MAX_VALUE;

      for (Entity var14 : var3.getNearbyEntities(var6, var4, var4, var4)) {
         if (var14 instanceof Player var15
            && var15.isOnline()
            && !var15.isDead()
            && !this.turretManager.isFriendly(var15.getUniqueId(), var1.getOwnerUuid())
            && (!var7 || var15.getGameMode() != GameMode.CREATIVE)
            && (!var8 || var15.getGameMode() != GameMode.SPECTATOR)
            && (!var9 || this.hasLineOfSight(var6, var15.getEyeLocation()))) {
            double var16 = var6.distanceSquared(var15.getLocation());
            if (var16 <= var4 * var4 && var16 < var11) {
               var11 = var16;
               var10 = var15;
            }
         }
      }

      return var10;
   }

   private boolean hasLineOfSight(Location var1, Location var2) {
      if (var1 != null && var2 != null && var1.getWorld() != null && var2.getWorld() != null && var1.getWorld().equals(var2.getWorld())) {
         Vector var3 = var2.toVector().subtract(var1.toVector());
         double var4 = var3.length();
         return var4 <= 0.0 ? true : var1.getWorld().rayTraceBlocks(var1, var3.normalize(), var4, FluidCollisionMode.NEVER, true) == null;
      } else {
         return false;
      }
   }

   private boolean fire(DefenseData var1, Location var2, Player var3) {
      if (var1 != null && var3 != null && var3.isOnline() && !var3.isDead()) {
         if (this.turretManager.isFriendly(var3.getUniqueId(), var1.getOwnerUuid())) {
            return false;
         }

         double var4 = this.turretManager.getDamage(var1.getLevel());
         if (var4 <= 0.0) {
            return false;
         }

         TurretTask.TurretVisual var6 = this.visuals.get(var1.getId());
         Location var7 = var6 != null && var6.isValid() ? var6.muzzleLocation(var2) : var2.clone().add(0.5, this.headHeight(var1.getLevel()), 0.5);
         Vector var8 = var3.getEyeLocation().toVector().subtract(var7.toVector());
         if (var8.lengthSquared() <= 1.0E-4) {
            return false;
         }

         var8.normalize();
         if (!this.turretManager.consumeArrow(var1)) {
            return false;
         }

         float var9 = (float)Math.max(0.1, this.plugin.getConfigManager().getDefenses().getDouble("turret.projectile.speed", 2.2));
         Arrow var10 = var7.getWorld().spawnArrow(var7, var8, var9, 0.0F);
         var10.setDamage(var4);
         var10.setCritical(false);
         var10.setKnockbackStrength(0);
         var10.setPickupStatus(PickupStatus.DISALLOWED);
         var10.setPersistent(false);
         var10.getPersistentDataContainer().set(this.turretArrowKey, PersistentDataType.BYTE, (byte)1);
         var10.getPersistentDataContainer().set(this.turretOwnerKey, PersistentDataType.STRING, var1.getOwnerUuid().toString());
         var10.getPersistentDataContainer().set(this.turretIdKey, PersistentDataType.LONG, var1.getId());
         var7.getWorld().spawnParticle(Particle.CRIT, var7, 4, 0.06, 0.06, 0.06, 0.015);
         var7.getWorld().spawnParticle(Particle.END_ROD, var7, 1, 0.02, 0.02, 0.02, 0.0);
         this.plugin.getSoundUtil().play(var2, "turret-shoot");
         if (var6 != null) {
            var6.markFired();
         }

         int var11 = Math.max(20, this.plugin.getConfigManager().getDefenses().getInt("turret.projectile.remove-after-ticks", 100));
         this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            if (var10.isValid()) {
               var10.remove();
            }
         }, var11);
         return true;
      } else {
         return false;
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onTurretArrowDamage(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Arrow var3 && this.isTurretArrow(var3)) {
         if (var1.getEntity() instanceof Player var5) {
            String var6 = (String)var3.getPersistentDataContainer().get(this.turretOwnerKey, PersistentDataType.STRING);
            if (var6 == null) {
               var1.setCancelled(true);
               var3.remove();
            } else {
               try {
                  UUID var7 = UUID.fromString(var6);
                  if (this.turretManager.isFriendly(var5.getUniqueId(), var7)) {
                     var1.setCancelled(true);
                     var3.remove();
                     return;
                  }
               } catch (IllegalArgumentException var8) {
                  var1.setCancelled(true);
                  var3.remove();
                  return;
               }

               this.plugin.getMessageUtil().sendActionBar(var5, "turret.target-hit-actionbar", "%damage%", this.format(var1.getDamage()));
            }
         } else {
            var1.setCancelled(true);
            var3.remove();
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onTurretArrowHit(ProjectileHitEvent var1) {
      if (var1.getEntity() instanceof Arrow var3 && this.isTurretArrow(var3)) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (var3.isValid()) {
               var3.remove();
            }
         });
      }
   }

   private boolean isTurretArrow(Arrow var1) {
      Byte var2 = (Byte)var1.getPersistentDataContainer().get(this.turretArrowKey, PersistentDataType.BYTE);
      return var2 != null && var2 == 1;
   }

   private void refreshVisual(DefenseData var1, Player var2, long var3) {
      if (var1 != null && this.plugin.getConfigManager().getDefenses().getBoolean("turret.visual.enabled", true)) {
         Location var5 = var1.getLocation();
         if (var5 != null && var5.getWorld() != null) {
            int var6 = Math.max(1, Math.min(5, var1.getLevel()));
            TurretTask.TurretVisual var7 = this.visuals.get(var1.getId());
            if (var7 == null || !var7.isValid() || var7.level != var6) {
               if (var7 != null) {
                  var7.remove();
               }

               var7 = this.createVisual(var5, var6);
               this.visuals.put(var1.getId(), var7);
            }

            float var8;
            if (var2 != null) {
               Location var9 = var5.clone().add(0.5, this.headHeight(var6), 0.5);
               var8 = this.yawTo(var9, var2.getEyeLocation());
            } else {
               double var13 = this.plugin.getConfigManager().getDefenses().getDouble("turret.visual.idle-rotation-degrees", 1.5);
               var8 = this.normalizeYaw((float)(var3 / 50.0 * var13));
            }

            float var14 = (float)this.clamp(this.plugin.getConfigManager().getDefenses().getDouble("turret.visual.turn-smoothing", 0.38), 0.05, 1.0);
            var7.currentYaw = this.approachAngle(var7.currentYaw, var8, var14);
            var7.update(var5, var1.getStoredArrows() > 0, var7.currentYaw);
            long var10 = Math.max(500L, this.plugin.getConfigManager().getDefenses().getLong("turret.visual.core-particle-interval-ms", 1000L));
            if (var3 - var7.lastCoreParticle >= var10) {
               Location var12 = var5.clone().add(0.5, this.coreHeight(var6), 0.5);
               var5.getWorld().spawnParticle(Particle.END_ROD, var12, 1, 0.08, 0.05, 0.08, 0.0);
               var7.lastCoreParticle = var3;
            }
         } else {
            this.removeVisual(var1.getId());
         }
      } else {
         if (var1 != null) {
            this.removeVisual(var1.getId());
         }
      }
   }

   private TurretTask.TurretVisual createVisual(Location var1, int var2) {
      TurretTask.TurretVisual var3 = new TurretTask.TurretVisual(var2);
      var3.base = this.spawnPart(var1, this.materialBase(var2), 0.95F + var2 * 0.05F, 0.28F + var2 * 0.025F, 0.95F + var2 * 0.05F);
      var3.core = this.spawnPart(var1, this.materialCore(var2), 0.3F + var2 * 0.025F, 0.22F + var2 * 0.015F, 0.3F + var2 * 0.025F);
      var3.head = this.spawnPart(var1, this.materialHead(var2), 0.62F + var2 * 0.06F, 0.34F + var2 * 0.025F, 0.52F + var2 * 0.04F);
      var3.barrel = this.spawnPart(var1, this.materialBarrel(var2), 0.16F + var2 * 0.015F, 0.15F + var2 * 0.012F, 0.52F + var2 * 0.1F);
      var3.sensor = this.spawnPart(var1, Material.SCULK_SENSOR, 0.22F + var2 * 0.012F, 0.16F, 0.22F + var2 * 0.012F);
      if (var2 >= 2) {
         var3.leftArmor = this.spawnPart(var1, this.materialArmor(var2), 0.18F + var2 * 0.012F, 0.3F + var2 * 0.02F, 0.46F + var2 * 0.03F);
         var3.rightArmor = this.spawnPart(var1, this.materialArmor(var2), 0.18F + var2 * 0.012F, 0.3F + var2 * 0.02F, 0.46F + var2 * 0.03F);
      }

      if (var2 >= 4) {
         var3.rearArmor = this.spawnPart(var1, this.materialArmor(var2), 0.46F + var2 * 0.025F, 0.28F + var2 * 0.02F, 0.2F + var2 * 0.01F);
      }

      var3.update(var1, true, 0.0F);
      return var3;
   }

   private BlockDisplay spawnPart(Location var1, Material var2, float var3, float var4, float var5) {
      BlockDisplay var6 = (BlockDisplay)var1.getWorld().spawn(var1.clone().add(0.5, 0.5, 0.5), BlockDisplay.class);
      var6.setPersistent(false);
      var6.setGravity(false);
      var6.setTeleportDuration(2);
      var6.setInterpolationDuration(3);
      BlockData var7 = var2.createBlockData();
      var6.setBlock(var7);
      var6.setTransformation(
         new Transformation(new Vector3f(-var3 / 2.0F, -var4 / 2.0F, -var5 / 2.0F), new Quaternionf(), new Vector3f(var3, var4, var5), new Quaternionf())
      );
      return var6;
   }

   private Material materialBase(int var1) {
      return switch (var1) {
         case 1 -> Material.POLISHED_BLACKSTONE;
         case 2 -> Material.DEEPSLATE_TILES;
         case 3 -> Material.POLISHED_DEEPSLATE;
         case 4 -> Material.POLISHED_BLACKSTONE_BRICKS;
         default -> Material.NETHERITE_BLOCK;
      };
   }

   private Material materialHead(int var1) {
      return switch (var1) {
         case 1 -> Material.IRON_BLOCK;
         case 2 -> Material.COPPER_BLOCK;
         case 3 -> Material.CUT_COPPER;
         case 4 -> Material.POLISHED_BLACKSTONE;
         default -> Material.NETHERITE_BLOCK;
      };
   }

   private Material materialBarrel(int var1) {
      return switch (var1) {
         case 1, 2 -> Material.IRON_BLOCK;
         case 3 -> Material.COPPER_BLOCK;
         case 4 -> Material.POLISHED_BLACKSTONE;
         default -> Material.NETHERITE_BLOCK;
      };
   }

   private Material materialArmor(int var1) {
      return var1 >= 5 ? Material.NETHERITE_BLOCK : (var1 >= 4 ? Material.POLISHED_BLACKSTONE_BRICKS : Material.IRON_BLOCK);
   }

   private Material materialCore(int var1) {
      return switch (var1) {
         case 1 -> Material.SEA_LANTERN;
         case 2 -> Material.SEA_LANTERN;
         case 3 -> Material.AMETHYST_BLOCK;
         case 4 -> Material.REDSTONE_BLOCK;
         default -> Material.BEACON;
      };
   }

   private double headHeight(int var1) {
      return 1.0 + Math.max(1, Math.min(5, var1)) * 0.055;
   }

   private double coreHeight(int var1) {
      return 0.68 + Math.max(1, Math.min(5, var1)) * 0.025;
   }

   private float yawTo(Location var1, Location var2) {
      double var3 = var2.getX() - var1.getX();
      double var5 = var2.getZ() - var1.getZ();
      return this.normalizeYaw((float)Math.toDegrees(Math.atan2(-var3, var5)));
   }

   private float approachAngle(float var1, float var2, float var3) {
      float var4 = this.wrapDegrees(var2 - var1);
      return this.normalizeYaw(var1 + var4 * var3);
   }

   private float normalizeYaw(float var1) {
      var1 %= 360.0F;
      if (var1 < 0.0F) {
         var1 += 360.0F;
      }

      return var1;
   }

   private float wrapDegrees(float var1) {
      var1 %= 360.0F;
      if (var1 >= 180.0F) {
         var1 -= 360.0F;
      }

      if (var1 < -180.0F) {
         var1 += 360.0F;
      }

      return var1;
   }

   private double clamp(double var1, double var3, double var5) {
      return Math.max(var3, Math.min(var5, var1));
   }

   private void cleanupMissingVisuals(Set<Long> var1) {
      Iterator var2 = this.visuals.entrySet().iterator();

      while (var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         if (!var1.contains(var3.getKey())) {
            ((TurretTask.TurretVisual)var3.getValue()).remove();
            var2.remove();
         }
      }
   }

   private void removeVisual(long var1) {
      TurretTask.TurretVisual var3 = this.visuals.remove(var1);
      if (var3 != null) {
         var3.remove();
      }
   }

   private void removeAllVisuals() {
      for (TurretTask.TurretVisual var2 : this.visuals.values()) {
         var2.remove();
      }

      this.visuals.clear();
   }

   private String format(double var1) {
      return var1 == Math.floor(var1) ? String.valueOf((long)var1) : String.valueOf(var1);
   }

   private final class TurretVisual {
      private final int level;
      private final List<BlockDisplay> all = new ArrayList<>();
      private BlockDisplay base;
      private BlockDisplay core;
      private BlockDisplay head;
      private BlockDisplay barrel;
      private BlockDisplay sensor;
      private BlockDisplay leftArmor;
      private BlockDisplay rightArmor;
      private BlockDisplay rearArmor;
      private float currentYaw;
      private int recoilTicks;
      private long lastCoreParticle;
      private Boolean lastLoaded;

      private TurretVisual(int nullx) {
         this.level = nullx;
      }

      private boolean isValid() {
         return this.base != null && this.base.isValid() && this.head != null && this.head.isValid() && this.barrel != null && this.barrel.isValid();
      }

      private void markFired() {
         this.recoilTicks = 2;
      }

      private void update(Location var1, boolean var2, float var3) {
         this.all.clear();
         this.add(this.base);
         this.add(this.core);
         this.add(this.head);
         this.add(this.barrel);
         this.add(this.sensor);
         this.add(this.leftArmor);
         this.add(this.rightArmor);
         this.add(this.rearArmor);
         double var4 = Math.toRadians(var3);
         double var6 = -Math.sin(var4);
         double var8 = Math.cos(var4);
         double var10 = Math.cos(var4);
         double var12 = Math.sin(var4);
         double var14 = var1.getX() + 0.5;
         double var16 = var1.getZ() + 0.5;
         double var18 = var1.getY() + TurretTask.this.headHeight(this.level);
         double var20 = this.recoilTicks > 0 ? 0.11 : 0.0;
         if (this.recoilTicks > 0) {
            this.recoilTicks--;
         }

         if (this.lastLoaded == null) {
            this.move(this.base, var14, var1.getY() + 0.34 + this.level * 0.018, var16, 0.0F);
            this.move(this.core, var14, var1.getY() + TurretTask.this.coreHeight(this.level), var16, 0.0F);
         }

         this.move(this.head, var14 + var6 * 0.04, var18, var16 + var8 * 0.04, var3);
         double var22 = 0.43 + this.level * 0.065 - var20;
         this.move(this.barrel, var14 + var6 * var22, var18 + 0.01, var16 + var8 * var22, var3);
         this.move(this.sensor, var14 - var6 * 0.1, var18 + 0.3 + this.level * 0.012, var16 - var8 * 0.1, var3);
         double var24 = 0.4 + this.level * 0.018;
         this.move(this.leftArmor, var14 + var10 * var24 - var6 * 0.03, var18 - 0.02, var16 + var12 * var24 - var8 * 0.03, var3);
         this.move(this.rightArmor, var14 - var10 * var24 - var6 * 0.03, var18 - 0.02, var16 - var12 * var24 - var8 * 0.03, var3);
         this.move(this.rearArmor, var14 - var6 * (0.34 + this.level * 0.025), var18 - 0.03, var16 - var8 * (0.34 + this.level * 0.025), var3);
         if (this.core != null && this.core.isValid() && (this.lastLoaded == null || this.lastLoaded != var2)) {
            Material var26 = var2 ? TurretTask.this.materialCore(this.level) : Material.REDSTONE_LAMP;
            this.core.setBlock(var26.createBlockData());
         }

         this.lastLoaded = var2;
      }

      private Location muzzleLocation(Location var1) {
         double var2 = Math.toRadians(this.currentYaw);
         double var4 = -Math.sin(var2);
         double var6 = Math.cos(var2);
         double var8 = 0.78 + this.level * 0.11;
         return new Location(
            var1.getWorld(), var1.getX() + 0.5 + var4 * var8, var1.getY() + TurretTask.this.headHeight(this.level) + 0.02, var1.getZ() + 0.5 + var6 * var8
         );
      }

      private void add(BlockDisplay var1) {
         if (var1 != null) {
            this.all.add(var1);
         }
      }

      private void move(BlockDisplay var1, double var2, double var4, double var6, float var8) {
         if (var1 != null && var1.isValid()) {
            Location var9 = new Location(var1.getWorld(), var2, var4, var6, var8, 0.0F);
            var1.teleport(var9);
            var1.setRotation(var8, 0.0F);
         }
      }

      private void remove() {
         this.all.clear();
         this.add(this.base);
         this.add(this.core);
         this.add(this.head);
         this.add(this.barrel);
         this.add(this.sensor);
         this.add(this.leftArmor);
         this.add(this.rightArmor);
         this.add(this.rearArmor);

         for (BlockDisplay var2 : this.all) {
            if (var2 != null && var2.isValid()) {
               var2.remove();
            }
         }

         this.all.clear();
      }
   }
}
