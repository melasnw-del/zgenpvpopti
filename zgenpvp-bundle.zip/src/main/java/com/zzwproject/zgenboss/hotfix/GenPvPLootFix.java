package com.zzwproject.zgenboss.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class GenPvPLootFix {
   private GenPvPLootFix() {
   }

   public static void grant(Object var0, Object var1, Object var2) {
      try {
         Object var3 = invoke(var0, "getConfig");
         if (!getBoolean(var3, "rewards.genpvp-special.enabled", true)) {
            return;
         }

         int var4 = bossLevel(var2);
         String var5 = var4 <= 20 ? "weak" : (var4 <= 30 ? "medium" : "strong");
         String var6 = "rewards.genpvp-special.bands." + var5;
         int var7 = Math.max(1, Math.min(3, getInt(var3, var6 + ".rolls", 2)));
         double var8 = Math.max(0.0, Math.min(100.0, getDouble(var3, var6 + ".bonus-roll-chance-percent", defaultBonus(var5))));
         if (var7 < 3 && ThreadLocalRandom.current().nextDouble(100.0) < var8) {
            var7++;
         }

         List var10 = getStringList(var3, var6 + ".pool");
         if (var10.isEmpty()) {
            var10 = builtInPool(var5);
         }

         List var11 = parse(var10);
         if (var11.isEmpty()) {
            return;
         }

         ArrayList var12 = new ArrayList();

         for (int var13 = 0; var13 < var7; var13++) {
            GenPvPLootFix.Entry var14 = choose(var11);
            if (var14 != null) {
               List var15 = createRewardItems(var0, var14);
               if (!var15.isEmpty()) {
                  for (Object var17 : var15) {
                     if (var17 != null) {
                        dropAtBoss(var2, var17);
                     }
                  }

                  var12.add(var14.display());
                  if (var1 != null) {
                     tryInvoke(var1, "sendMessage", "§d✦ §fBoss ödülü: §a" + var14.display());
                  }
               }
            }
         }

         if (!var12.isEmpty()) {
            try {
               Object var20 = field(var2, "lastRewardName");
               String var21 = var20 == null ? "" : String.valueOf(var20).trim();
               String var22 = String.join(" §8• §a", var12);
               setField(var2, "lastRewardName", var21.isEmpty() ? var22 : var21 + " §8• §a" + var22);
            } catch (Throwable var18) {
            }
         }
      } catch (Throwable var19) {
         warn(var0, "GenPvP boss loot hatasi: " + var19.getClass().getSimpleName() + ": " + var19.getMessage());
      }
   }

   private static List<Object> createRewardItems(Object var0, GenPvPLootFix.Entry var1) throws Exception {
      String var2 = var1.type().toUpperCase(Locale.ROOT);
      if (var2.equals("MARKET")) {
         Object var10 = createMarketItem(var0, var1.value());
         return var10 == null ? List.of() : List.of(var10);
      }

      if (var2.equals("MARKET_SET")) {
         return createMarketSet(var0, var1.value());
      }

      Object var3 = invoke(var0, "getServer");
      Object var4 = invoke(var3, "getPluginManager");
      if (var2.equals("SHARD")) {
         Object var11 = invoke(var4, "getPlugin", "ZShard");
         if (var11 == null) {
            return List.of();
         }

         Object var12 = invoke(var11, "getApi");
         Object var13 = invoke(var12, "createShardItem", Long.parseLong(var1.value()));
         return var13 == null ? List.of() : List.of(var13);
      } else {
         Object var5 = invoke(var4, "getPlugin", "ZGenPvP");
         if (var5 == null) {
            return List.of();
         }

         int var6 = parseInt(var1.value(), 1);

         Object var7 = switch (var2) {
            case "GENERATOR" -> invoke(invoke(var5, "getGeneratorManager"), "createGeneratorItem", var6);
            case "DEFENSE" -> invoke(invoke(var5, "getItemFactory"), "createDefenseBlock", var6);
            case "DOOR" -> invoke(invoke(var5, "getItemFactory"), "createDefenseDoor", var6);
            case "TRAPDOOR" -> invoke(invoke(var5, "getItemFactory"), "createDefenseTrapdoor", var6);
            case "TURRET" -> invoke(invoke(var5, "getItemFactory"), "createTurret", var6);
            case "MONEY" -> invoke(invoke(var5, "getMoneyItemManager"), "createMoney", Double.parseDouble(var1.value()));
            case "SELL_WAND" -> invoke(invoke(var5, "getSellWandManager"), "createWand", var6);
            case "INSTABREAKER" -> invoke(invoke(var5, "getInstabreakerManager"), "createItem");
            case "HASTE" -> invoke(invoke(var5, "getHasteItemManager"), "createItem", Math.max(1, var6));
            case "BASE" -> invoke(invoke(var5, "getItemFactory"), "createBaseBlock");
            case "BEACON" -> invoke(invoke(var5, "getItemFactory"), "createRespawnBeacon");
            case "RAID_BOMB" -> createRaidBomb(var5, var6);
            default -> null;
         };
         return var7 == null ? List.of() : List.of(var7);
      }
   }

   private static Object createRaidBomb(Object var0, int var1) throws Exception {
      Object var2 = invoke(var0, "getRaidBombManager");
      Method var3 = null;

      for (Method var7 : var2.getClass().getMethods()) {
         if (var7.getName().equals("createBomb") && var7.getParameterCount() == 1) {
            var3 = var7;
            break;
         }
      }

      if (var3 == null) {
         return null;
      }

      Class var10 = var3.getParameterTypes()[0];
      Method var11 = null;

      for (Method var9 : var10.getMethods()) {
         if (var9.getName().equals("fromId") && Modifier.isStatic(var9.getModifiers()) && var9.getParameterCount() == 1) {
            var11 = var9;
            break;
         }
      }

      if (var11 == null) {
         return null;
      }

      Object var13 = var11.invoke(null, var1);
      Object var15 = invoke(var13, "orElse", null);
      return var15 == null ? null : var3.invoke(var2, var15);
   }

   private static Object createMarketItem(Object var0, String var1) throws Exception {
      Object var2 = invoke(var0, "getServer");
      Object var3 = invoke(var2, "getPluginManager");
      Object var4 = invoke(var3, "getPlugin", "ZShop");
      if (var4 == null) {
         return null;
      }

      Object var5 = invoke(var4, "getShopManager");
      Method var6 = null;

      for (Method var10 : var5.getClass().getMethods()) {
         if (var10.getName().equals("getProduct") && var10.getParameterCount() == 2) {
            var6 = var10;
            break;
         }
      }

      if (var6 == null) {
         return null;
      }

      Class var12 = var6.getParameterTypes()[0];
      Object var13 = enumConstant(var12, "EQUIPMENT");
      if (var13 == null) {
         return null;
      }

      Object var14 = var6.invoke(var5, var13, var1);
      if (var14 == null) {
         return null;
      }

      Object var15 = invoke(var4, "getCategoryMenu");
      Method var11 = findDeclared(var15.getClass(), "createProductItem", 1);
      if (var11 == null) {
         return null;
      }

      var11.setAccessible(true);
      return var11.invoke(var15, var14);
   }

   private static List<Object> createMarketSet(Object var0, String var1) throws Exception {
      String var2 = var1.toLowerCase(Locale.ROOT);
      String var3 = var2.equals("chain") ? "chainmail" : var2;
      ArrayList var4 = new ArrayList();

      for (String var6 : List.of("helmet", "chestplate", "leggings", "boots")) {
         Object var7 = createMarketItem(var0, var3 + "-" + var6);
         if (var7 != null) {
            var4.add(var7);
         }
      }

      return var4;
   }

   private static void dropAtBoss(Object var0, Object var1) throws Exception {
      Object var2 = field(var0, "entity");
      Object var3 = invoke(var2, "getLocation");
      Object var4 = invoke(var3, "getWorld");
      invoke(var4, "dropItemNaturally", var3, var1);
   }

   private static int bossLevel(Object var0) {
      try {
         Object var1 = field(var0, "generator");

         try {
            return ((Number)field(var1, "level")).intValue();
         } catch (Throwable var5) {
            return tryInvoke(var1, "level") instanceof Number var4 ? var4.intValue() : 1;
         }
      } catch (Throwable var6) {
         return 1;
      }
   }

   private static double defaultBonus(String var0) {
      return var0.equals("weak") ? 10.0 : (var0.equals("medium") ? 25.0 : 40.0);
   }

   private static List<String> builtInPool(String var0) {
      if (var0.equals("weak")) {
         return List.of(
            "SHARD|18|15|15 Shard",
            "SHARD|10|25|25 Shard",
            "MONEY|12|10000|$10.000 Banknot",
            "MARKET|10|wooden-sword|Ahşap Kılıç",
            "MARKET|8|stone-sword|Taş Kılıç",
            "MARKET|8|stone-pickaxe|Taş Kazma",
            "MARKET|7|chainmail-chestplate|Zincir Göğüslük",
            "MARKET|6|chainmail-helmet|Zincir Kask",
            "MARKET|4|iron-sword|Demir Kılıç",
            "MARKET_SET|3|leather|Deri Set",
            "MARKET_SET|2|chain|Zincir Set",
            "GENERATOR|6|2|Seviye 2 Jeneratör",
            "DEFENSE|7|1|Seviye 1 Defans Bloğu",
            "DOOR|4|1|Seviye 1 Defans Kapısı",
            "TRAPDOOR|4|1|Seviye 1 Defans Tuzak Kapısı",
            "RAID_BOMB|2|1|Küçük Raid Bombası"
         );
      } else {
         return var0.equals("medium")
            ? List.of(
               "SHARD|15|25|25 Shard",
               "SHARD|10|40|40 Shard",
               "MONEY|12|20000|$20.000 Banknot",
               "MONEY|5|35000|$35.000 Banknot",
               "MARKET|9|iron-sword|Demir Kılıç",
               "MARKET|7|iron-pickaxe|Demir Kazma",
               "MARKET|7|iron-chestplate|Demir Göğüslük",
               "MARKET|6|diamond-sword|Elmas Kılıç",
               "MARKET|5|diamond-helmet|Elmas Kask",
               "MARKET|5|diamond-chestplate|Elmas Göğüslük",
               "MARKET_SET|4|iron|Demir Set",
               "MARKET_SET|1|diamond|Elmas Set",
               "GENERATOR|7|3|Seviye 3 Jeneratör",
               "GENERATOR|3|5|Seviye 5 Jeneratör",
               "DEFENSE|6|2|Seviye 2 Defans Bloğu",
               "DEFENSE|3|3|Seviye 3 Defans Bloğu",
               "DOOR|4|2|Seviye 2 Defans Kapısı",
               "TRAPDOOR|4|2|Seviye 2 Defans Tuzak Kapısı",
               "TURRET|3|1|Seviye 1 Taret",
               "RAID_BOMB|3|1|Küçük Raid Bombası",
               "RAID_BOMB|2|2|Orta Raid Bombası",
               "SELL_WAND|2|25|25 Kullanımlık Sell Wand",
               "HASTE|2|1|Acele II Eşyası"
            )
            : List.of(
               "SHARD|13|40|40 Shard",
               "SHARD|8|60|60 Shard",
               "MONEY|10|35000|$35.000 Banknot",
               "MONEY|5|50000|$50.000 Banknot",
               "MARKET|8|diamond-sword|Elmas Kılıç",
               "MARKET|6|diamond-chestplate|Elmas Göğüslük",
               "MARKET|5|netherite-sword|Netherite Kılıç",
               "MARKET|4|netherite-helmet|Netherite Kask",
               "MARKET|4|netherite-chestplate|Netherite Göğüslük",
               "MARKET_SET|3|diamond|Elmas Set",
               "MARKET_SET|1|netherite|Netherite Set",
               "GENERATOR|6|5|Seviye 5 Jeneratör",
               "GENERATOR|1|10|Seviye 10 Jeneratör",
               "DEFENSE|5|3|Seviye 3 Defans Bloğu",
               "DEFENSE|3|4|Seviye 4 Defans Bloğu",
               "DEFENSE|2|5|Seviye 5 Defans Bloğu",
               "DOOR|3|3|Seviye 3 Defans Kapısı",
               "DOOR|2|5|Seviye 5 Defans Kapısı",
               "TRAPDOOR|3|3|Seviye 3 Defans Tuzak Kapısı",
               "TRAPDOOR|2|5|Seviye 5 Defans Tuzak Kapısı",
               "TURRET|3|2|Seviye 2 Taret",
               "RAID_BOMB|3|2|Orta Raid Bombası",
               "RAID_BOMB|2|3|Büyük Raid Bombası",
               "SELL_WAND|2|50|50 Kullanımlık Sell Wand",
               "INSTABREAKER|2|1|Instabreaker",
               "HASTE|2|1|Acele II Eşyası",
               "BASE|1|1|Base Bloğu",
               "BEACON|1|1|Respawn Beacon"
            );
      }
   }

   private static List<GenPvPLootFix.Entry> parse(List<String> var0) {
      ArrayList var1 = new ArrayList();

      for (String var3 : var0) {
         if (var3 != null && !var3.isBlank()) {
            String[] var4 = var3.split("\\|", 4);
            if (var4.length >= 3) {
               try {
                  int var5 = Math.max(0, Integer.parseInt(var4[1].trim()));
                  if (var5 != 0) {
                     var1.add(
                        new GenPvPLootFix.Entry(
                           var4[0].trim().toUpperCase(Locale.ROOT), var5, var4[2].trim(), var4.length >= 4 ? var4[3].trim() : var4[0].trim()
                        )
                     );
                  }
               } catch (Throwable var6) {
               }
            }
         }
      }

      return var1;
   }

   private static GenPvPLootFix.Entry choose(List<GenPvPLootFix.Entry> var0) {
      int var1 = 0;

      for (GenPvPLootFix.Entry var3 : var0) {
         var1 += var3.weight();
      }

      if (var1 <= 0) {
         return null;
      }

      int var6 = ThreadLocalRandom.current().nextInt(var1);
      int var7 = 0;

      for (GenPvPLootFix.Entry var5 : var0) {
         var7 += var5.weight();
         if (var6 < var7) {
            return var5;
         }
      }

      return (GenPvPLootFix.Entry)var0.get(var0.size() - 1);
   }

   private static Object enumConstant(Class<?> var0, String var1) {
      try {
         Object[] var2 = var0.getEnumConstants();
         if (var2 != null) {
            for (Object var6 : var2) {
               if (String.valueOf(var6).equalsIgnoreCase(var1)) {
                  return var6;
               }
            }
         }
      } catch (Throwable var7) {
      }

      return null;
   }

   private static Method findDeclared(Class<?> var0, String var1, int var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2) {
               return var7;
            }
         }
      }

      return null;
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static void setField(Object var0, String var1, Object var2) throws Exception {
      for (Class var3 = var0.getClass(); var3 != null; var3 = var3.getSuperclass()) {
         try {
            Field var4 = var3.getDeclaredField(var1);
            var4.setAccessible(true);
            var4.set(var0, var2);
            return;
         } catch (NoSuchFieldException var5) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static List<String> getStringList(Object var0, String var1) {
      try {
         if (invoke(var0, "getStringList", var1) instanceof List var3) {
            ArrayList var4 = new ArrayList();

            for (Object var6 : var3) {
               if (var6 != null) {
                  var4.add(String.valueOf(var6));
               }
            }

            return var4;
         }
      } catch (Throwable var7) {
      }

      return List.of();
   }

   private static boolean getBoolean(Object var0, String var1, boolean var2) {
      try {
         return invoke(var0, "getBoolean", var1, var2) instanceof Boolean var4 ? var4 : var2;
      } catch (Throwable var5) {
         return var2;
      }
   }

   private static int getInt(Object var0, String var1, int var2) {
      try {
         return invoke(var0, "getInt", var1, var2) instanceof Number var4 ? var4.intValue() : var2;
      } catch (Throwable var5) {
         return var2;
      }
   }

   private static double getDouble(Object var0, String var1, double var2) {
      try {
         return invoke(var0, "getDouble", var1, var2) instanceof Number var5 ? var5.doubleValue() : var2;
      } catch (Throwable var6) {
         return var2;
      }
   }

   private static int parseInt(String var0, int var1) {
      try {
         return Integer.parseInt(var0);
      } catch (Throwable var3) {
         return var1;
      }
   }

   private static Object invoke(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = null;

      for (Method var7 : var0.getClass().getMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length && compatible(var7.getParameterTypes(), var2)) {
            var3 = var7;
            break;
         }
      }

      if (var3 == null) {
         for (Class var9 = var0.getClass(); var9 != null && var3 == null; var9 = var9.getSuperclass()) {
            for (Method var8 : var9.getDeclaredMethods()) {
               if (var8.getName().equals(var1) && var8.getParameterCount() == var2.length && compatible(var8.getParameterTypes(), var2)) {
                  var3 = var8;
                  break;
               }
            }
         }
      }

      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object tryInvoke(Object var0, String var1, Object... var2) {
      try {
         return invoke(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static boolean compatible(Class<?>[] var0, Object[] var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isAssignableFrom(var1[var2].getClass())) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static void warn(Object var0, String var1) {
      try {
         invoke(invoke(var0, "getLogger"), "warning", var1);
      } catch (Throwable var3) {
      }
   }

   private record Entry(String type, int weight, String value, String display) {
   }
}
