package com.zzwproject.zgenpvp.generator;

import com.zzwproject.zgenpvp.model.GeneratorData;
import java.util.Optional;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public final class GeneratorMenuListener implements Listener {
   private final GeneratorManager generatorManager;
   private final GeneratorMenu generatorMenu;

   public GeneratorMenuListener(GeneratorManager var1, GeneratorMenu var2) {
      this.generatorManager = var1;
      this.generatorMenu = var2;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      if (this.generatorMenu.isMenu(var2)) {
         var1.setCancelled(true);
         if (var1.getWhoClicked() instanceof Player var4) {
            int var5 = var1.getRawSlot();
            if (var5 >= 0 && var5 < var2.getSize()) {
               String var6 = this.generatorMenu.getAction(var1.getCurrentItem());
               if (var6 != null) {
                  Optional var7 = this.generatorMenu.getGenerator(var2);
                  if (var7.isEmpty()) {
                     var4.closeInventory();
                  } else {
                     GeneratorData var8 = (GeneratorData)var7.get();
                     switch (var6) {
                        case "OPEN_UPGRADE_CONFIRM":
                           this.generatorMenu.openUpgradeConfirm(var4, var8);
                           break;
                        case "CONFIRM_UPGRADE":
                           this.generatorManager.upgrade(var4, var8);
                           this.generatorMenu.open(var4, var8);
                           break;
                        case "BACK_MAIN":
                           this.generatorMenu.open(var4, var8);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      if (this.generatorMenu.isMenu(var2)) {
         for (int var4 : var1.getRawSlots()) {
            if (var4 >= 0 && var4 < var2.getSize()) {
               var1.setCancelled(true);
               return;
            }
         }
      }
   }
}
