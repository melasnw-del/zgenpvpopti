package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

final class R {
   private R() {
   }

   static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   static Method method(Class<?> var0, String var1, int var2) throws Exception {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2) {
               var7.setAccessible(true);
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && var11.getParameterCount() == var2) {
            var11.setAccessible(true);
            return var11;
         }
      }

      throw new NoSuchMethodException(var1 + "/" + var2);
   }

   static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = null;
      Class var4 = var0.getClass();
      Class var5 = var4;

      label72:
      while (var5 != null) {
         for (Method var9 : var5.getDeclaredMethods()) {
            if (var9.getName().equals(var1) && var9.getParameterCount() == var2.length) {
               Class[] var10 = var9.getParameterTypes();

               for (int var11 = 0; var11 < var10.length; var11++) {
                  if (!fits(var10[var11], var2[var11])) {
                     continue label72;
                  }
               }

               var3 = var9;
               break label72;
            }
         }

         var5 = var5.getSuperclass();
      }

      if (var3 == null) {
         label52:
         for (Method var15 : var4.getMethods()) {
            if (var15.getName().equals(var1) && var15.getParameterCount() == var2.length) {
               Class[] var16 = var15.getParameterTypes();

               for (int var17 = 0; var17 < var16.length; var17++) {
                  if (!fits(var16[var17], var2[var17])) {
                     continue label52;
                  }
               }

               var3 = var15;
               break;
            }
         }
      }

      if (var3 == null) {
         var3 = method(var4, var1, var2.length);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = method(var0, var1, var2.length);
      return var3.invoke(null, var2);
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == int.class && var1 instanceof Integer
               || var0 == long.class && var1 instanceof Long
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }
}
