package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class BeaconSpawnMenu {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final NamespacedKey actionKey;
   private final NamespacedKey beaconIdKey;

   public BeaconSpawnMenu(ZGenPvP var1, BeaconManager var2) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.actionKey = new NamespacedKey(var1, "beacon_spawn_action");
      this.beaconIdKey = new NamespacedKey(var1, "beacon_spawn_id");
   }

   public void open(Player var1) {
      this.open(var1, false);
   }

   public void openManagement(Player var1) {
      this.open(var1, true);
   }

   private void open(Player var1, boolean var2) {
      if (var1 != null) {
         List<BeaconData> var3 = this.beaconManager.getOwnedBeacons(var1.getUniqueId());
         int var4 = Math.max(1, var3.size() + (var2 ? 0 : 1));
         int var5 = var2 ? 54 : Math.min(54, Math.max(9, (var4 + 8) / 9 * 9));
         BeaconSpawnMenu.BeaconSpawnMenuHolder var6 = new BeaconSpawnMenu.BeaconSpawnMenuHolder(var2);
         Inventory var7 = Bukkit.createInventory(
            var6,
            var5,
            ColorUtil.color(
               this.plugin
                  .getConfigManager()
                  .getMenus()
                  .getString(var2 ? "beacon-list.title" : "beacon-spawn-select.title", var2 ? "&8Fenerlerin" : "&8Doğacağın yeri seç")
            )
         );
         var6.inventory = var7;
         if (var2) {
            ItemStack var8 = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
            ItemMeta var9 = var8.getItemMeta();
            if (var9 != null) {
               var9.setDisplayName(" ");
               var8.setItemMeta(var9);
            }

            for (int var10 = 0; var10 < var5; var10++) {
               var7.setItem(var10, var8);
            }

            ItemStack var16 = new ItemStack(Material.NETHER_STAR);
            ItemMeta var11 = var16.getItemMeta();
            if (var11 != null) {
               var11.setDisplayName(ColorUtil.color("&bYeniden doğma fenerlerin"));
               var11.setLore(List.of(ColorUtil.color("&7Toplam fener: &f" + var3.size()), "", ColorUtil.color("&eYönetmek istediğin feneri seç.")));
               var16.setItemMeta(var11);
            }

            var7.setItem(4, var16);
         } else {
            var7.setItem(0, this.createSpawnItem(var1));
         }

         List var14 = List.of(10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43);
         int var15 = var2 ? 0 : 1;
         int var17 = 1;

         for (BeaconData var12 : var3) {
            int var13;
            if (var2) {
               if (var15 >= var14.size()) {
                  break;
               }

               var13 = (Integer)var14.get(var15++);
            } else {
               if (var15 >= var5) {
                  break;
               }

               var13 = var15++;
            }

            var7.setItem(var13, this.createBeaconItem(var1, var12, var17++, var2));
         }

         var1.openInventory(var7);
         this.plugin.getSoundUtil().play(var1, "beacon-menu-open");
      }
   }

   private ItemStack createSpawnItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.RED_BED);
      ItemMeta var3 = var2.getItemMeta();
      if (var3 == null) {
         return var2;
      }

      boolean var4 = this.beaconManager.isServerSpawnSelected(var1);
      var3.setDisplayName(ColorUtil.color(var4 ? "&aSpawn &7(seçili)" : "&aSpawn"));
      ArrayList var5 = new ArrayList();
      var5.add(ColorUtil.color("&eIşınlan &8(sol-tık)"));
      var5.add(ColorUtil.color("&eVarsayılan yap &8(sağ-tık)"));
      var3.setLore(var5);
      var3.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, "SPAWN");
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createBeaconItem(Player var1, BeaconData var2, int var3, boolean var4) {
      ItemStack var5 = new ItemStack(Material.BEACON);
      ItemMeta var6 = var5.getItemMeta();
      if (var6 == null) {
         return var5;
      }

      boolean var7 = this.beaconManager.isBeaconSelected(var1, var2.getId());
      String var8 = var7 ? " &7(Seçili)" : "";
      var6.setDisplayName(ColorUtil.color("&dYeniden doğma feneri #" + var3 + " &8(" + var2.getX() + ", " + var2.getY() + ", " + var2.getZ() + ")" + var8));
      ArrayList var9 = new ArrayList();
      if (var2.getName() != null && !var2.getName().isBlank()) {
         var9.add(ColorUtil.color("&7" + var2.getName()));
         var9.add("");
      }

      if (var4) {
         var9.add(ColorUtil.color("&7Dünya: &f" + var2.getWorldName()));
         var9.add(ColorUtil.color("&7Konum: &f" + var2.getX() + ", " + var2.getY() + ", " + var2.getZ()));
         var9.add("");
         var9.add(ColorUtil.color("&eYönetim menüsünü aç &8(tıkla)"));
      } else {
         var9.add(ColorUtil.color("&eIşınlan &8(sol-tık)"));
         var9.add(ColorUtil.color("&eVarsayılan yap &8(sağ-tık)"));
      }

      var6.setLore(var9);
      var6.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, "BEACON");
      var6.getPersistentDataContainer().set(this.beaconIdKey, PersistentDataType.LONG, var2.getId());
      var5.setItemMeta(var6);
      return var5;
   }

   public boolean isMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BeaconSpawnMenu.BeaconSpawnMenuHolder;
   }

   public boolean isManagementMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof BeaconSpawnMenu.BeaconSpawnMenuHolder var2 && var2.managementMode;
   }

   public String getAction(ItemStack var1) {
      return var1 != null && var1.hasItemMeta() ? (String)var1.getItemMeta().getPersistentDataContainer().get(this.actionKey, PersistentDataType.STRING) : null;
   }

   public long getBeaconId(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta()) {
         Long var2 = (Long)var1.getItemMeta().getPersistentDataContainer().get(this.beaconIdKey, PersistentDataType.LONG);
         return var2 == null ? -1L : var2;
      } else {
         return -1L;
      }
   }

   private static final class BeaconSpawnMenuHolder implements InventoryHolder {
      private final boolean managementMode;
      private Inventory inventory;

      private BeaconSpawnMenuHolder(boolean var1) {
         this.managementMode = var1;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }
}
