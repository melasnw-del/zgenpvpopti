package com.zzwproject.zgenpvp.access;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class DefenseAccessListener implements Listener {
   private final ZGenPvP plugin;
   private final DefenseAccessManager manager;
   private final SpecialItemFactory itemFactory;

   public DefenseAccessListener(ZGenPvP var1, DefenseAccessManager var2, SpecialItemFactory var3) {
      this.plugin = var1;
      this.manager = var2;
      this.itemFactory = var3;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      DefenseAccessType var2;
      if (this.itemFactory.isDefenseDoor(var1.getItemInHand())) {
         var2 = DefenseAccessType.DOOR;
      } else {
         if (!this.itemFactory.isDefenseTrapdoor(var1.getItemInHand())) {
            StructureSupportGuard.restore(this, var1);
            return;
         }

         var2 = DefenseAccessType.TRAPDOOR;
      }

      if (!this.manager.place(var1.getPlayer(), var1.getBlockPlaced(), var2, this.itemFactory.getAccessLevel(var1.getItemInHand()))) {
         var1.setCancelled(true);
      }

      StructureSupportGuard.restore(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.manager.get(var2);
            if (!var3.isEmpty() && var1.getAction().isRightClick()) {
               DefenseData var4 = (DefenseData)var3.get();
               Player var5 = var1.getPlayer();
               this.manager.showInfo(var5, var4);
               var1.setCancelled(true);
               if (this.manager.canManageAccess(var5, var4)) {
                  if (var5.isSneaking()) {
                     this.manager.upgrade(var5, var4);
                  } else {
                     this.manager.toggleOpen(var5, var4);
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      Optional var2 = this.manager.get(var1.getBlock());
      if (!var2.isEmpty()) {
         Player var3 = var1.getPlayer();
         DefenseData var4 = (DefenseData)var2.get();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var3.getInventory().getItemInMainHand())) {
            var1.setCancelled(true);
            String var5 = "ACCESS:" + var4.getId();
            if (TeamPermissionBridge.accessBreakOwnerOrAllowed(var4.getOwnerUuid(), var3.getUniqueId(), var4)) {
               StructureMiningUtil.startOwnerMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  () -> this.manager.get(var1.getBlock()).isPresent(),
                  () -> this.manager.get(var1.getBlock()).ifPresent(var2xx -> {
                     if (this.manager.removeByOwner(var3, var2xx)) {
                        this.clearPhysicalBlocks(var2xx);
                     }
                  })
               );
            } else if (this.manager.isFriendly(var3.getUniqueId(), var4.getOwnerUuid())) {
               StructureMiningUtil.stopMining(var3);
               this.manager.sendOwnerInfo(var3, var4);
            } else {
               StructureMiningUtil.startEnemyMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  var4::getCurrentHp,
                  var4::getMaxHp,
                  () -> this.manager.get(var1.getBlock()).isPresent(),
                  () -> this.manager.get(var1.getBlock()).ifPresent(var2xx -> this.manager.damage(var3, var2xx))
               );
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBreak(BlockBreakEvent var1) {
      Optional var2 = this.manager.get(var1.getBlock());
      if (!var2.isEmpty()) {
         var1.setCancelled(true);
         var1.setDropItems(false);
         var1.setExpToDrop(0);
         DefenseData var3 = (DefenseData)var2.get();
         Player var4 = var1.getPlayer();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var4.getInventory().getItemInMainHand())) {
            if (TeamPermissionBridge.accessBreakOwnerOrAllowed(var3.getOwnerUuid(), var4.getUniqueId(), var3)) {
               if (this.manager.removeByOwner(var4, var3)) {
                  this.clearPhysicalBlocks(var3);
               }
            } else if (this.manager.isFriendly(var4.getUniqueId(), var3.getOwnerUuid())) {
               this.manager.sendOwnerInfo(var4, var3);
            } else {
               this.manager.damage(var4, var3);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onEntityExplode(EntityExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.manager.get(var1x).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBlockExplode(BlockExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.manager.get(var1x).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonExtend(BlockPistonExtendEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.manager.get(var3).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonRetract(BlockPistonRetractEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.manager.get(var3).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   private void clearPhysicalBlocks(DefenseData var1) {
      if (var1 != null && var1.getLocation() != null && var1.getLocation().getWorld() != null) {
         DefenseAccessType var2 = this.manager.getType(var1);
         Block var3 = var1.getLocation().getBlock();
         if (var2 == DefenseAccessType.DOOR) {
            var3.setType(Material.AIR, false);
            var3.getRelative(0, 1, 0).setType(Material.AIR, false);
         } else {
            var3.setType(Material.AIR, false);
         }
      }
   }
}
