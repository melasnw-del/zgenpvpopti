package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import com.zzwproject.zgenpvp.model.DefenseData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Location;

public final class DefenseRepository {
   private final DatabaseManager databaseManager;

   public DefenseRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public List<DefenseData> findAllByType(String var1) {
      ArrayList var2 = new ArrayList();
      String var3 = "SELECT *\nFROM defenses\nWHERE type = ?;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setString(1, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            while (var5.next()) {
               var2.add(this.read(var5));
            }
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
      }

      return var2;
   }

   public long create(long var1, UUID var3, String var4, Location var5, int var6, int var7) {
      if (var5.getWorld() == null) {
         return -1L;
      }

      String var8 = "INSERT INTO defenses (\n    base_id,\n    owner_uuid,\n    type,\n\n    world,\n    x,\n    y,\n    z,\n\n    level,\n\n    current_hp,\n    max_hp,\n\n    created_at\n)\n\nVALUES (\n    ?, ?, ?,\n    ?, ?, ?, ?,\n    ?,\n    ?, ?,\n    ?\n);\n";

      try (PreparedStatement var9 = this.databaseManager.getConnection().prepareStatement(var8, 1)) {
         if (var1 > 0L) {
            var9.setLong(1, var1);
         } else {
            var9.setNull(1, 4);
         }

         var9.setString(2, var3.toString());
         var9.setString(3, var4);
         var9.setString(4, var5.getWorld().getName());
         var9.setInt(5, var5.getBlockX());
         var9.setInt(6, var5.getBlockY());
         var9.setInt(7, var5.getBlockZ());
         var9.setInt(8, var6);
         var9.setInt(9, var7);
         var9.setInt(10, var7);
         var9.setLong(11, System.currentTimeMillis());
         var9.executeUpdate();

         try (ResultSet var10 = var9.getGeneratedKeys()) {
            if (var10.next()) {
               return var10.getLong(1);
            }
         }
      } catch (SQLException var17) {
         var17.printStackTrace();
      }

      return -1L;
   }

   public boolean updateHealth(long var1, int var3) {
      String var4 = "UPDATE defenses\nSET current_hp = ?\nWHERE id = ?;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setInt(1, Math.max(0, var3));
         var5.setLong(2, var1);
         return var5.executeUpdate() > 0;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return false;
      }
   }

   public boolean updateLevel(long var1, int var3, int var4) {
      String var5 = "UPDATE defenses\n\nSET\n    level = ?,\n    current_hp = ?,\n    max_hp = ?\n\nWHERE id = ?;\n";

      try (PreparedStatement var6 = this.databaseManager.getConnection().prepareStatement(var5)) {
         var6.setInt(1, var3);
         var6.setInt(2, var4);
         var6.setInt(3, var4);
         var6.setLong(4, var1);
         return var6.executeUpdate() > 0;
      } catch (SQLException var11) {
         var11.printStackTrace();
         return false;
      }
   }

   public boolean updateStoredArrows(long var1, int var3) {
      String var4 = "UPDATE defenses\nSET stored_arrows = ?\nWHERE id = ?;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setInt(1, Math.max(0, var3));
         var5.setLong(2, var1);
         return var5.executeUpdate() > 0;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return false;
      }
   }

   public boolean delete(long var1) {
      String var3 = "DELETE FROM defenses\nWHERE id = ?;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);
         return var4.executeUpdate() > 0;
      } catch (SQLException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public boolean existsById(long var1) {
      String var3 = "SELECT 1 FROM defenses WHERE id = ? LIMIT 1;";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            return var5.next();
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
         return true;
      }
   }

   public List<DefenseData> findAllByBase(long var1) {
      ArrayList var3 = new ArrayList();
      String var4 = "SELECT *\nFROM defenses\nWHERE base_id = ?\nORDER BY id ASC;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setLong(1, var1);

         try (ResultSet var6 = var5.executeQuery()) {
            while (var6.next()) {
               var3.add(this.read(var6));
            }
         }
      } catch (SQLException var13) {
         var13.printStackTrace();
      }

      return var3;
   }

   public int countByBaseAndType(long var1, String var3) {
      String var4 = "SELECT COUNT(*) AS total\nFROM defenses\nWHERE base_id = ?\n  AND type = ?;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setLong(1, var1);
         var5.setString(2, var3);

         try (ResultSet var6 = var5.executeQuery()) {
            if (var6.next()) {
               return var6.getInt("total");
            }
         }
      } catch (SQLException var13) {
         var13.printStackTrace();
      }

      return 0;
   }

   public int countStructures(long var1) {
      String var3 = "SELECT\n    (\n        SELECT COUNT(*)\n        FROM generators\n        WHERE base_id = ?\n    )\n    +\n    (\n        SELECT COUNT(*)\n        FROM defenses\n        WHERE base_id = ?\n    )\n    AS total;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);
         var4.setLong(2, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            if (var5.next()) {
               return var5.getInt("total");
            }
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
      }

      return 0;
   }

   private DefenseData read(ResultSet var1) throws SQLException {
      return new DefenseData(
         var1.getLong("id"),
         var1.getLong("base_id"),
         UUID.fromString(var1.getString("owner_uuid")),
         var1.getString("type"),
         var1.getString("world"),
         var1.getInt("x"),
         var1.getInt("y"),
         var1.getInt("z"),
         var1.getInt("level"),
         var1.getInt("current_hp"),
         var1.getInt("max_hp"),
         var1.getInt("stored_arrows")
      );
   }
}
