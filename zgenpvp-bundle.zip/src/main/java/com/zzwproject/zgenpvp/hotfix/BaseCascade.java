package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Optional;
import java.util.logging.Logger;

public final class BaseCascade {
   private BaseCascade() {
   }

   public static void remove(Object var0, Object var1) {
      Object var2 = unwrapOptional(var1);
      if (var0 != null && var2 != null) {
         int var3 = 0;

         try {
            long var21 = ((Number)call(var2, "getId")).longValue();
            Object var22 = call(var0, "getDefenseRepository");
            Object var7 = call(var22, "findAllByBase", var21);
            ArrayList var8 = new ArrayList();
            if (var7 instanceof Iterable) {
               for (Object var11 : (Iterable)var7) {
                  var8.add(var11);
               }
            }

            Object var23 = safeCall(var0, "getTurretTask");

            for (Object var26 : var8) {
               try {
                  long var12 = ((Number)call(var26, "getId")).longValue();
                  String var14 = String.valueOf(call(var26, "getType")).toUpperCase(Locale.ROOT);
                  Object var15 = safeCall(var26, "getLocation");
                  if (var14.contains("TURRET") && var23 != null) {
                     safeCall(var23, "removeVisual", var12);
                  }

                  if (var15 != null) {
                     clearBlockAt(var15);
                     if (var14.contains("DOOR") && !var14.contains("TRAP")) {
                        clearDoorHalf(var15, 1);
                        clearDoorHalf(var15, -1);
                     }
                  }

                  Object var16 = safeCall(var22, "delete", var12);
                  if (!(var16 instanceof Boolean) || (Boolean)var16) {
                     var3++;
                  }
               } catch (Throwable var19) {
               }
            }

            reloadManager(var0, "getDefenseManager");
            reloadManager(var0, "getTurretManager");
            reloadManager(var0, "getDefenseAccessManager");

            try {
               if (call(var0, "getLogger") instanceof Logger var27) {
                  var27.info("[BaseCascade] Base #" + var21 + " icin " + var3 + " bagli savunma/taret kaldirildi.");
               }
            } catch (Throwable var18) {
            }
         } catch (Throwable var20) {
            Throwable var4 = var20;

            try {
               if (call(var0, "getLogger") instanceof Logger var6) {
                  var6.warning("[BaseCascade] Temizlik hatasi: " + var4.getClass().getSimpleName() + ": " + var4.getMessage());
               }
            } catch (Throwable var17) {
            }
         }
      }
   }

   private static void reloadManager(Object var0, String var1) {
      try {
         Object var2 = call(var0, var1);
         if (var2 != null) {
            safeCall(var2, "loadCache");
         }
      } catch (Throwable var3) {
      }
   }

   private static void clearBlockAt(Object var0) throws Exception {
      Object var1 = call(var0, "getBlock");
      setAir(var1);
   }

   private static void clearDoorHalf(Object var0, int var1) {
      try {
         Object var2 = call(var0, "clone");
         call(var2, "add", 0.0, (double)var1, 0.0);
         Object var3 = call(var2, "getBlock");
         String var4 = String.valueOf(call(call(var3, "getType"), "name")).toUpperCase(Locale.ROOT);
         if (var4.contains("DOOR") && !var4.contains("TRAP")) {
            setAir(var3);
         }
      } catch (Throwable var5) {
      }
   }

   private static void setAir(Object var0) throws Exception {
      Class var1 = Class.forName("org.bukkit.Material");
      Enum var2 = Enum.valueOf(var1, "AIR");

      try {
         call(var0, "setType", var2, false);
      } catch (Throwable var4) {
         call(var0, "setType", var2);
      }
   }

   private static Object unwrapOptional(Object var0) {
      if (var0 == null) {
         return null;
      }

      try {
         return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
      } catch (Throwable var2) {
         return var0;
      }
   }

   private static Object safeCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = findMethod(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method findMethod(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
               Class[] var8 = var7.getParameterTypes();
               boolean var9 = true;

               for (int var10 = 0; var10 < var8.length; var10++) {
                  Object var11 = var2[var10];
                  if (var11 == null) {
                     if (var8[var10].isPrimitive()) {
                        var9 = false;
                        break;
                     }
                  } else {
                     Class var12 = wrap(var8[var10]);
                     if (!var12.isInstance(var11) && (!Number.class.isAssignableFrom(var12) || !(var11 instanceof Number))) {
                        var9 = false;
                        break;
                     }
                  }
               }

               if (var9) {
                  return var7;
               }
            }
         }
      }

      for (Method var16 : var0.getMethods()) {
         if (var16.getName().equals(var1) && var16.getParameterCount() == var2.length) {
            return var16;
         }
      }

      return null;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
