package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class StructureSupportGuard {
   private static final Map<Object, List<StructureSupportGuard.Snapshot>> SNAPSHOTS = Collections.synchronizedMap(new IdentityHashMap<>());

   private StructureSupportGuard() {
   }

   public static void capture(Object var0, Object var1) {
      try {
         if (var1 == null || !isSpecialPlacement(var0, var1)) {
            return;
         }

         ArrayList var2 = new ArrayList(2);
         addIfCityMaterial(var2, call(var1, "getBlockAgainst"));
         Object var3 = call(var1, "getBlockPlaced");
         Object var4 = relativeDown(var3);
         addIfCityMaterial(var2, var4);
         if (!var2.isEmpty()) {
            SNAPSHOTS.put(var1, var2);
         }
      } catch (Throwable var5) {
      }
   }

   public static void restore(Object var0, Object var1) {
      List<StructureSupportGuard.Snapshot> var2 = SNAPSHOTS.remove(var1);
      if (var2 != null && !var2.isEmpty()) {
         Object var3 = resolvePlugin(var0, 0, Collections.newSetFromMap(new IdentityHashMap<>()));

         for (StructureSupportGuard.Snapshot var5 : var2) {
            restoreNow(var5);
            schedule(var3, var5, 1L);
            schedule(var3, var5, 2L);
         }
      }
   }

   private static boolean isSpecialPlacement(Object var0, Object var1) {
      try {
         String var2 = var0 == null ? "" : var0.getClass().getName();
         Object var3 = call(var1, "getItemInHand");
         if (var2.endsWith("BaseListener")) {
            return testField(var0, "itemFactory", "isBaseBlock", var3);
         }

         if (var2.endsWith("GeneratorListener")) {
            return testField(var0, "generatorManager", "isGeneratorItem", var3);
         }

         if (var2.endsWith("DefenseListener")) {
            return testField(var0, "itemFactory", "isDefenseBlock", var3);
         }

         if (var2.endsWith("TurretListener")) {
            return testField(var0, "itemFactory", "isTurret", var3);
         }

         if (var2.endsWith("BeaconListener")) {
            return testField(var0, "itemFactory", "isRespawnBeacon", var3);
         }

         if (var2.endsWith("DefenseAccessListener")) {
            return testField(var0, "itemFactory", "isDefenseDoor", var3) || testField(var0, "itemFactory", "isDefenseTrapdoor", var3);
         }

         if (var2.endsWith("StructureToolGuardListener")) {
            Object var4 = resolvePlugin(var0, 0, Collections.newSetFromMap(new IdentityHashMap<>()));
            if (var4 == null) {
               return false;
            }

            Object var5 = call(var4, "getItemFactory");
            if (!bool(call(var5, "isRespawnBeacon", var3))
               && !bool(call(var5, "isBaseBlock", var3))
               && !bool(call(var5, "isDefenseBlock", var3))
               && !bool(call(var5, "isTurret", var3))
               && !bool(call(var5, "isDefenseDoor", var3))
               && !bool(call(var5, "isDefenseTrapdoor", var3))) {
               Object var6 = tryCall(var4, "getGeneratorManager");
               return var6 != null && bool(call(var6, "isGeneratorItem", var3));
            }

            return true;
         }
      } catch (Throwable var7) {
      }

      return false;
   }

   private static boolean testField(Object var0, String var1, String var2, Object var3) throws Exception {
      Object var4 = readField(var0, var1);
      return var4 != null && bool(call(var4, var2, var3));
   }

   private static boolean bool(Object var0) {
      return Boolean.TRUE.equals(var0);
   }

   private static void addIfCityMaterial(List<StructureSupportGuard.Snapshot> var0, Object var1) {
      try {
         if (var1 == null) {
            return;
         }

         String var2 = String.valueOf(call(var1, "getType"));
         if (!"GRAY_WOOL".equals(var2) && !"LIGHT_GRAY_CONCRETE".equals(var2)) {
            return;
         }

         for (StructureSupportGuard.Snapshot var4 : var0) {
            if (sameBlock(var4.block, var1)) {
               return;
            }
         }

         var0.add(new StructureSupportGuard.Snapshot(var1, call(var1, "getType"), tryCall(var1, "getBlockData")));
      } catch (Throwable var5) {
      }
   }

   private static Object relativeDown(Object var0) {
      try {
         Class var1 = Class.forName("org.bukkit.block.BlockFace");
         Object var2 = var1.getField("DOWN").get(null);
         return call(var0, "getRelative", var2);
      } catch (Throwable var3) {
         return null;
      }
   }

   private static boolean sameBlock(Object var0, Object var1) {
      try {
         return key(var0).equals(key(var1));
      } catch (Throwable var3) {
         return var0 == var1;
      }
   }

   private static String key(Object var0) throws Exception {
      return call(call(var0, "getWorld"), "getName") + ":" + call(var0, "getX") + ":" + call(var0, "getY") + ":" + call(var0, "getZ");
   }

   private static void restoreNow(StructureSupportGuard.Snapshot var0) {
      try {
         Object var1 = call(var0.block, "getType");
         if (String.valueOf(var1).equals(String.valueOf(var0.type))) {
            return;
         }

         if (var0.data != null && invokeVoid(var0.block, "setBlockData", var0.data, Boolean.FALSE)) {
            return;
         }

         if (invokeVoid(var0.block, "setType", var0.type, Boolean.FALSE)) {
            return;
         }

         invokeVoid(var0.block, "setType", var0.type);
      } catch (Throwable var2) {
      }
   }

   private static void schedule(Object var0, StructureSupportGuard.Snapshot var1, long var2) {
      if (var0 != null) {
         try {
            Object var4 = call(var0, "getServer");
            Object var5 = call(var4, "getScheduler");
            Runnable var6 = () -> restoreNow(var1);
            call(var5, "runTaskLater", var0, var6, var2);
         } catch (Throwable var7) {
         }
      }
   }

   private static Object resolvePlugin(Object var0, int var1, Set<Object> var2) {
      if (var0 != null && var1 <= 3 && !var2.contains(var0)) {
         var2.add(var0);

         try {
            if (hasMethod(var0.getClass(), "getServer", 0) && hasMethod(var0.getClass(), "getLogger", 0)) {
               return var0;
            }
         } catch (Throwable var10) {
         }

         for (String var6 : new String[]{
            "plugin", "generatorManager", "baseManager", "defenseManager", "turretManager", "beaconManager", "manager", "itemFactory"
         }) {
            try {
               Object var7 = readField(var0, var6);
               Object var8 = resolvePlugin(var7, var1 + 1, var2);
               if (var8 != null) {
                  return var8;
               }
            } catch (Throwable var9) {
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static Object readField(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }

   private static boolean hasMethod(Class<?> var0, String var1, int var2) {
      for (Method var6 : var0.getMethods()) {
         if (var6.getName().equals(var1) && var6.getParameterCount() == var2) {
            return true;
         }
      }

      return false;
   }

   private static boolean invokeVoid(Object var0, String var1, Object... var2) {
      try {
         call(var0, var1, var2);
         return true;
      } catch (Throwable var4) {
         return false;
      }
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         return null;
      }

      Method var3 = find(var0.getClass(), var1, var2);
      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) throws NoSuchMethodException {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && fits(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && fits(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      throw new NoSuchMethodException(var0.getName() + "." + var1);
   }

   private static boolean fits(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isInstance(var1[var2])) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private record Snapshot(Object block, Object type, Object data) {
   }
}
