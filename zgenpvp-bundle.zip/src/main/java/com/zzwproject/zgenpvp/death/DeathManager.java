package com.zzwproject.zgenpvp.death;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.level.LevelManager;
import com.zzwproject.zgenpvp.level.XpRewardManager;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.title.Title.Times;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class DeathManager {
   private final ZGenPvP plugin;
   private final EconomyManager economyManager;
   private final LevelManager levelManager;
   private final XpRewardManager xpRewardManager;
   private final Map<UUID, DeathManager.DeathSession> sessions = new HashMap<>();

   public DeathManager(ZGenPvP plugin, EconomyManager economyManager, LevelManager levelManager, XpRewardManager xpRewardManager) {
      this.plugin = plugin;
      this.economyManager = economyManager;
      this.levelManager = levelManager;
      this.xpRewardManager = xpRewardManager;
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getDeath().getBoolean("enabled", true);
   }

   public void handleDeath(Player victim, Player killer) {
      if (this.isEnabled() && victim != null) {
         this.cleanupSession(victim.getUniqueId());
         DeathManager.DeathSession session = new DeathManager.DeathSession(victim.getLocation().clone());
         this.sessions.put(victim.getUniqueId(), session);
         this.applyXpLoss(victim);
         if (killer != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
            boolean teammates = this.areTeammates(killer, victim);
            if (!teammates) {
               this.stealMoney(victim, killer);
               this.xpRewardManager.rewardPlayerKill(killer, victim);
            }
         }

         if (this.plugin.getConfigManager().getDeath().getBoolean("auto-respawn", true)) {
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
               if (victim.isOnline() && victim.isDead()) {
                  victim.spigot().respawn();
               }
            });
         }
      }
   }

   private boolean areTeammates(Player first, Player second) {
      if (first == null || second == null) {
         return false;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().areTeammates(first.getUniqueId(), second.getUniqueId());
      }
   }

   private void applyXpLoss(Player victim) {
      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      if (config.getBoolean("xp-loss.enabled", true)) {
         double percentage = Math.max(0.0, Math.min(100.0, config.getDouble("xp-loss.percentage", 10.0)));
         double lost = this.levelManager.removeCurrentXpPercent(victim.getUniqueId(), percentage);
         this.levelManager.syncHud(victim);
         if (!(lost <= 0.0)) {
            String message = config.getString("messages.xp-lost", "%prefix%&cOldugun için &f%xp% XP &ckaybettin.");
            this.sendMessage(victim, this.replace(message, "%xp%", this.formatNumber(lost)));
         }
      }
   }

   private void stealMoney(Player victim, Player killer) {
      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      if (config.getBoolean("money-steal.enabled", true)) {
         double percentage = Math.max(0.0, Math.min(100.0, config.getDouble("money-steal.percentage", 25.0)));
         if (!(percentage <= 0.0)) {
            double victimBalance = this.economyManager.getBalance(victim);
            if (!(victimBalance <= 0.0)) {
               double amount = victimBalance * (percentage / 100.0);
               int decimals = Math.max(0, config.getInt("money-steal.decimals", 2));
               amount = this.roundDown(amount, decimals);
               double minimum = Math.max(0.0, config.getDouble("money-steal.minimum-amount", 0.0));
               double maximum = config.getDouble("money-steal.maximum-amount", -1.0);
               if (minimum > 0.0 && amount < minimum) {
                  amount = Math.min(victimBalance, minimum);
               }

               if (maximum >= 0.0) {
                  amount = Math.min(amount, maximum);
               }

               amount = Math.min(victimBalance, amount);
               if (!(amount <= 0.0)) {
                  if (!this.economyManager.withdraw(victim, amount)) {
                     this.sendMoneyError(victim);
                  } else if (!this.economyManager.deposit(killer, amount)) {
                     this.economyManager.deposit(victim, amount);
                     this.sendMoneyError(victim);
                  } else {
                     String formattedAmount = this.formatNumber(amount);
                     String killerActionBar = config.getString("messages.killer-actionbar", "&a⚔ &f%victim% &7Oyuncusundan &a$%amount% &7caldın!");
                     killer.sendActionBar(this.component(this.replace(killerActionBar, "%victim%", victim.getName(), "%amount%", formattedAmount)));
                     String victimActionBar = config.getString("messages.victim-actionbar", "&c⚔ &f%killer% &7Senden &c$%amount% &7caldi!");
                     DeathManager.DeathSession session = this.sessions.get(victim.getUniqueId());
                     if (session != null) {
                        session.setVictimActionBar(this.replace(victimActionBar, "%killer%", killer.getName(), "%amount%", formattedAmount));
                     }
                  }
               }
            }
         }
      }
   }

   public void startSpectatorCountdown(final Player player) {
      if (player != null) {
         DeathManager.DeathSession session = this.sessions.get(player.getUniqueId());
         if (session != null) {
            FileConfiguration config = this.plugin.getConfigManager().getDeath();
            if (!config.getBoolean("spectator.enabled", true)) {
               this.finishRespawn(player, true);
            } else {
               player.setGameMode(GameMode.SPECTATOR);
               player.setSpectatorTarget(null);
               Location deathLocation = session.getDeathLocation();
               if (deathLocation != null && deathLocation.getWorld() != null) {
                  player.teleport(deathLocation, TeleportCause.PLUGIN);
               }

               session.setFreezeLocation(player.getLocation().clone());
               if (session.getVictimActionBar() != null) {
                  player.sendActionBar(this.component(session.getVictimActionBar()));
               }

               final int countdown = Math.max(1, config.getInt("spectator.countdown-seconds", 5));
               BukkitTask task = (new BukkitRunnable() {
                  private int seconds = countdown;

                  public void run() {
                     if (!player.isOnline()) {
                        DeathManager.this.cleanupSession(player.getUniqueId());
                        this.cancel();
                     } else if (this.seconds <= 0) {
                        this.cancel();
                        DeathManager.this.finishRespawn(player, true);
                     } else {
                        DeathManager.this.showCountdown(player, this.seconds);
                        DeathManager.this.playConfiguredSound(player, "sounds.countdown", "BLOCK_NOTE_BLOCK_HAT");
                        this.seconds--;
                     }
                  }
               }).runTaskTimer(this.plugin, 0L, 20L);
               session.setTask(task);
            }
         }
      }
   }

   private void showCountdown(Player player, int seconds) {
      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      String title = config.getString("titles.countdown.title", "&cOldun");
      String subtitle = config.getString("titles.countdown.subtitle", "&f%seconds% &7Saniye sonra yeniden dogacaksin");
      player.showTitle(
         Title.title(
            this.component(title),
            this.component(this.replace(subtitle, "%seconds%", String.valueOf(seconds))),
            Times.times(Duration.ZERO, Duration.ofMillis(1100L), Duration.ofMillis(100L))
         )
      );
   }

   public void finishRespawn(Player player, boolean effects) {
      if (player != null) {
         DeathManager.DeathSession session = this.sessions.remove(player.getUniqueId());
         if (session != null) {
            if (session.getTask() != null) {
               session.getTask().cancel();
            }

            player.setSpectatorTarget(null);
            player.setGameMode(this.getFinalGameMode());
            Location spawn = this.resolveSpawnLocation(player);
            if (spawn != null && spawn.getWorld() != null) {
               player.teleport(spawn, TeleportCause.PLUGIN);
            }

            player.setFallDistance(0.0F);
            if (effects) {
               this.showRespawnTitle(player);
               this.playConfiguredSound(player, "sounds.respawned", "ENTITY_PLAYER_LEVELUP");
            }
         }
      }
   }

   private Location resolveSpawnLocation(Player player) {
      if (this.plugin.getBeaconManager() != null && this.plugin.getBeaconManager().isEnabled()) {
         Location selected = this.plugin.getBeaconManager().resolveSelectedDeathSpawn(player);
         if (selected != null && selected.getWorld() != null) {
            return selected;
         }
      }

      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      Location spawn = player.getWorld().getSpawnLocation().clone();
      spawn.add(
         config.getDouble("respawn.spawn-offset.x", 0.5), config.getDouble("respawn.spawn-offset.y", 0.0), config.getDouble("respawn.spawn-offset.z", 0.5)
      );
      return spawn;
   }

   public boolean isFrozen(UUID uuid) {
      DeathManager.DeathSession session = this.sessions.get(uuid);
      return session != null && session.getFreezeLocation() != null
         ? this.plugin.getConfigManager().getDeath().getBoolean("spectator.freeze-movement", true)
         : false;
   }

   public Location getFreezeLocation(UUID uuid) {
      DeathManager.DeathSession session = this.sessions.get(uuid);
      return session != null && session.getFreezeLocation() != null ? session.getFreezeLocation().clone() : null;
   }

   public boolean isInDeathSession(UUID uuid) {
      return this.sessions.containsKey(uuid);
   }

   public void handleQuit(Player player) {
      if (player != null) {
         DeathManager.DeathSession session = this.sessions.remove(player.getUniqueId());
         if (session != null) {
            if (session.getTask() != null) {
               session.getTask().cancel();
            }

            if (!player.isDead()) {
               player.setSpectatorTarget(null);
               player.setGameMode(this.getFinalGameMode());
            }
         }
      }
   }

   public void shutdown() {
      UUID[] uuids = this.sessions.keySet().toArray(UUID[]::new);

      for (UUID uuid : uuids) {
         Player player = this.plugin.getServer().getPlayer(uuid);
         if (player != null && player.isOnline()) {
            this.handleQuit(player);
         } else {
            this.cleanupSession(uuid);
         }
      }

      this.sessions.clear();
   }

   private void cleanupSession(UUID uuid) {
      DeathManager.DeathSession session = this.sessions.remove(uuid);
      if (session != null && session.getTask() != null) {
         session.getTask().cancel();
      }
   }

   private void showRespawnTitle(Player player) {
      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      player.showTitle(
         Title.title(
            this.component(config.getString("titles.respawned.title", "&aYeniden dogdun")),
            this.component(config.getString("titles.respawned.subtitle", "&7Spawn'a gonderildin")),
            Times.times(Duration.ofMillis(100L), Duration.ofMillis(1200L), Duration.ofMillis(300L))
         )
      );
   }

   private void playConfiguredSound(Player player, String path, String fallback) {
      FileConfiguration config = this.plugin.getConfigManager().getDeath();
      String sound = config.getString(path + ".sound", fallback);
      float volume = (float)config.getDouble(path + ".volume", 1.0);
      float pitch = (float)config.getDouble(path + ".pitch", 1.0);
      player.playSound(player.getLocation(), this.normalizeSound(sound), volume, pitch);
   }

   private String normalizeSound(String sound) {
      if (sound != null && !sound.isBlank()) {
         String value = sound.trim().toLowerCase();
         return value.contains(":") ? value : value.replace('_', '.');
      } else {
         return "entity.player.levelup";
      }
   }

   private GameMode getFinalGameMode() {
      String configured = this.plugin.getConfigManager().getDeath().getString("spectator.final-gamemode", "SURVIVAL");
      if (configured != null) {
         try {
            return GameMode.valueOf(configured.toUpperCase());
         } catch (IllegalArgumentException var3) {
         }
      }

      return GameMode.SURVIVAL;
   }

   private void sendMoneyError(Player player) {
      String message = this.plugin.getConfigManager().getDeath().getString("messages.money-error", "%prefix%&cOlum para islemi sırasında hata olustu.");
      this.sendMessage(player, message);
   }

   private void sendMessage(Player var1, String var2) {
      if (var2 != null && !var2.isBlank()) {
         String var3 = this.plugin.getConfigManager().getMessages().getString("prefix", "&#FF8A00GenPvP &8» &r");
         if (var3 == null) {
            var3 = "";
         }

         var2 = var2.replace("%prefix%", var3).replace("%Prefix%", var3);
         var1.sendMessage(this.component(var2));
      }
   }

   private Component component(String text) {
      return LegacyComponentSerializer.legacySection().deserialize(ColorUtil.color(text == null ? "" : text));
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private double roundDown(double amount, int decimals) {
      double multiplier = Math.pow(10.0, Math.max(0, decimals));
      return Math.floor(amount * multiplier + 1.0E-7) / multiplier;
   }

   private String formatNumber(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }

   private static final class DeathSession {
      private final Location deathLocation;
      private Location freezeLocation;
      private BukkitTask task;
      private String victimActionBar;

      private DeathSession(Location deathLocation) {
         this.deathLocation = deathLocation;
      }

      public Location getDeathLocation() {
         return this.deathLocation;
      }

      public Location getFreezeLocation() {
         return this.freezeLocation;
      }

      public void setFreezeLocation(Location freezeLocation) {
         this.freezeLocation = freezeLocation;
      }

      public BukkitTask getTask() {
         return this.task;
      }

      public void setTask(BukkitTask task) {
         this.task = task;
      }

      public String getVictimActionBar() {
         return this.victimActionBar;
      }

      public void setVictimActionBar(String victimActionBar) {
         this.victimActionBar = victimActionBar;
      }
   }
}
