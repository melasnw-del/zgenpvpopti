package com.zzwproject.zgenpvp.v2;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class EnergySupport {
   private EnergySupport() {
   }

   private static Object call(Object var0, String var1, Class<?>[] var2, Object... var3) throws Exception {
      Method var4 = var0.getClass().getMethod(var1, var2);
      return var4.invoke(var0, var3);
   }

   private static Object call0(Object var0, String var1) throws Exception {
      return call(var0, var1, new Class[0]);
   }

   public static boolean isPowered(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            if (call0(var1, "getOwnerUuid") instanceof UUID var3) {
               Object var4 = call0(var0, "getBaseRepository");
               if (call(var4, "findByOwner", new Class[]{UUID.class}, var3) instanceof Optional var6 && !var6.isEmpty()) {
                  Object var7 = var6.get();

                  try {
                     Object var8 = call0(var1, "getBaseId");
                     Object var9 = call0(var7, "getId");
                     if (var8 instanceof Number var10 && var9 instanceof Number var11 && var10.longValue() > 0L && var10.longValue() != var11.longValue()) {
                        return true;
                     }
                  } catch (ReflectiveOperationException var14) {
                  }

                  Object var16 = call0(var0, "getBaseEnergyManager");
                  if (var16 == null) {
                     return true;
                  }

                  Method var17 = null;

                  for (Method var13 : var16.getClass().getMethods()) {
                     if (var13.getName().equals("isPowered") && var13.getParameterCount() == 1) {
                        var17 = var13;
                        break;
                     }
                  }

                  return var17 == null ? true : !(var17.invoke(var16, var7) instanceof Boolean var21 && !var21);
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } catch (Throwable var15) {
            return true;
         }
      } else {
         return true;
      }
   }

   public static double generatorConsumption(Object var0, long var1) {
      if (var0 != null && var1 > 0L) {
         try {
            Object var3 = call0(var0, "getBaseRepository");
            if (!(call0(var3, "findAll") instanceof List var5)) {
               return 0.0;
            } else {
               UUID var6 = null;

               for (Object var8 : var5) {
                  if (call0(var8, "getId") instanceof Number var10 && var10.longValue() == var1) {
                     if (call0(var8, "getOwnerUuid") instanceof UUID var12) {
                        var6 = var12;
                     }
                     break;
                  }
               }

               if (var6 == null) {
                  return 0.0;
               }

               Object var18 = call0(var0, "getGeneratorManager");
               int var20 = call(var18, "countGenerators", new Class[]{UUID.class}, var6) instanceof Number var21 ? Math.max(0, var21.intValue()) : 0;
               Object var22 = call0(var0, "getConfigManager");
               Object var23 = call0(var22, "getConfig");
               Method var24 = var23.getClass().getMethod("getDouble", String.class, double.class);
               double var14 = var24.invoke(var23, "base.energy.consumption.generator", 0.2) instanceof Number var16 ? Math.max(0.0, var16.doubleValue()) : 0.2;
               return var20 * var14;
            }
         } catch (Throwable var17) {
            return 0.0;
         }
      } else {
         return 0.0;
      }
   }
}
