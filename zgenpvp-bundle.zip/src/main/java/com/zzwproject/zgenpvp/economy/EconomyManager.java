package com.zzwproject.zgenpvp.economy;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.ZGenPvP;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class EconomyManager {
   private final ZGenPvP plugin;
   private Economy economy;

   public EconomyManager(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   public boolean setup() {
      if ((Plugin)BundleResolver.getPlugin(this.plugin.getServer().getPluginManager(), "Vault") == null) {
         return false;
      }

      RegisteredServiceProvider<Economy> provider = this.plugin.getServer().getServicesManager().getRegistration(Economy.class);
      if (provider == null) {
         return false;
      }

      this.economy = (Economy)provider.getProvider();
      return this.economy != null;
   }

   public boolean isAvailable() {
      return this.economy != null;
   }

   public String getProviderName() {
      return !this.isAvailable() ? "Bulunamadı" : this.economy.getName();
   }

   public double getBalance(OfflinePlayer player) {
      return this.isAvailable() && player != null ? Math.max(0.0, this.economy.getBalance(player)) : 0.0;
   }

   public double getBalance(Player player) {
      return this.getBalance(player);
   }

   public boolean has(OfflinePlayer player, double amount) {
      return this.isAvailable() && player != null && !(amount < 0.0) ? this.economy.has(player, amount) : false;
   }

   public boolean has(Player player, double amount) {
      return this.has((OfflinePlayer)player, amount);
   }

   public boolean withdraw(OfflinePlayer player, double amount) {
      if (this.isAvailable() && player != null && !(amount <= 0.0)) {
         EconomyResponse response = this.economy.withdrawPlayer(player, amount);
         return response != null && response.transactionSuccess();
      } else {
         return false;
      }
   }

   public boolean withdraw(Player player, double amount) {
      return this.withdraw((OfflinePlayer)player, amount);
   }

   public boolean deposit(OfflinePlayer player, double amount) {
      if (this.isAvailable() && player != null && !(amount <= 0.0)) {
         EconomyResponse response = this.economy.depositPlayer(player, amount);
         return response != null && response.transactionSuccess();
      } else {
         return false;
      }
   }

   public boolean deposit(Player player, double amount) {
      return this.deposit((OfflinePlayer)player, amount);
   }

   public String format(double amount) {
      return !this.isAvailable() ? String.format("%.2f", amount) : this.economy.format(amount);
   }
}
