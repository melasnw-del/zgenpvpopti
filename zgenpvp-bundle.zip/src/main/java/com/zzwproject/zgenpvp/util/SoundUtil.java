package com.zzwproject.zgenpvp.util;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.util.Locale;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private final ZGenPvP plugin;

   public SoundUtil(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   public void play(Player player, String path) {
      if (player != null) {
         this.play(player.getLocation(), path);
      }
   }

   public void play(Location location, String path) {
      if (location != null && location.getWorld() != null) {
         FileConfiguration config = this.plugin.getConfigManager().getSounds();
         if (config.getBoolean("enabled", true)) {
            if (config.getBoolean(path + ".enabled", true)) {
               String soundName = config.getString(path + ".sound");
               if (soundName != null && !soundName.isBlank()) {
                  float volume = (float)config.getDouble(path + ".volume", 1.0);
                  float pitch = (float)config.getDouble(path + ".pitch", 1.0);

                  try {
                     Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
                     location.getWorld().playSound(location, sound, volume, pitch);
                  } catch (IllegalArgumentException exception) {
                     this.plugin.getLogger().warning("Geçersiz ses: " + soundName + " (" + path + ")");
                  }
               }
            }
         }
      }
   }
}
