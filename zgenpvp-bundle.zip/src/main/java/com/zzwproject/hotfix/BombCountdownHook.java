package com.zzwproject.hotfix;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

public final class BombCountdownHook {
   private static final Map<Object, Object> DISPLAYS = Collections.synchronizedMap(new WeakHashMap<>());

   private BombCountdownHook() {
   }

   public static void tick(Object var0, Object var1, int var2) {
      if (var1 != null) {
         try {
            if (var2 <= 0) {
               remove(var1);
               return;
            }

            Object var3 = DISPLAYS.get(var1);
            if (var3 == null || !isValid(var3)) {
               Object var4 = call0(var1, "location");
               if (var4 == null) {
                  return;
               }

               Object var5 = var4.getClass().getMethod("clone").invoke(var4);
               var5.getClass().getMethod("add", double.class, double.class, double.class).invoke(var5, 0.5, 1.65, 0.5);
               Object var6 = var5.getClass().getMethod("getWorld").invoke(var5);
               if (var6 == null) {
                  return;
               }

               Class var7 = Class.forName("org.bukkit.entity.EntityType");
               Enum var8 = Enum.valueOf(var7.asSubclass(Enum.class), "TEXT_DISPLAY");
               Method var9 = null;

               for (Method var13 : var6.getClass().getMethods()) {
                  if (var13.getName().equals("spawnEntity")
                     && var13.getParameterCount() == 2
                     && var13.getParameterTypes()[1].getName().equals("org.bukkit.entity.EntityType")) {
                     var9 = var13;
                     break;
                  }
               }

               if (var9 == null) {
                  return;
               }

               var3 = var9.invoke(var6, var5, var8);

               try {
                  var3.getClass().getMethod("setPersistent", boolean.class).invoke(var3, false);
               } catch (Throwable var17) {
               }

               try {
                  var3.getClass().getMethod("setShadowed", boolean.class).invoke(var3, true);
               } catch (Throwable var16) {
               }

               try {
                  var3.getClass().getMethod("setSeeThrough", boolean.class).invoke(var3, true);
               } catch (Throwable var15) {
               }

               try {
                  Class var19 = Class.forName("org.bukkit.entity.Display$Billboard");
                  Enum var20 = Enum.valueOf(var19.asSubclass(Enum.class), "CENTER");
                  var3.getClass().getMethod("setBillboard", var19).invoke(var3, var20);
               } catch (Throwable var14) {
               }

               DISPLAYS.put(var1, var3);
            }

            setText(var3, "§c✦ §f" + var2 + " §7saniye");
            playTickSound(var1, var2);
         } catch (Throwable var18) {
         }
      }
   }

   private static Object call0(Object var0, String var1) throws Exception {
      Method var2 = var0.getClass().getDeclaredMethod(var1);
      var2.setAccessible(true);
      return var2.invoke(var0);
   }

   private static boolean isValid(Object var0) {
      try {
         return Boolean.TRUE.equals(var0.getClass().getMethod("isValid").invoke(var0));
      } catch (Throwable var2) {
         return false;
      }
   }

   private static void setText(Object var0, String var1) {
      try {
         var0.getClass().getMethod("setText", String.class).invoke(var0, var1);
      } catch (Throwable var5) {
         try {
            Class var2 = Class.forName("net.kyori.adventure.text.Component");
            Object var3 = var2.getMethod("text", String.class).invoke(null, var1.replace('§', '&'));
            var0.getClass().getMethod("text", var2).invoke(var0, var3);
         } catch (Throwable var4) {
         }
      }
   }

   private static void remove(Object var0) {
      Object var1 = DISPLAYS.remove(var0);
      if (var1 != null) {
         try {
            var1.getClass().getMethod("remove").invoke(var1);
         } catch (Throwable var3) {
         }
      }
   }

   private static void playTickSound(Object var0, int var1) {
      try {
         Object var2 = call0(var0, "location");
         Object var3 = var2.getClass().getMethod("getWorld").invoke(var2);
         if (var3 == null) {
            return;
         }

         String var4 = var1 <= 2 ? "minecraft:block.note_block.pling" : "minecraft:block.note_block.hat";
         float var5 = var1 <= 2 ? 1.4F : 1.0F + (5 - var1) * 0.08F;

         for (Method var9 : var3.getClass().getMethods()) {
            if (var9.getName().equals("playSound") && var9.getParameterCount() == 4) {
               Class[] var10 = var9.getParameterTypes();
               if (var10[1] == String.class && var10[2] == float.class && var10[3] == float.class) {
                  var9.invoke(var3, var2, var4, 0.8F, var5);
                  break;
               }
            }
         }
      } catch (Throwable var11) {
      }
   }
}
