package com.zzwproject.zgenpvp.money;

import com.zzwproject.hotfix.MoneyItemsAdderHook;
import com.zzwproject.zgenpvp.ZGenPvP;
import java.text.DecimalFormat;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public final class MoneyItemManager {
   private final ZGenPvP plugin;
   private final NamespacedKey moneyItemKey;
   private final NamespacedKey moneyValueKey;
   private Material material;
   private String nameTemplate;
   private List<String> loreTemplates;
   private int customModelData;

   public MoneyItemManager(ZGenPvP var1) {
      this.plugin = var1;
      this.moneyItemKey = new NamespacedKey(var1, "money_item");
      this.moneyValueKey = new NamespacedKey(var1, "money_value");
      this.reload();
   }

   public void reload() {
      FileConfiguration var1 = this.plugin.getConfigManager().getItems();
      String var2 = var1.getString("money.material", "PAPER");
      Material var3 = Material.matchMaterial(var2 == null ? "PAPER" : var2);
      this.material = var3 == null ? Material.PAPER : var3;
      this.nameTemplate = var1.getString("money.name", "&a✦ Banknot &8| &a$%amount%");
      if (this.nameTemplate == null) {
         this.nameTemplate = "&a✦ Banknot &8| &a$%amount%";
      }

      this.loreTemplates = List.copyOf(var1.getStringList("money.lore"));
      this.customModelData = Math.max(0, var1.getInt("money.custom-model-data", 0));
   }

   public ItemStack createMoney(double var1) {
      return (ItemStack)MoneyItemsAdderHook.createMoney(this, var1);
   }

   public boolean isMoneyItem(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         Byte var2 = (Byte)var1.getItemMeta().getPersistentDataContainer().get(this.moneyItemKey, PersistentDataType.BYTE);
         return var2 != null && var2 == 1;
      } else {
         return false;
      }
   }

   public double getMoneyValue(ItemStack var1) {
      if (!this.isMoneyItem(var1)) {
         return 0.0;
      }

      Double var2 = (Double)var1.getItemMeta().getPersistentDataContainer().get(this.moneyValueKey, PersistentDataType.DOUBLE);
      return var2 == null ? 0.0 : Math.max(0.0, var2);
   }

   public double getStackValue(ItemStack var1) {
      return !this.isMoneyItem(var1) ? 0.0 : this.getMoneyValue(var1) * var1.getAmount();
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }
}
