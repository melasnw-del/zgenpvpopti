package com.zzwproject.zgenpvp.model;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class GeneratorData {
   private final long id;
   private final long baseId;
   private final UUID ownerUuid;
   private final String worldName;
   private final int x;
   private final int y;
   private final int z;
   private int level;
   private double storedMoney;
   private int storedShards;
   private long lastMoneyGeneration;
   private long lastShardGeneration;
   private String linkedWorld;
   private Integer linkedX;
   private Integer linkedY;
   private Integer linkedZ;

   public GeneratorData(
      long id,
      long baseId,
      UUID ownerUuid,
      String worldName,
      int x,
      int y,
      int z,
      int level,
      double storedMoney,
      int storedShards,
      long lastMoneyGeneration,
      long lastShardGeneration,
      String linkedWorld,
      Integer linkedX,
      Integer linkedY,
      Integer linkedZ
   ) {
      this.id = id;
      this.baseId = baseId;
      this.ownerUuid = ownerUuid;
      this.worldName = worldName;
      this.x = x;
      this.y = y;
      this.z = z;
      this.level = level;
      this.storedMoney = storedMoney;
      this.storedShards = storedShards;
      this.lastMoneyGeneration = lastMoneyGeneration;
      this.lastShardGeneration = lastShardGeneration;
      this.linkedWorld = linkedWorld;
      this.linkedX = linkedX;
      this.linkedY = linkedY;
      this.linkedZ = linkedZ;
   }

   public long getId() {
      return this.id;
   }

   public long getBaseId() {
      return this.baseId;
   }

   public UUID getOwnerUuid() {
      return this.ownerUuid;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public int getLevel() {
      return this.level;
   }

   public double getStoredMoney() {
      return this.storedMoney;
   }

   public int getStoredShards() {
      return this.storedShards;
   }

   public long getLastMoneyGeneration() {
      return this.lastMoneyGeneration;
   }

   public long getLastShardGeneration() {
      return this.lastShardGeneration;
   }

   public String getLinkedWorld() {
      return this.linkedWorld;
   }

   public Integer getLinkedX() {
      return this.linkedX;
   }

   public Integer getLinkedY() {
      return this.linkedY;
   }

   public Integer getLinkedZ() {
      return this.linkedZ;
   }

   public void setLevel(int level) {
      this.level = level;
   }

   public void setStoredMoney(double storedMoney) {
      this.storedMoney = Math.max(0.0, storedMoney);
   }

   public void setStoredShards(int storedShards) {
      this.storedShards = Math.max(0, storedShards);
   }

   public void setLastMoneyGeneration(long lastMoneyGeneration) {
      this.lastMoneyGeneration = lastMoneyGeneration;
   }

   public void setLastShardGeneration(long lastShardGeneration) {
      this.lastShardGeneration = lastShardGeneration;
   }

   public boolean hasLinkedChest() {
      return this.linkedWorld != null && !this.linkedWorld.isBlank() && this.linkedX != null && this.linkedY != null && this.linkedZ != null;
   }

   public Location getLinkedChestLocation() {
      if (!this.hasLinkedChest()) {
         return null;
      }

      World world = Bukkit.getWorld(this.linkedWorld);
      return world == null ? null : new Location(world, this.linkedX.intValue(), this.linkedY.intValue(), this.linkedZ.intValue());
   }

   public void setLinkedChest(Location location) {
      if (location != null && location.getWorld() != null) {
         this.linkedWorld = location.getWorld().getName();
         this.linkedX = location.getBlockX();
         this.linkedY = location.getBlockY();
         this.linkedZ = location.getBlockZ();
      } else {
         this.clearLinkedChest();
      }
   }

   public void clearLinkedChest() {
      this.linkedWorld = null;
      this.linkedX = null;
      this.linkedY = null;
      this.linkedZ = null;
   }

   public Location getLocation() {
      World world = Bukkit.getWorld(this.worldName);
      return world == null ? null : new Location(world, this.x, this.y, this.z);
   }
}
