package com.zzwproject.zmenu.util;

import com.zzwproject.zmenu.ZMenu;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private final ZMenu p;

   public SoundUtil(ZMenu var1) {
      this.p = var1;
   }

   public void play(Player var1, String var2) {
      if (var1 != null) {
         String var3 = this.p.sounds().getString(var2 + ".sound");
         if (var3 != null && !var3.isBlank()) {
            try {
               Sound var4 = Sound.valueOf(var3.toUpperCase());
               var1.playSound(
                  var1.getLocation(), var4, (float)this.p.sounds().getDouble(var2 + ".volume", 1.0), (float)this.p.sounds().getDouble(var2 + ".pitch", 1.0)
               );
            } catch (IllegalArgumentException var5) {
            }
         }
      }
   }
}
