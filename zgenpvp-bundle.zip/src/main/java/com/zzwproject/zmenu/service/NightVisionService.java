package com.zzwproject.zmenu.service;

import com.zzwproject.zmenu.ZMenu;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class NightVisionService {
   private final ZMenu plugin;
   private final File file;
   private final Set<UUID> enabled = new HashSet<>();

   public NightVisionService(ZMenu var1) {
      this.plugin = var1;
      this.file = new File(var1.getDataFolder(), "nightvision.yml");
   }

   public void load() {
      this.enabled.clear();
      if (this.file.exists()) {
         YamlConfiguration var1 = YamlConfiguration.loadConfiguration(this.file);

         for (String var3 : var1.getStringList("enabled")) {
            try {
               this.enabled.add(UUID.fromString(var3));
            } catch (IllegalArgumentException var5) {
            }
         }
      }
   }

   public void save() {
      YamlConfiguration var1 = new YamlConfiguration();
      var1.set("enabled", this.enabled.stream().map(UUID::toString).sorted().toList());

      try {
         var1.save(this.file);
      } catch (IOException var3) {
         this.plugin.getLogger().warning("nightvision.yml kaydedilemedi: " + var3.getMessage());
      }
   }

   public boolean isEnabled(Player var1) {
      return this.enabled.contains(var1.getUniqueId());
   }

   public boolean toggle(Player var1) {
      boolean var2;
      if (this.enabled.remove(var1.getUniqueId())) {
         this.disableEffect(var1);
         var2 = false;
      } else {
         this.enabled.add(var1.getUniqueId());
         this.apply(var1);
         var2 = true;
      }

      this.save();
      return var2;
   }

   public void reapply(Player var1) {
      if (this.isEnabled(var1)) {
         this.apply(var1);
      }
   }

   private void apply(Player var1) {
      boolean var2 = this.plugin.getConfig().getBoolean("night-vision.particles", false);
      boolean var3 = this.plugin.getConfig().getBoolean("night-vision.icon", true);
      var1.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, var2, var3), true);
   }

   private void disableEffect(Player var1) {
      var1.removePotionEffect(PotionEffectType.NIGHT_VISION);
   }
}
