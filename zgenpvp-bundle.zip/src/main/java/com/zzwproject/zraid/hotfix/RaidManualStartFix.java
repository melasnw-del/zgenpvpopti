package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.UUID;
import java.util.logging.Logger;

public final class RaidManualStartFix {
   private RaidManualStartFix() {
   }

   public static Object repairBase(Object var0, Object var1, Throwable var2) {
      if (var0 != null && var1 != null) {
         try {
            Object var36 = field(var0, "core");
            if (var36 == null) {
               return null;
            }

            Object var4 = call(var36, "getBeaconManager");
            if (var4 == null) {
               return null;
            }

            long var5 = ((Number)call(var1, "getBeaconId")).longValue();
            Object var7 = call(var4, "getBeacon", new Class[]{long.class}, var5);
            if (optionalPresent(var7)) {
               return null;
            }

            UUID var8 = (UUID)call(var1, "getOwnerUuid");
            if (call(var4, "getOwnedBeacons", new Class[]{UUID.class}, var8) instanceof Iterable var10) {
               String var11 = String.valueOf(call(var1, "getWorldName"));
               int var12 = ((Number)call(var1, "getX")).intValue();
               int var13 = ((Number)call(var1, "getY")).intValue();
               int var14 = ((Number)call(var1, "getZ")).intValue();
               Object var15 = null;
               double var16 = Double.MAX_VALUE;

               for (Object var19 : var10) {
                  if (var19 != null) {
                     String var20 = String.valueOf(call(var19, "getWorldName"));
                     if (Objects.equals(var11, var20)) {
                        int var21 = ((Number)call(var19, "getX")).intValue();
                        int var22 = ((Number)call(var19, "getY")).intValue();
                        int var23 = ((Number)call(var19, "getZ")).intValue();
                        double var24 = var21 - var12;
                        double var26 = var22 - var13;
                        double var28 = var23 - var14;
                        double var30 = var24 * var24 + var26 * var26 + var28 * var28;
                        if (var30 < var16) {
                           var16 = var30;
                           var15 = var19;
                        }
                     }
                  }
               }

               if (var15 == null) {
                  return null;
               }

               long var37 = ((Number)call(var15, "getId")).longValue();
               Class var38 = var1.getClass();
               Constructor var39 = var38.getConstructor(
                  long.class,
                  long.class,
                  UUID.class,
                  String.class,
                  String.class,
                  int.class,
                  int.class,
                  int.class,
                  int.class,
                  int.class,
                  int.class,
                  int.class,
                  int.class
               );
               Object var40 = var39.newInstance(
                  ((Number)call(var1, "getId")).longValue(),
                  var37,
                  var8,
                  (String)call(var1, "getName"),
                  var11,
                  var12,
                  var13,
                  var14,
                  ((Number)call(var1, "getLevel")).intValue(),
                  ((Number)call(var1, "getCurrentHp")).intValue(),
                  ((Number)call(var1, "getMaxHp")).intValue(),
                  ((Number)call(var1, "getRadius")).intValue(),
                  ((Number)call(var1, "getBlockLimit")).intValue()
               );

               try {
                  Object var41 = call(var36, "getDatabaseManager");
                  Object var42 = call(var41, "getConnection");
                  Object var25 = call(var42, "prepareStatement", new Class[]{String.class}, "UPDATE bases SET beacon_id=? WHERE id=?");
                  call(var25, "setLong", new Class[]{int.class, long.class}, 1, var37);
                  call(var25, "setLong", new Class[]{int.class, long.class}, 2, ((Number)call(var1, "getId")).longValue());
                  call(var25, "executeUpdate");

                  try {
                     call(var25, "close");
                  } catch (Throwable var33) {
                  }
               } catch (Throwable var34) {
               }

               logger(var0)
                  .warning(
                     "[Update53] Raid snapshot: stale beacon link repaired for base "
                        + call(var1, "getId")
                        + " -> beacon "
                        + var37
                        + ". Original: "
                        + shortError(var2)
                  );
               return var40;
            } else {
               return null;
            }
         } catch (Throwable var35) {
            Throwable var3 = var35;

            try {
               logger(var0).warning("[Update53] Raid snapshot auto-repair failed: " + shortError(var3));
            } catch (Throwable var32) {
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private static boolean optionalPresent(Object var0) throws Exception {
      if (var0 == null) {
         return false;
      }

      Method var1 = var0.getClass().getMethod("isPresent");
      return Boolean.TRUE.equals(var1.invoke(var0));
   }

   private static Logger logger(Object var0) throws Exception {
      Object var1 = call(var0, "getLogger");
      return (Logger)var1;
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }

   private static Object call(Object var0, String var1, Class<?>[] var2, Object... var3) throws Exception {
      Method var4 = var0.getClass().getMethod(var1, var2);
      var4.setAccessible(true);
      return var4.invoke(var0, var3);
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = null;

      for (Method var7 : var0.getClass().getMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
            var3 = var7;
            break;
         }
      }

      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static String shortError(Throwable var0) {
      if (var0 == null) {
         return "unknown";
      }

      String var1 = var0.getMessage();
      return var0.getClass().getSimpleName() + (var1 == null ? "" : ": " + var1);
   }
}
