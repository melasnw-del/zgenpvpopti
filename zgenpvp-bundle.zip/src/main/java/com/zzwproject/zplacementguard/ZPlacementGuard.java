package com.zzwproject.zplacementguard;

import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;

public final class ZPlacementGuard extends LegacyPluginBase implements Listener {
   private final Map<UUID, Long> messageCooldown = new ConcurrentHashMap<>();

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      this.getServer().getPluginManager().registerEvents(this, this);
      this.getLogger().info("ZPlacementGuard 1.1.0 aktif: gorus/mesafe + base ici defans yerlesim korumasi aktif.");
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      if (this.getConfig().getBoolean("enabled", true)) {
         Player var2 = var1.getPlayer();
         if (var2 != null) {
            ItemStack var3 = var1.getItemInHand();
            ZGenPvP var4 = ZGenPvP.getInstance();
            if (var4 != null && var4.getItemFactory() != null) {
               SpecialItemFactory var5 = var4.getItemFactory();
               boolean var6 = this.isProtectedGenPvPItem(var5, var4, var3);
               if (var6) {
                  if (var2.hasPermission("zgenpvp.placement.base-bypass")
                     || !this.isDefenseStructure(var5, var3)
                     || this.validateBasePlacement(var1, var2, var4)) {
                     if (!var2.hasPermission("zgenpvp.placement.bypass")) {
                        this.validateLineOfSight(var1, var2);
                     }
                  }
               }
            }
         }
      }
   }

   private boolean validateBasePlacement(BlockPlaceEvent var1, Player var2, ZGenPvP var3) {
      if (!this.getConfig().getBoolean("base-restriction.enabled", true)) {
         return true;
      }

      BaseRepository var4 = var3.getBaseRepository();
      if (var4 == null) {
         this.reject(var1, var2, "base-restriction.no-base-message", "&cDefans yapilari yerlestirmek icin once bir Base Block kurmalisin.");
         return false;
      }

      Optional var5;
      try {
         var5 = TeamPermissionBridge.findOwnOrTeamBase(var4, var2.getUniqueId());
      } catch (Throwable var9) {
         var5 = var4.findByOwner(var2.getUniqueId());
      }

      BaseData var6 = (BaseData)var5.orElse(null);
      if (var6 == null) {
         this.reject(var1, var2, "base-restriction.no-base-message", "&cDefans yapilari yerlestirmek icin once bir Base Block kurmalisin.");
         return false;
      }

      Block var7 = var1.getBlockPlaced();
      Location var8 = var7 == null ? null : var7.getLocation();
      if (var8 != null && this.isInsideBase(var6, var8)) {
         return true;
      }

      this.reject(var1, var2, "base-restriction.outside-message", "&cDefans yapilarini sadece kendi base alaninin icine yerlestirebilirsin.");
      return false;
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!var2.getWorld().getName().equals(var1.getWorldName())) {
            return false;
         }

         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = Math.max(0, var1.getRadius());
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   private void validateLineOfSight(BlockPlaceEvent var1, Player var2) {
      Block var3 = var1.getBlockPlaced();
      Block var4 = var1.getBlockAgainst();
      if (var3 == null) {
         this.reject(var1, var2, "message", "&cBu konuma dogrudan gorusun olmadigi icin yerlestiremezsin.");
      } else {
         Location var5 = var2.getEyeLocation();
         Location var6 = var3.getLocation().clone().add(0.5, 0.5, 0.5);
         double var7 = Math.max(3.0, this.getConfig().getDouble("max-distance", 5.75));
         if (var5 == null || var5.getWorld() == null || var6.getWorld() == null || var5.getWorld() != var6.getWorld()) {
            this.reject(var1, var2, "message", "&cBu konuma dogrudan gorusun olmadigi icin yerlestiremezsin.");
         } else if (var5.distanceSquared(var6) > var7 * var7) {
            this.reject(var1, var2, "message", "&cBu konuma dogrudan gorusun olmadigi icin yerlestiremezsin.");
         } else {
            World var9 = var2.getWorld();
            RayTraceResult var10 = var9.rayTraceBlocks(var5, var5.getDirection(), var7 + 0.35, FluidCollisionMode.NEVER, true);
            Block var11 = var10 == null ? null : var10.getHitBlock();
            if (var11 == null || !sameBlock(var11, var3) && !sameBlock(var11, var4)) {
               this.reject(var1, var2, "message", "&cBu konuma dogrudan gorusun olmadigi icin yerlestiremezsin.");
            }
         }
      }
   }

   private boolean isProtectedGenPvPItem(SpecialItemFactory var1, ZGenPvP var2, ItemStack var3) {
      if (var3 == null) {
         return false;
      }

      try {
         return !var1.isRespawnBeacon(var3)
               && !var1.isBaseBlock(var3)
               && !var1.isDefenseBlock(var3)
               && !var1.isTurret(var3)
               && !var1.isDefenseDoor(var3)
               && !var1.isDefenseTrapdoor(var3)
            ? var2.getGeneratorManager() != null && var2.getGeneratorManager().isGeneratorItem(var3)
            : true;
      } catch (Throwable var5) {
         return true;
      }
   }

   private boolean isDefenseStructure(SpecialItemFactory var1, ItemStack var2) {
      try {
         return var1.isDefenseBlock(var2) || var1.isTurret(var2) || var1.isDefenseDoor(var2) || var1.isDefenseTrapdoor(var2);
      } catch (Throwable var4) {
         return false;
      }
   }

   private static boolean sameBlock(Block var0, Block var1) {
      return var0 != null && var1 != null && var0.equals(var1);
   }

   private void reject(BlockPlaceEvent var1, Player var2, String var3, String var4) {
      var1.setCancelled(true);
      long var5 = System.currentTimeMillis();
      Long var7 = this.messageCooldown.put(var2.getUniqueId(), var5);
      if (var7 == null || var5 - var7 > 900L) {
         String var8 = this.getConfig().getString(var3, var4);
         if (var8 != null && !var8.isEmpty()) {
            var2.sendMessage(var8.replace('&', '§'));
         }
      }
   }
}
