package com.zzwproject.zraid;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.hotfix.RaidCompletionRules;
import com.zzwproject.zgenpvp.integration.ZTeamHook;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import com.zzwproject.zraid.hotfix.ConfigurableRaidRules;
import com.zzwproject.zraid.hotfix.RaidBombImmediateFix;
import com.zzwproject.zraid.hotfix.RaidConfigMigration;
import com.zzwproject.zraid.hotfix.RaidDamagePolicy;
import com.zzwproject.zraid.hotfix.RaidManualStartFix;
import com.zzwproject.zraid.hotfix.RaidObjectiveFix;
import com.zzwproject.zraid.hotfix.RaidSimpleRules;
import com.zzwproject.zraid.hotfix.ZRaidGeneratorResolver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public final class ZRaid extends LegacyPluginBase implements Listener {
   private ZGenPvP core;
   private final Map<Long, ZRaid.RaidSession> sessions = new ConcurrentHashMap<>();
   private final Map<UUID, Long> lastMessageAt = new ConcurrentHashMap<>();
   private final Map<String, Long> bountyPairCredit = new ConcurrentHashMap<>();
   private File recoveryDir;
   private File statsFile;
   private long tick;

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      RaidConfigMigration.apply(this);
      Plugin var1 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenPvP");
      if (var1 instanceof ZGenPvP var2 && var1.isEnabled()) {
         this.core = var2;
         this.recoveryDir = new File(this.getDataFolder(), "recovery");
         if (!this.recoveryDir.exists()) {
            this.recoveryDir.mkdirs();
         }

         this.statsFile = new File(this.getDataFolder(), "raid-stats.properties");
         this.loadStats();
         this.recoverAbandonedSnapshots();
         Bukkit.getPluginManager().registerEvents(this, this);
         Bukkit.getScheduler().runTaskTimer(this, this::tickSessions, 20L, 20L);
         this.getLogger().info("ZRaid 1.0.7 aktif. Oturum tabanlı raid sistemi hazır.");
      } else {
         this.getLogger().severe("ZGenPvP bulunamadı. ZRaid devre dışı bırakılıyor.");
         BundleResolver.disablePlugin(Bukkit.getPluginManager(), this);
      }
   }

   @Override
   public void onDisable() {
      for (ZRaid.RaidSession var2 : new ArrayList<>(this.sessions.values())) {
         try {
            this.failRaid(var2, "restart");
         } catch (Throwable var4) {
            this.getLogger().warning("Raid restore hatasi: " + var4.getMessage());
         }
      }

      this.sessions.clear();
      this.saveStats();
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      String var5 = var2.getName().toLowerCase(Locale.ROOT);
      if (var5.equals("raid")) {
         if (var1 instanceof Player var9) {
            ZRaid.RaidSession var11 = this.sessionForParticipant(var9.getUniqueId());
            if (var11 == null) {
               this.msg(var9, "Şu an aktif bir raid oturumun yok.", ChatColor.GRAY);
               return true;
            } else {
               this.sendStatus(var9, var11);
               return true;
            }
         } else {
            var1.sendMessage("Bu komut sadece oyuncular icindir.");
            return true;
         }
      } else {
         if (!var5.equals("zraid")) {
            return false;
         }

         if (!var1.hasPermission("zraid.admin")) {
            var1.sendMessage("Yetkin yok.");
            return true;
         }

         if (var4.length == 0 || var4[0].equalsIgnoreCase("status")) {
            var1.sendMessage("ZRaid: " + this.sessions.size() + " aktif raid.");

            for (ZRaid.RaidSession var10 : this.sessions.values()) {
               var1.sendMessage(
                  "- base="
                     + var10.snapshot.base.id
                     + " owner="
                     + this.nameOf(var10.snapshot.owner)
                     + " attacker="
                     + this.nameOf(var10.initiator)
                     + " left="
                     + this.formatTime(Math.max(0L, var10.endsAt - System.currentTimeMillis()))
               );
            }

            return true;
         } else {
            if (var4[0].equalsIgnoreCase("reload")) {
               this.reloadConfig();
               var1.sendMessage("ZRaid ayarlari yeniden yuklendi.");
               return true;
            }

            if (var4[0].equalsIgnoreCase("stop") && var4.length >= 2) {
               Player var6 = this.findOnline(var4[1]);
               if (var6 == null) {
                  var1.sendMessage("Oyuncu bulunamadı.");
                  return true;
               } else {
                  ZRaid.RaidSession var7 = this.sessionForParticipant(var6.getUniqueId());
                  if (var7 == null) {
                     var1.sendMessage("Bu oyuncunun aktif raid oturumu yok.");
                     return true;
                  } else {
                     this.failRaid(var7, "admin");
                     var1.sendMessage("Raid durduruldu ve yapılar restore edildi.");
                     return true;
                  }
               }
            } else {
               var1.sendMessage("/zraid status | reload | stop <oyuncu>");
               return true;
            }
         }
      }
   }

   public boolean handleRaidBombPlace(BlockPlaceEvent var1) {
      return RaidBombImmediateFix.handle(this, var1);
   }

   public boolean handleGeneratorBreak(BlockBreakEvent var1) {
      return RaidSimpleRules.handleGeneratorBreak(this, var1);
   }

   public boolean handleBeaconDamage(BlockDamageEvent var1) {
      return RaidObjectiveFix.handleBeacon(this, var1, false);
   }

   public boolean handleBeaconBreak(BlockBreakEvent var1) {
      return RaidObjectiveFix.handleBeacon(this, var1, true);
   }

   public boolean suppressStructureXp(Player var1, Object var2) {
      if (this.enabled() && var1 != null && var2 != null) {
         ZRaid.RaidSession var3 = this.sessionForRaider(var1.getUniqueId());
         if (var3 == null) {
            return false;
         }

         String var4 = String.valueOf(var2);
         return var4.equalsIgnoreCase("DEFENSE_DESTROY") || var4.equalsIgnoreCase("TURRET_DESTROY") || var4.equalsIgnoreCase("BASE_DESTROY");
      } else {
         return false;
      }
   }

   public boolean isUnderRaid(UUID var1) {
      if (var1 != null && this.enabled()) {
         for (ZRaid.RaidSession var3 : this.sessions.values()) {
            if (this.isDefender(var3.snapshot.owner, var1)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean canStartRaid(BaseData var1, Player var2) {
      if (var1 != null && var2 != null && this.enabled()) {
         if (this.sessions.get(var1.getId()) != null) {
            return true;
         }

         if (this.isDefender(var1.getOwnerUuid(), var2.getUniqueId())) {
            this.msg(var2, "Kendi veya takım üssüne raid başlatamazsın.", ChatColor.RED);
            return false;
         }

         if (this.cfgB("start.require-owner-online", true)) {
            Player var3 = Bukkit.getPlayer(var1.getOwnerUuid());
            if (var3 == null || !var3.isOnline()) {
               this.msg(var2, "Üs sahibi çevrim dışıyken raid başlatılamaz.", ChatColor.RED);
               return false;
            }
         }

         if (this.cfgB("limits.one-active-raid-per-attacker-team", true) && this.sessionForRaider(var2.getUniqueId()) != null) {
            this.msg(var2, "Zaten aktif bir raid oturumun var.", ChatColor.RED);
            return false;
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean suppressRaidProtection(long var1) {
      return this.enabled() && this.sessions.containsKey(var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      RaidDamagePolicy.handle(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      if (var1.getPlayer() != null) {
         StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onPlace(BlockPlaceEvent var1) {
   }

   public void onDeath(PlayerDeathEvent var1) {
      RaidObjectiveFix.handleDeath(this, var1);
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent var1) {
      UUID var2 = var1.getPlayer().getUniqueId();
      long var3 = System.currentTimeMillis();

      for (ZRaid.RaidSession var6 : this.sessions.values()) {
         if (var2.equals(var6.snapshot.owner)) {
            var6.ownerOfflineSince = var3;
         }

         if (this.isRaider(var6, var2) && !this.hasOnlineRaider(var6)) {
            var6.raidersOfflineSince = var3;
         }
      }
   }

   private ZRaid.RaidSession startRaid(BaseData var1, Player var2, String var3) {
      if (var1 != null && var2 != null && this.enabled()) {
         ZRaid.RaidSession var4 = this.sessions.get(var1.getId());
         if (var4 != null) {
            return var4;
         }

         if ("bomb".equals(var3) && !ConfigurableRaidRules.bombStartsSession(this)) {
            return null;
         }

         if (this.isDefender(var1.getOwnerUuid(), var2.getUniqueId())) {
            this.msg(var2, "Kendi veya takım üssüne raid başlatamazsın.", ChatColor.RED);
            return null;
         }

         if (this.cfgB("start.require-owner-online", true)) {
            Player var5 = Bukkit.getPlayer(var1.getOwnerUuid());
            if (var5 == null || !var5.isOnline()) {
               this.msg(var2, "Üs sahibi çevrim dışıyken raid başlatılamaz.", ChatColor.RED);
               return null;
            }
         }

         if (this.cfgB("limits.one-active-raid-per-attacker-team", true) && this.sessionForRaider(var2.getUniqueId()) != null) {
            this.msg(var2, "Zaten aktif bir raid oturumun var.", ChatColor.RED);
            return null;
         }

         ZRaid.RaidSnapshot var14;
         try {
            var14 = this.captureSnapshot(var1);
         } catch (Throwable var13) {
            this.getLogger().severe("Raid snapshot alinamadi: " + var13.getMessage());
            this.throttleMsg(var2, "Raid başlatılamadı. Lütfen yöneticiye bildir.", ChatColor.RED, 2000L);
            return null;
         }

         long var6 = System.currentTimeMillis();
         long var8 = Math.max(120L, this.cfgL("session.duration-seconds", 720L)) * 1000L;
         ZRaid.RaidSession var10 = new ZRaid.RaidSession(var14, var2.getUniqueId(), var6, var6 + var8);
         var10.beaconRaidHp = Math.max(20, this.cfgI("objectives.beacon-raid-hp", 100));
         var10.bossBar = this.createBossBar();
         var10.defenderBossBar = this.createBossBar();
         this.sessions.put(var1.getId(), var10);
         this.persistRecovery(var14);
         this.clearCoreProtection(var1.getId());
         this.refreshAudience(var10);
         String var11 = this.nameOf(var14.owner);
         var2.sendTitle(this.color("&aRAID BAŞLATILDI!"), this.color("&7" + var11 + " &8• &f" + this.formatTime(var8)), 10, 60, 15);
         Player var12 = Bukkit.getPlayer(var14.owner);
         if (var12 != null && var12.isOnline()) {
            var12.sendTitle(this.color("&cRAID YİYORSUN!"), this.color("&7" + var2.getName() + " &8• &f" + this.formatTime(var8)), 10, 60, 15);
            var12.sendMessage(this.color("&8[&cRaid&8] &cRaid yiyorsun! &7Saldıran: &f" + var2.getName() + " &8• &7Raid bitene kadar jeneratörlerini kıramazsın."));
         }

         this.announceToSides(var10, "⚔ &cRAID BAŞLADI &8• &7Süre: &f" + this.formatTime(var8));
         this.announceToSides(var10, "&7HEDEFLER: &fÜs sahibini öldür &8• &f" + var14.generators.size() + " jeneratörü yok et &8• &fFeneri kır");
         this.playGlobalRaidSound(var10, Sound.ENTITY_WITHER_SPAWN, 0.65F, 1.15F);
         return var10;
      } else {
         return null;
      }
   }

   private void tickSessions() {
      if (this.enabled()) {
         this.tick++;
         long var1 = System.currentTimeMillis();

         for (ZRaid.RaidSession var4 : new ArrayList<>(this.sessions.values())) {
            if (this.sessions.get(var4.snapshot.base.id) == var4) {
               this.clearCoreProtection(var4.snapshot.base.id);
               this.refreshAudience(var4);
               Player var5 = Bukkit.getPlayer(var4.snapshot.owner);
               if (var5 != null && var5.isOnline()) {
                  var4.ownerOfflineSince = 0L;
               }

               if (this.hasOnlineRaider(var4)) {
                  var4.raidersOfflineSince = 0L;
               }

               if (var4.ownerOfflineSince > 0L) {
                  long var6 = Math.max(10L, this.cfgL("disconnect.owner-grace-seconds", 90L)) * 1000L;
                  if (var1 - var4.ownerOfflineSince >= var6) {
                     this.failRaid(var4, "owner-offline");
                     continue;
                  }
               }

               if (var4.raidersOfflineSince > 0L) {
                  long var9 = Math.max(10L, this.cfgL("disconnect.raider-grace-seconds", 60L)) * 1000L;
                  if (var1 - var4.raidersOfflineSince >= var9) {
                     this.failRaid(var4, "raider-offline");
                     continue;
                  }
               }

               if (var1 >= var4.endsAt) {
                  this.failRaid(var4, "timeout");
               } else {
                  int var10 = this.remainingGeneratorCount(var4);
                  if (var10 != var4.lastRemainingGenerators) {
                     var4.lastRemainingGenerators = var10;
                     this.evaluateSuccessReadiness(var4);
                  }

                  this.updateBossBar(var4, var1, var10);
                  long var7 = Math.max(0L, (var4.endsAt - var1 + 999L) / 1000L);
                  if (var7 <= 10L && var7 != var4.lastCountdownSecond) {
                     var4.lastCountdownSecond = var7;
                     this.playGlobalRaidSound(var4, Sound.BLOCK_NOTE_BLOCK_HAT, 0.35F, 1.55F);
                  }
               }
            }
         }
      }
   }

   private void evaluateSuccessReadiness(ZRaid.RaidSession var1) {
   }

   private void completeBeaconObjective(ZRaid.RaidSession var1, Player var2, BeaconData var3, Block var4) {
      if (this.sessions.get(var1.snapshot.base.id) == var1 && this.isRaider(var1, var2.getUniqueId())) {
         if (RaidCompletionRules.allowedOwner(this, var1) && RaidCompletionRules.remainingForCompletion(this, var1) <= 0) {
            try {
               this.deleteById("beacons", var3.getId());
               var4.setType(Material.AIR, false);
               var1.beaconDestroyed = true;
               this.playBreakFx(var4.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE);
               this.successRaid(var1, var2);
            } catch (Throwable var6) {
               this.getLogger().warning("Beacon final objective hatasi: " + var6.getMessage());
               this.msg(var2, "Fener kırma işlemi başarısız. Tekrar dene.", ChatColor.RED);
            }
         }
      }
   }

   private void successRaid(ZRaid.RaidSession var1, Player var2) throws SQLException {
      this.collapseBaseAfterSuccess(var1.snapshot);
      RaidSimpleRules.success(this, var1, var2);
   }

   private void failRaid(ZRaid.RaidSession var1, String var2) {
      RaidSimpleRules.fail(this, var1, var2);
   }

   private ZRaid.RaidSnapshot captureSnapshot$update53Original(BaseData var1) {
      BeaconData var2 = this.core.getBeaconManager().getBeacon(var1.getBeaconId()).orElse(null);
      if (var2 == null) {
         throw new IllegalStateException("Base'e bağlı beacon bulunamadı: " + var1.getBeaconId());
      }

      ZRaid.BaseSnap var3 = new ZRaid.BaseSnap(
         var1.getId(),
         var1.getBeaconId(),
         var1.getOwnerUuid(),
         var1.getName(),
         var1.getWorldName(),
         var1.getX(),
         var1.getY(),
         var1.getZ(),
         var1.getLevel(),
         var1.getCurrentHp(),
         var1.getMaxHp(),
         var1.getRadius(),
         var1.getBlockLimit()
      );
      ZRaid.BeaconSnap var4 = new ZRaid.BeaconSnap(
         var2.getId(), var2.getOwnerUuid(), var2.getName(), var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()
      );
      ArrayList var5 = new ArrayList();

      for (GeneratorData var7 : ZRaidGeneratorResolver.findAllByBase(this.core.getGeneratorRepository(), var1.getId())) {
         var5.add(
            new ZRaid.GeneratorSnap(
               var7.getId(),
               var7.getBaseId(),
               var7.getOwnerUuid(),
               var7.getWorldName(),
               var7.getX(),
               var7.getY(),
               var7.getZ(),
               var7.getLevel(),
               var7.getStoredMoney(),
               var7.getStoredShards(),
               var7.getLastMoneyGeneration(),
               var7.getLastShardGeneration(),
               var7.getLinkedWorld(),
               var7.getLinkedX(),
               var7.getLinkedY(),
               var7.getLinkedZ()
            )
         );
      }

      ArrayList var15 = new ArrayList();

      for (DefenseData var8 : this.core.getDefenseRepository().findAllByBase(var1.getId())) {
         var15.add(
            new ZRaid.DefenseSnap(
               var8.getId(),
               var8.getBaseId(),
               var8.getOwnerUuid(),
               var8.getType(),
               var8.getWorldName(),
               var8.getX(),
               var8.getY(),
               var8.getZ(),
               var8.getLevel(),
               var8.getCurrentHp(),
               var8.getMaxHp(),
               var8.getStoredArrows()
            )
         );
      }

      LinkedHashMap var17 = new LinkedHashMap();
      this.captureBlock(var17, var1.getLocation());
      this.captureBlock(var17, var2.getLocation());

      for (GeneratorData var9 : ZRaidGeneratorResolver.findAllByBase(this.core.getGeneratorRepository(), var1.getId())) {
         this.captureBlock(var17, var9.getLocation());
      }

      for (DefenseData var20 : this.core.getDefenseRepository().findAllByBase(var1.getId())) {
         Location var10 = var20.getLocation();
         this.captureBlock(var17, var10);
         if (var10 != null && var10.getWorld() != null) {
            Block var11 = var10.getBlock();
            String var12 = var11.getType().name();
            if (var12.endsWith("_DOOR") && !var12.endsWith("TRAPDOOR")) {
               Block var13 = var10.clone().add(0.0, 1.0, 0.0).getBlock();
               Block var14 = var10.clone().add(0.0, -1.0, 0.0).getBlock();
               if (var13.getType() == var11.getType()) {
                  this.captureBlock(var17, var13.getLocation());
               }

               if (var14.getType() == var11.getType()) {
                  this.captureBlock(var17, var14.getLocation());
               }
            }
         }
      }

      return new ZRaid.RaidSnapshot(var3, var4, var1.getOwnerUuid(), var5, var15, new ArrayList<>(var17.values()));
   }

   private void captureBlock(Map<String, ZRaid.BlockSnap> var1, Location var2) {
      if (var2 != null && var2.getWorld() != null) {
         Block var3 = var2.getBlock();
         BlockData var4 = var3.getBlockData();

         String var5;
         try {
            var5 = var4.getAsString();
         } catch (Throwable var7) {
            var5 = var3.getType().getKey().toString();
         }

         ZRaid.BlockSnap var6 = new ZRaid.BlockSnap(var2.getWorld().getName(), var3.getX(), var3.getY(), var3.getZ(), var3.getType().name(), var5);
         var1.put(var6.world + ":" + var6.x + ":" + var6.y + ":" + var6.z, var6);
      }
   }

   private void restoreSnapshot(ZRaid.RaidSnapshot var1) throws SQLException {
      Connection var2 = this.core.getDatabaseManager().getConnection();
      boolean var3 = var2.getAutoCommit();
      var2.setAutoCommit(false);

      try {
         this.upsertBeacon(var2, var1.beacon);
         this.upsertBase(var2, var1.base);

         for (ZRaid.GeneratorSnap var5 : var1.generators) {
            this.upsertGenerator(var2, var5);
         }

         for (ZRaid.DefenseSnap var14 : var1.defenses) {
            this.upsertDefense(var2, var14);
         }

         var2.commit();
      } catch (SQLException var9) {
         var2.rollback();
         throw var9;
      } finally {
         var2.setAutoCommit(var3);
      }

      for (ZRaid.BlockSnap var15 : var1.blocks) {
         this.restoreBlock(var15);
      }

      this.reloadCoreCaches();
      Location var13 = this.location(var1.base.world, var1.base.x, var1.base.y, var1.base.z);
      if (var13 != null && var13.getWorld() != null) {
         var13.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, var13.clone().add(0.5, 1.2, 0.5), 35, 2.5, 1.3, 2.5, 0.05);
         var13.getWorld().playSound(var13, Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.0F);
      }
   }

   private void collapseBaseAfterSuccess(ZRaid.RaidSnapshot var1) throws SQLException {
      if (ConfigurableRaidRules.cleanupLinkedStructures(this)) {
         Connection var2 = this.core.getDatabaseManager().getConnection();
         boolean var3 = var2.getAutoCommit();
         var2.setAutoCommit(false);

         try {
            for (ZRaid.GeneratorSnap var5 : var1.generators) {
               this.deleteById(var2, "generators", var5.id);
            }

            for (ZRaid.DefenseSnap var14 : var1.defenses) {
               this.deleteById(var2, "defenses", var14.id);
            }

            this.deleteById(var2, "bases", var1.base.id);
            this.deleteById(var2, "beacons", var1.beacon.id);
            var2.commit();
         } catch (SQLException var9) {
            var2.rollback();
            throw var9;
         } finally {
            var2.setAutoCommit(var3);
         }

         for (ZRaid.GeneratorSnap var15 : var1.generators) {
            this.removeGeneratorVisual(var15.id);
         }

         for (ZRaid.BlockSnap var16 : var1.blocks) {
            World var6 = Bukkit.getWorld(var16.world);
            if (var6 != null) {
               var6.getBlockAt(var16.x, var16.y, var16.z).setType(Material.AIR, false);
            }
         }

         this.reloadCoreCaches();
      }
   }

   private void upsertBeacon(Connection var1, ZRaid.BeaconSnap var2) throws SQLException {
      String var3 = "INSERT INTO beacons(id,owner_uuid,name,world,x,y,z,created_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET owner_uuid=excluded.owner_uuid,name=excluded.name,world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z";

      try (PreparedStatement var4 = var1.prepareStatement(var3)) {
         var4.setLong(1, var2.id);
         var4.setString(2, var2.owner.toString());
         var4.setString(3, var2.name);
         var4.setString(4, var2.world);
         var4.setInt(5, var2.x);
         var4.setInt(6, var2.y);
         var4.setInt(7, var2.z);
         var4.setLong(8, System.currentTimeMillis());
         var4.executeUpdate();
      }
   }

   private void upsertBase(Connection var1, ZRaid.BaseSnap var2) throws SQLException {
      String var3 = "INSERT INTO bases(id,beacon_id,owner_uuid,name,world,x,y,z,level,current_hp,max_hp,radius,block_limit,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET beacon_id=excluded.beacon_id,owner_uuid=excluded.owner_uuid,name=excluded.name,world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z,level=excluded.level,current_hp=excluded.current_hp,max_hp=excluded.max_hp,radius=excluded.radius,block_limit=excluded.block_limit";

      try (PreparedStatement var4 = var1.prepareStatement(var3)) {
         var4.setLong(1, var2.id);
         var4.setLong(2, var2.beaconId);
         var4.setString(3, var2.owner.toString());
         var4.setString(4, var2.name);
         var4.setString(5, var2.world);
         var4.setInt(6, var2.x);
         var4.setInt(7, var2.y);
         var4.setInt(8, var2.z);
         var4.setInt(9, var2.level);
         var4.setInt(10, var2.currentHp);
         var4.setInt(11, var2.maxHp);
         var4.setInt(12, var2.radius);
         var4.setInt(13, var2.blockLimit);
         var4.setLong(14, System.currentTimeMillis());
         var4.executeUpdate();
      }
   }

   private void upsertGenerator(Connection var1, ZRaid.GeneratorSnap var2) throws SQLException {
      String var3 = "INSERT INTO generators(id,base_id,owner_uuid,world,x,y,z,level,stored_money,stored_shards,last_money_generation,last_shard_generation,linked_world,linked_x,linked_y,linked_z,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET base_id=excluded.base_id,owner_uuid=excluded.owner_uuid,world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z,level=excluded.level,stored_money=excluded.stored_money,stored_shards=excluded.stored_shards,last_money_generation=excluded.last_money_generation,last_shard_generation=excluded.last_shard_generation,linked_world=excluded.linked_world,linked_x=excluded.linked_x,linked_y=excluded.linked_y,linked_z=excluded.linked_z";

      try (PreparedStatement var4 = var1.prepareStatement(var3)) {
         var4.setLong(1, var2.id);
         var4.setLong(2, var2.baseId);
         var4.setString(3, var2.owner.toString());
         var4.setString(4, var2.world);
         var4.setInt(5, var2.x);
         var4.setInt(6, var2.y);
         var4.setInt(7, var2.z);
         var4.setInt(8, var2.level);
         var4.setDouble(9, var2.storedMoney);
         var4.setInt(10, var2.storedShards);
         var4.setLong(11, var2.lastMoney);
         var4.setLong(12, var2.lastShard);
         var4.setString(13, var2.linkedWorld);
         if (var2.linkedX == null) {
            var4.setObject(14, null);
         } else {
            var4.setInt(14, var2.linkedX);
         }

         if (var2.linkedY == null) {
            var4.setObject(15, null);
         } else {
            var4.setInt(15, var2.linkedY);
         }

         if (var2.linkedZ == null) {
            var4.setObject(16, null);
         } else {
            var4.setInt(16, var2.linkedZ);
         }

         var4.setLong(17, System.currentTimeMillis());
         var4.executeUpdate();
      }
   }

   private void upsertDefense(Connection var1, ZRaid.DefenseSnap var2) throws SQLException {
      String var3 = "INSERT INTO defenses(id,base_id,owner_uuid,type,world,x,y,z,level,current_hp,max_hp,stored_arrows,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET base_id=excluded.base_id,owner_uuid=excluded.owner_uuid,type=excluded.type,world=excluded.world,x=excluded.x,y=excluded.y,z=excluded.z,level=excluded.level,current_hp=excluded.current_hp,max_hp=excluded.max_hp,stored_arrows=excluded.stored_arrows";

      try (PreparedStatement var4 = var1.prepareStatement(var3)) {
         var4.setLong(1, var2.id);
         var4.setLong(2, var2.baseId);
         var4.setString(3, var2.owner.toString());
         var4.setString(4, var2.type);
         var4.setString(5, var2.world);
         var4.setInt(6, var2.x);
         var4.setInt(7, var2.y);
         var4.setInt(8, var2.z);
         var4.setInt(9, var2.level);
         var4.setInt(10, var2.currentHp);
         var4.setInt(11, var2.maxHp);
         var4.setInt(12, var2.storedArrows);
         var4.setLong(13, System.currentTimeMillis());
         var4.executeUpdate();
      }
   }

   private void restoreBlock(ZRaid.BlockSnap var1) {
      World var2 = Bukkit.getWorld(var1.world);
      if (var2 != null) {
         Block var3 = var2.getBlockAt(var1.x, var1.y, var1.z);

         try {
            var3.setBlockData(Bukkit.createBlockData(var1.blockData), false);
         } catch (Throwable var6) {
            Material var5 = Material.matchMaterial(var1.material);
            if (var5 != null) {
               var3.setType(var5, false);
            }
         }
      }
   }

   private boolean deleteGeneratorForRaid(GeneratorData var1) {
      try {
         if (!this.deleteById("generators", var1.getId())) {
            return false;
         }

         this.removeGeneratorVisual(var1.getId());
         Location var2 = var1.getLocation();
         if (var2 != null && var2.getWorld() != null) {
            var2.getBlock().setType(Material.AIR, false);
         }

         this.core.getGeneratorManager().loadCache();
         return true;
      } catch (Throwable var3) {
         this.getLogger().warning("Raid generator delete hatasi: " + var3.getMessage());
         return false;
      }
   }

   private boolean deleteById(String var1, long var2) throws SQLException {
      Connection var4 = this.core.getDatabaseManager().getConnection();

      try (PreparedStatement var5 = var4.prepareStatement("DELETE FROM " + this.safeTable(var1) + " WHERE id=?")) {
         var5.setLong(1, var2);
         return var5.executeUpdate() > 0;
      }
   }

   private void deleteById(Connection var1, String var2, long var3) throws SQLException {
      try (PreparedStatement var5 = var1.prepareStatement("DELETE FROM " + this.safeTable(var2) + " WHERE id=?")) {
         var5.setLong(1, var3);
         var5.executeUpdate();
      }
   }

   private String safeTable(String var1) {
      switch (var1) {
         case "beacons":
         case "bases":
         case "generators":
         case "defenses":
            return var1;
         default:
            throw new IllegalArgumentException("table");
      }
   }

   private void reloadCoreCaches() {
      try {
         this.core.getBaseRepository().clearCache();
      } catch (Throwable var6) {
      }

      try {
         this.core.getDefenseManager().loadCache();
      } catch (Throwable var5) {
      }

      try {
         this.core.getTurretManager().loadCache();
      } catch (Throwable var4) {
      }

      try {
         this.core.getDefenseAccessManager().loadCache();
      } catch (Throwable var3) {
      }

      try {
         this.core.getGeneratorManager().loadCache();
      } catch (Throwable var2) {
      }
   }

   private void removeGeneratorVisual(long var1) {
      try {
         Field var3 = GeneratorManager.class.getDeclaredField("visualManager");
         var3.setAccessible(true);
         Object var4 = var3.get(this.core.getGeneratorManager());
         Method var5 = var4.getClass().getMethod("remove", long.class);
         var5.invoke(var4, var1);
      } catch (Throwable var6) {
      }
   }

   private void persistRecovery(ZRaid.RaidSnapshot var1) {
   }

   private void recoverAbandonedSnapshots() {
   }

   private File recoveryFile(long var1) {
      return new File(this.recoveryDir, "base-" + var1 + ".bin");
   }

   private void deleteRecovery(long var1) {
      File var3 = this.recoveryFile(var1);
      if (var3.isFile() && !var3.delete()) {
         var3.deleteOnExit();
      }
   }

   private void creditBountyRaidWin(UUID var1, UUID var2) {
      if (this.cfgB("bounty-integration.enabled", true)) {
         long var3 = System.currentTimeMillis();
         String var5 = var1 + ":" + var2;
         long var6 = Math.max(1L, this.cfgL("bounty-integration.same-target-credit-cooldown-hours", 6L)) * 3600000L;
         Long var8 = this.bountyPairCredit.get(var5);
         if (var8 == null || var3 - var8 >= var6) {
            Plugin var9 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZBounty");
            if (var9 != null && var9.isEnabled()) {
               try {
                  Method var10 = var9.getClass().getMethod("recordRaidWin", UUID.class, UUID.class);
                  var10.invoke(var9, var1, var2);
                  this.bountyPairCredit.put(var5, var3);
                  this.saveStats();
               } catch (NoSuchMethodException var11) {
                  this.getLogger().warning("ZBounty eski sürüm. Raid win API bulunamadı; ZBounty 1.1.0+ kullanın.");
               } catch (Throwable var12) {
                  this.getLogger().warning("ZBounty raid win bildirimi başarısız: " + var12.getMessage());
               }
            }
         }
      }
   }

   private void loadStats() {
      if (this.statsFile != null && this.statsFile.isFile()) {
         Properties var1 = new Properties();

         try (InputStreamReader var2 = new InputStreamReader(new FileInputStream(this.statsFile), StandardCharsets.UTF_8)) {
            var1.load(var2);

            for (String var4 : var1.stringPropertyNames()) {
               if (var4.startsWith("pair.")) {
                  try {
                     this.bountyPairCredit.put(var4.substring(5), Long.parseLong(var1.getProperty(var4)));
                  } catch (Exception var7) {
                  }
               }
            }
         } catch (Exception var9) {
            this.getLogger().warning("Raid stats okunamadi: " + var9.getMessage());
         }
      }
   }

   private synchronized void saveStats() {
      if (this.statsFile != null) {
         try {
            if (!this.getDataFolder().exists()) {
               this.getDataFolder().mkdirs();
            }

            Properties var1 = new Properties();
            long var2 = System.currentTimeMillis() - 604800000L;
            this.bountyPairCredit.entrySet().removeIf(var2x -> var2x.getValue() < var2);

            for (Entry var5 : this.bountyPairCredit.entrySet()) {
               var1.setProperty("pair." + (String)var5.getKey(), String.valueOf(var5.getValue()));
            }

            try (OutputStreamWriter var10 = new OutputStreamWriter(new FileOutputStream(this.statsFile), StandardCharsets.UTF_8)) {
               var1.store(var10, "ZRaid internal stats");
            }
         } catch (Exception var9) {
            this.getLogger().warning("Raid stats kaydedilemedi: " + var9.getMessage());
         }
      }
   }

   private ZRaid.Target identifyTarget(Block var1) {
      if (var1 == null) {
         return null;
      }

      Location var2 = var1.getLocation();
      GeneratorData var3 = this.core.getGeneratorManager().getGenerator(var2).orElse(null);
      if (var3 != null) {
         return new ZRaid.Target(this.findBaseById(var3.getBaseId()), "GENERATOR");
      }

      DefenseData var4 = this.core.getDefenseAccessManager().get(var1).orElse(null);
      if (var4 != null) {
         return new ZRaid.Target(this.findBaseById(var4.getBaseId()), var4.getType());
      }

      DefenseData var5 = this.core.getTurretManager().getTurret(var2).orElse(null);
      if (var5 != null) {
         return new ZRaid.Target(this.findBaseById(var5.getBaseId()), "TURRET");
      }

      DefenseData var6 = this.core.getDefenseManager().getDefense(var2).orElse(null);
      if (var6 != null) {
         return new ZRaid.Target(this.findBaseById(var6.getBaseId()), "DEFENSE");
      }

      BeaconData var7 = this.core.getBeaconManager().getBeacon(var2).orElse(null);
      if (var7 != null) {
         return new ZRaid.Target(this.findBaseByBeacon(var7.getId(), var7.getOwnerUuid()), "BEACON");
      }

      BaseData var8 = this.core.getBaseManager().getBase(var2).orElse(null);
      return var8 != null && this.sameBlock(var8.getLocation(), var2) ? new ZRaid.Target(var8, "BASE") : null;
   }

   private BaseData findBombTargetBase(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         BaseData var2 = this.core.getBaseManager().getBase(var1).orElse(null);
         if (var2 != null) {
            return var2;
         }

         double var3 = Math.max(2.0, this.cfgD("start.bomb-search-extra-radius", 7.0));
         BaseData var5 = null;
         double var6 = Double.MAX_VALUE;

         for (BaseData var9 : this.core.getBaseRepository().findAll()) {
            Location var10 = var9.getLocation();
            if (var10 != null && var10.getWorld() != null && var10.getWorld().getName().equalsIgnoreCase(var1.getWorld().getName())) {
               double var11 = var10.getX() - var1.getX();
               double var13 = var10.getZ() - var1.getZ();
               double var15 = var11 * var11 + var13 * var13;
               double var17 = var9.getRadius() + var3;
               if (var15 <= var17 * var17 && var15 < var6) {
                  var6 = var15;
                  var5 = var9;
               }
            }
         }

         return var5;
      } else {
         return null;
      }
   }

   private BaseData findBaseById(long var1) {
      if (var1 <= 0L) {
         return null;
      }

      for (BaseData var4 : this.core.getBaseRepository().findAll()) {
         if (var4.getId() == var1) {
            return var4;
         }
      }

      return null;
   }

   private BaseData findBaseByBeacon(long var1, UUID var3) {
      BaseData var4 = this.core.getBaseRepository().findByOwner(var3).orElse(null);
      if (var4 != null && var4.getBeaconId() == var1) {
         return var4;
      }

      for (BaseData var6 : this.core.getBaseRepository().findAll()) {
         if (var6.getBeaconId() == var1) {
            return var6;
         }
      }

      return null;
   }

   private boolean sameBlock(Location var1, Location var2) {
      return var1 != null && var2 != null && var1.getWorld() != null && var2.getWorld() != null
         ? var1.getWorld().getName().equalsIgnoreCase(var2.getWorld().getName())
            && var1.getBlockX() == var2.getBlockX()
            && var1.getBlockY() == var2.getBlockY()
            && var1.getBlockZ() == var2.getBlockZ()
         : false;
   }

   private boolean isRaider(ZRaid.RaidSession var1, UUID var2) {
      return var1 != null && var2 != null ? var1.initiator.equals(var2) || this.teammates(var1.initiator, var2) : false;
   }

   private boolean isDefender(UUID var1, UUID var2) {
      return var1 != null && var2 != null ? var1.equals(var2) || this.teammates(var1, var2) : false;
   }

   private boolean teammates(UUID var1, UUID var2) {
      if (var1 != null && var2 != null && !var1.equals(var2)) {
         try {
            ZTeamHook var3 = this.core.getZTeamHook();
            return var3 != null && var3.isAvailable() && var3.areTeammates(var1, var2);
         } catch (Throwable var4) {
            return false;
         }
      } else {
         return var1 != null && var1.equals(var2);
      }
   }

   private ZRaid.RaidSession sessionByGeneratorId(long var1) {
      if (var1 <= 0L) {
         return null;
      }

      for (ZRaid.RaidSession var4 : this.sessions.values()) {
         if (this.snapshotContainsGenerator(var4.snapshot, var1)) {
            return var4;
         }
      }

      return null;
   }

   private ZRaid.RaidSession sessionByBeaconId(long var1) {
      if (var1 <= 0L) {
         return null;
      }

      for (ZRaid.RaidSession var4 : this.sessions.values()) {
         if (var4.snapshot.beacon.id == var1) {
            return var4;
         }
      }

      return null;
   }

   private ZRaid.RaidSession sessionByLocation(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         double var2 = Math.max(2.0, this.cfgD("start.bomb-search-extra-radius", 7.0));
         ZRaid.RaidSession var4 = null;
         double var5 = Double.MAX_VALUE;

         for (ZRaid.RaidSession var8 : this.sessions.values()) {
            ZRaid.BaseSnap var9 = var8.snapshot.base;
            if (var9.world.equalsIgnoreCase(var1.getWorld().getName())) {
               double var10 = var9.x + 0.5 - var1.getX();
               double var12 = var9.z + 0.5 - var1.getZ();
               double var14 = var10 * var10 + var12 * var12;
               double var16 = Math.max(1.0, var9.radius) + var2;
               if (var14 <= var16 * var16 && var14 < var5) {
                  var5 = var14;
                  var4 = var8;
               }
            }
         }

         return var4;
      } else {
         return null;
      }
   }

   private ZRaid.RaidSession sessionForBlock(Block var1) {
      if (var1 != null && var1.getLocation() != null && var1.getLocation().getWorld() != null) {
         String var2 = var1.getLocation().getWorld().getName();
         int var3 = var1.getX();
         int var4 = var1.getY();
         int var5 = var1.getZ();

         for (ZRaid.RaidSession var7 : this.sessions.values()) {
            for (ZRaid.BlockSnap var9 : var7.snapshot.blocks) {
               if (var9.x == var3 && var9.y == var4 && var9.z == var5 && var9.world.equalsIgnoreCase(var2)) {
                  return var7;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private ZRaid.RaidSession sessionForRaider(UUID var1) {
      for (ZRaid.RaidSession var3 : this.sessions.values()) {
         if (this.isRaider(var3, var1)) {
            return var3;
         }
      }

      return null;
   }

   private ZRaid.RaidSession sessionForParticipant(UUID var1) {
      for (ZRaid.RaidSession var3 : this.sessions.values()) {
         if (this.isRaider(var3, var1) || this.isDefender(var3.snapshot.owner, var1)) {
            return var3;
         }
      }

      return null;
   }

   private boolean hasOnlineRaider(ZRaid.RaidSession var1) {
      for (Player var3 : Bukkit.getOnlinePlayers()) {
         if (var3.isOnline() && this.isRaider(var1, var3.getUniqueId())) {
            return true;
         }
      }

      return false;
   }

   private int remainingGeneratorCount(ZRaid.RaidSession var1) {
      int var2 = 0;

      try {
         java.util.HashSet<Long> var20 = new java.util.HashSet<>();

         for (GeneratorData var21 : this.core.getGeneratorManager().getCachedGenerators()) {
            var20.add(var21.getId());
         }

         for (ZRaid.GeneratorSnap var22 : var1.snapshot.generators) {
            if (var20.contains(var22.id)) {
               var2++;
            }
         }

         return var2;
      } catch (Throwable var23) {
         var2 = 0;
      }

      try {
         Connection var3 = this.core.getDatabaseManager().getConnection();

         try (PreparedStatement var4 = var3.prepareStatement("SELECT 1 FROM generators WHERE id=? LIMIT 1")) {
            for (ZRaid.GeneratorSnap var6 : var1.snapshot.generators) {
               var4.setLong(1, var6.id);

               try (ResultSet var7 = var4.executeQuery()) {
                  if (var7.next()) {
                     var2++;
                  }
               }
            }
         }

         return var2;
      } catch (SQLException var14) {
         this.getLogger().warning("Generator objective check hatasi: " + var14.getMessage());
         return var1.snapshot.generators.size() - var1.destroyedGenerators.size();
      }
   }

   private int destroyedGeneratorCount(ZRaid.RaidSession var1) {
      return Math.max(0, var1.snapshot.generators.size() - this.remainingGeneratorCount(var1));
   }

   private boolean snapshotContainsGenerator(ZRaid.RaidSnapshot var1, long var2) {
      for (ZRaid.GeneratorSnap var5 : var1.generators) {
         if (var5.id == var2) {
            return true;
         }
      }

      return false;
   }

   private BossBar createBossBar() {
      BarColor var1 = BarColor.valueOf(this.cfgS("bossbar.color", "RED").toUpperCase(Locale.ROOT));
      BarStyle var2 = BarStyle.valueOf(this.cfgS("bossbar.style", "SEGMENTED_10").toUpperCase(Locale.ROOT));
      return Bukkit.createBossBar("Raid", var1, var2, new BarFlag[0]);
   }

   private void updateBossBar(ZRaid.RaidSession var1, long var2, int var4) {
      RaidSimpleRules.updateBossBar(this, var1, var2, var4);
   }

   private void refreshAudience(ZRaid.RaidSession var1) {
      for (Player var3 : Bukkit.getOnlinePlayers()) {
         boolean var4 = this.isDefender(var1.snapshot.owner, var3.getUniqueId());
         boolean var5 = !var4 && this.isRaider(var1, var3.getUniqueId());
         this.syncBar(var1.bossBar, var3, var5);
         this.syncBar(var1.defenderBossBar, var3, var4);
      }
   }

   private void syncBar(BossBar var1, Player var2, boolean var3) {
      if (var1 != null) {
         boolean var4 = var1.getPlayers().contains(var2);
         if (var3 && !var4) {
            var1.addPlayer(var2);
         } else if (!var3 && var4) {
            var1.removePlayer(var2);
         }
      }
   }

   private void sendStatus(Player var1, ZRaid.RaidSession var2) {
      long var3 = Math.max(0L, var2.endsAt - System.currentTimeMillis());
      int var5 = this.remainingGeneratorCount(var2);
      this.msg(var1, "&8&m--------------------------------", ChatColor.DARK_GRAY);
      this.msg(var1, "&cRAID DURUMU &8• &f" + this.formatTime(var3), ChatColor.WHITE);
      this.msg(var1, (var2.ownerKilled ? "&a✓" : "&c✗") + " &7Üs sahibini öldür", ChatColor.WHITE);
      this.msg(
         var1,
         (var5 == 0 ? "&a✓" : "&c✗") + " &7Jeneratörler &8• &f" + (var2.snapshot.generators.size() - var5) + "/" + var2.snapshot.generators.size(),
         ChatColor.WHITE
      );
      this.msg(var1, (var2.ownerKilled && var5 == 0 ? "&e➜" : "&8✗") + " &7Respawn feneri", ChatColor.WHITE);
      this.msg(var1, "&8&m--------------------------------", ChatColor.DARK_GRAY);
   }

   private void announceObjective(ZRaid.RaidSession var1, String var2) {
      this.announceToSides(var1, "&e⚔ &f" + var2);
   }

   private void announceToSides(ZRaid.RaidSession var1, String var2) {
      RaidSimpleRules.announce(this, var1, var2);
   }

   private void broadcastOptional(String var1) {
      if (this.cfgB("notifications.broadcast-success", true)) {
         Bukkit.broadcastMessage(this.color(var1));
      }
   }

   private void playGlobalRaidSound(ZRaid.RaidSession var1, Sound var2, float var3, float var4) {
      if (this.cfgB("sounds.enabled", true)) {
         for (Player var6 : Bukkit.getOnlinePlayers()) {
            if (this.isRaider(var1, var6.getUniqueId()) || this.isDefender(var1.snapshot.owner, var6.getUniqueId())) {
               var6.playSound(var6.getLocation(), var2, var3, var4);
            }
         }
      }
   }

   private void playBreakFx(Location var1, Sound var2) {
      if (var1 != null && var1.getWorld() != null) {
         var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var1.clone().add(0.5, 0.8, 0.5), 18, 0.35, 0.45, 0.35, 0.05);
         var1.getWorld().spawnParticle(Particle.SMOKE, var1.clone().add(0.5, 0.6, 0.5), 12, 0.3, 0.3, 0.3, 0.02);
         if (this.cfgB("sounds.enabled", true)) {
            var1.getWorld().playSound(var1, var2, 0.85F, 1.0F);
         }
      }
   }

   private void stopAllMining(ZRaid.RaidSession var1) {
      for (Player var3 : Bukkit.getOnlinePlayers()) {
         if (this.isRaider(var1, var3.getUniqueId()) || this.isDefender(var1.snapshot.owner, var3.getUniqueId())) {
            StructureMiningUtil.stopMining(var3);
         }
      }
   }

   private void throttleMsg(Player var1, String var2, ChatColor var3, long var4) {
      long var6 = System.currentTimeMillis();
      long var8 = this.lastMessageAt.getOrDefault(var1.getUniqueId(), 0L);
      if (var6 - var8 >= var4) {
         this.lastMessageAt.put(var1.getUniqueId(), var6);
         this.msg(var1, var2, var3);
      }
   }

   private void msg(Player var1, String var2, ChatColor var3) {
      var1.sendMessage(this.color(var2.startsWith("&") ? var2 : "&7" + var2));
   }

   private String color(String var1) {
      return ChatColor.translateAlternateColorCodes('&', var1 == null ? "" : var1);
   }

   private String formatTime(long var1) {
      long var3 = Math.max(0L, (var1 + 999L) / 1000L);
      return String.format(Locale.ROOT, "%02d:%02d", var3 / 60L, var3 % 60L);
   }

   private String nameOf(UUID var1) {
      Player var2 = Bukkit.getPlayer(var1);
      if (var2 != null) {
         return var2.getName();
      }

      OfflinePlayer var3 = Bukkit.getOfflinePlayer(var1);
      return var3 != null && var3.getName() != null ? var3.getName() : var1.toString().substring(0, 8);
   }

   private Player findOnline(String var1) {
      for (Player var3 : Bukkit.getOnlinePlayers()) {
         if (var3.getName().equalsIgnoreCase(var1)) {
            return var3;
         }
      }

      return null;
   }

   private Location location(String var1, int var2, int var3, int var4) {
      World var5 = Bukkit.getWorld(var1);
      return var5 == null ? null : new Location(var5, var2, var3, var4);
   }

   private void clearCoreProtection(long var1) {
      try {
         this.core.getRaidBombManager().getProtectionManager().removeProtection(var1);
      } catch (Throwable var4) {
      }
   }

   private boolean enabled() {
      return this.cfgB("system.enabled", true) && this.core != null && this.core.isEnabled();
   }

   private boolean cfgB(String var1, boolean var2) {
      return this.getConfig().getBoolean(var1, var2);
   }

   private int cfgI(String var1, int var2) {
      return this.getConfig().getInt(var1, var2);
   }

   private long cfgL(String var1, long var2) {
      return this.getConfig().getLong(var1, var2);
   }

   private double cfgD(String var1, double var2) {
      return this.getConfig().getDouble(var1, var2);
   }

   private String cfgS(String var1, String var2) {
      return this.getConfig().getString(var1, var2);
   }

   private ZRaid.RaidSnapshot captureSnapshot(BaseData var1) {
      try {
         return this.captureSnapshot$update53Original(var1);
      } catch (Throwable var4) {
         Object var3 = RaidManualStartFix.repairBase(this, var1, var4);
         if (var3 != null) {
            return this.captureSnapshot$update53Original((BaseData)var3);
         } else {
            throw var4;
         }
      }
   }

   private record BaseSnap(
      long id, long beaconId, UUID owner, String name, String world, int x, int y, int z, int level, int currentHp, int maxHp, int radius, int blockLimit
   ) implements Serializable {
   }

   private record BeaconSnap(long id, UUID owner, String name, String world, int x, int y, int z) implements Serializable {
   }

   private record BlockSnap(String world, int x, int y, int z, String material, String blockData) implements Serializable {
   }

   private record DefenseSnap(
      long id, long baseId, UUID owner, String type, String world, int x, int y, int z, int level, int currentHp, int maxHp, int storedArrows
   ) implements Serializable {
   }

   private record GeneratorSnap(
      long id,
      long baseId,
      UUID owner,
      String world,
      int x,
      int y,
      int z,
      int level,
      double storedMoney,
      int storedShards,
      long lastMoney,
      long lastShard,
      String linkedWorld,
      Integer linkedX,
      Integer linkedY,
      Integer linkedZ
   ) implements Serializable {
   }

   private static final class RaidSession {
      final ZRaid.RaidSnapshot snapshot;
      final UUID initiator;
      final long startedAt;
      final long endsAt;
      final Set<Long> destroyedGenerators = ConcurrentHashMap.newKeySet();
      volatile boolean ownerKilled;
      volatile long ownerKilledAt;
      volatile boolean beaconDestroyed;
      volatile int beaconRaidHp;
      volatile int lastRemainingGenerators = -1;
      volatile boolean beaconUnlockedAnnounced;
      volatile long ownerOfflineSince;
      volatile long raidersOfflineSince;
      volatile long lastCountdownSecond = -1L;
      BossBar bossBar;
      BossBar defenderBossBar;

      RaidSession(ZRaid.RaidSnapshot var1, UUID var2, long var3, long var5) {
         this.snapshot = var1;
         this.initiator = var2;
         this.startedAt = var3;
         this.endsAt = var5;
      }
   }

   private record RaidSnapshot(
      ZRaid.BaseSnap base,
      ZRaid.BeaconSnap beacon,
      UUID owner,
      List<ZRaid.GeneratorSnap> generators,
      List<ZRaid.DefenseSnap> defenses,
      List<ZRaid.BlockSnap> blocks
   ) implements Serializable {
   }

   private record Target(BaseData base, String type) {
   }
}