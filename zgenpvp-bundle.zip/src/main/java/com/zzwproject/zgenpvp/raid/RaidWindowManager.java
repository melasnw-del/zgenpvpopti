package com.zzwproject.zgenpvp.raid;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BaseData;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public final class RaidWindowManager {
   private final ZGenPvP plugin;
   private final File dataFile;
   private final Map<Long, RaidWindowManager.RaidWindow> active = new HashMap<>();

   public RaidWindowManager(ZGenPvP var1) {
      this.plugin = var1;
      this.dataFile = new File(var1.getDataFolder(), "raid-windows.yml");
      this.load();
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getRaid().getBoolean("raid-window.enabled", true);
   }

   public long getDurationSeconds() {
      FileConfiguration var1 = this.plugin.getConfigManager().getRaid();
      return Math.max(1L, var1.getLong("raid-window.duration-minutes", 15L)) * 60L;
   }

   public boolean beginRaid(BaseData var1, Player var2) {
      if (this.isEnabled() && var1 != null && var2 != null) {
         long var3 = System.currentTimeMillis();
         RaidWindowManager.RaidWindow var5 = this.active.get(var1.getId());
         if (var5 != null && var5.expiresAt() > var3) {
            return false;
         }

         long var6 = var3 + this.getDurationSeconds() * 1000L;
         RaidWindowManager.RaidWindow var8 = new RaidWindowManager.RaidWindow(var1.getId(), var1.getOwnerUuid(), var2.getUniqueId(), var6);
         this.active.put(var1.getId(), var8);
         this.save();
         long var9 = this.getRemainingSeconds(var1.getId());
         String var11 = this.formatRemaining(var9);
         this.plugin.getMessageUtil().send(var2, "base.raid-started-attacker", "%time%", var11);
         Player var12 = Bukkit.getPlayer(var1.getOwnerUuid());
         if (var12 != null && var12.isOnline()) {
            this.plugin.getMessageUtil().send(var12, "base.raid-started-owner", "%attacker%", var2.getName(), "%time%", var11);
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean isRaidActive(long var1) {
      return this.getRemainingSeconds(var1) > 0L;
   }

   public long getRemainingSeconds(long var1) {
      if (!this.isEnabled()) {
         return 0L;
      } else {
         RaidWindowManager.RaidWindow var3 = this.active.get(var1);
         if (var3 == null) {
            return 0L;
         } else {
            long var4 = var3.expiresAt() - System.currentTimeMillis();
            if (var4 <= 0L) {
               this.active.remove(var1);
               this.save();
               return 0L;
            } else {
               return (var4 + 999L) / 1000L;
            }
         }
      }
   }

   public Optional<UUID> getAttacker(long var1) {
      RaidWindowManager.RaidWindow var3 = this.active.get(var1);
      return var3 != null && this.isRaidActive(var1) ? Optional.ofNullable(var3.attackerUuid()) : Optional.empty();
   }

   public void endRaid(long var1) {
      if (this.active.remove(var1) != null) {
         this.save();
      }
   }

   public void cleanupExpired() {
      long var1 = System.currentTimeMillis();
      boolean var3 = false;
      Iterator var4 = this.active.entrySet().iterator();

      while (var4.hasNext()) {
         Entry var5 = (Entry)var4.next();
         RaidWindowManager.RaidWindow var6 = (RaidWindowManager.RaidWindow)var5.getValue();
         if (var6 == null || var6.expiresAt() <= var1) {
            var4.remove();
            var3 = true;
         }
      }

      if (var3) {
         this.save();
      }
   }

   public String formatRemaining(long var1) {
      long var3 = Math.max(0L, var1);
      long var5 = var3 / 60L;
      long var7 = var3 % 60L;
      return var5 > 0L ? var5 + "dk " + var7 + "sn" : var7 + "sn";
   }

   public void shutdown() {
      this.cleanupExpired();
      this.save();
      this.active.clear();
   }

   private void load() {
      this.active.clear();
      if (this.dataFile.exists()) {
         YamlConfiguration var1 = YamlConfiguration.loadConfiguration(this.dataFile);
         ConfigurationSection var2 = var1.getConfigurationSection("raids");
         if (var2 != null) {
            long var3 = System.currentTimeMillis();

            for (String var6 : var2.getKeys(false)) {
               try {
                  long var7 = Long.parseLong(var6);
                  long var9 = var2.getLong(var6 + ".expires-at", 0L);
                  if (var9 > var3) {
                     UUID var11 = parseUuid(var2.getString(var6 + ".owner"));
                     UUID var12 = parseUuid(var2.getString(var6 + ".attacker"));
                     this.active.put(var7, new RaidWindowManager.RaidWindow(var7, var11, var12, var9));
                  }
               } catch (NumberFormatException var13) {
               }
            }
         }
      }
   }

   private void save() {
      try {
         File var1 = this.dataFile.getParentFile();
         if (var1 != null && !var1.exists()) {
            var1.mkdirs();
         }

         YamlConfiguration var2 = new YamlConfiguration();
         long var3 = System.currentTimeMillis();

         for (RaidWindowManager.RaidWindow var6 : this.active.values()) {
            if (var6 != null && var6.expiresAt() > var3) {
               String var7 = "raids." + var6.baseId();
               var2.set(var7 + ".owner", var6.ownerUuid() == null ? null : var6.ownerUuid().toString());
               var2.set(var7 + ".attacker", var6.attackerUuid() == null ? null : var6.attackerUuid().toString());
               var2.set(var7 + ".expires-at", var6.expiresAt());
            }
         }

         var2.save(this.dataFile);
      } catch (IOException var8) {
         this.plugin.getLogger().log(Level.SEVERE, "Raid pencere verisi kaydedilemedi.", var8);
      }
   }

   private static UUID parseUuid(String var0) {
      if (var0 != null && !var0.isBlank()) {
         try {
            return UUID.fromString(var0);
         } catch (IllegalArgumentException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   private record RaidWindow(long baseId, UUID ownerUuid, UUID attackerUuid, long expiresAt) {
   }
}
