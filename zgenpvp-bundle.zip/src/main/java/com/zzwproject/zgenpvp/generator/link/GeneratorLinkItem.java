package com.zzwproject.zgenpvp.generator.link;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.util.ArrayList;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GeneratorLinkItem {
   private final ZGenPvP plugin;
   private final NamespacedKey linkerKey;

   public GeneratorLinkItem(ZGenPvP var1) {
      this.plugin = var1;
      this.linkerKey = new NamespacedKey(var1, "generator_linker");
   }

   public ItemStack create() {
      FileConfiguration var1 = this.plugin.getConfigManager().getGenerators();
      String var2 = var1.getString("link-tool.material", "HOPPER");
      Material var3 = var2 == null ? null : Material.matchMaterial(var2);
      if (var3 == null || var3.isAir()) {
         var3 = Material.HOPPER;
      }

      ItemStack var4 = new ItemStack(var3);
      ItemMeta var5 = var4.getItemMeta();
      if (var5 == null) {
         return var4;
      }

      String var6 = var1.getString("link-tool.name", "&#FF8A00Jeneratör Bağlayıcı");
      var5.setDisplayName(ColorUtil.color(var6));
      ArrayList var7 = new ArrayList();

      for (String var9 : var1.getStringList("link-tool.lore")) {
         var7.add(ColorUtil.color(var9));
      }

      var5.setLore(var7);
      int var10 = var1.getInt("link-tool.custom-model-data", 0);
      if (var10 > 0) {
         var5.setCustomModelData(var10);
      }

      var5.getPersistentDataContainer().set(this.linkerKey, PersistentDataType.BYTE, (byte)1);
      var4.setItemMeta(var5);
      return var4;
   }

   public boolean isLinker(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 == null) {
            return false;
         }

         Byte var3 = (Byte)var2.getPersistentDataContainer().get(this.linkerKey, PersistentDataType.BYTE);
         if (var3 != null && var3 == 1) {
            return true;
         }

         FileConfiguration var4 = this.plugin.getConfigManager().getGenerators();
         String var5 = var4.getString("link-tool.material", "HOPPER");
         Material var6 = var5 == null ? Material.HOPPER : Material.matchMaterial(var5);
         if (var6 == null || var6.isAir()) {
            var6 = Material.HOPPER;
         }

         if (var1.getType() == var6 && var2.hasDisplayName()) {
            String var7 = normalizeName(var2.getDisplayName());
            String var8 = normalizeName(ColorUtil.color(var4.getString("link-tool.name", "&#FF8A00Jeneratör Bağlayıcı")));
            return var7.equals(var8) || var7.equals("jeneratör bağlayıcı") || var7.equals("jenerator bağlayıcı") || var7.equals("jenerator baglayici");
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static String normalizeName(String var0) {
      if (var0 == null) {
         return "";
      }

      String var1 = var0.replaceAll("(?i)§x(?:§[0-9a-f]){6}", "")
         .replaceAll("(?i)§[0-9a-fk-or]", "")
         .replaceAll("(?i)&#[0-9a-f]{6}", "")
         .replaceAll("(?i)&[0-9a-fk-or]", "");
      return var1.trim().toLowerCase(Locale.ROOT);
   }
}
