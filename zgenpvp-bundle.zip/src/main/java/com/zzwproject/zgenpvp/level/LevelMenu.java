package com.zzwproject.zgenpvp.level;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class LevelMenu {
   private final ZGenPvP plugin;
   private final LevelManager levelManager;
   private final GeneratorManager generatorManager;

   public LevelMenu(ZGenPvP plugin, LevelManager levelManager, GeneratorManager generatorManager) {
      this.plugin = plugin;
      this.levelManager = levelManager;
      this.generatorManager = generatorManager;
   }

   public void open(Player player) {
      FileConfiguration config = this.plugin.getConfigManager().getLevels();
      int size = this.normalizeSize(config.getInt("menu.size", 27));
      String title = config.getString("menu.title", "&#FF8A00Seviye bilgileri");
      LevelMenu.LevelMenuHolder holder = new LevelMenu.LevelMenuHolder();
      Inventory inventory = Bukkit.createInventory(holder, size, this.component(title));
      holder.setInventory(inventory);
      if (config.getBoolean("menu.filler.enabled", true)) {
         ItemStack filler = this.createSimpleItem(
            config.getString("menu.filler.material", "GRAY_STAINED_GLASS_PANE"), config.getString("menu.filler.name", " "), List.of()
         );

         for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
         }
      }

      int level = this.levelManager.getLevel(player.getUniqueId());
      double xp = this.levelManager.getXp(player.getUniqueId());
      double required = this.levelManager.getRequiredXp(level);
      double percentage = this.levelManager.getXpPercentage(player.getUniqueId());
      int generators = this.generatorManager.countGenerators(player.getUniqueId());
      int generatorLimit = this.generatorManager.getGeneratorLimit(level);
      int remaining = Math.max(0, generatorLimit - generators);
      String[] replacements = new String[]{
         "%level%",
         String.valueOf(level),
         "%max_level%",
         String.valueOf(this.levelManager.getMaxLevel()),
         "%xp%",
         this.format(xp),
         "%required_xp%",
         level >= this.levelManager.getMaxLevel() ? "MAX" : this.format(required),
         "%percentage%",
         this.format(percentage),
         "%progress_bar%",
         this.createProgressBar(percentage),
         "%generators%",
         String.valueOf(generators),
         "%generator_limit%",
         String.valueOf(generatorLimit),
         "%generator_remaining%",
         String.valueOf(remaining)
      };
      this.setConfiguredItem(inventory, "menu.items.level", replacements);
      this.setConfiguredItem(inventory, "menu.items.xp", replacements);
      this.setConfiguredItem(inventory, "menu.items.generator", replacements);
      this.setConfiguredItem(inventory, "menu.items.rewards", replacements);
      this.setConfiguredItem(inventory, "menu.items.close", replacements);
      player.openInventory(inventory);
   }

   public boolean isLevelMenu(Inventory inventory) {
      return inventory != null && inventory.getHolder() instanceof LevelMenu.LevelMenuHolder;
   }

   public int getCloseSlot() {
      return this.plugin.getConfigManager().getLevels().getInt("menu.items.close.slot", 22);
   }

   private void setConfiguredItem(Inventory inventory, String path, String[] replacements) {
      FileConfiguration config = this.plugin.getConfigManager().getLevels();
      int slot = config.getInt(path + ".slot", -1);
      if (slot >= 0 && slot < inventory.getSize()) {
         String materialName = config.getString(path + ".material", "STONE");
         Material material = Material.matchMaterial(materialName == null ? "STONE" : materialName);
         if (material == null) {
            material = Material.STONE;
         }

         ItemStack item = new ItemStack(material);
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            String name = this.replace(config.getString(path + ".name", ""), replacements);
            meta.displayName(this.component(name));
            List<Component> lore = new ArrayList<>();

            for (String line : config.getStringList(path + ".lore")) {
               lore.add(this.component(this.replace(line, replacements)));
            }

            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(slot, item);
         }
      }
   }

   private ItemStack createSimpleItem(String materialName, String name, List<String> loreLines) {
      Material material = Material.matchMaterial(materialName == null ? "STONE" : materialName);
      if (material == null) {
         material = Material.STONE;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.displayName(this.component(name));
      List<Component> lore = new ArrayList<>();

      for (String line : loreLines) {
         lore.add(this.component(line));
      }

      meta.lore(lore);
      item.setItemMeta(meta);
      return item;
   }

   private String createProgressBar(double percentage) {
      int totalBars = 20;
      int filled = (int)Math.round(Math.max(0.0, Math.min(100.0, percentage)) / 100.0 * totalBars);
      StringBuilder builder = new StringBuilder();

      for (int index = 0; index < totalBars; index++) {
         if (index < filled) {
            builder.append("&a■");
         } else {
            builder.append("&7■");
         }
      }

      return builder.toString();
   }

   private int normalizeSize(int size) {
      int normalized = Math.max(9, Math.min(54, size));
      if (normalized % 9 != 0) {
         normalized = (normalized + 8) / 9 * 9;
      }

      return Math.min(54, normalized);
   }

   private Component component(String text) {
      return LegacyComponentSerializer.legacySection().deserialize(ColorUtil.color(text == null ? "" : text));
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private String format(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }

   private static final class LevelMenuHolder implements InventoryHolder {
      private Inventory inventory;

      private void setInventory(Inventory inventory) {
         this.inventory = inventory;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }
}
