package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BeaconData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class BeaconSpawnMenuListener implements Listener {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final BeaconSpawnMenu menu;
   private final BeaconMenu beaconMenu;

   public BeaconSpawnMenuListener(ZGenPvP var1, BeaconManager var2, BeaconSpawnMenu var3, BeaconMenu var4) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.menu = var3;
      this.beaconMenu = var4;
   }

   public BeaconSpawnMenuListener(ZGenPvP var1, BeaconManager var2, BeaconSpawnMenu var3) {
      this(var1, var2, var3, var1.getBeaconMenu());
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      if (this.menu.isMenu(var2)) {
         var1.setCancelled(true);
         if (var1.getWhoClicked() instanceof Player var3) {
            if (var1.getRawSlot() >= 0 && var1.getRawSlot() < var2.getSize()) {
               ItemStack var9 = var1.getCurrentItem();
               String var5 = this.menu.getAction(var9);
               if (var5 != null) {
                  if (var5.equals("SPAWN")) {
                     if (var1.isRightClick()) {
                        this.beaconManager.selectServerSpawn(var3);
                        this.menu.open(var3);
                     } else {
                        var3.closeInventory();
                        this.beaconManager.startServerRespawn(var3);
                     }
                  } else if (var5.equals("BEACON")) {
                     long var6 = this.menu.getBeaconId(var9);
                     BeaconData var8 = this.beaconManager.getBeacon(var6).orElse(null);
                     if (var8 == null || !var3.getUniqueId().equals(var8.getOwnerUuid())) {
                        this.plugin.getMessageUtil().send(var3, "beacon.not-found");
                        if (this.menu.isManagementMenu(var2)) {
                           this.menu.openManagement(var3);
                        } else {
                           this.menu.open(var3);
                        }
                     } else if (this.menu.isManagementMenu(var2)) {
                        this.beaconMenu.open(var3, var8);
                     } else {
                        if (var1.isRightClick()) {
                           this.beaconManager.selectBeaconSpawn(var3, var8);
                           this.menu.open(var3);
                        } else {
                           var3.closeInventory();
                           this.beaconManager.startRespawn(var3, var8);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent var1) {
      if (this.menu.isMenu(var1.getView().getTopInventory())) {
         int var2 = var1.getView().getTopInventory().getSize();

         for (int var4 : var1.getRawSlots()) {
            if (var4 >= 0 && var4 < var2) {
               var1.setCancelled(true);
               return;
            }
         }
      }
   }
}
