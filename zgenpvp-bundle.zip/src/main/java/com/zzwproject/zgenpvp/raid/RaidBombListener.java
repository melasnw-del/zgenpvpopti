package com.zzwproject.zgenpvp.raid;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.integration.RaidSessionBridge;
import java.lang.reflect.Field;
import java.util.Locale;
import java.util.Optional;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;

public final class RaidBombListener implements Listener {
   private final ZGenPvP plugin;
   private final RaidBombManager raidBombManager;

   public RaidBombListener(ZGenPvP var1, RaidBombManager var2) {
      this.plugin = var1;
      this.raidBombManager = var2;
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      Optional var2 = this.raidBombManager.getBombType(var1.getItemInHand());
      if (var2.isEmpty()) {
         if (this.raidBombManager.hasActiveBombAt(var1.getBlockPlaced().getLocation())) {
            var1.setCancelled(true);
         }
      } else if (!RaidSessionBridge.handleRaidBombPlace(var1)) {
         var1.setCancelled(true);
         final Location var3 = var1.getBlockPlaced().getLocation().clone();
         final RaidBombType var4 = (RaidBombType)var2.get();
         this.raidBombManager.queuePlant(var1.getPlayer(), var3, var4);
         (new BukkitRunnable() {
            public void run() {
               if (RaidBombListener.this.raidBombManager.hasActiveBombAt(var3)) {
                  RaidBombListener.this.startCosmetics(var3, var4);
               }
            }
         }).runTaskLater(this.plugin, 2L);
      }
   }

   private void startCosmetics(final Location var1, final RaidBombType var2) {
      final FileConfiguration var3 = this.plugin.getConfigManager().getRaid();
      if (var3.getBoolean("effects.enabled", true)) {
         final String var4 = "effects.tiers." + var2.getId() + ".";
         if (var3.getBoolean(var4 + "enabled", true)) {
            final int var5 = clamp(var3.getInt(var4 + "interval-ticks", defaultInterval(var2)), 2, 20);
            final int var6 = Math.max(1, this.raidBombManager.getFuseSeconds(var2)) * 20;
            this.playPlacement(var1, var2, var3, var4);
            (new BukkitRunnable() {
               private int elapsed;
               private int pulse;

               public void run() {
                  this.elapsed = this.elapsed + var5;
                  this.pulse++;
                  if (!RaidBombListener.this.raidBombManager.hasActiveBombAt(var1)) {
                     if (this.elapsed >= Math.max(4, var6 - var5 * 3)) {
                        RaidBombListener.this.playExplosion(var1, var2, var3, var4);
                     }

                     this.cancel();
                  } else if (this.elapsed > var6 + 40) {
                     this.cancel();
                  } else {
                     RaidBombListener.this.playFusePulse(var1, var2, var3, var4, this.pulse, this.elapsed, var6);
                  }
               }
            }).runTaskTimer(this.plugin, var5, var5);
         }
      }
   }

   private void playPlacement(Location var1, RaidBombType var2, FileConfiguration var3, String var4) {
      World var5 = var1.getWorld();
      if (var5 != null) {
         Particle var6 = resolve(Particle.class, var3.getString(var4 + "accent-particle", defaultAccent(var2)));
         if (var6 != null) {
            double var7 = Math.max(0.5, var3.getDouble(var4 + "ring-radius", defaultRadius(var2)) * 0.65);
            int var9 = clamp(var3.getInt(var4 + "ring-points", defaultPoints(var2)), 8, 64);
            ring(var5, var1, var6, var7, var9, 0.18);
         }

         Sound var10 = resolve(Sound.class, var3.getString(var4 + "sound", defaultFuseSound(var2)));
         if (var10 != null) {
            var5.playSound(center(var1, 0.35), var10, (float)var3.getDouble(var4 + "volume", 0.8), (float)var3.getDouble(var4 + "pitch", defaultPitch(var2)));
         }
      }
   }

   private void playFusePulse(Location var1, RaidBombType var2, FileConfiguration var3, String var4, int var5, int var6, int var7) {
      World var8 = var1.getWorld();
      if (var8 != null) {
         Particle var9 = resolve(Particle.class, var3.getString(var4 + "fuse-particle", defaultFuseParticle(var2)));
         Particle var10 = resolve(Particle.class, var3.getString(var4 + "accent-particle", defaultAccent(var2)));
         double var11 = Math.max(0.25, var3.getDouble(var4 + "height", defaultHeight(var2)));
         Location var13 = center(var1, 0.45 + Math.min(var11, (double)var6 / Math.max(1, var7) * var11));
         if (var9 != null) {
            int var14 = 1 + var2.getId();
            var8.spawnParticle(var9, var13, var14, 0.18 + var2.getId() * 0.05, 0.1, 0.18 + var2.getId() * 0.05, 0.0);
         }

         if (var10 != null) {
            double var17 = var3.getDouble(var4 + "ring-radius", defaultRadius(var2));
            int var16 = clamp(var3.getInt(var4 + "ring-points", defaultPoints(var2)), 8, 64);
            if (var2.getId() == 1) {
               if ((var5 & 1) == 0) {
                  ring(var8, var1, var10, var17 * 0.55, Math.max(8, var16 / 2), 0.28);
               }
            } else if (var2.getId() == 2) {
               ring(var8, var1, var10, var17 * 0.65, Math.max(10, var16 / 2), 0.28 + var5 % 3 * 0.08);
            } else {
               ring(var8, var1, var10, var17 * 0.7, var16, 0.25 + var5 % 4 * 0.13);
               var8.spawnParticle(var10, center(var1, 0.35 + var5 % 5 * 0.2), 2, 0.05, 0.05, 0.05, 0.0);
            }
         }
      }
   }

   private void playExplosion(Location var1, RaidBombType var2, FileConfiguration var3, String var4) {
      World var5 = var1.getWorld();
      if (var5 != null) {
         Particle var6 = resolve(Particle.class, var3.getString(var4 + "explosion-particle", defaultExplosion(var2)));
         Particle var7 = resolve(Particle.class, var3.getString(var4 + "ring-particle", defaultRing(var2)));
         Particle var8 = resolve(Particle.class, var3.getString(var4 + "accent-particle", defaultAccent(var2)));
         Location var9 = center(var1, 0.55);
         if (var6 != null) {
            int var10 = var2.getId() == 3 ? 1 : 3 + var2.getId() * 2;
            var5.spawnParticle(var6, var9, var10, 0.35 * var2.getId(), 0.25, 0.35 * var2.getId(), 0.05);
         }

         double var14 = Math.max(1.0, var3.getDouble(var4 + "ring-radius", defaultRadius(var2)));
         int var12 = clamp(var3.getInt(var4 + "ring-points", defaultPoints(var2)), 8, 64);
         if (var7 != null) {
            ring(var5, var1, var7, var14, var12, 0.3);
            if (var2.getId() >= 2) {
               ring(var5, var1, var7, var14 * 0.62, Math.max(10, var12 - 6), 0.72);
            }

            if (var2.getId() >= 3) {
               ring(var5, var1, var7, var14 * 1.18, Math.min(64, var12 + 8), 0.48);
            }
         }

         if (var8 != null && var2.getId() == 3) {
            for (int var13 = 0; var13 < 5; var13++) {
               var5.spawnParticle(var8, center(var1, 0.35 + var13 * 0.3), 4, 0.18 + var13 * 0.03, 0.08, 0.18 + var13 * 0.03, 0.0);
            }
         }

         Sound var15 = resolve(Sound.class, var3.getString(var4 + "explosion-sound", "ENTITY_GENERIC_EXPLODE"));
         if (var15 != null) {
            var5.playSound(var9, var15, (float)var3.getDouble(var4 + "volume", 1.0), (float)var3.getDouble(var4 + "pitch", defaultExplosionPitch(var2)));
         }
      }
   }

   private static void ring(World var0, Location var1, Particle var2, double var3, int var5, double var6) {
      for (int var8 = 0; var8 < var5; var8++) {
         double var9 = (Math.PI * 2) * var8 / var5;
         double var11 = 0.5 + Math.cos(var9) * var3;
         double var13 = 0.5 + Math.sin(var9) * var3;
         Location var15 = var1.clone().add(var11, var6, var13);
         var0.spawnParticle(var2, var15, 1, 0.0, 0.0, 0.0, 0.0);
      }
   }

   private static Location center(Location var0, double var1) {
      return var0.clone().add(0.5, var1, 0.5);
   }

   private static <T> T resolve(Class<T> var0, String var1) {
      if (var1 != null && !var1.isBlank()) {
         String var2 = var1.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');

         try {
            Field var3 = var0.getField(var2);
            Object var4 = var3.get(null);
            return (T)(var0.isInstance(var4) ? var0.cast(var4) : null);
         } catch (ReflectiveOperationException var5) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static int clamp(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   private static int defaultInterval(RaidBombType var0) {
      return var0.getId() == 1 ? 8 : (var0.getId() == 2 ? 6 : 4);
   }

   private static int defaultPoints(RaidBombType var0) {
      return var0.getId() == 1 ? 18 : (var0.getId() == 2 ? 24 : 32);
   }

   private static double defaultRadius(RaidBombType var0) {
      return var0.getId() == 1 ? 1.7 : (var0.getId() == 2 ? 2.5 : 3.4);
   }

   private static double defaultHeight(RaidBombType var0) {
      return var0.getId() == 1 ? 0.55 : (var0.getId() == 2 ? 0.8 : 1.15);
   }

   private static float defaultPitch(RaidBombType var0) {
      return var0.getId() == 1 ? 1.25F : (var0.getId() == 2 ? 1.0F : 0.75F);
   }

   private static float defaultExplosionPitch(RaidBombType var0) {
      return var0.getId() == 1 ? 1.15F : (var0.getId() == 2 ? 0.9F : 0.7F);
   }

   private static String defaultFuseParticle(RaidBombType var0) {
      return var0.getId() == 3 ? "LARGE_SMOKE" : "SMOKE";
   }

   private static String defaultAccent(RaidBombType var0) {
      return var0.getId() == 1 ? "END_ROD" : "ELECTRIC_SPARK";
   }

   private static String defaultExplosion(RaidBombType var0) {
      return var0.getId() == 3 ? "EXPLOSION_EMITTER" : "EXPLOSION";
   }

   private static String defaultRing(RaidBombType var0) {
      return var0.getId() == 1 ? "CRIT" : (var0.getId() == 2 ? "FLAME" : "END_ROD");
   }

   private static String defaultFuseSound(RaidBombType var0) {
      return var0.getId() == 3 ? "BLOCK_BEACON_POWER_SELECT" : "BLOCK_NOTE_BLOCK_HAT";
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.raidBombManager.getBombType(var1.getItem());
            if (!var3.isEmpty()) {
               var1.setCancelled(true);
               Location var4 = var2.getRelative(var1.getBlockFace()).getLocation();
               this.raidBombManager.queuePlant(var1.getPlayer(), var4, (RaidBombType)var3.get());
            }
         }
      }
   }
}
