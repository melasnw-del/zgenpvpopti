package com.zzwproject.zgenpvp.model;

import com.zzwproject.zgenpvp.hotfix.NameSanitizer;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class BeaconData {
   private final long id;
   private final UUID ownerUuid;
   private String name;
   private final String worldName;
   private final int x;
   private final int y;
   private final int z;

   public BeaconData(long id, UUID ownerUuid, String name, String worldName, int x, int y, int z) {
      this.id = id;
      this.ownerUuid = ownerUuid;
      this.name = name;
      this.worldName = worldName;
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public long getId() {
      return this.id;
   }

   public UUID getOwnerUuid() {
      return this.ownerUuid;
   }

   public String getName() {
      return NameSanitizer.sanitize(this.ownerUuid, this.name);
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public Location getLocation() {
      World world = Bukkit.getWorld(this.worldName);
      return world == null ? null : new Location(world, this.x, this.y, this.z);
   }

   public Location getTeleportLocation() {
      Location location = this.getLocation();
      return location == null ? null : location.clone().add(0.5, 1.1, 0.5);
   }
}
