package com.zzwproject.zgenpvp.effects;

import com.zzwproject.zgenpvp.ZGenPvP;
import org.bukkit.event.HandlerList;

public final class EffectBootstrap {
   private static EffectSettings settings;
   private static EffectListener listener;

   private EffectBootstrap() {
   }

   public static synchronized void enable(ZGenPvP var0) {
      if (listener == null) {
         settings = new EffectSettings(var0);
         EffectPlayer var1 = new EffectPlayer(var0, settings);
         listener = new EffectListener(var0, var1);
         var0.getServer().getPluginManager().registerEvents(listener, var0);
         var0.getLogger().info("V2 animasyon ve efekt sistemi aktif.");
      }
   }

   public static synchronized void reload(ZGenPvP var0) {
      if (settings == null) {
         enable(var0);
      } else {
         settings.reload();
         var0.getLogger().info("V2 effects.yml yeniden yuklendi.");
      }
   }

   public static synchronized void disable(ZGenPvP var0) {
      if (listener != null) {
         HandlerList.unregisterAll(listener);
      }

      listener = null;
      settings = null;
   }
}
