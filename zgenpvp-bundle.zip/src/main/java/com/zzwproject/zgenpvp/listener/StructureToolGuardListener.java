package com.zzwproject.zgenpvp.listener;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.hotfix.CityMapHardGuard;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.ZGenMapPlacementGuard;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.repository.PlacedBlockRepository;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.lang.reflect.Method;
import java.util.Optional;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class StructureToolGuardListener implements Listener {
   private final ZGenPvP plugin;
   private final PlacedBlockRepository placedBlocks;
   private boolean lateCompatibilityRegistered;

   public StructureToolGuardListener(ZGenPvP var1) {
      this.plugin = var1;
      this.placedBlocks = new PlacedBlockRepository(var1.getDatabaseManager());
      this.placedBlocks.loadCache();
      var1.getLogger().info(this.placedBlocks.size() + " oyuncu yerleştirmesi takip ediliyor.");
      Bukkit.getPluginManager().registerEvents(new StructureToolGuardListener.LateBuildCompatibility(), var1);
   }

   @EventHandler
   public void onServerLoad(ServerLoadEvent var1) {
      if (!this.lateCompatibilityRegistered) {
         this.lateCompatibilityRegistered = true;
         Bukkit.getPluginManager().registerEvents(new StructureToolGuardListener.LateBuildCompatibility(), this.plugin);
         this.plugin.getLogger().info("Geç Survival build uyumluluk katmanı aktif.");
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onAnimation(PlayerAnimationEvent var1) {
      StructureMiningUtil.markSwing(var1.getPlayer());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      if ((this.plugin.getGeneratorManager() == null || !this.plugin.getGeneratorManager().getGenerator(var1.getBlock().getLocation()).isPresent())
         && this.isProtectedStructure(var1.getBlock())
         && !this.usesVanillaBreakTiming(var1.getBlock())
         && !this.isPickaxe(var1.getPlayer())) {
         CityMapHardGuard.setCancelledSafely(var1, true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onProtectedBreak(BlockBreakEvent var1) {
      if ((this.plugin.getGeneratorManager() == null || !this.plugin.getGeneratorManager().getGenerator(var1.getBlock().getLocation()).isPresent())
         && this.isProtectedStructure(var1.getBlock())
         && !this.usesVanillaBreakTiming(var1.getBlock())
         && !this.isPickaxe(var1.getPlayer())) {
         CityMapHardGuard.setCancelledSafely(var1, true);
         var1.setDropItems(false);
         var1.setExpToDrop(0);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onNormalDamageCompatibility(BlockDamageEvent var1) {
      Block var2 = var1.getBlock();
      if (!this.isPluginStructure(var2) && this.canBreakNormalBlock(var1.getPlayer(), var2)) {
         CityMapHardGuard.setCancelledSafely(var1, false);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onPlace(BlockPlaceEvent var1) {
      Block var2 = var1.getBlockPlaced();
      ItemStack var3 = var1.getItemInHand();
      if (this.canForceNormalBuildAt(var1.getPlayer(), var2.getLocation())) {
         var1.setBuild(true);
      }

      if (this.plugin.getRaidBombManager() == null || !this.plugin.getRaidBombManager().getBombType(var3).isPresent()) {
         boolean var4 = this.isSpecialPlacementItem(var3);
         if (var1.isCancelled()) {
            if (var4) {
               if (!this.canForceSpecialPlacementAt(var1.getPlayer(), var2.getLocation())) {
                  return;
               }

               if (!this.recoverSpecialPlacement(var1)) {
                  return;
               }

               var1.setCancelled(false);
               return;
            }

            if (!this.canForceNormalBuildAt(var1.getPlayer(), var2.getLocation())) {
               return;
            }

            var1.setCancelled(false);
         }

         if (!var4 && !this.isPluginStructure(var2)) {
            this.placedBlocks.track(var2.getLocation(), var1.getPlayer().getUniqueId());
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onMultiPlace(BlockMultiPlaceEvent var1) {
      for (BlockState var3 : var1.getReplacedBlockStates()) {
         if (var3 != null) {
            Block var4 = var3.getBlock();
            if (!this.isPluginStructure(var4)) {
               this.placedBlocks.track(var4.getLocation(), var1.getPlayer().getUniqueId());
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onNormalBreakPermission(BlockBreakEvent var1) {
      Block var2 = var1.getBlock();
      if (!this.isPluginStructure(var2) && this.canBreakNormalBlock(var1.getPlayer(), var2)) {
         CityMapHardGuard.setCancelledSafely(var1, false);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onNormalBreakCleanup(BlockBreakEvent var1) {
      if (!this.isPluginStructure(var1.getBlock())) {
         this.placedBlocks.remove(var1.getBlock().getLocation());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onEntityExplode(EntityExplodeEvent var1) {
      this.placedBlocks.removeBlocks(var1.blockList());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onBlockExplode(BlockExplodeEvent var1) {
      this.placedBlocks.removeBlocks(var1.blockList());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onBurn(BlockBurnEvent var1) {
      this.placedBlocks.remove(var1.getBlock().getLocation());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onFade(BlockFadeEvent var1) {
      this.placedBlocks.remove(var1.getBlock().getLocation());
   }

   private boolean recoverSpecialPlacement(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      Player var2 = var1.getPlayer();
      Block var3 = var1.getBlockPlaced();
      Location var4 = var3.getLocation();
      ItemStack var5 = var1.getItemInHand();
      if (this.plugin.getItemFactory().isRespawnBeacon(var5)) {
         boolean var11 = this.plugin.getBeaconManager().getBeacon(var4).isPresent() ? true : this.plugin.getBeaconManager().createBeacon(var2, var4);
         StructureSupportGuard.restore(this, var1);
         return var11;
      }

      if (this.plugin.getItemFactory().isBaseBlock(var5)) {
         boolean var10 = this.plugin.getBaseManager().getBase(var4).isPresent() ? true : this.plugin.getBaseManager().createBase(var2, var4);
         StructureSupportGuard.restore(this, var1);
         return var10;
      }

      if (this.plugin.getGeneratorManager().isGeneratorItem(var5)) {
         boolean var9 = this.plugin.getGeneratorManager().getGenerator(var4).isPresent()
            ? true
            : this.plugin.getGeneratorManager().place(var2, var4, this.plugin.getGeneratorManager().getGeneratorItemLevel(var5));
         StructureSupportGuard.restore(this, var1);
         return var9;
      }

      if (this.plugin.getItemFactory().isDefenseBlock(var5)) {
         boolean var8 = this.plugin.getDefenseManager().getDefense(var4).isPresent()
            ? true
            : this.plugin
               .getDefenseManager()
               .place(var2, var4, this.plugin.getItemFactory().getDefenseType(var5), this.plugin.getItemFactory().getDefenseLevel(var5));
         StructureSupportGuard.restore(this, var1);
         return var8;
      }

      if (this.plugin.getItemFactory().isTurret(var5)) {
         boolean var7 = this.plugin.getTurretManager().getTurret(var4).isPresent()
            ? true
            : this.plugin.getTurretManager().place(var2, var4, this.plugin.getItemFactory().getTurretLevel(var5));
         StructureSupportGuard.restore(this, var1);
         return var7;
      }

      DefenseAccessType var6 = null;
      if (this.plugin.getItemFactory().isDefenseDoor(var5)) {
         var6 = DefenseAccessType.DOOR;
      } else if (this.plugin.getItemFactory().isDefenseTrapdoor(var5)) {
         var6 = DefenseAccessType.TRAPDOOR;
      }

      if (var6 != null) {
         boolean var10000 = this.plugin.getDefenseAccessManager().get(var3).isPresent()
            ? true
            : this.plugin.getDefenseAccessManager().place(var2, var3, var6, this.plugin.getItemFactory().getAccessLevel(var5));
         StructureSupportGuard.restore(this, var1);
         return var10000;
      } else {
         StructureSupportGuard.restore(this, var1);
         return false;
      }
   }

   private boolean isSpecialPlacementItem(ItemStack var1) {
      return var1 != null && !var1.getType().isAir()
         ? this.plugin.getItemFactory().isRespawnBeacon(var1)
            || this.plugin.getItemFactory().isBaseBlock(var1)
            || this.plugin.getGeneratorManager().isGeneratorItem(var1)
            || this.plugin.getGeneratorLinkItem() != null && this.plugin.getGeneratorLinkItem().isLinker(var1)
            || this.plugin.getItemFactory().isDefenseBlock(var1)
            || this.plugin.getItemFactory().isTurret(var1)
            || this.plugin.getItemFactory().isDefenseDoor(var1)
            || this.plugin.getItemFactory().isDefenseTrapdoor(var1)
         : false;
   }

   private boolean canBreakNormalBlock(Player var1, Block var2) {
      if (ZGenMapPlacementGuard.canAdminBreakInSpawn(var1, var2)) {
         return true;
      }

      if (var1 != null && var2 != null && !var2.getType().isAir()) {
         Location var3 = var2.getLocation();
         StructureToolGuardListener.ZGenMapState var4 = this.queryZGenMap(var3);
         if (var4.managed()) {
            if (var4.spawnProtected()) {
               return false;
            } else {
               return this.placedBlocks.isTracked(var3) ? true : !this.isGeneratedMapBlock(var2);
            }
         } else if (this.placedBlocks.isTracked(var3)) {
            return true;
         } else {
            return !this.canForceNormalBuildAt(var1, var3) ? false : !this.isGeneratedMapBlock(var2);
         }
      } else {
         return false;
      }
   }

   private boolean canForceNormalBuildAt(Player var1, Location var2) {
      if (ZGenMapPlacementGuard.canAdminBuildInSpawn(var1, var2)) {
         return true;
      }

      if (var1 != null && var2 != null && var2.getWorld() != null) {
         StructureToolGuardListener.ZGenMapState var3 = this.queryZGenMap(var2);
         if (var3.managed()) {
            return !var3.spawnProtected();
         } else if (this.plugin.getBaseRepository() != null && this.plugin.getBaseManager() != null) {
            Optional var4 = this.plugin.getBaseRepository().findContaining(var2);
            return var4.isPresent() && this.plugin.getBaseManager().canManageBase(var1, (BaseData)var4.get());
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean canForceSpecialPlacementAt(Player var1, Location var2) {
      if (ZGenMapPlacementGuard.canAdminBuildInSpawn(var1, var2)) {
         return true;
      }

      if (var1 != null && var2 != null && var2.getWorld() != null) {
         StructureToolGuardListener.ZGenMapState var3 = this.queryZGenMap(var2);
         if (var3.managed() && !var3.baseArea()) {
            return false;
         }

         if (this.plugin.getBaseRepository() != null && this.plugin.getBaseManager() != null) {
            Optional var4 = this.plugin.getBaseRepository().findContaining(var2);
            if (var4.isPresent() && !this.plugin.getBaseManager().canManageBase(var1, (BaseData)var4.get())) {
               return false;
            }
         }

         if (var3.managed()) {
            return true;
         } else if (this.plugin.getBaseRepository() != null && this.plugin.getBaseManager() != null) {
            Optional var5 = this.plugin.getBaseRepository().findContaining(var2);
            return var5.isPresent() && this.plugin.getBaseManager().canManageBase(var1, (BaseData)var5.get());
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isGeneratedMapBlock(Block var1) {
      if (var1 == null) {
         return false;
      }

      try {
         Plugin var2 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var2 == null) {
            return false;
         }

         Method var3 = var2.getClass().getMethod("getWorldManager");
         Object var4 = var3.invoke(var2);
         if (var4 == null) {
            return false;
         }

         Method var5 = var4.getClass().getMethod("isManagedWorld", World.class);
         Object var6 = var5.invoke(var4, var1.getWorld());
         if (!Boolean.TRUE.equals(var6)) {
            return false;
         }

         Method var7 = var4.getClass().getMethod("getGenerator");
         Object var8 = var7.invoke(var4);
         if (var8 == null) {
            return false;
         }

         Method var9 = var8.getClass().getMethod("isGeneratedProtectedBlock", Block.class);
         return Boolean.TRUE.equals(var9.invoke(var8, var1));
      } catch (Throwable var10) {
         return false;
      }
   }

   private StructureToolGuardListener.ZGenMapState queryZGenMap(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         Plugin var2 = Bukkit.getPluginManager().getPlugin("ZGenMap");
         if (var2 == null) {
            return StructureToolGuardListener.ZGenMapState.NOT_MANAGED;
         }

         boolean var3 = false;
         boolean var4 = false;
         boolean var5 = false;

         try {
            Method var6 = var2.getClass().getMethod("getApi");
            Object var7 = var6.invoke(var2);
            if (var7 != null) {
               Method var8 = var7.getClass().getMethod("isManagedWorld", World.class);
               var3 = Boolean.TRUE.equals(var8.invoke(var7, var1.getWorld()));
               if (var3) {
                  try {
                     Method var9 = var7.getClass().getMethod("isBaseArea", Location.class);
                     var4 = Boolean.TRUE.equals(var9.invoke(var7, var1));
                  } catch (Throwable var14) {
                  }
               }
            }
         } catch (Throwable var15) {
         }

         if (!var3) {
            var3 = this.isConfiguredZGenMapWorld(var2, var1);
         }

         if (!var3) {
            return StructureToolGuardListener.ZGenMapState.NOT_MANAGED;
         }

         try {
            Method var17 = var2.getClass().getMethod("getWorldManager");
            Object var18 = var17.invoke(var2);
            if (var18 != null) {
               Method var19 = var18.getClass().getMethod("getGenerator");
               Object var20 = var19.invoke(var18);
               if (var20 != null) {
                  try {
                     Method var10 = var20.getClass().getMethod("isSpawnBuildProtected", Location.class);
                     var5 = Boolean.TRUE.equals(var10.invoke(var20, var1));
                  } catch (Throwable var12) {
                     var5 = this.isSpawnProtectedByConfig(var2, var1);
                  }

                  if (!var4) {
                     try {
                        Method var21 = var20.getClass().getMethod("isBaseArea", Location.class);
                        var4 = Boolean.TRUE.equals(var21.invoke(var20, var1));
                     } catch (Throwable var11) {
                     }
                  }
               } else {
                  var5 = this.isSpawnProtectedByConfig(var2, var1);
               }
            } else {
               var5 = this.isSpawnProtectedByConfig(var2, var1);
            }
         } catch (Throwable var13) {
            var5 = this.isSpawnProtectedByConfig(var2, var1);
         }

         return new StructureToolGuardListener.ZGenMapState(true, var4, var5);
      } else {
         return StructureToolGuardListener.ZGenMapState.NOT_MANAGED;
      }
   }

   private boolean isConfiguredZGenMapWorld(Plugin var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         String var3 = "genpvp_city";

         try {
            Method var4 = var1.getClass().getMethod("getConfig");
            Object var5 = var4.invoke(var1);
            if (var5 != null) {
               Method var6 = var5.getClass().getMethod("getString", String.class, String.class);
               if (var6.invoke(var5, "world.name", var3) instanceof String var8 && !var8.isBlank()) {
                  var3 = var8;
               }
            }
         } catch (Throwable var9) {
         }

         return var2.getWorld().getName().equalsIgnoreCase(var3);
      } else {
         return false;
      }
   }

   private boolean isSpawnProtectedByConfig(Plugin var1, Location var2) {
      if (var2 != null && var2.getWorld() != null) {
         int var3 = 34;

         try {
            Method var4 = var1.getClass().getMethod("getConfig");
            Object var5 = var4.invoke(var1);
            if (var5 != null) {
               Method var6 = var5.getClass().getMethod("getInt", String.class, int.class);
               if (var6.invoke(var5, "spawn.build-protection-radius", var3) instanceof Integer var8) {
                  var3 = Math.max(0, var8);
               }
            }
         } catch (Throwable var9) {
         }

         long var10 = var2.getBlockX();
         long var11 = var2.getBlockZ();
         return var10 * var10 + var11 * var11 <= (long)var3 * var3;
      } else {
         return false;
      }
   }

   private boolean isProtectedStructure(Block var1) {
      if (var1 == null) {
         return false;
      } else {
         Location var2 = var1.getLocation();
         if (this.plugin.getBaseManager() != null && this.plugin.getBaseManager().getBase(var2).isPresent()) {
            return true;
         } else if (this.plugin.getDefenseManager() != null && this.plugin.getDefenseManager().getDefense(var2).isPresent()) {
            return true;
         } else if (this.plugin.getDefenseAccessManager() != null && this.plugin.getDefenseAccessManager().get(var1).isPresent()) {
            return true;
         } else if (this.plugin.getTurretManager() != null && this.plugin.getTurretManager().getTurret(var2).isPresent()) {
            return true;
         } else {
            return this.plugin.getGeneratorManager() != null && this.plugin.getGeneratorManager().getGenerator(var2).isPresent()
               ? true
               : this.plugin.getBeaconManager() != null && this.plugin.getBeaconManager().getBeacon(var2).isPresent();
         }
      }
   }

   private boolean isPluginStructure(Block var1) {
      return this.isProtectedStructure(var1);
   }

   private boolean usesVanillaBreakTiming(Block var1) {
      if (var1 == null) {
         return false;
      } else {
         Location var2 = var1.getLocation();
         if (this.plugin.getBaseManager() != null && this.plugin.getBaseManager().getBase(var2).isPresent()) {
            return true;
         } else if (this.plugin.getDefenseManager() != null && this.plugin.getDefenseManager().getDefense(var2).isPresent()) {
            return true;
         } else {
            return this.plugin.getDefenseAccessManager() != null && this.plugin.getDefenseAccessManager().get(var1).isPresent()
               ? true
               : this.plugin.getTurretManager() != null && this.plugin.getTurretManager().getTurret(var2).isPresent();
         }
      }
   }

   private boolean isPickaxe(Player var1) {
      if (var1 == null) {
         return false;
      }

      Material var2 = var1.getInventory().getItemInMainHand().getType();
      return var2.name().endsWith("_PICKAXE");
   }

   private final class LateBuildCompatibility implements Listener {
      @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
      public void onInteract(PlayerInteractEvent var1) {
         if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block var2 = var1.getClickedBlock();
            if (var2 != null && StructureToolGuardListener.this.plugin.getBeaconManager().getBeacon(var2.getLocation()).isPresent()) {
               var1.setUseInteractedBlock(Result.DENY);
               if (var1.getHand() != EquipmentSlot.HAND) {
                  var1.setUseItemInHand(Result.DENY);
               }

               return;
            }
         }

         if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block var7 = var1.getClickedBlock();
            if (var7 == null) {
               return;
            }

            if (StructureToolGuardListener.this.plugin.getDefenseAccessManager().get(var7).isPresent()) {
               var1.setCancelled(true);
               var1.setUseInteractedBlock(Result.DENY);
               var1.setUseItemInHand(Result.DENY);
               return;
            }
         }

         if (var1.getHand() == EquipmentSlot.HAND) {
            Block var8 = var1.getClickedBlock();
            if (var8 != null) {
               StructureToolGuardListener.ZGenMapState var3 = StructureToolGuardListener.this.queryZGenMap(var8.getLocation());
               if (var3.managed() && !var3.spawnProtected()) {
                  if (var1.getAction() == Action.LEFT_CLICK_BLOCK) {
                     if (!StructureToolGuardListener.this.isPluginStructure(var8)
                        && StructureToolGuardListener.this.canBreakNormalBlock(var1.getPlayer(), var8)) {
                        var1.setCancelled(false);
                        var1.setUseInteractedBlock(Result.ALLOW);
                        var1.setUseItemInHand(Result.DEFAULT);
                     }
                  } else if (var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
                     ItemStack var4 = var1.getItem();
                     if (var4 != null
                        && !var4.getType().isAir()
                        && var4.getType().isBlock()
                        && !StructureToolGuardListener.this.isSpecialPlacementItem(var4)
                        && (
                           StructureToolGuardListener.this.plugin.getRaidBombManager() == null
                              || !StructureToolGuardListener.this.plugin.getRaidBombManager().getBombType(var4).isPresent()
                        )) {
                        Block var5 = var8.getRelative(var1.getBlockFace());
                        StructureToolGuardListener.ZGenMapState var6 = StructureToolGuardListener.this.queryZGenMap(var5.getLocation());
                        if (var6.managed() && !var6.spawnProtected()) {
                           var1.setCancelled(false);
                           var1.setUseItemInHand(Result.ALLOW);
                        }
                     }
                  }
               }
            }
         }
      }

      @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
      public void onDamage(BlockDamageEvent var1) {
         if (!StructureToolGuardListener.this.isPluginStructure(var1.getBlock())
            && StructureToolGuardListener.this.canBreakNormalBlock(var1.getPlayer(), var1.getBlock())) {
            var1.setCancelled(false);
         }
      }

      @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
      public void onBreak(BlockBreakEvent var1) {
         Block var2 = var1.getBlock();
         if (!StructureToolGuardListener.this.isPluginStructure(var2) && StructureToolGuardListener.this.canBreakNormalBlock(var1.getPlayer(), var2)) {
            var1.setCancelled(false);
            var1.setDropItems(true);
            StructureToolGuardListener.this.placedBlocks.remove(var2.getLocation());
         }
      }

      @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
      public void onPlace(BlockPlaceEvent var1) {
         ItemStack var2 = var1.getItemInHand();
         if (StructureToolGuardListener.this.canForceNormalBuildAt(var1.getPlayer(), var1.getBlockPlaced().getLocation())) {
            var1.setBuild(true);
         }

         if (StructureToolGuardListener.this.plugin.getRaidBombManager() == null
            || !StructureToolGuardListener.this.plugin.getRaidBombManager().getBombType(var2).isPresent()) {
            boolean var3 = StructureToolGuardListener.this.isSpecialPlacementItem(var2);
            if (var1.isCancelled()) {
               if (var3) {
                  if (!StructureToolGuardListener.this.canForceSpecialPlacementAt(var1.getPlayer(), var1.getBlockPlaced().getLocation())) {
                     return;
                  }

                  if (!StructureToolGuardListener.this.recoverSpecialPlacement(var1)) {
                     return;
                  }

                  var1.setCancelled(false);
                  return;
               }

               if (!StructureToolGuardListener.this.canForceNormalBuildAt(var1.getPlayer(), var1.getBlockPlaced().getLocation())) {
                  return;
               }

               var1.setCancelled(false);
            }

            if (!var3 && !StructureToolGuardListener.this.isPluginStructure(var1.getBlockPlaced())) {
               StructureToolGuardListener.this.placedBlocks.track(var1.getBlockPlaced().getLocation(), var1.getPlayer().getUniqueId());
            }
         }
      }
   }

   private record ZGenMapState(boolean managed, boolean baseArea, boolean spawnProtected) {
      private static final StructureToolGuardListener.ZGenMapState NOT_MANAGED = new StructureToolGuardListener.ZGenMapState(false, false, false);
   }
}
