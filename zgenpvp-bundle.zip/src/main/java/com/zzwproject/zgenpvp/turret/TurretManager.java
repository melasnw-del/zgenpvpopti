package com.zzwproject.zgenpvp.turret;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.level.XpRewardManager;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.DefenseRepository;
import java.text.DecimalFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class TurretManager {
   public static final String TYPE = "TURRET";
   private final ZGenPvP plugin;
   private final DefenseRepository defenseRepository;
   private final BaseRepository baseRepository;
   private final EconomyManager economyManager;
   private final SpecialItemFactory itemFactory;
   private final XpRewardManager xpRewardManager;
   private final Map<String, DefenseData> turretCache = new HashMap<>();
   private final Map<String, Long> hitCooldowns = new HashMap<>();

   public TurretManager(ZGenPvP var1, DefenseRepository var2, BaseRepository var3, EconomyManager var4, SpecialItemFactory var5, XpRewardManager var6) {
      this.plugin = var1;
      this.defenseRepository = var2;
      this.baseRepository = var3;
      this.economyManager = var4;
      this.itemFactory = var5;
      this.xpRewardManager = var6;
   }

   public void loadCache() {
      this.turretCache.clear();

      for (DefenseData var2 : this.defenseRepository.findAllByType("TURRET")) {
         this.turretCache.put(this.key(var2), var2);
      }

      this.plugin.getLogger().info(this.turretCache.size() + " taret cache'e yuklendi.");
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("modules.turrets", true)
         && this.plugin.getConfigManager().getDefenses().getBoolean("turret.enabled", true);
   }

   public Optional<DefenseData> getTurret(Location var1) {
      return var1 != null && var1.getWorld() != null ? Optional.ofNullable(this.turretCache.get(this.key(var1))) : Optional.empty();
   }

   public Collection<DefenseData> getTurrets() {
      return List.copyOf(this.turretCache.values());
   }

   public boolean canManageTurret(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : TeamPermissionBridge.turretManage(this.plugin.getZTeamHook(), var1, var2);
      }
   }

   public boolean canManageTurret(Player var1, DefenseData var2) {
      return var1 != null && var2 != null ? this.canManageTurret(var2.getOwnerUuid(), var1.getUniqueId()) : false;
   }

   public boolean place(Player var1, Location var2, int var3) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!this.isEnabled()) {
            this.plugin.getMessageUtil().sendActionBar(var1, "turret.disabled");
            return false;
         }

         BaseData var4 = TeamPermissionBridge.findOwnOrTeamBase(this.baseRepository, var1.getUniqueId())
            .filter(var2x -> this.isInsideBase(var2x, var2))
            .orElse(null);
         long var5 = 0L;
         if (var4 != null) {
            if (this.plugin.getBaseEnergyManager() != null && !this.plugin.getBaseEnergyManager().isPowered(var4)) {
               this.plugin.getMessageUtil().sendActionBar(var1, "turret.energy-required");
               this.plugin.getSoundUtil().play(var1, "error");
               return false;
            }

            int var7 = this.defenseRepository.countStructures(var4.getId());
            if (var7 >= var4.getBlockLimit()) {
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(var1, "turret.structure-limit", "%current%", String.valueOf(var7), "%max%", String.valueOf(var4.getBlockLimit()));
               return false;
            }

            var5 = var4.getId();
            var7 = Math.max(1, Math.min(this.getMaxLevel(), var3));
            int var8 = this.getHealth(var7);
            long var9 = this.defenseRepository.create(var5, var1.getUniqueId(), "TURRET", var2, var7, var8);
            if (var9 <= 0L) {
               this.plugin.getMessageUtil().sendActionBar(var1, "turret.place-error");
               return false;
            }

            DefenseData var11 = new DefenseData(
               var9, var5, var1.getUniqueId(), "TURRET", var2.getWorld().getName(), var2.getBlockX(), var2.getBlockY(), var2.getBlockZ(), var7, var8, var8
            );
            this.turretCache.put(this.key(var2), var11);
            var2.getBlock().setType(this.getMaterial(var7), false);
            this.plugin.getMessageUtil().sendActionBar(var1, "turret.placed", "%level%", String.valueOf(var7), "%health%", String.valueOf(var8));
            this.plugin.getSoundUtil().play(var1, "turret-place");
            return true;
         }
      }

      return false;
   }

   public int addArrows(DefenseData var1, int var2) {
      if (var1 != null && var2 > 0) {
         int var3 = this.getArrowCapacity(var1.getLevel());
         int var4 = Math.max(0, var3 - var1.getStoredArrows());
         int var5 = Math.min(var4, var2);
         if (var5 <= 0) {
            return 0;
         }

         int var6 = var1.getStoredArrows() + var5;
         if (!this.defenseRepository.updateStoredArrows(var1.getId(), var6)) {
            return 0;
         }

         var1.setStoredArrows(var6);
         return var5;
      } else {
         return 0;
      }
   }

   public int depositAllArrows(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         int var3 = 0;

         for (ItemStack var7 : var1.getInventory().getStorageContents()) {
            if (var7 != null && var7.getType() == Material.ARROW) {
               var3 += var7.getAmount();
            }
         }

         int var10 = this.addArrows(var2, var3);
         if (var10 <= 0) {
            this.plugin.getMessageUtil().sendActionBar(var1, "turret.ammo-full");
            return 0;
         }

         int var11 = var10;
         ItemStack[] var12 = var1.getInventory().getStorageContents();

         for (int var13 = 0; var13 < var12.length && var11 > 0; var13++) {
            ItemStack var8 = var12[var13];
            if (var8 != null && var8.getType() == Material.ARROW) {
               int var9 = Math.min(var11, var8.getAmount());
               var8.setAmount(var8.getAmount() - var9);
               var11 -= var9;
            }
         }

         var1.getInventory().setStorageContents(var12);
         this.sendArrowDepositActionBar(var1, var2, var10);
         return var10;
      } else {
         return 0;
      }
   }

   public int depositClickedArrows(Player var1, DefenseData var2, ItemStack var3) {
      if (var1 != null && var2 != null && var3 != null && var3.getType() == Material.ARROW) {
         int var4 = this.addArrows(var2, var3.getAmount());
         if (var4 <= 0) {
            this.plugin.getMessageUtil().sendActionBar(var1, "turret.ammo-full");
            return 0;
         } else {
            var3.setAmount(var3.getAmount() - var4);
            this.sendArrowDepositActionBar(var1, var2, var4);
            return var4;
         }
      } else {
         return 0;
      }
   }

   public int buyArrows(Player var1, DefenseData var2, int var3) {
      if (var1 != null && var2 != null) {
         int var4 = Math.max(0, this.getArrowCapacity(var2.getLevel()) - var2.getStoredArrows());
         int var5 = var3 < 0 ? var4 : Math.min(var4, var3);
         if (var5 <= 0) {
            this.plugin.getMessageUtil().sendActionBar(var1, "turret.ammo-full");
            return 0;
         } else {
            double var6 = var5 * this.getArrowPrice();
            if (!this.economyManager.has(var1, var6)) {
               this.plugin.getMessageUtil().sendActionBar(var1, "turret.ammo-not-enough-money", "%price%", this.format(var6));
               return 0;
            } else if (!this.economyManager.withdraw(var1, var6)) {
               return 0;
            } else {
               int var8 = this.addArrows(var2, var5);
               if (var8 <= 0) {
                  this.economyManager.deposit(var1, var6);
                  return 0;
               } else {
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(
                        var1,
                        "turret.ammo-bought",
                        "%amount%",
                        String.valueOf(var8),
                        "%price%",
                        this.format(var6),
                        "%arrows%",
                        String.valueOf(var2.getStoredArrows()),
                        "%capacity%",
                        String.valueOf(this.getArrowCapacity(var2.getLevel()))
                     );
                  return var8;
               }
            }
         }
      } else {
         return 0;
      }
   }

   public boolean consumeArrow(DefenseData var1) {
      if (var1 != null && var1.getStoredArrows() > 0) {
         int var2 = var1.getStoredArrows() - 1;
         if (!this.defenseRepository.updateStoredArrows(var1.getId(), var2)) {
            return false;
         }

         var1.setStoredArrows(var2);
         return true;
      } else {
         return false;
      }
   }

   private void sendArrowDepositActionBar(Player var1, DefenseData var2, int var3) {
      this.plugin
         .getMessageUtil()
         .sendActionBar(
            var1,
            "turret.ammo-deposited",
            "%amount%",
            String.valueOf(var3),
            "%arrows%",
            String.valueOf(var2.getStoredArrows()),
            "%capacity%",
            String.valueOf(this.getArrowCapacity(var2.getLevel()))
         );
   }

   public boolean upgrade(Player var1, DefenseData var2) {
      if (var1 == null || var2 == null) {
         return false;
      }

      if (!this.canManageTurret(var1, var2)) {
         this.sendOwnerInfo(var1, var2);
         return false;
      }

      if (var2.getLevel() >= this.getMaxLevel()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "turret.max-level");
         return false;
      }

      double var3 = this.getUpgradePrice(var2.getLevel());
      if (!this.economyManager.has(var1, var3)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "turret.not-enough-money", "%price%", this.format(var3));
         this.plugin.getSoundUtil().play(var1, "error");
         return false;
      }

      if (!this.economyManager.withdraw(var1, var3)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "general.economy-error");
         return false;
      }

      int var5 = var2.getLevel() + 1;
      int var6 = this.getHealth(var5);
      boolean var7 = this.defenseRepository.updateLevel(var2.getId(), var5, var6);
      if (!var7) {
         this.economyManager.deposit(var1, var3);
         this.plugin.getMessageUtil().sendActionBar(var1, "general.database-error");
         return false;
      }

      var2.setLevel(var5);
      var2.setCurrentHp(var6);
      var2.setMaxHp(var6);
      Location var8 = var2.getLocation();
      if (var8 != null && var8.getWorld() != null) {
         var8.getBlock().setType(this.getMaterial(var5), false);
      }

      this.plugin
         .getMessageUtil()
         .sendActionBar(
            var1,
            "turret.upgraded",
            "%level%",
            String.valueOf(var5),
            "%health%",
            String.valueOf(var6),
            "%damage%",
            this.format(this.getDamage(var5)),
            "%range%",
            this.format(this.getRange(var5)),
            "%interval%",
            this.format(this.getAttackIntervalSeconds(var5)),
            "%price%",
            this.format(var3)
         );
      this.plugin.getSoundUtil().play(var1, "turret-upgrade");
      return true;
   }

   public void damage(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            String var3 = var1.getUniqueId() + ":" + var2.getId();
            long var4 = System.currentTimeMillis();
            long var6 = this.plugin.getConfigManager().getDefenses().getLong("turret.attack.hit-cooldown-milliseconds", 120L);
            Long var8 = this.hitCooldowns.get(var3);
            if (var8 == null || var4 - var8 >= var6) {
               this.hitCooldowns.put(var3, var4);
               int var9 = Math.max(1, this.plugin.getConfigManager().getDefenses().getInt("turret.attack.damage-per-hit", 1));
               this.damage(var1, var2, var9, false);
            }
         }
      }
   }

   public void damage(Player var1, DefenseData var2, int var3, boolean var4) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            int var5 = var4 ? var2.getCurrentHp() : Math.max(1, var3);
            int var6 = Math.max(0, var2.getCurrentHp() - var5);
            this.plugin
               .getRaidAlertManager()
               .alert(
                  var2.getOwnerUuid(),
                  var1,
                  "Taret",
                  var2.getLocation(),
                  var2.getLevel(),
                  var6,
                  var2.getMaxHp(),
                  var4 ? "Instabreaker/Bomba" : "oyuncu saldirisi"
               );
            if (var6 > 0) {
               boolean var7 = this.defenseRepository.updateHealth(var2.getId(), var6);
               if (var7) {
                  var2.setCurrentHp(var6);
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(
                        var1,
                        "turret.hit-actionbar",
                        "%health%",
                        String.valueOf(var6),
                        "%max_health%",
                        String.valueOf(var2.getMaxHp()),
                        "%damage%",
                        String.valueOf(var5)
                     );
                  this.plugin.getSoundUtil().play(var1, "turret-hit");
               }
            } else {
               this.destroy(var1, var2);
            }
         }
      }
   }

   public boolean removeByOwner(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!TeamPermissionBridge.turretOwnerOrAllowed(var2.getOwnerUuid(), var1.getUniqueId())) {
            return false;
         }

         boolean var3 = this.defenseRepository.delete(var2.getId());
         if (!var3 && this.defenseRepository.existsById(var2.getId())) {
            return false;
         }

         this.turretCache.remove(this.key(var2));
         boolean var4 = this.plugin.getConfigManager().getDefenses().getBoolean("turret.owner-break.return-item", true);
         if (var4) {
            ItemStack var5 = this.itemFactory.createTurret(var2.getLevel());
            if (var5 != null) {
               HashMap<Integer, ItemStack> var6 = zzw$groundOverflow(var1.getInventory(), new ItemStack[]{var5});

               for (ItemStack var8 : var6.values()) {
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var8);
               }
            }
         }

         if (var2.getStoredArrows() > 0) {
            ItemStack var9 = new ItemStack(Material.ARROW, var2.getStoredArrows());
            HashMap<Integer, ItemStack> var10 = zzw$groundOverflow(var1.getInventory(), new ItemStack[]{var9});

            for (ItemStack var12 : var10.values()) {
               var1.getWorld().dropItemNaturally(var1.getLocation(), var12);
            }
         }

         this.plugin.getMessageUtil().sendActionBar(var1, "turret.removed", "%level%", String.valueOf(var2.getLevel()));
         this.plugin.getSoundUtil().play(var1, "turret-remove");
         return true;
      } else {
         return false;
      }
   }

   public void sendOwnerInfo(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         OfflinePlayer var3 = this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid());
         String var4 = var3.getName() == null ? "Bilinmeyen" : var3.getName();
         this.plugin.getMessageUtil().sendActionBar(var1, "turret.owner-info", "%owner%", var4);
      }
   }

   private void destroy(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            if (this.defenseRepository.delete(var2.getId())) {
               this.turretCache.remove(this.key(var2));
               Location var3 = var2.getLocation();
               if (var3 != null && var3.getWorld() != null) {
                  var3.getBlock().setType(Material.AIR, false);
               }

               this.plugin.getMessageUtil().sendActionBar(var1, "turret.destroyed");
               OfflinePlayer var4 = this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid());
               if (var4.isOnline() && var4.getPlayer() != null) {
                  this.plugin.getMessageUtil().send(var4.getPlayer(), "turret.destroyed-owner", "%attacker%", var1.getName());
               }

               this.plugin.getSoundUtil().play(var1, "turret-break");
               this.xpRewardManager.reward(var1, XpRewardType.TURRET_DESTROY);
            }
         }
      }
   }

   public boolean isFriendly(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().areTeammates(var1, var2);
      }
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!var1.getWorldName().equals(var2.getWorld().getName())) {
            return false;
         }

         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = var1.getRadius();
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   public int getMaxLevel() {
      return Math.max(1, this.plugin.getConfigManager().getDefenses().getInt("turret.max-level", 5));
   }

   public int getHealth(int var1) {
      return this.plugin.getConfigManager().getDefenses().getInt(this.path(var1) + ".health", 150);
   }

   public double getDamage(int var1) {
      return this.plugin.getConfigManager().getDefenses().getDouble(this.path(var1) + ".damage", 4.0);
   }

   public double getRange(int var1) {
      return this.plugin.getConfigManager().getDefenses().getDouble(this.path(var1) + ".range", 12.0);
   }

   public double getAttackIntervalSeconds(int var1) {
      return Math.max(0.1, this.plugin.getConfigManager().getDefenses().getDouble(this.path(var1) + ".attack-interval-seconds", 2.0));
   }

   public double getUpgradePrice(int var1) {
      return this.plugin.getConfigManager().getDefenses().getDouble(this.path(var1) + ".upgrade-price", 0.0);
   }

   public int getArrowCapacity(int var1) {
      return Math.max(
         1,
         this.plugin
            .getConfigManager()
            .getDefenses()
            .getInt(this.path(var1) + ".arrow-capacity", this.plugin.getConfigManager().getDefenses().getInt("turret.ammo.capacity", 64))
      );
   }

   public double getArrowPrice() {
      return Math.max(0.0, this.plugin.getConfigManager().getDefenses().getDouble("turret.ammo.price-per-arrow", 100.0));
   }

   public Material getMaterial(int var1) {
      String var2 = this.plugin.getConfigManager().getDefenses().getString(this.path(var1) + ".material", "DEEPSLATE_TILES");
      Material var3 = Material.matchMaterial(var2 == null ? "DEEPSLATE_TILES" : var2);
      return var3 == null ? Material.DEEPSLATE_TILES : var3;
   }

   private String path(int var1) {
      return "turret.levels." + var1;
   }

   private String key(DefenseData var1) {
      return this.key(var1.getWorldName(), var1.getX(), var1.getY(), var1.getZ());
   }

   private String key(Location var1) {
      return this.key(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
   }

   private String key(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private static HashMap<Integer, ItemStack> zzw$groundOverflow(org.bukkit.inventory.PlayerInventory var0, ItemStack[] var1) {
      HashMap<Integer, ItemStack> var2 = new HashMap<>();
      var2.put(0, var1[0]);
      return var2;
   }
}
