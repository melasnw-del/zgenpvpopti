package com.zzwproject.zgenpvp.generator;

import org.bukkit.Location;
import org.bukkit.entity.Item;
import org.bukkit.util.Vector;

public final class GeneratorRewardPosition {
   private static final int MAX_VERTICAL_SCAN = 32;

   private GeneratorRewardPosition() {
   }

   public static Location resolve(Location var0) {
      if (var0 == null) {
         return null;
      }

      Location var1 = var0.clone().add(0.5, 1.15, 0.5);

      for (int var2 = 0; var2 < 32; var2++) {
         if (var1.getBlock().getType().isAir()) {
            return var1;
         }

         var1.add(0.0, 1.0, 0.0);
      }

      return var1;
   }

   public static void freeze(Item var0) {
      if (var0 != null) {
         var0.setVelocity(new Vector(0.0, 0.0, 0.0));
         var0.setGravity(false);
      }
   }
}
