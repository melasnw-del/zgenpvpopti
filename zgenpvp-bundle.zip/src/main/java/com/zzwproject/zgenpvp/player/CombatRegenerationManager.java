package com.zzwproject.zgenpvp.player;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

public final class CombatRegenerationManager implements Listener {
   private final ZGenPvP plugin;
   private final Map<UUID, Long> lastPvpAt = new HashMap<>();
   private BukkitTask task;

   public CombatRegenerationManager(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   public void start() {
      this.stop();
      long intervalSeconds = Math.max(1L, this.plugin.getConfigManager().getConfig().getLong("player.combat-regeneration.interval-seconds", 2L));
      this.task = this.plugin.getServer().getScheduler().runTaskTimer(this.plugin, this::tick, 20L * intervalSeconds, 20L * intervalSeconds);
   }

   public void stop() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.lastPvpAt.clear();
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPvpDamage(EntityDamageByEntityEvent event) {
      if (event.getEntity() instanceof Player victim) {
         Player attacker = this.resolvePlayer(event.getDamager());
         if (attacker != null && !attacker.getUniqueId().equals(victim.getUniqueId())) {
            long now = System.currentTimeMillis();
            this.lastPvpAt.put(victim.getUniqueId(), now);
            this.lastPvpAt.put(attacker.getUniqueId(), now);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onNaturalRegain(EntityRegainHealthEvent event) {
      if (event.getEntity() instanceof Player) {
         if (this.isEnabled()) {
            if (event.getRegainReason() == RegainReason.SATIATED) {
               event.setCancelled(true);
            }
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.lastPvpAt.remove(event.getPlayer().getUniqueId());
   }

   private void tick() {
      if (this.isEnabled()) {
         long now = System.currentTimeMillis();
         long delayMillis = Math.max(0L, this.plugin.getConfigManager().getConfig().getLong("player.combat-regeneration.delay-seconds", 10L) * 1000L);
         double heal = Math.max(0.1, this.plugin.getConfigManager().getConfig().getDouble("player.combat-regeneration.heal-per-interval", 1.0));

         for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            if (!player.isDead()) {
               long last = this.lastPvpAt.getOrDefault(player.getUniqueId(), 0L);
               if (last <= 0L || now - last >= delayMillis) {
                  AttributeInstance attribute = player.getAttribute(Attribute.MAX_HEALTH);
                  if (attribute != null) {
                     double maxHealth = attribute.getValue();
                     if (!(player.getHealth() >= maxHealth)) {
                        player.setHealth(Math.min(maxHealth, player.getHealth() + heal));
                     }
                  }
               }
            }
         }
      }
   }

   private Player resolvePlayer(Entity damager) {
      if (damager instanceof Player player) {
         return player;
      } else {
         return damager instanceof Projectile projectile && projectile.getShooter() instanceof Player player ? player : null;
      }
   }

   private boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("player.combat-regeneration.enabled", true);
   }
}
