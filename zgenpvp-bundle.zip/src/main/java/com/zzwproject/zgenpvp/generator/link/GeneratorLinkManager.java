package com.zzwproject.zgenpvp.generator.link;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.hotfix.DoubleChestFix;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.GeneratorRepository;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GeneratorLinkManager {
   private final ZGenPvP plugin;
   private final GeneratorManager generatorManager;
   private final GeneratorRepository generatorRepository;
   private final BaseRepository baseRepository;
   private final Map<UUID, GeneratorLinkManager.Selection> selections = new HashMap<>();

   public GeneratorLinkManager(ZGenPvP var1, GeneratorManager var2, GeneratorRepository var3, BaseRepository var4) {
      this.plugin = var1;
      this.generatorManager = var2;
      this.generatorRepository = var3;
      this.baseRepository = var4;
   }

   public void selectGenerator(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         if (!this.canManageGeneratorLink(var1, var2)) {
            this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.not-owner");
            this.clearSelection(var1.getUniqueId());
         } else if (var1.isSneaking()) {
            this.unlinkGenerator(var1, var2);
         } else {
            long var3 = System.currentTimeMillis() + this.getSelectionTimeoutMillis();
            this.selections.put(var1.getUniqueId(), new GeneratorLinkManager.Selection(var2, var3));
            this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.generator-selected", "%level%", String.valueOf(var2.getLevel()));
         }
      }
   }

   public void selectChest(Player var1, Block var2) {
      if (var1 != null && var2 != null) {
         if (!this.isAllowedContainer(var2.getType())) {
            this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.invalid-container");
         } else {
            GeneratorLinkManager.Selection var3 = this.selections.get(var1.getUniqueId());
            if (var3 == null) {
               this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.select-generator-first");
            } else if (System.currentTimeMillis() > var3.expiresAt()) {
               this.selections.remove(var1.getUniqueId());
               this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.selection-expired");
            } else {
               GeneratorData var4 = var3.generator();
               Location var5 = var4.getLocation();
               if (var5 != null && var5.getWorld() != null) {
                  Optional var6 = this.generatorManager.getGenerator(var5);
                  if (!var6.isEmpty() && ((GeneratorData)var6.get()).getId() == var4.getId()) {
                     GeneratorData var7 = (GeneratorData)var6.get();
                     if (!this.canManageGeneratorLink(var1, var7)) {
                        this.selections.remove(var1.getUniqueId());
                        this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.not-owner");
                     } else {
                        Location var8 = var2.getLocation();
                        var8 = DoubleChestFix.canonical(var8);
                        var5 = var7.getLocation();
                        double var9 = Math.max(2.0, this.plugin.getConfigManager().getGenerators().getDouble("linking.max-distance", 16.0));
                        if (var5 != null
                           && var5.getWorld() != null
                           && var8.getWorld() != null
                           && var5.getWorld() == var8.getWorld()
                           && !(var5.distanceSquared(var8) > var9 * var9)) {
                           if (var7.hasLinkedChest()) {
                              Location var11 = var7.getLinkedChestLocation();
                              if (var11 != null && this.sameBlock(var11, var8)) {
                                 this.selections.remove(var1.getUniqueId());
                                 this.plugin.getMessageUtil().send(var1, "generator-link.already-linked");
                                 return;
                              }
                           }

                           if (!this.generatorRepository.updateLinkedChest(var7.getId(), var8)) {
                              this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.link-error");
                           } else {
                              var7.setLinkedChest(var8);
                              this.selections.remove(var1.getUniqueId());
                              this.consumeLinker(var1);
                              this.generatorManager.refreshVisual(var7);
                              this.plugin
                                 .getMessageUtil()
                                 .sendActionBar(
                                    var1,
                                    "generator-link.linked",
                                    "%x%",
                                    String.valueOf(var8.getBlockX()),
                                    "%y%",
                                    String.valueOf(var8.getBlockY()),
                                    "%z%",
                                    String.valueOf(var8.getBlockZ())
                                 );
                           }
                        } else {
                           this.plugin
                              .getMessageUtil()
                              .sendActionBar(var1, "generator-link.independent-too-far", "%distance%", String.valueOf((int)Math.round(var9)));
                        }
                     }
                  } else {
                     this.selections.remove(var1.getUniqueId());
                     this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.generator-missing");
                  }
               } else {
                  this.selections.remove(var1.getUniqueId());
                  this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.generator-missing");
               }
            }
         }
      }
   }

   public boolean unlinkGenerator(Player var1, GeneratorData var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (!this.canManageGeneratorLink(var1, var2)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.not-owner");
         return false;
      } else if (!var2.hasLinkedChest()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.not-linked");
         return false;
      } else if (!this.canManageGeneratorLink(var1, var2)) {
         this.selections.remove(var1.getUniqueId());
         this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.not-owner");
         return false;
      } else if (!this.generatorRepository.clearLinkedChest(var2.getId())) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.unlink-error");
         return false;
      } else {
         var2.clearLinkedChest();
         this.generatorManager.refreshVisual(var2);
         this.selections.remove(var1.getUniqueId());
         this.returnLinkers(var1, 1, var2.getLocation());
         this.plugin.getMessageUtil().sendActionBar(var1, "generator-link.unlinked");
         return true;
      }
   }

   public boolean isLinkedChest(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.generatorRepository.isLinkedChestCached(var1) : false;
   }

   public boolean canBreakLinkedChest(Player var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         List<GeneratorData> var3 = this.generatorRepository.findByLinkedChest(var2);
         if (var3.isEmpty()) {
            return true;
         }

         UUID var4 = var1.getUniqueId();

         for (GeneratorData var6 : var3) {
            UUID var7 = var6.getOwnerUuid();
            if (!var7.equals(var4) && this.generatorManager.areTeammates(var7, var4)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean canOpenLinkedChest(Player var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         List<GeneratorData> var3 = this.generatorRepository.findByLinkedChest(var2);
         if (var3.isEmpty()) {
            return true;
         }

         for (GeneratorData var5 : var3) {
            if (!this.generatorManager.canAccessGeneratorChest(var5.getOwnerUuid(), var1.getUniqueId())) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean unlinkChest(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         List<GeneratorData> var2 = this.generatorRepository.findByLinkedChest(var1);
         if (var2.isEmpty()) {
            return true;
         }

         for (GeneratorData var4 : var2) {
            if (!this.generatorRepository.clearLinkedChest(var4.getId())) {
               return false;
            }

            Location var5 = var4.getLocation();
            if (var5 != null && var5.getWorld() != null) {
               this.generatorManager.getGenerator(var5).filter(var1x -> var1x.getId() == var4.getId()).ifPresent(var1x -> {
                  var1x.clearLinkedChest();
                  this.generatorManager.refreshVisual(var1x);
               });
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public int getLinkedGeneratorCount(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.generatorRepository.findByLinkedChest(var1).size() : 0;
   }

   public void returnLinkers(Player var1, int var2, Location var3) {
      if (var1 != null && var2 > 0 && this.plugin.getGeneratorLinkItem() != null) {
         for (int var4 = 0; var4 < var2; var4++) {
            ItemStack var5 = this.plugin.getGeneratorLinkItem().create();
            if (var5 != null && !var5.getType().isAir()) {
               HashMap<Integer, ItemStack> var6 = var1.getInventory().addItem(new ItemStack[]{var5});

               for (ItemStack var8 : var6.values()) {
                  Location var9 = var3 != null && var3.getWorld() != null ? var3.clone().add(0.5, 0.5, 0.5) : var1.getLocation();
                  var9.getWorld().dropItemNaturally(var9, var8);
               }
            }
         }
      }
   }

   private void consumeLinker(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      if (var2 != null && !var2.getType().isAir() && var2.hasItemMeta()) {
         ItemMeta var3 = var2.getItemMeta();
         Byte var4 = (Byte)var3.getPersistentDataContainer().get(new NamespacedKey(this.plugin, "generator_linker"), PersistentDataType.BYTE);
         if (var4 != null && var4 == 1) {
            if (var2.getAmount() <= 1) {
               var1.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            } else {
               var2.setAmount(var2.getAmount() - 1);
               var1.getInventory().setItemInMainHand(var2);
            }
         }
      }
   }

   public boolean isAllowedContainer(Material var1) {
      if (var1 == null) {
         return false;
      }

      for (String var3 : this.plugin.getConfigManager().getGenerators().getStringList("linking.allowed-containers")) {
         Material var4 = Material.matchMaterial(var3);
         if (var4 == var1) {
            return true;
         }
      }

      return var1 == Material.CHEST || var1 == Material.TRAPPED_CHEST;
   }

   public void clearSelection(UUID var1) {
      if (var1 != null) {
         this.selections.remove(var1);
      }
   }

   public void shutdown() {
      this.selections.clear();
   }

   private boolean canManageGeneratorLink(Player var1, GeneratorData var2) {
      return var1 != null && var2 != null && var2.getOwnerUuid() != null
         ? this.generatorManager.canLinkGeneratorChest(var2.getOwnerUuid(), var1.getUniqueId())
         : false;
   }

   private long getSelectionTimeoutMillis() {
      long var1 = Math.max(5L, this.plugin.getConfigManager().getGenerators().getLong("linking.selection-timeout-seconds", 60L));
      return var1 * 1000L;
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!var2.getWorld().getName().equals(var1.getWorldName())) {
            return false;
         }

         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = var1.getRadius();
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   private boolean sameBlock(Location var1, Location var2) {
      return DoubleChestFix.sameContainer(var1, var2);
   }

   private record Selection(GeneratorData generator, long expiresAt) {
   }
}
