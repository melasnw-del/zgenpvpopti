package com.zzwproject.hotfix;

import java.lang.reflect.Method;

public final class OverclockEconomyFix {
   private OverclockEconomyFix() {
   }

   public static boolean withdraw(Object var0, Object var1, double var2) {
      if (var2 <= 0.0) {
         return true;
      }

      try {
         Method var4 = var0.getClass().getMethod("getEconomyManager");
         Object var5 = var4.invoke(var0);
         if (var5 == null) {
            return false;
         }

         Class var6 = Class.forName("org.bukkit.entity.Player", true, var0.getClass().getClassLoader());
         Method var7 = var5.getClass().getMethod("has", var6, double.class);
         Object var8 = var7.invoke(var5, var1, var2);
         if (!Boolean.TRUE.equals(var8)) {
            return false;
         }

         Method var9 = var5.getClass().getMethod("withdraw", var6, double.class);
         Object var10 = var9.invoke(var5, var1, var2);
         return Boolean.TRUE.equals(var10);
      } catch (Throwable var11) {
         return false;
      }
   }
}
