package com.zzwproject.zgenpvp.item;

import com.zzwproject.compat.ItemMetaCompat;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class SpecialItemFactory {
   private final ZGenPvP plugin;
   private final NamespacedKey itemTypeKey;
   private final NamespacedKey defenseLevelKey;
   private final NamespacedKey turretLevelKey;
   private final NamespacedKey accessLevelKey;

   public SpecialItemFactory(ZGenPvP var1) {
      this.plugin = var1;
      this.itemTypeKey = new NamespacedKey(var1, "special_item_type");
      this.defenseLevelKey = new NamespacedKey(var1, "defense_level");
      this.turretLevelKey = new NamespacedKey(var1, "turret_level");
      this.accessLevelKey = new NamespacedKey(var1, "access_level");
   }

   public ItemStack createRespawnBeacon() {
      return this.createNormalItem("respawn-beacon", "RESPAWN_BEACON", Material.BEACON);
   }

   public ItemStack createBaseBlock() {
      return this.createNormalItem("base-block", "BASE_BLOCK", this.getMaterial("LODESTONE", Material.STONE));
   }

   public ItemStack createDefenseBlock(int var1) {
      return this.createDefenseBlock("DEFENSE_BLOCK", var1);
   }

   public ItemStack createHeavyDefenseBlock(int var1) {
      return this.createDefenseBlock(var1);
   }

   public ItemStack createDefenseBlock(String var1, int var2) {
      FileConfiguration var3 = this.plugin.getConfigManager().getDefenses();
      String var4 = "defense-block";
      int var5 = this.clamp(var2, var3.getInt(var4 + ".max-level", 15));
      String var6 = var4 + ".levels." + var5;
      Material var7 = this.getMaterial(var3.getString(var6 + ".material"), Material.MOSSY_COBBLESTONE);
      int var8 = var3.getInt(var6 + ".health", 150);
      ItemStack var9 = new ItemStack(var7);
      ItemMeta var10 = var9.getItemMeta();
      var10.setDisplayName(ColorUtil.color(var3.getString(var4 + ".item.name", "&e✦ ᴅᴇꜰᴀɴꜱ ʙʟᴏɢᴜ")));
      var10.setLore(this.replaceLore(var3.getStringList(var4 + ".item.lore"), "%level%", String.valueOf(var5), "%health%", String.valueOf(var8)));
      var10.getPersistentDataContainer().set(this.itemTypeKey, PersistentDataType.STRING, "DEFENSE_BLOCK");
      var10.getPersistentDataContainer().set(this.defenseLevelKey, PersistentDataType.INTEGER, var5);
      ItemMetaCompat.apply(var9, var10);
      return var9;
   }

   public ItemStack createTurret(int var1) {
      FileConfiguration var2 = this.plugin.getConfigManager().getDefenses();
      int var3 = this.clamp(var1, var2.getInt("turret.max-level", 5));
      String var4 = "turret.levels." + var3;
      Material var5 = this.getMaterial(var2.getString(var4 + ".material"), this.getMaterial("DEEPSLATE_TILES", Material.STONE));
      ItemStack var6 = new ItemStack(var5);
      ItemMeta var7 = var6.getItemMeta();
      int var8 = var2.getInt(var4 + ".health", 150);
      double var9 = var2.getDouble(var4 + ".damage", 4.0);
      double var11 = var2.getDouble(var4 + ".range", 12.0);
      double var13 = var2.getDouble(var4 + ".attack-interval-seconds", 2.0);
      var7.setDisplayName(ColorUtil.color(var2.getString("turret.item.name", "&cᴛᴀʀᴇᴛ")));
      var7.setLore(
         this.replaceLore(
            var2.getStringList("turret.item.lore"),
            "%level%",
            String.valueOf(var3),
            "%health%",
            String.valueOf(var8),
            "%damage%",
            this.format(var9),
            "%range%",
            this.format(var11),
            "%interval%",
            this.format(var13)
         )
      );
      var7.getPersistentDataContainer().set(this.itemTypeKey, PersistentDataType.STRING, "TURRET");
      var7.getPersistentDataContainer().set(this.turretLevelKey, PersistentDataType.INTEGER, var3);
      ItemMetaCompat.apply(var6, var7);
      return var6;
   }

   public ItemStack createDefenseDoor(int var1) {
      return this.createAccessItem(DefenseAccessType.DOOR, var1);
   }

   public ItemStack createDefenseTrapdoor(int var1) {
      return this.createAccessItem(DefenseAccessType.TRAPDOOR, var1);
   }

   private ItemStack createAccessItem(DefenseAccessType var1, int var2) {
      FileConfiguration var3 = this.plugin.getConfigManager().getDefenses();
      String var4 = var1.getConfigPath();
      int var5 = this.clamp(var2, var3.getInt(var4 + ".max-level", 5));
      String var6 = var4 + ".levels." + var5;
      Material var7 = var1 == DefenseAccessType.DOOR
         ? this.getMaterial("EXPOSED_COPPER_DOOR", Material.IRON_DOOR)
         : this.getMaterial("EXPOSED_COPPER_TRAPDOOR", Material.IRON_TRAPDOOR);
      Material var8 = this.getMaterial(var3.getString(var6 + ".material"), var7);
      int var9 = var3.getInt(var6 + ".health", 250);
      ItemStack var10 = new ItemStack(var8);
      ItemMeta var11 = var10.getItemMeta();
      var11.setDisplayName(ColorUtil.color(var3.getString(var4 + ".item.name", var1 == DefenseAccessType.DOOR ? "&bᴅᴇꜰᴀɴꜱ ᴋᴀᴘɪꜱɪ" : "&bᴅᴇꜰᴀɴꜱ ᴛᴜᴢᴀᴋ ᴋᴀᴘɪꜱɪ")));
      var11.setLore(this.replaceLore(var3.getStringList(var4 + ".item.lore"), "%level%", String.valueOf(var5), "%health%", String.valueOf(var9)));
      var11.getPersistentDataContainer().set(this.itemTypeKey, PersistentDataType.STRING, var1.getDatabaseType());
      var11.getPersistentDataContainer().set(this.accessLevelKey, PersistentDataType.INTEGER, var5);
      ItemMetaCompat.apply(var10, var11);
      return var10;
   }

   public boolean isRespawnBeacon(ItemStack var1) {
      return this.hasType(var1, "RESPAWN_BEACON");
   }

   public boolean isBaseBlock(ItemStack var1) {
      return this.hasType(var1, "BASE_BLOCK");
   }

   public boolean isDefenseBlock(ItemStack var1) {
      return this.hasType(var1, "DEFENSE_BLOCK");
   }

   public boolean isHeavyDefenseBlock(ItemStack var1) {
      return false;
   }

   public String getDefenseType(ItemStack var1) {
      return "DEFENSE_BLOCK";
   }

   public boolean isTurret(ItemStack var1) {
      return this.hasType(var1, "TURRET");
   }

   public boolean isDefenseDoor(ItemStack var1) {
      return this.hasType(var1, "DEFENSE_DOOR");
   }

   public boolean isDefenseTrapdoor(ItemStack var1) {
      return this.hasType(var1, "DEFENSE_TRAPDOOR");
   }

   public int getDefenseLevel(ItemStack var1) {
      return this.getInteger(var1, this.defenseLevelKey, 1);
   }

   public int getTurretLevel(ItemStack var1) {
      return this.getInteger(var1, this.turretLevelKey, 1);
   }

   public int getAccessLevel(ItemStack var1) {
      return this.getInteger(var1, this.accessLevelKey, 1);
   }

   private ItemStack createNormalItem(String var1, String var2, Material var3) {
      FileConfiguration var4 = this.plugin.getConfigManager().getItems();
      if (!var4.getBoolean(var1 + ".enabled", true)) {
         return null;
      }

      Material var5 = this.getMaterial(var4.getString(var1 + ".material"), var3);
      ItemStack var6 = new ItemStack(var5);
      ItemMeta var7 = var6.getItemMeta();
      var7.setDisplayName(ColorUtil.color(var4.getString(var1 + ".name", var2)));
      var7.setLore(this.replaceLore(var4.getStringList(var1 + ".lore")));
      var7.getPersistentDataContainer().set(this.itemTypeKey, PersistentDataType.STRING, var2);
      ItemMetaCompat.apply(var6, var7);
      return var6;
   }

   private boolean hasType(ItemStack var1, String var2) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         String var3 = (String)var1.getItemMeta().getPersistentDataContainer().get(this.itemTypeKey, PersistentDataType.STRING);
         return var2.equals(var3);
      } else {
         return false;
      }
   }

   private int getInteger(ItemStack var1, NamespacedKey var2, int var3) {
      if (var1 != null && var1.hasItemMeta()) {
         Integer var4 = (Integer)var1.getItemMeta().getPersistentDataContainer().get(var2, PersistentDataType.INTEGER);
         return var4 == null ? var3 : var4;
      } else {
         return var3;
      }
   }

   private List<String> replaceLore(List<String> var1, String... var2) {
      ArrayList var3 = new ArrayList();

      for (String var5 : var1) {
         String var6 = var5;

         for (byte var7 = 0; var7 + 1 < var2.length; var7 += 2) {
            var6 = var6.replace(var2[var7], var2[var7 + 1]);
         }

         var3.add(ColorUtil.color(var6));
      }

      return var3;
   }

   private int clamp(int var1, int var2) {
      return Math.max(1, Math.min(Math.max(1, var2), var1));
   }

   private Material getMaterial(String var1, Material var2) {
      if (var1 == null) {
         return var2;
      }

      Material var3 = Material.matchMaterial(var1);
      return var3 == null ? var2 : var3;
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }
}
