package com.zzwproject.zgenpvp.database;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public final class DatabaseManager {
   private final ZGenPvP plugin;
   private Connection connection;

   public DatabaseManager(ZGenPvP var1) {
      this.plugin = var1;
   }

   public void connect() throws SQLException {
      if (!this.plugin.getDataFolder().exists()) {
         this.plugin.getDataFolder().mkdirs();
      }

      File var1 = new File(this.plugin.getDataFolder(), "zgenpvp.db");
      this.connection = DriverManager.getConnection("jdbc:sqlite:" + var1.getAbsolutePath());

      try (Statement var2 = this.connection.createStatement()) {
         var2.execute("PRAGMA foreign_keys = ON;");
         var2.execute("PRAGMA journal_mode = WAL;");
         var2.execute("PRAGMA synchronous = NORMAL;");
         var2.execute("PRAGMA busy_timeout = 5000;");
      }

      this.plugin.getLogger().info("SQLite bağlantısı kuruldu.");
   }

   public void createTables() throws SQLException {
      this.createPlayersTable();
      this.createBeaconsTable();
      this.createBasesTable();
      this.createGeneratorsTable();
      this.createDefensesTable();
      this.createPlacedBlocksTable();
      this.migrateGeneratorTable();
      this.migrateGeneratorBaseNullable();
      this.migrateDefenseTable();
      this.migrateBaseBeaconNullable();
      this.migrateDefenseBaseNullable();
      this.migrateIndependentStructureDeleteRules();
      this.createIndexes();
   }

   private void createPlayersTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS players (\n\n    uuid TEXT PRIMARY KEY,\n\n    last_name TEXT NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    xp REAL NOT NULL DEFAULT 0,\n\n    created_at INTEGER NOT NULL,\n\n    last_seen INTEGER NOT NULL\n);\n"
      );
   }

   private void createBeaconsTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS beacons (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    owner_uuid TEXT NOT NULL,\n\n    name TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n"
      );
   }

   private void createBasesTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS bases (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    beacon_id INTEGER,\n\n    owner_uuid TEXT NOT NULL,\n\n    name TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    current_hp INTEGER NOT NULL,\n    max_hp INTEGER NOT NULL,\n\n    radius INTEGER NOT NULL,\n\n    block_limit INTEGER NOT NULL,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (beacon_id)\n        REFERENCES beacons(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n"
      );
   }

   private void createGeneratorsTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS generators (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n\n    owner_uuid TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    stored_money REAL NOT NULL DEFAULT 0,\n\n    stored_shards INTEGER NOT NULL DEFAULT 0,\n\n    last_money_generation INTEGER NOT NULL DEFAULT 0,\n\n    last_shard_generation INTEGER NOT NULL DEFAULT 0,\n\n    linked_world TEXT,\n\n    linked_x INTEGER,\n    linked_y INTEGER,\n    linked_z INTEGER,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n"
      );
   }

   private void createDefensesTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS defenses (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n\n    owner_uuid TEXT NOT NULL,\n\n    type TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    current_hp INTEGER NOT NULL,\n\n    max_hp INTEGER NOT NULL,\n\n    stored_arrows INTEGER NOT NULL DEFAULT 0,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n"
      );
   }

   private void createPlacedBlocksTable() throws SQLException {
      this.execute(
         "CREATE TABLE IF NOT EXISTS placed_blocks (\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    owner_uuid TEXT,\n    placed_at INTEGER NOT NULL,\n\n    PRIMARY KEY (world, x, y, z)\n);\n"
      );
   }

   private void migrateGeneratorBaseNullable() throws SQLException {
      boolean var1 = false;

      try (
         Statement var2 = this.connection.createStatement();
         ResultSet var3 = var2.executeQuery("PRAGMA table_info(generators);");
      ) {
         while (var3.next()) {
            if ("base_id".equalsIgnoreCase(var3.getString("name"))) {
               var1 = var3.getInt("notnull") != 0;
               break;
            }
         }
      }

      if (var1) {
         boolean var38 = this.connection.getAutoCommit();

         try (Statement var39 = this.connection.createStatement()) {
            var39.execute("PRAGMA foreign_keys = OFF;");
         }

         try {
            this.connection.setAutoCommit(false);

            try (Statement var40 = this.connection.createStatement()) {
               var40.executeUpdate("DROP TABLE IF EXISTS generators_v106;");
               var40.executeUpdate(
                  "CREATE TABLE generators_v106 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    stored_money REAL NOT NULL DEFAULT 0,\n    stored_shards INTEGER NOT NULL DEFAULT 0,\n\n    last_money_generation INTEGER NOT NULL DEFAULT 0,\n    last_shard_generation INTEGER NOT NULL DEFAULT 0,\n\n    linked_world TEXT,\n    linked_x INTEGER,\n    linked_y INTEGER,\n    linked_z INTEGER,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n"
               );
               var40.executeUpdate(
                  "INSERT INTO generators_v106 (\n    id, base_id, owner_uuid,\n    world, x, y, z,\n    level,\n    stored_money, stored_shards,\n    last_money_generation, last_shard_generation,\n    linked_world, linked_x, linked_y, linked_z,\n    created_at\n)\nSELECT\n    id, base_id, owner_uuid,\n    world, x, y, z,\n    level,\n    stored_money, stored_shards,\n    last_money_generation, last_shard_generation,\n    linked_world, linked_x, linked_y, linked_z,\n    created_at\nFROM generators;\n"
               );
               var40.executeUpdate("DROP TABLE generators;");
               var40.executeUpdate("ALTER TABLE generators_v106 RENAME TO generators;");
            }

            this.connection.commit();
            this.plugin.getLogger().info("Database migration: generators.base_id artık opsiyonel.");
         } catch (SQLException var34) {
            try {
               this.connection.rollback();
            } catch (SQLException var26) {
            }

            throw var34;
         } finally {
            this.connection.setAutoCommit(var38);

            try (Statement var7 = this.connection.createStatement()) {
               var7.execute("PRAGMA foreign_keys = ON;");
            }
         }
      }
   }

   private boolean isColumnNotNull(String var1, String var2) throws SQLException {
      try (
         Statement var3 = this.connection.createStatement();
         ResultSet var4 = var3.executeQuery("PRAGMA table_info(" + var1 + ");");
      ) {
         while (var4.next()) {
            if (var2.equalsIgnoreCase(var4.getString("name"))) {
               return var4.getInt("notnull") != 0;
            }
         }
      }

      return false;
   }

   private void migrateBaseBeaconNullable() throws SQLException {
      if (this.isColumnNotNull("bases", "beacon_id")) {
         this.rebuildNullableForeignKeyTable(
            "bases",
            "bases_nullable_v114",
            "CREATE TABLE bases_nullable_v114 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    beacon_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n    name TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n    current_hp INTEGER NOT NULL,\n    max_hp INTEGER NOT NULL,\n\n    radius INTEGER NOT NULL,\n    block_limit INTEGER NOT NULL,\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (beacon_id)\n        REFERENCES beacons(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n",
            "INSERT INTO bases_nullable_v114 (\n    id, beacon_id, owner_uuid, name,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    radius, block_limit, created_at\n)\nSELECT\n    id, beacon_id, owner_uuid, name,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    radius, block_limit, created_at\nFROM bases;\n"
         );
         this.plugin.getLogger().info("Database migration: bases.beacon_id artık opsiyonel.");
      }
   }

   private void migrateDefenseBaseNullable() throws SQLException {
      if (this.isColumnNotNull("defenses", "base_id")) {
         this.rebuildNullableForeignKeyTable(
            "defenses",
            "defenses_nullable_v114",
            "CREATE TABLE defenses_nullable_v114 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n    type TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n    current_hp INTEGER NOT NULL,\n    max_hp INTEGER NOT NULL,\n\n    stored_arrows INTEGER NOT NULL DEFAULT 0,\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n",
            "INSERT INTO defenses_nullable_v114 (\n    id, base_id, owner_uuid, type,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    stored_arrows, created_at\n)\nSELECT\n    id, base_id, owner_uuid, type,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    stored_arrows, created_at\nFROM defenses;\n"
         );
         this.plugin.getLogger().info("Database migration: defenses.base_id artık opsiyonel.");
      }
   }

   private void migrateIndependentStructureDeleteRules() throws SQLException {
      if (!this.hasForeignKeyDeleteAction("bases", "beacon_id", "SET NULL")) {
         this.rebuildNullableForeignKeyTable(
            "bases",
            "bases_detached_v115",
            "CREATE TABLE bases_detached_v115 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    beacon_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n    name TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n    current_hp INTEGER NOT NULL,\n    max_hp INTEGER NOT NULL,\n\n    radius INTEGER NOT NULL,\n    block_limit INTEGER NOT NULL,\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (beacon_id)\n        REFERENCES beacons(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n",
            "INSERT INTO bases_detached_v115 (\n    id, beacon_id, owner_uuid, name,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    radius, block_limit, created_at\n)\nSELECT\n    id, beacon_id, owner_uuid, name,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    radius, block_limit, created_at\nFROM bases;\n"
         );
         this.plugin.getLogger().info("Database migration: beacon silinince Base artık silinmiyor (SET NULL).");
      }

      if (!this.hasForeignKeyDeleteAction("generators", "base_id", "SET NULL")) {
         this.rebuildNullableForeignKeyTable(
            "generators",
            "generators_detached_v115",
            "CREATE TABLE generators_detached_v115 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n\n    stored_money REAL NOT NULL DEFAULT 0,\n    stored_shards INTEGER NOT NULL DEFAULT 0,\n\n    last_money_generation INTEGER NOT NULL DEFAULT 0,\n    last_shard_generation INTEGER NOT NULL DEFAULT 0,\n\n    linked_world TEXT,\n    linked_x INTEGER,\n    linked_y INTEGER,\n    linked_z INTEGER,\n\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n",
            "INSERT INTO generators_detached_v115 (\n    id, base_id, owner_uuid,\n    world, x, y, z,\n    level,\n    stored_money, stored_shards,\n    last_money_generation, last_shard_generation,\n    linked_world, linked_x, linked_y, linked_z,\n    created_at\n)\nSELECT\n    id, base_id, owner_uuid,\n    world, x, y, z,\n    level,\n    stored_money, stored_shards,\n    last_money_generation, last_shard_generation,\n    linked_world, linked_x, linked_y, linked_z,\n    created_at\nFROM generators;\n"
         );
         this.plugin.getLogger().info("Database migration: Base silinince jeneratör artık silinmiyor (SET NULL).");
      }

      if (!this.hasForeignKeyDeleteAction("defenses", "base_id", "SET NULL")) {
         this.rebuildNullableForeignKeyTable(
            "defenses",
            "defenses_detached_v115",
            "CREATE TABLE defenses_detached_v115 (\n\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n\n    base_id INTEGER,\n    owner_uuid TEXT NOT NULL,\n    type TEXT NOT NULL,\n\n    world TEXT NOT NULL,\n    x INTEGER NOT NULL,\n    y INTEGER NOT NULL,\n    z INTEGER NOT NULL,\n\n    level INTEGER NOT NULL DEFAULT 1,\n    current_hp INTEGER NOT NULL,\n    max_hp INTEGER NOT NULL,\n\n    stored_arrows INTEGER NOT NULL DEFAULT 0,\n    created_at INTEGER NOT NULL,\n\n    FOREIGN KEY (base_id)\n        REFERENCES bases(id)\n        ON DELETE SET NULL,\n\n    FOREIGN KEY (owner_uuid)\n        REFERENCES players(uuid)\n        ON DELETE CASCADE\n);\n",
            "INSERT INTO defenses_detached_v115 (\n    id, base_id, owner_uuid, type,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    stored_arrows, created_at\n)\nSELECT\n    id, base_id, owner_uuid, type,\n    world, x, y, z,\n    level, current_hp, max_hp,\n    stored_arrows, created_at\nFROM defenses;\n"
         );
         this.plugin.getLogger().info("Database migration: Base silinince savunma/taret/kapı artık silinmiyor (SET NULL).");
      }
   }

   private boolean hasForeignKeyDeleteAction(String var1, String var2, String var3) throws SQLException {
      try (
         Statement var4 = this.connection.createStatement();
         ResultSet var5 = var4.executeQuery("PRAGMA foreign_key_list(" + var1 + ");");
      ) {
         while (var5.next()) {
            if (var2.equalsIgnoreCase(var5.getString("from"))) {
               return var3.equalsIgnoreCase(var5.getString("on_delete"));
            }
         }
      }

      return false;
   }

   private void rebuildNullableForeignKeyTable(String var1, String var2, String var3, String var4) throws SQLException {
      boolean var5 = this.connection.getAutoCommit();

      try (Statement var6 = this.connection.createStatement()) {
         var6.execute("PRAGMA foreign_keys = OFF;");
      }

      try {
         this.connection.setAutoCommit(false);

         try (Statement var33 = this.connection.createStatement()) {
            var33.executeUpdate("DROP TABLE IF EXISTS " + var2 + ";");
            var33.executeUpdate(var3);
            var33.executeUpdate(var4);
            var33.executeUpdate("DROP TABLE " + var1 + ";");
            var33.executeUpdate("ALTER TABLE " + var2 + " RENAME TO " + var1 + ";");
         }

         this.connection.commit();
      } catch (SQLException var31) {
         try {
            this.connection.rollback();
         } catch (SQLException var25) {
         }

         throw var31;
      } finally {
         this.connection.setAutoCommit(var5);

         try (Statement var10 = this.connection.createStatement()) {
            var10.execute("PRAGMA foreign_keys = ON;");
         }
      }
   }

   private void migrateGeneratorTable() throws SQLException {
      this.ensureColumn("generators", "stored_money", "REAL NOT NULL DEFAULT 0");
      this.ensureColumn("generators", "stored_shards", "INTEGER NOT NULL DEFAULT 0");
      this.ensureColumn("generators", "last_money_generation", "INTEGER NOT NULL DEFAULT 0");
      this.ensureColumn("generators", "last_shard_generation", "INTEGER NOT NULL DEFAULT 0");
      this.ensureColumn("generators", "linked_world", "TEXT");
      this.ensureColumn("generators", "linked_x", "INTEGER");
      this.ensureColumn("generators", "linked_y", "INTEGER");
      this.ensureColumn("generators", "linked_z", "INTEGER");
      long var1 = System.currentTimeMillis();

      try (PreparedStatement var3 = this.connection
            .prepareStatement("UPDATE generators\n\nSET last_money_generation = ?\n\nWHERE last_money_generation IS NULL\n   OR last_money_generation <= 0;\n")) {
         var3.setLong(1, var1);
         var3.executeUpdate();
      }

      try (PreparedStatement var10 = this.connection
            .prepareStatement("UPDATE generators\n\nSET last_shard_generation = ?\n\nWHERE last_shard_generation IS NULL\n   OR last_shard_generation <= 0;\n")) {
         var10.setLong(1, var1);
         var10.executeUpdate();
      }
   }

   private void migrateDefenseTable() throws SQLException {
      this.ensureColumn("defenses", "stored_arrows", "INTEGER NOT NULL DEFAULT 0");
   }

   private void ensureColumn(String var1, String var2, String var3) throws SQLException {
      if (!this.hasColumn(var1, var2)) {
         try (Statement var4 = this.connection.createStatement()) {
            var4.executeUpdate("ALTER TABLE " + var1 + " ADD COLUMN " + var2 + " " + var3 + ";");
         }

         this.plugin.getLogger().info("Database migration: " + var1 + "." + var2 + " oluşturuldu.");
      }
   }

   private boolean hasColumn(String var1, String var2) throws SQLException {
      try (
         Statement var3 = this.connection.createStatement();
         ResultSet var4 = var3.executeQuery("PRAGMA table_info(" + var1 + ");");
      ) {
         while (var4.next()) {
            String var5 = var4.getString("name");
            if (var2.equalsIgnoreCase(var5)) {
               return true;
            }
         }
      }

      return false;
   }

   private void createIndexes() throws SQLException {
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_beacons_owner\nON beacons(owner_uuid);\n");
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_bases_owner\nON bases(owner_uuid);\n");
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_generators_owner\nON generators(owner_uuid);\n");
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_generators_base\nON generators(base_id);\n");
      this.execute(
         "CREATE INDEX IF NOT EXISTS\nidx_generators_linked_chest\nON generators(\n    linked_world,\n    linked_x,\n    linked_y,\n    linked_z\n);\n"
      );
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_defenses_owner\nON defenses(owner_uuid);\n");
      this.execute("CREATE INDEX IF NOT EXISTS\nidx_defenses_base\nON defenses(base_id);\n");
   }

   private void execute(String var1) throws SQLException {
      try (Statement var2 = this.connection.createStatement()) {
         var2.execute(var1);
      }
   }

   public Connection getConnection() {
      if (!this.isConnected()) {
         throw new IllegalStateException("SQLite bağlantısı açık değil.");
      } else {
         return this.connection;
      }
   }

   public boolean isConnected() {
      if (this.connection == null) {
         return false;
      }

      try {
         return !this.connection.isClosed();
      } catch (SQLException var2) {
         return false;
      }
   }

   public void close() {
      if (this.connection != null) {
         try {
            if (!this.connection.isClosed()) {
               this.connection.close();
            }
         } catch (SQLException var5) {
            this.plugin.getLogger().warning("SQLite kapatılırken hata oluştu: " + var5.getMessage());
         } finally {
            this.connection = null;
         }
      }
   }
}
