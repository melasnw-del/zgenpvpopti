package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Method;

public final class GenerationGate {
   private GenerationGate() {
   }

   public static boolean shouldProcess(Object var0) {
      if (var0 == null) {
         return false;
      }

      if (var0 instanceof com.zzwproject.zgenpvp.model.GeneratorData) {
         org.bukkit.Location var7 = ((com.zzwproject.zgenpvp.model.GeneratorData)var0).getLocation();
         if (var7 == null || var7.getWorld() == null) {
            return false;
         }

         return var7.getWorld().isChunkLoaded(var7.getBlockX() >> 4, var7.getBlockZ() >> 4);
      }

      try {
         Object var1 = call(var0, "getLocation");
         if (var1 == null) {
            return false;
         }

         Object var2 = call(var1, "getWorld");
         if (var2 == null) {
            return false;
         }

         int var3 = ((Number)call(var1, "getBlockX")).intValue() >> 4;
         int var4 = ((Number)call(var1, "getBlockZ")).intValue() >> 4;
         Object var5 = call(var2, "isChunkLoaded", var3, var4);
         return !(var5 instanceof Boolean) || (Boolean)var5;
      } catch (Throwable var6) {
         return true;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && ok(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && ok(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      return null;
   }

   private static boolean ok(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else {
            Class var3 = wrap(var0[var2]);
            if (!var3.isInstance(var1[var2]) && (!Number.class.isAssignableFrom(var3) || !(var1[var2] instanceof Number))) {
               return false;
            }
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
