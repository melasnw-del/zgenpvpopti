package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.level.LevelMenu;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class LevelCommand implements CommandExecutor, TabCompleter {
   private final ZGenPvP plugin;
   private final LevelMenu levelMenu;

   public LevelCommand(ZGenPvP var1, LevelMenu var2) {
      this.plugin = var1;
      this.levelMenu = var2;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 0) {
         return this.handleAdmin(var1, var4);
      }

      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("zgenpvp.level")) {
            this.plugin.getMessageUtil().send(var5, "general.no-permission");
            return true;
         } else if (!this.plugin.getLevelManager().isEnabled()) {
            this.plugin.getMessageUtil().send(var5, "general.module-disabled");
            return true;
         } else {
            this.levelMenu.open(var5);
            return true;
         }
      } else {
         this.plugin.getMessageUtil().send(var1, "general.only-player");
         return true;
      }
   }

   private boolean handleAdmin(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("zgenpvp.level.admin")) {
         this.plugin.getMessageUtil().send(var1, "general.no-permission");
         return true;
      }

      if (var2.length != 3) {
         this.plugin.getMessageUtil().send(var1, "level.admin-usage");
         return true;
      }

      Player var3 = Bukkit.getPlayerExact(var2[1]);
      if (var3 == null) {
         this.plugin.getMessageUtil().send(var1, "general.player-not-found");
         return true;
      }

      int var4;
      try {
         var4 = Integer.parseInt(var2[2]);
      } catch (NumberFormatException var7) {
         this.plugin.getMessageUtil().send(var1, "level.admin-invalid-number");
         return true;
      }

      String var5 = var2[0].toLowerCase(Locale.ROOT);
      if (!var5.equals("ver") && !var5.equals("give") && !var5.equals("add")) {
         if (!var5.equals("ayarla") && !var5.equals("set")) {
            this.plugin.getMessageUtil().send(var1, "level.admin-usage");
            return true;
         }

         if (var4 < 1 || var4 > this.plugin.getLevelManager().getMaxLevel()) {
            this.plugin.getMessageUtil().send(var1, "level.admin-invalid-level", "%max%", String.valueOf(this.plugin.getLevelManager().getMaxLevel()));
            return true;
         }

         if (!this.plugin.getLevelManager().setLevel(var3.getUniqueId(), var4)) {
            this.plugin.getMessageUtil().send(var1, "general.database-error");
            return true;
         }

         int var8 = var4;
         this.plugin.getMessageUtil().send(var1, "level.admin-set", "%player%", var3.getName(), "%level%", String.valueOf(var8));
         this.plugin.getMessageUtil().send(var3, "level.admin-set-received", "%level%", String.valueOf(var8));
      } else {
         if (var4 <= 0) {
            this.plugin.getMessageUtil().send(var1, "level.admin-invalid-number");
            return true;
         }

         int var6 = this.plugin.getLevelManager().addLevels(var3.getUniqueId(), var4);
         if (var6 < 0) {
            this.plugin.getMessageUtil().send(var1, "general.database-error");
            return true;
         }

         this.plugin
            .getMessageUtil()
            .send(var1, "level.admin-given", "%player%", var3.getName(), "%amount%", String.valueOf(var4), "%level%", String.valueOf(var6));
         this.plugin.getMessageUtil().send(var3, "level.admin-received", "%amount%", String.valueOf(var4), "%level%", String.valueOf(var6));
      }

      this.plugin.getLevelManager().syncHud(var3);
      return true;
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("zgenpvp.level.admin")) {
         return List.of();
      }

      if (var4.length == 1) {
         return this.filter(List.of("ver", "ayarla"), var4[0]);
      }

      if (var4.length != 2) {
         return var4.length == 3 ? this.filter(List.of("1", "5", "10", "25", "50"), var4[2]) : List.of();
      }

      ArrayList var5 = new ArrayList();

      for (Player var7 : Bukkit.getOnlinePlayers()) {
         var5.add(var7.getName());
      }

      return this.filter(var5, var4[1]);
   }

   private List<String> filter(List<String> var1, String var2) {
      String var3 = var2 == null ? "" : var2.toLowerCase(Locale.ROOT);
      ArrayList var4 = new ArrayList();

      for (String var6 : var1) {
         if (var6.toLowerCase(Locale.ROOT).startsWith(var3)) {
            var4.add(var6);
         }
      }

      return var4;
   }
}
