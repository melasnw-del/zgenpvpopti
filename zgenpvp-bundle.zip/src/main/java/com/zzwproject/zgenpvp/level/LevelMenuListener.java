package com.zzwproject.zgenpvp.level;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class LevelMenuListener implements Listener {
   private final LevelMenu levelMenu;

   public LevelMenuListener(LevelMenu levelMenu) {
      this.levelMenu = levelMenu;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent event) {
      if (this.levelMenu.isLevelMenu(event.getView().getTopInventory())) {
         event.setCancelled(true);
         if (event.getWhoClicked() instanceof Player player) {
            if (event.getRawSlot() == this.levelMenu.getCloseSlot()) {
               player.closeInventory();
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent event) {
      if (this.levelMenu.isLevelMenu(event.getView().getTopInventory())) {
         event.setCancelled(true);
      }
   }
}
