package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class PlayerRepository {
   private final DatabaseManager databaseManager;
   private final ConcurrentMap<UUID, PlayerRepository.Progress> progressCache = new ConcurrentHashMap<>();

   public PlayerRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public boolean touchPlayer(UUID var1, String var2) {
      if (var1 == null) {
         return false;
      }

      String var3 = var2 != null && !var2.isBlank() ? var2 : "Unknown";
      long var4 = System.currentTimeMillis();
      String var6 = "INSERT INTO players (uuid, last_name, level, xp, created_at, last_seen)\nVALUES (?, ?, 1, 0, ?, ?)\nON CONFLICT(uuid) DO UPDATE SET\n    last_name = excluded.last_name,\n    last_seen = excluded.last_seen;\n";

      try (PreparedStatement var7 = this.databaseManager.getConnection().prepareStatement(var6)) {
         var7.setString(1, var1.toString());
         var7.setString(2, var3);
         var7.setLong(3, var4);
         var7.setLong(4, var4);
         return var7.executeUpdate() > 0;
      } catch (SQLException var12) {
         var12.printStackTrace();
         return false;
      }
   }

   public int getLevel(UUID var1) {
      return var1 == null ? 1 : this.getProgress(var1).level;
   }

   public double getXp(UUID var1) {
      return var1 == null ? 0.0 : this.getProgress(var1).xp;
   }

   public boolean updateProgress(UUID var1, int var2, double var3) {
      if (var1 == null) {
         return false;
      }

      int var5 = Math.max(1, var2);
      double var6 = Math.max(0.0, var3);
      String var8 = "UPDATE players\nSET level = ?, xp = ?, last_seen = ?\nWHERE uuid = ?;\n";

      try (PreparedStatement var9 = this.databaseManager.getConnection().prepareStatement(var8)) {
         var9.setInt(1, var5);
         var9.setDouble(2, var6);
         var9.setLong(3, System.currentTimeMillis());
         var9.setString(4, var1.toString());
         boolean var10 = var9.executeUpdate() > 0;
         if (var10) {
            this.progressCache.put(var1, new PlayerRepository.Progress(var5, var6));
         }

         return var10;
      } catch (SQLException var14) {
         var14.printStackTrace();
         return false;
      }
   }

   public boolean setXp(UUID var1, double var2) {
      return this.updateProgress(var1, this.getLevel(var1), var2);
   }

   public boolean setLevel(UUID var1, int var2) {
      return this.updateProgress(var1, var2, this.getXp(var1));
   }

   public void invalidate(UUID var1) {
      if (var1 != null) {
         this.progressCache.remove(var1);
      }
   }

   public void clearCache() {
      this.progressCache.clear();
   }

   private PlayerRepository.Progress getProgress(UUID var1) {
      PlayerRepository.Progress var2 = this.progressCache.get(var1);
      if (var2 != null) {
         return var2;
      }

      PlayerRepository.Progress var3 = this.loadProgress(var1);
      PlayerRepository.Progress var4 = this.progressCache.putIfAbsent(var1, var3);
      return var4 == null ? var3 : var4;
   }

   private PlayerRepository.Progress loadProgress(UUID var1) {
      String var2 = "SELECT level, xp FROM players WHERE uuid = ? LIMIT 1;";

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2)) {
         var3.setString(1, var1.toString());

         try (ResultSet var4 = var3.executeQuery()) {
            if (var4.next()) {
               return new PlayerRepository.Progress(Math.max(1, var4.getInt("level")), Math.max(0.0, var4.getDouble("xp")));
            }
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return new PlayerRepository.Progress(1, 0.0);
   }

   private static final class Progress {
      private final int level;
      private final double xp;

      private Progress(int var1, double var2) {
         this.level = var1;
         this.xp = var2;
      }
   }
}
