package com.zzwproject.zgenpvp.turret;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class TurretListener implements Listener {
   private final ZGenPvP plugin;
   private final TurretManager turretManager;
   private final TurretMenu turretMenu;
   private final SpecialItemFactory itemFactory;

   public TurretListener(ZGenPvP var1, TurretManager var2, TurretMenu var3, SpecialItemFactory var4) {
      this.plugin = var1;
      this.turretManager = var2;
      this.turretMenu = var3;
      this.itemFactory = var4;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      if (this.itemFactory.isTurret(var1.getItemInHand())) {
         int var2 = this.itemFactory.getTurretLevel(var1.getItemInHand());
         if (!this.turretManager.place(var1.getPlayer(), var1.getBlockPlaced().getLocation(), var2)) {
            var1.setCancelled(true);
         }
      }

      StructureSupportGuard.restore(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND && var1.getAction().isRightClick()) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.turretManager.getTurret(var2.getLocation());
            if (!var3.isEmpty()) {
               var1.setCancelled(true);
               DefenseData var4 = (DefenseData)var3.get();
               Player var5 = var1.getPlayer();
               if (this.turretManager.canManageTurret(var5, var4)) {
                  this.turretMenu.open(var5, var4);
               } else {
                  this.turretManager.sendOwnerInfo(var5, var4);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      Optional var2 = this.turretManager.getTurret(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         Player var3 = var1.getPlayer();
         DefenseData var4 = (DefenseData)var2.get();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var3.getInventory().getItemInMainHand())) {
            var1.setCancelled(true);
            String var5 = "TURRET:" + var4.getId();
            if (TeamPermissionBridge.turretOwnerOrAllowed(var4.getOwnerUuid(), var3.getUniqueId())) {
               StructureMiningUtil.startOwnerMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  () -> this.turretManager.getTurret(var1.getBlock().getLocation()).isPresent(),
                  () -> this.turretManager.getTurret(var1.getBlock().getLocation()).ifPresent(var3x -> {
                     if (this.turretManager.removeByOwner(var3, var3x)) {
                        var1.getBlock().setType(Material.AIR, false);
                     }
                  })
               );
            } else if (this.turretManager.isFriendly(var3.getUniqueId(), var4.getOwnerUuid())) {
               StructureMiningUtil.stopMining(var3);
               this.turretManager.sendOwnerInfo(var3, var4);
            } else {
               StructureMiningUtil.startEnemyMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  var4::getCurrentHp,
                  var4::getMaxHp,
                  () -> this.turretManager.getTurret(var1.getBlock().getLocation()).isPresent(),
                  () -> this.turretManager.getTurret(var1.getBlock().getLocation()).ifPresent(var2xx -> this.turretManager.damage(var3, var2xx))
               );
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBreak(BlockBreakEvent var1) {
      Optional var2 = this.turretManager.getTurret(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         var1.setCancelled(true);
         var1.setDropItems(false);
         var1.setExpToDrop(0);
         DefenseData var3 = (DefenseData)var2.get();
         Player var4 = var1.getPlayer();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var4.getInventory().getItemInMainHand())) {
            if (TeamPermissionBridge.turretOwnerOrAllowed(var3.getOwnerUuid(), var4.getUniqueId())) {
               if (this.turretManager.removeByOwner(var4, var3)) {
                  var1.getBlock().setType(Material.AIR, false);
               }
            } else if (this.turretManager.isFriendly(var4.getUniqueId(), var3.getOwnerUuid())) {
               this.turretManager.sendOwnerInfo(var4, var3);
            } else {
               this.turretManager.damage(var4, var3);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onEntityExplode(EntityExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.turretManager.getTurret(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBlockExplode(BlockExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.turretManager.getTurret(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonExtend(BlockPistonExtendEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.turretManager.getTurret(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonRetract(BlockPistonRetractEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.turretManager.getTurret(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEntityChangeBlock(EntityChangeBlockEvent var1) {
      if (this.turretManager.getTurret(var1.getBlock().getLocation()).isPresent()) {
         var1.setCancelled(true);
      }
   }
}
