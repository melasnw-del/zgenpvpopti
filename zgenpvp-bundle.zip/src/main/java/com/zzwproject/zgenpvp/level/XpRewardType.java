package com.zzwproject.zgenpvp.level;

public enum XpRewardType {
   PLAYER_KILL("player-kill"),
   GENERATOR_SELL("generator-sell"),
   GENERATOR_PRODUCTION("generator-production"),
   DEFENSE_DESTROY("defense-destroy"),
   TURRET_DESTROY("turret-destroy"),
   BASE_DESTROY("base-destroy");

   private final String configPath;

   XpRewardType(String configPath) {
      this.configPath = configPath;
   }

   public String getConfigPath() {
      return this.configPath;
   }
}
