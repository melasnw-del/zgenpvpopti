package com.zzwproject.zgenpvp.integration;

import com.zzwproject.zgenpvp.hotfix.RaidReflectionCache;
import com.zzwproject.zgenpvp.level.XpRewardType;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public final class RaidSessionBridge {
   private RaidSessionBridge() {
   }

   public static boolean handleRaidBombPlace(BlockPlaceEvent var0) {
      return invokeBoolean("handleRaidBombPlace", var0);
   }

   public static boolean handleGeneratorBreak(BlockBreakEvent var0) {
      return invokeBoolean("handleGeneratorBreak", var0);
   }

   public static boolean handleBeaconDamage(BlockDamageEvent var0) {
      return invokeBoolean("handleBeaconDamage", var0);
   }

   public static boolean handleBeaconBreak(BlockBreakEvent var0) {
      return invokeBoolean("handleBeaconBreak", var0);
   }

   public static boolean suppressStructureXp(Player var0, XpRewardType var1) {
      return invokeBoolean("suppressStructureXp", var0, var1);
   }

   public static boolean isUnderRaid(UUID var0) {
      return var0 != null && invokeBoolean("isUnderRaid", var0);
   }

   public static boolean suppressRaidProtection(long var0) {
      return invokeBoolean("suppressRaidProtection", var0);
   }

   private static boolean invokeBoolean(String var0, Object... var1) {
      try {
         Object var2 = findRaidModule();
         if (var2 == null) {
            return false;
         }

         Method var3 = findCompatible(var2.getClass(), var0, var1);
         if (var3 == null) {
            return false;
         }

         var3.setAccessible(true);
         Object var4 = var3.invoke(var2, var1);
         return var4 instanceof Boolean && (Boolean)var4;
      } catch (Throwable var5) {
         return false;
      }
   }

   private static Object findRaidModule$hotfixUncached() throws Exception {
      Class var0 = Class.forName("org.bukkit.Bukkit");
      Object var1 = var0.getMethod("getPluginManager").invoke(null);

      try {
         Class var2 = Class.forName("com.zzwproject.bundle.BundleResolver");
         Object var3 = var2.getMethod("getPlugin", Object.class, String.class).invoke(null, var1, "ZRaid");
         if (var3 != null && hasMethod(var3.getClass(), "handleBeaconBreak")) {
            return var3;
         }
      } catch (Throwable var8) {
      }

      for (String var5 : new String[]{"ZRaid", "zRaid"}) {
         try {
            Object var6 = var1.getClass().getMethod("getPlugin", String.class).invoke(var1, var5);
            if (var6 != null && hasMethod(var6.getClass(), "handleBeaconBreak")) {
               return var6;
            }
         } catch (Throwable var7) {
         }
      }

      Object var10 = var1.getClass().getMethod("getPlugins").invoke(var1);
      if (var10 instanceof Object[]) {
         for (Object var15 : (Object[])var10) {
            if (var15 != null && (var15.getClass().getName().equals("com.zzwproject.zraid.ZRaid") || hasMethod(var15.getClass(), "handleRaidBombPlace"))) {
               return var15;
            }
         }
      }

      return null;
   }

   private static boolean hasMethod(Class<?> var0, String var1) {
      for (Method var5 : var0.getMethods()) {
         if (var5.getName().equals(var1)) {
            return true;
         }
      }

      for (Method var9 : var0.getDeclaredMethods()) {
         if (var9.getName().equals(var1)) {
            return true;
         }
      }

      return false;
   }

   private static Method findCompatible$hotfixUncached(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && compatible(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && compatible(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      return null;
   }

   private static boolean compatible(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else {
            Class var3 = wrap(var0[var2]);
            if (!var3.isInstance(var1[var2]) && (!Number.class.isAssignableFrom(var3) || !(var1[var2] instanceof Number))) {
               return false;
            }
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static Object findRaidModule() throws Exception {
      return RaidReflectionCache.findModule();
   }

   private static Method findCompatible(Class<?> var0, String var1, Object[] var2) {
      return RaidReflectionCache.findCompatible(var0, var1, var2);
   }
}
