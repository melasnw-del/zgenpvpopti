package com.zzwproject.zmenu.gui;

public record MenuAction(String type, String value, boolean close) {
}
