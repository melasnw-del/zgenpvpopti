package com.zzwproject.zgenpvp.base;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.raid.RaidWindowManager;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class BaseListener implements Listener {
   private final ZGenPvP plugin;
   private final BaseManager baseManager;
   private final BaseMenu baseMenu;
   private final SpecialItemFactory itemFactory;

   public BaseListener(ZGenPvP var1, BaseManager var2, BaseMenu var3, SpecialItemFactory var4) {
      this.plugin = var1;
      this.baseManager = var2;
      this.baseMenu = var3;
      this.itemFactory = var4;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      if (this.itemFactory.isBaseBlock(var1.getItemInHand())) {
         boolean var2 = this.baseManager.createBase(var1.getPlayer(), var1.getBlockPlaced().getLocation());
         if (!var2) {
            var1.setCancelled(true);
         }
      }

      StructureSupportGuard.restore(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.baseManager.getBase(var2.getLocation());
            if (!var3.isEmpty()) {
               BaseData var4 = (BaseData)var3.get();
               Player var5 = var1.getPlayer();
               if (var1.getAction().isRightClick()) {
                  ItemStack var6 = var1.getItem();
                  if (var6 == null || var6.getType().isAir() || !var6.getType().isBlock()) {
                     var1.setCancelled(true);
                     if (!this.baseManager.canManageBase(var4.getOwnerUuid(), var5.getUniqueId())) {
                        this.baseManager.sendOwnerInfo(var5, var4);
                     } else if (var5.isSneaking()) {
                        this.baseManager.upgrade(var5, var4);
                     } else {
                        this.baseMenu.open(var5, var4);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      Optional var2 = this.baseManager.getBase(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         Player var3 = var1.getPlayer();
         BaseData var4 = (BaseData)var2.get();
         if (!var3.isOp() && !var3.hasPermission("zgenpvp.base.admin-break")) {
            if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var3.getInventory().getItemInMainHand())) {
               var1.setCancelled(true);
               RaidWindowManager var5 = this.plugin.getRaidWindowManager();
               boolean var6 = var5 != null && var5.isRaidActive(var4.getId());
               boolean var7 = var4.getOwnerUuid().equals(var3.getUniqueId());
               boolean var8 = this.isFriendly(var3.getUniqueId(), var4.getOwnerUuid());
               if (var6) {
                  if (var8) {
                     StructureMiningUtil.stopMining(var3);
                     long var12 = var5.getRemainingSeconds(var4.getId());
                     this.plugin.getMessageUtil().send(var3, "base.raid-owner-remove-denied", "%time%", var5.formatRemaining(var12));
                  } else {
                     String var11 = "BASE:" + var4.getId();
                     StructureMiningUtil.startEnemyMining(
                        this.plugin,
                        var3,
                        var1.getBlock(),
                        var11,
                        var4::getCurrentHp,
                        var4::getMaxHp,
                        () -> this.baseManager.getBase(var1.getBlock().getLocation()).filter(var1xx -> var1xx.getId() == var4.getId()).filter(var1xx -> {
                           RaidWindowManager var2xx = this.plugin.getRaidWindowManager();
                           return var2xx != null && var2xx.isRaidActive(var1xx.getId());
                        }).isPresent(),
                        () -> this.baseManager
                           .getBase(var1.getBlock().getLocation())
                           .filter(var1xx -> var1xx.getId() == var4.getId())
                           .ifPresent(var3xx -> this.damageRaidBase(var3, var3xx, var1.getBlock()))
                     );
                  }
               } else if (!var7) {
                  StructureMiningUtil.stopMining(var3);
                  this.plugin.getMessageUtil().send(var3, "base.raid-required");
               } else {
                  String var9 = "BASE-OWNER:" + var4.getId();
                  StructureMiningUtil.startOwnerMining(
                     this.plugin,
                     var3,
                     var1.getBlock(),
                     var9,
                     () -> this.baseManager.getBase(var1.getBlock().getLocation()).isPresent(),
                     () -> this.baseManager.getBase(var1.getBlock().getLocation()).ifPresent(var3x -> {
                        if (this.baseManager.removeByOwner(var3)) {
                           if (this.plugin.getBaseEnergyManager() != null) {
                              this.plugin.getBaseEnergyManager().deleteEnergy(var3x.getId());
                           }

                           var1.getBlock().setType(Material.AIR, false);
                        }
                     })
                  );
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
   }

   private void damageRaidBase(Player var1, BaseData var2, Block var3) {
      if (var1 != null && var2 != null && var3 != null) {
         RaidWindowManager var4 = this.plugin.getRaidWindowManager();
         if (var4 != null && var4.isRaidActive(var2.getId()) && !this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            int var5 = Math.max(1, this.plugin.getConfigManager().getConfig().getInt("base.attack.damage-per-hit", 1));
            int var6 = Math.max(0, var2.getCurrentHp() - var5);
            if (var6 > 0) {
               if (this.plugin.getBaseRepository().updateHealth(var2.getId(), var6)) {
                  var2.setCurrentHp(var6);
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(var1, "base.damaged", "%health%", String.valueOf(var6), "%max_health%", String.valueOf(var2.getMaxHp()));
                  if (this.plugin.getRaidAlertManager() != null) {
                     this.plugin
                        .getRaidAlertManager()
                        .alert(var2.getOwnerUuid(), var1, "Base Bloğu", var2.getLocation(), var2.getLevel(), var6, var2.getMaxHp(), "Oyuncu saldırısı");
                  }
               }
            } else {
               this.destroyDirect(var1, var2, var3, true);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBreak(BlockBreakEvent var1) {
      Optional var2 = this.baseManager.getBase(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         var1.setCancelled(true);
         var1.setDropItems(false);
         var1.setExpToDrop(0);
         BaseData var3 = (BaseData)var2.get();
         Player var4 = var1.getPlayer();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var4.getInventory().getItemInMainHand())) {
            RaidWindowManager var5 = this.plugin.getRaidWindowManager();
            boolean var6 = var5 != null && var5.isRaidActive(var3.getId());
            boolean var7 = var3.getOwnerUuid().equals(var4.getUniqueId());
            boolean var8 = this.isFriendly(var4.getUniqueId(), var3.getOwnerUuid());
            if (var4.isOp() || var4.hasPermission("zgenpvp.base.admin-break")) {
               this.destroyDirect(var4, var3, var1.getBlock(), false);
            } else if (var6) {
               if (var8) {
                  long var9 = var5.getRemainingSeconds(var3.getId());
                  this.plugin.getMessageUtil().send(var4, "base.raid-owner-remove-denied", "%time%", var5.formatRemaining(var9));
               } else {
                  this.destroyDirect(var4, var3, var1.getBlock(), true);
               }
            } else if (!var7) {
               this.plugin.getMessageUtil().send(var4, "base.raid-required");
            } else {
               if (this.baseManager.removeByOwner(var4)) {
                  if (this.plugin.getBaseEnergyManager() != null) {
                     this.plugin.getBaseEnergyManager().deleteEnergy(var3.getId());
                  }

                  if (var5 != null) {
                     var5.endRaid(var3.getId());
                  }

                  var1.getBlock().setType(Material.AIR, false);
               }
            }
         }
      }
   }

   private void destroyDirect(Player var1, BaseData var2, Block var3, boolean var4) {
      if (var1 != null && var2 != null && var3 != null) {
         if (!var4 || !this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            boolean var5 = this.plugin.getBaseRepository().deleteByOwner(var2.getOwnerUuid());
            if (!var5) {
               this.plugin.getMessageUtil().send(var1, "general.database-error");
            } else {
               var3.setType(Material.AIR, false);
               if (this.plugin.getBaseEnergyManager() != null) {
                  this.plugin.getBaseEnergyManager().deleteEnergy(var2.getId());
               }

               RaidWindowManager var6 = this.plugin.getRaidWindowManager();
               if (var6 != null) {
                  var6.endRaid(var2.getId());
               }

               if (!var4) {
                  this.plugin.getSoundUtil().play(var1, "base-break");
               } else {
                  BaseReplacementCooldownManager var7 = this.plugin.getBaseReplacementCooldownManager();
                  if (var7 != null) {
                     var7.start(var2.getOwnerUuid());
                  }

                  OfflinePlayer var8 = Bukkit.getOfflinePlayer(var2.getOwnerUuid());
                  String var9 = var8.getName() == null ? "Bilinmeyen" : var8.getName();
                  String var10 = this.plugin.getMessageUtil().get("base.destroyed-broadcast", "%attacker%", var1.getName(), "%owner%", var9);
                  Bukkit.broadcastMessage(var10);
                  if (var8.isOnline()) {
                     Player var11 = var8.getPlayer();
                     if (var11 != null) {
                        this.plugin.getMessageUtil().send(var11, "base.destroyed-owner", "%attacker%", var1.getName());
                        if (var7 != null) {
                           long var12 = var7.getRemainingSeconds(var2.getOwnerUuid());
                           if (var12 > 0L) {
                              this.plugin.getMessageUtil().send(var11, "base.replacement-cooldown-started", "%time%", var7.formatRemaining(var12));
                           }
                        }
                     }
                  }

                  this.plugin.getSoundUtil().play(var1, "base-break");
                  this.plugin.getXpRewardManager().reward(var1, XpRewardType.BASE_DESTROY);
               }
            }
         }
      }
   }

   private boolean isFriendly(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : this.plugin.getZTeamHook() != null && this.plugin.getZTeamHook().areTeammates(var1, var2);
      }
   }
}
