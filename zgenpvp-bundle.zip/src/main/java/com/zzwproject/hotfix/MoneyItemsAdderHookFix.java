package com.zzwproject.hotfix;

import java.lang.reflect.Method;

public final class MoneyItemsAdderHookFix {
   private MoneyItemsAdderHookFix() {
   }

   public static Object invokeNoArgs(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         for (Method var6 : var2.getDeclaredMethods()) {
            if (var6.getName().equals(var1) && var6.getParameterCount() == 0) {
               var6.setAccessible(true);
               return var6.invoke(var0);
            }
         }
      }

      for (Method var10 : var0.getClass().getMethods()) {
         if (var10.getName().equals(var1) && var10.getParameterCount() == 0) {
            var10.setAccessible(true);
            return var10.invoke(var0);
         }
      }

      throw new NoSuchMethodException(var1);
   }

   public static Object invokeArgs(Object var0, String var1, Class<?>[] var2, Object[] var3) throws Exception {
      for (Class var4 = var0.getClass(); var4 != null; var4 = var4.getSuperclass()) {
         try {
            Method var5 = var4.getDeclaredMethod(var1, var2);
            var5.setAccessible(true);
            return var5.invoke(var0, var3);
         } catch (NoSuchMethodException var6) {
         }
      }

      Method var7 = var0.getClass().getMethod(var1, var2);
      var7.setAccessible(true);
      return var7.invoke(var0, var3);
   }
}
