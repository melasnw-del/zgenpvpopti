package com.zzwproject.zgenpvp.effects;

public enum EffectType {
   GENERATOR("generator"),
   BEACON("beacon"),
   BASE("base"),
   TURRET("turret"),
   DEFENSE_BLOCK("defense-block"),
   DEFENSE_DOOR("defense-door"),
   DEFENSE_TRAPDOOR("defense-trapdoor");

   private final String path;

   EffectType(String nullxx) {
      this.path = nullxx;
   }

   public String path() {
      return this.path;
   }
}
