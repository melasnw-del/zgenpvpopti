package com.zzwproject.zgenpvp.base;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.hotfix.BasePlacementFix;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.BeaconRepository;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class BaseManager {
   private final ZGenPvP plugin;
   private final BaseRepository baseRepository;
   private final BeaconRepository beaconRepository;
   private final EconomyManager economyManager;
   private final SpecialItemFactory itemFactory;

   public BaseManager(ZGenPvP var1, BaseRepository var2, BeaconRepository var3, EconomyManager var4, SpecialItemFactory var5) {
      this.plugin = var1;
      this.baseRepository = var2;
      this.beaconRepository = var3;
      this.economyManager = var4;
      this.itemFactory = var5;
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("modules.base", true);
   }

   public Optional<BaseData> getBase(UUID var1) {
      return var1 == null ? Optional.empty() : this.baseRepository.findByOwner(var1);
   }

   public Optional<BaseData> getBase(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.baseRepository.findByLocation(var1) : Optional.empty();
   }

   public boolean hasBase(UUID var1) {
      return this.getBase(var1).isPresent();
   }

   public boolean canManageBase(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canManageBase(var1, var2);
      }
   }

   public boolean canManageBase(Player var1, BaseData var2) {
      return var1 != null && var2 != null ? this.canManageBase(var2.getOwnerUuid(), var1.getUniqueId()) : false;
   }

   public boolean createBase(Player var1, Location var2) {
      if (!BasePlacementFix.allow(this.plugin, var1, var2)) {
         return false;
      }

      if (var1 == null || var2 == null || var2.getWorld() == null) {
         return false;
      }

      if (!this.isEnabled()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "base.disabled");
         return false;
      }

      UUID var3 = var1.getUniqueId();
      if (this.hasBase(var3)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "base.already-have");
         return false;
      }

      BaseReplacementCooldownManager var4 = this.plugin.getBaseReplacementCooldownManager();
      if (var4 != null && !var4.canPlace(var1)) {
         long var14 = var4.getRemainingSeconds(var3);
         this.plugin
            .getMessageUtil()
            .sendActionBar(var1, "base.replacement-cooldown", "%time%", var4.formatRemaining(var14), "%seconds%", String.valueOf(var14));
         return false;
      }

      FileConfiguration var5 = this.plugin.getConfigManager().getConfig();
      long var6 = this.beaconRepository.findByOwner(var3).map(BeaconData::getId).orElse(0L);
      int var8 = this.getHealth(1);
      int var9 = this.getRadius(1);
      int var10 = this.getBlockLimit(1);
      String var11 = var5.getString("base.default-name", "%player%'ɪɴ ᴜꜱꜱᴜ");
      if (var11 == null) {
         var11 = var1.getName() + "'ɪɴ ᴜꜱꜱᴜ";
      }

      var11 = var11.replace("%player%", var1.getName());
      long var12 = this.baseRepository.create(var6, var3, var11, var2, 1, var8, var9, var10);
      if (var12 <= 0L) {
         this.plugin.getMessageUtil().sendActionBar(var1, "base.place-error");
         return false;
      } else {
         this.plugin.getMessageUtil().sendActionBar(var1, "base.placed");
         this.plugin.getSoundUtil().play(var1, "base-place");
         return true;
      }
   }

   public boolean renameBase(Player var1, String var2) {
      if (var1 == null) {
         return false;
      }

      Optional var3 = this.getBase(var1.getUniqueId());
      return var3.isEmpty() ? false : this.renameBase(var1, (BaseData)var3.get(), var2);
   }

   public boolean renameBase(Player var1, BaseData var2, String var3) {
      if (var1 != null && var2 != null) {
         Optional var4 = this.getLiveBase(var2);
         if (var4.isEmpty()) {
            return false;
         }

         BaseData var5 = (BaseData)var4.get();
         if (!this.canManageBase(var1, var5)) {
            this.sendOwnerInfo(var1, var5);
            return false;
         }

         String var6 = var3 == null ? "" : var3.trim();
         if (var6.isBlank()) {
            this.plugin.getMessageUtil().sendActionBar(var1, "base.rename-empty");
            return false;
         }

         int var7 = this.plugin.getConfigManager().getConfig().getInt("base.rename.max-length", 24);
         if (var6.length() > var7) {
            this.plugin.getMessageUtil().sendActionBar(var1, "base.rename-too-long", "%max%", String.valueOf(var7));
            return false;
         }

         boolean var8 = this.baseRepository.updateName(var5.getOwnerUuid(), var6);
         if (var8) {
            this.plugin.getMessageUtil().sendActionBar(var1, "base.renamed", "%name%", var6);
            this.plugin.getSoundUtil().play(var1, "base-upgrade");
         }

         return var8;
      } else {
         return false;
      }
   }

   public boolean upgrade(Player var1) {
      if (var1 == null) {
         return false;
      }

      Optional var2 = this.getBase(var1.getUniqueId());
      return var2.isEmpty() ? false : this.upgrade(var1, (BaseData)var2.get());
   }

   public boolean upgrade(Player var1, BaseData var2) {
      if (var1 != null && var2 != null) {
         Optional var3 = this.getLiveBase(var2);
         if (var3.isEmpty()) {
            return false;
         } else {
            BaseData var4 = (BaseData)var3.get();
            if (!this.canManageBase(var1, var4)) {
               this.sendOwnerInfo(var1, var4);
               return false;
            } else {
               int var5 = this.plugin.getConfigManager().getConfig().getInt("base.max-level", 10);
               if (var4.getLevel() >= var5) {
                  this.plugin.getMessageUtil().sendActionBar(var1, "base.max-level");
                  return false;
               } else {
                  double var6 = this.getUpgradePrice(var4.getLevel());
                  if (!this.economyManager.has(var1, var6)) {
                     this.plugin.getMessageUtil().sendActionBar(var1, "base.not-enough-money", "%price%", this.format(var6));
                     this.plugin.getSoundUtil().play(var1, "error");
                     return false;
                  } else if (!this.economyManager.withdraw(var1, var6)) {
                     this.plugin.getMessageUtil().sendActionBar(var1, "general.economy-error");
                     return false;
                  } else {
                     int var8 = var4.getLevel() + 1;
                     boolean var9 = this.baseRepository
                        .updateLevel(var4.getOwnerUuid(), var8, this.getHealth(var8), this.getRadius(var8), this.getBlockLimit(var8));
                     if (!var9) {
                        this.economyManager.deposit(var1, var6);
                        this.plugin.getMessageUtil().sendActionBar(var1, "general.database-error");
                        return false;
                     } else {
                        this.plugin.getMessageUtil().sendActionBar(var1, "base.upgraded", "%level%", String.valueOf(var8), "%price%", this.format(var6));
                        this.plugin.getSoundUtil().play(var1, "base-upgrade");
                        return true;
                     }
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean removeByOwner(Player var1) {
      if (var1 == null) {
         return false;
      }

      Optional var2 = this.getBase(var1.getUniqueId());
      if (var2.isEmpty()) {
         return false;
      }

      boolean var3 = this.plugin.getConfigManager().getConfig().getBoolean("base.remove.give-item-back", true);
      ItemStack var4 = null;
      if (var3) {
         try {
            var4 = this.itemFactory.createBaseBlock();
         } catch (Throwable var10) {
            Logger var6 = this.plugin.getLogger();
            String var7 = var10.getClass().getSimpleName();
            var6.severe("ʙᴀꜱᴇ ʙʟᴏɢᴜ ɢᴇʀɪ ᴠᴇʀɪʟᴇᴄᴇᴋ ɪᴛᴇᴍ ᴏʟᴜꜱᴛᴜʀᴜʟᴀᴍᴀᴅɪ: " + var7 + ": " + var10.getMessage());
            return false;
         }

         if (var4 == null || var4.getType().isAir()) {
            this.plugin.getLogger().severe("ʙᴀꜱᴇ ʙʟᴏɢᴜ ᴋᴀʟᴅɪʀᴍᴀ ɪᴘᴛᴀʟ ᴇᴅɪʟᴅɪ: ɢᴇʀɪ ᴠᴇʀɪʟᴇᴄᴇᴋ ɪᴛᴇᴍ ɢᴇᴄᴇʀꜱɪᴢ.");
            return false;
         }
      }

      boolean var5 = this.baseRepository.deleteByOwner(var1.getUniqueId());
      if (!var5) {
         return false;
      }

      if (var3 && var4 != null) {
         try {
            HashMap<Integer, ItemStack> var12 = var1.getInventory().addItem(new ItemStack[]{var4});

            for (ItemStack var8 : var12.values()) {
               if (var8 != null && !var8.getType().isAir()) {
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var8);
               }
            }
         } catch (Throwable var11) {
            try {
               var1.getWorld().dropItemNaturally(var1.getLocation(), var4);
            } catch (Throwable var9) {
               this.plugin.getLogger().severe("ʙᴀꜱᴇ ʙʟᴏɢᴜ ᴋᴀʟᴅɪʀɪʟᴅɪ ꜰᴀᴋᴀᴛ ɪᴛᴇᴍ ᴏʏᴜɴᴄᴜʏᴀ ᴠᴇʀɪʟᴇᴍᴇᴅɪ: " + var11.getMessage());
            }
         }
      }

      this.plugin.getMessageUtil().sendActionBar(var1, "base.removed");
      return true;
   }

   public void sendOwnerInfo(Player var1, BaseData var2) {
      if (var1 != null && var2 != null && var2.getOwnerUuid() != null) {
         OfflinePlayer var3 = Bukkit.getOfflinePlayer(var2.getOwnerUuid());
         String var4 = var3.getName() == null ? "Bilinmeyen" : var3.getName();
         this.plugin.getMessageUtil().sendActionBar(var1, "base.owner-info", "%owner%", var4);
      }
   }

   public int getHealth(int var1) {
      return this.plugin.getConfigManager().getConfig().getInt("base.levels." + var1 + ".health", 500);
   }

   public int getRadius(int var1) {
      return this.plugin.getConfigManager().getConfig().getInt("base.levels." + var1 + ".radius", 32);
   }

   public int getBlockLimit(int var1) {
      return this.plugin.getConfigManager().getConfig().getInt("base.levels." + var1 + ".block-limit", 50);
   }

   public double getUpgradePrice(int var1) {
      return this.plugin.getConfigManager().getConfig().getDouble("base.levels." + var1 + ".upgrade-price", 0.0);
   }

   private Optional<BaseData> getLiveBase(BaseData var1) {
      return var1 != null && var1.getOwnerUuid() != null ? this.getBase(var1.getOwnerUuid()).filter(var1x -> var1x.getId() == var1.getId()) : Optional.empty();
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }
}
