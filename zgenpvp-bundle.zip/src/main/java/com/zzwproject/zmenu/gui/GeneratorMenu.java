package com.zzwproject.zmenu.gui;

import com.zzwproject.zmenu.ZMenu;
import com.zzwproject.zmenu.service.GeneratorService;
import com.zzwproject.zmenu.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class GeneratorMenu {
   private static final int PAGE_SIZE = 45;
   private final ZMenu plugin;

   public GeneratorMenu(ZMenu var1) {
      this.plugin = var1;
   }

   public void open(Player var1, int var2) {
      GeneratorService var3 = this.plugin.generatorService();
      List var4 = var3.list(var1);
      int var5 = Math.max(1, (var4.size() + 45 - 1) / 45);
      int var6 = Math.max(0, Math.min(var2, var5 - 1));
      MenuHolder var7 = new MenuHolder("generators", var6);
      String var8 = this.plugin.getConfig().getString("generator-menu.title", "Jeneratör Yönetimi • %page%/%pages%");
      var8 = var8.replace("%page%", String.valueOf(var6 + 1)).replace("%pages%", String.valueOf(var5));
      Inventory var9 = Bukkit.createInventory(var7, 54, ColorUtil.color(var8));
      if (this.plugin.getConfig().getBoolean("generator-menu.filler.enabled", false)) {
         MenuItems.fill(
            var9,
            MenuItems.material(this.plugin.getConfig().getString("generator-menu.filler.material"), Material.GRAY_STAINED_GLASS_PANE),
            this.plugin.getConfig().getString("generator-menu.filler.name", " ")
         );
      }

      if (!var3.isAvailable()) {
         var9.setItem(
            22, MenuItems.item(Material.BARRIER, "&c✦ Zgenpvp bulunamadı", List.of("&7Jeneratör yönetimi için ZGenPvP", "&7Sunucuda aktif olmalidir."))
         );
      } else if (var4.isEmpty()) {
         var9.setItem(
            22,
            MenuItems.item(
               Material.MINECART,
               "&7Henüz jeneratörün yok",
               List.of("&7Yerlestirdigin Jeneratörler", "&7Bu menude otomatik gorunur.", "", "&fLimit: &e0&8/&e" + var3.limit(var1))
            )
         );
      } else {
         int var10 = var6 * 45;
         int var11 = Math.min(var4.size(), var10 + 45);

         for (int var12 = var10; var12 < var11; var12++) {
            GeneratorService.GeneratorView var13 = (GeneratorService.GeneratorView)var4.get(var12);
            int var14 = var12 - var10;
            var9.setItem(var14, this.generatorItem(var3, var13, var12 + 1));
            var7.action(var14, new MenuAction("GENERATOR_REMOVE", var13.id() + ":" + var6, false));
         }
      }

      if (var6 > 0) {
         var9.setItem(45, MenuItems.item(Material.ARROW, "&e‹ Önceki sayfa", List.of("&7Sayfa: &f" + var6 + "&8/&f" + var5)));
         var7.action(45, new MenuAction("GENERATOR_PAGE", String.valueOf(var6 - 1), false));
      } else {
         var9.setItem(45, MenuItems.item(Material.OAK_DOOR, "&c‹ Ana menuye dön", List.of("&7Sunucu menusunu aç.")));
         var7.action(45, new MenuAction("MAIN_MENU", "", false));
      }

      Material var16 = var4.isEmpty() ? Material.GRAY_DYE : Material.ANVIL;
      var9.setItem(
         49,
         MenuItems.item(
            var16,
            var4.isEmpty() ? "&7Hepsini yükselt" : "&a✦ Hepsini yükselt",
            List.of(
               "&7Jeneratörlerini en düşük maliyetten başlayarak",
               "&7Paran yettiği kadar birer seviye yükseltir.",
               "",
               "&fJeneratör: &e" + var4.size(),
               "&fMaksimum seviye: &e" + var3.maxLevel(),
               "",
               var4.isEmpty() ? "&8Yükseltilebilecek jeneratör yok." : "&a› yükseltmek için tıkla!"
            )
         )
      );
      if (!var4.isEmpty()) {
         var7.action(49, new MenuAction("GENERATOR_UPGRADE_ALL", String.valueOf(var6), false));
      }

      if (var6 + 1 < var5) {
         var9.setItem(53, MenuItems.item(Material.ARROW, "&eSonraki sayfa ›", List.of("&7Sayfa: &f" + (var6 + 2) + "&8/&f" + var5)));
         var7.action(53, new MenuAction("GENERATOR_PAGE", String.valueOf(var6 + 1), false));
      }

      var1.openInventory(var9);
      this.plugin.sound().play(var1, "menu-open");
   }

   public void remove(Player var1, String var2) {
      String[] var3 = var2 == null ? new String[0] : var2.split(":", 2);
      if (var3.length != 0) {
         try {
            long var4 = Long.parseLong(var3[0]);
            int var6 = var3.length > 1 ? Integer.parseInt(var3[1]) : 0;
            boolean var7 = this.plugin.generatorService().remove(var1, var4);
            if (!var7) {
               this.plugin.message().send(var1, "generator-remove-failed");
               this.plugin.sound().play(var1, "error");
            }

            this.reopen(var1, var6);
         } catch (NumberFormatException var8) {
            this.plugin.message().send(var1, "generator-action-error");
            this.plugin.sound().play(var1, "error");
         }
      }
   }

   public void upgradeAll(Player var1, int var2) {
      GeneratorService.UpgradeSummary var3 = this.plugin.generatorService().upgradeAll(var1);
      if (var3.upgraded() <= 0) {
         this.plugin.message().send(var1, "generator-upgrade-none");
         this.plugin.sound().play(var1, "error");
      } else {
         this.plugin
            .message()
            .send(var1, "generator-upgrade-all", "%count%", String.valueOf(var3.upgraded()), "%cost%", this.plugin.generatorService().format(var3.spent()));
         this.plugin.sound().play(var1, "generator-upgrade");
      }

      this.reopen(var1, var2);
   }

   private void reopen(Player var1, int var2) {
      this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.open(var1, var2));
   }

   private ItemStack generatorItem(GeneratorService var1, GeneratorService.GeneratorView var2, int var3) {
      ArrayList var4 = new ArrayList();
      var4.add("&f│ &7Seviye: &f" + var2.level() + "&8/&f" + var1.maxLevel());
      var4.add("&a│ &7Uretim: &a$" + var1.format(var2.moneyPerCycle()) + " &8(her " + var1.format(var1.intervalSeconds()) + " sn)");
      var4.add("&a│ &7Biriken para: &a$" + var1.format(var2.storedMoney()));
      var4.add("&d│ &7Biriken kristal: &d" + var2.storedShards());
      if (var2.level() < var1.maxLevel()) {
         var4.add("&e│ &7Sonraki yükseltme: &e$" + var1.format(var2.upgradePrice()));
      } else {
         var4.add("&aMaksimum seviyede");
      }

      var4.add("");
      var4.add("&f│ &7Dunya: &f" + var2.world());
      var4.add("&f│ &7Konum: &f" + var2.x() + "&8, &f" + var2.y() + "&8, &f" + var2.z());
      var4.add("");
      var4.add("&c› Uzaktan kaldir");
      var4.add("&8Icindeki ödüller once otomatik aktarilir.");
      return MenuItems.item(var2.material(), "&b✦ Jeneratör #" + var3 + " &8• &fSeviye " + var2.level(), var4);
   }
}
