package com.zzwproject.zgenpvp.defense;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.level.XpRewardManager;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.DefenseRepository;
import com.zzwproject.zgenpvp.v2.EnergySupport;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class DefenseManager {
   public static final String TYPE = "DEFENSE_BLOCK";
   public static final String TYPE_HEAVY = "DEFENSE_TANK";
   private final ZGenPvP plugin;
   private final DefenseRepository defenseRepository;
   private final BaseRepository baseRepository;
   private final EconomyManager economyManager;
   private final SpecialItemFactory itemFactory;
   private final XpRewardManager xpRewardManager;
   private final Map<String, DefenseData> defenseCache = new HashMap<>();
   private final Map<String, Long> hitCooldowns = new HashMap<>();

   public DefenseManager(ZGenPvP var1, DefenseRepository var2, BaseRepository var3, EconomyManager var4, SpecialItemFactory var5, XpRewardManager var6) {
      this.plugin = var1;
      this.defenseRepository = var2;
      this.baseRepository = var3;
      this.economyManager = var4;
      this.itemFactory = var5;
      this.xpRewardManager = var6;
   }

   public void loadCache() {
      this.defenseCache.clear();
      this.loadType("DEFENSE_BLOCK");
      this.loadType("DEFENSE_TANK");
      this.plugin.getLogger().info(this.defenseCache.size() + " defans bloğu cache'e yüklendi.");
   }

   private void loadType(String var1) {
      for (DefenseData var3 : this.defenseRepository.findAllByType(var1)) {
         this.defenseCache.put(this.key(var3.getWorldName(), var3.getX(), var3.getY(), var3.getZ()), var3);
      }
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("modules.defenses", true)
         && this.plugin.getConfigManager().getDefenses().getBoolean("defense-block.enabled", true);
   }

   public Optional<DefenseData> getDefense(Location var1) {
      return var1 != null && var1.getWorld() != null ? Optional.ofNullable(this.defenseCache.get(this.key(var1))) : Optional.empty();
   }

   public boolean canManageDefense(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : this.plugin.getZTeamHook() != null && TeamPermissionBridge.defenseManage(this.plugin.getZTeamHook(), var1, var2);
      }
   }

   public boolean canManageDefense(Player var1, DefenseData var2) {
      return var1 != null && var2 != null && this.canManageDefense(var2.getOwnerUuid(), var1.getUniqueId());
   }

   public boolean place(Player var1, Location var2, int var3) {
      return this.place(var1, var2, "DEFENSE_BLOCK", var3);
   }

   public boolean place(Player var1, Location var2, String var3, int var4) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         var3 = this.normalizeType(var3);
         if (!this.typeEnabled(var3)) {
            this.plugin.getMessageUtil().sendActionBar(var1, "defense.disabled");
            return false;
         }

         BaseData var5 = TeamPermissionBridge.findOwnOrTeamBase(this.baseRepository, var1.getUniqueId())
            .filter(var2x -> this.isInsideBase(var2x, var2))
            .orElse(null);
         long var6 = 0L;
         if (var5 != null) {
            if (this.plugin.getBaseEnergyManager() != null && !this.plugin.getBaseEnergyManager().isPowered(var5)) {
               this.plugin.getMessageUtil().sendActionBar(var1, "defense.energy-required");
               this.plugin.getSoundUtil().play(var1, "error");
               return false;
            }

            int var8 = this.defenseRepository.countStructures(var5.getId());
            if (var8 >= var5.getBlockLimit()) {
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(var1, "defense.structure-limit", "%current%", String.valueOf(var8), "%max%", String.valueOf(var5.getBlockLimit()));
               return false;
            }

            var6 = var5.getId();
         }

         int var14 = Math.max(1, Math.min(this.getMaxLevel(var3), var4));
         int var9 = this.getHealth(var3, var14);
         long var10 = this.defenseRepository.create(var6, var1.getUniqueId(), var3, var2, var14, var9);
         if (var10 <= 0L) {
            this.plugin.getMessageUtil().sendActionBar(var1, "defense.place-error");
            return false;
         } else {
            DefenseData var12 = new DefenseData(
               var10, var6, var1.getUniqueId(), var3, var2.getWorld().getName(), var2.getBlockX(), var2.getBlockY(), var2.getBlockZ(), var14, var9, var9
            );
            this.defenseCache.put(this.key(var2), var12);
            var2.getBlock().setType(this.getMaterial(var3, var14), false);
            this.plugin.getMessageUtil().sendActionBar(var1, "defense.placed", "%level%", String.valueOf(var14), "%health%", String.valueOf(var9));
            this.plugin.getSoundUtil().play(var1, "defense-place");
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean upgrade(Player var1, DefenseData var2) {
      if (var1 == null || var2 == null) {
         return false;
      }

      if (!this.canManageDefense(var1, var2)) {
         this.sendOwnerInfo(var1, var2);
         return false;
      }

      String var3 = this.normalizeType(var2.getType());
      int var4 = this.getMaxLevel(var3);
      if (var2.getLevel() >= var4) {
         this.plugin.getMessageUtil().sendActionBar(var1, "defense.max-level");
         return false;
      }

      double var5 = this.getUpgradePrice(var3, var2.getLevel());
      if (!this.economyManager.has(var1, var5)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "defense.not-enough-money", "%price%", this.format(var5));
         this.plugin.getSoundUtil().play(var1, "error");
         return false;
      }

      if (!this.economyManager.withdraw(var1, var5)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "general.economy-error");
         return false;
      }

      int var7 = var2.getLevel() + 1;
      int var8 = this.getHealth(var3, var7);
      if (!this.defenseRepository.updateLevel(var2.getId(), var7, var8)) {
         this.economyManager.deposit(var1, var5);
         this.plugin.getMessageUtil().sendActionBar(var1, "general.database-error");
         return false;
      }

      var2.setLevel(var7);
      var2.setCurrentHp(var8);
      var2.setMaxHp(var8);
      Location var9 = var2.getLocation();
      if (var9 != null && var9.getWorld() != null) {
         var9.getBlock().setType(this.getMaterial(var3, var7), false);
      }

      this.plugin
         .getMessageUtil()
         .sendActionBar(var1, "defense.upgraded", "%level%", String.valueOf(var7), "%health%", String.valueOf(var8), "%price%", this.format(var5));
      this.plugin.getSoundUtil().play(var1, "defense-upgrade");
      return true;
   }

   public void showInfo(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         String var3 = this.normalizeType(var2.getType());
         double var4 = var2.getLevel() >= this.getMaxLevel(var3) ? 0.0 : this.getUpgradePrice(var3, var2.getLevel());
         this.plugin
            .getMessageUtil()
            .sendActionBar(
               var1,
               "defense.info",
               "%level%",
               String.valueOf(var2.getLevel()),
               "%health%",
               String.valueOf(var2.getCurrentHp()),
               "%max_health%",
               String.valueOf(var2.getMaxHp()),
               "%price%",
               this.format(var4)
            );
      }
   }

   public void damage(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null && !this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
         String var3 = this.normalizeType(var2.getType());
         String var4 = var1.getUniqueId() + ":" + var2.getId();
         long var5 = System.currentTimeMillis();
         long var7 = this.plugin.getConfigManager().getDefenses().getLong(this.root(var3) + ".attack.hit-cooldown-milliseconds", 120L);
         Long var9 = this.hitCooldowns.get(var4);
         if (var9 == null || var5 - var9 >= var7) {
            this.hitCooldowns.put(var4, var5);
            int var10 = Math.max(1, this.plugin.getConfigManager().getDefenses().getInt(this.root(var3) + ".attack.damage-per-hit", 1));
            this.damage(var1, var2, var10, false);
         }
      }
   }

   public void damage(Player var1, DefenseData var2, int var3, boolean var4) {
      if (var1 != null && var2 != null && !this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
         int var5 = var4 ? var2.getCurrentHp() : Math.max(1, var3);
         if (!EnergySupport.isPowered(this.plugin, var2)) {
            var5 *= 2;
         }

         int var6 = Math.max(0, var2.getCurrentHp() - var5);
         this.plugin
            .getRaidAlertManager()
            .alert(
               var2.getOwnerUuid(),
               var1,
               this.displayName(var2.getType()),
               var2.getLocation(),
               var2.getLevel(),
               var6,
               var2.getMaxHp(),
               var4 ? "Instabreaker/Bomba" : "Oyuncu saldırısı"
            );
         if (var6 > 0) {
            if (this.defenseRepository.updateHealth(var2.getId(), var6)) {
               var2.setCurrentHp(var6);
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(
                     var1,
                     "defense.hit-actionbar",
                     "%health%",
                     String.valueOf(var6),
                     "%max_health%",
                     String.valueOf(var2.getMaxHp()),
                     "%damage%",
                     String.valueOf(var5)
                  );
               this.plugin.getSoundUtil().play(var1, "defense-hit");
            }
         } else {
            this.destroy(var1, var2);
         }
      }
   }

   public boolean removeByOwner(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!TeamPermissionBridge.defenseBlockOwnerOrAllowed(var2.getOwnerUuid(), var1.getUniqueId())) {
            return false;
         }

         boolean var3 = this.defenseRepository.delete(var2.getId());
         if (!var3 && this.defenseRepository.existsById(var2.getId())) {
            return false;
         }

         this.defenseCache.remove(this.key(var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()));
         if (this.plugin.getConfigManager().getDefenses().getBoolean(this.root(var2.getType()) + ".owner-break.return-item", true)) {
            ItemStack var4 = this.itemFactory.createDefenseBlock(var2.getType(), var2.getLevel());
            if (var4 != null) {
               HashMap<Integer, ItemStack> var5 = var1.getInventory().addItem(new ItemStack[]{var4});

               for (ItemStack var7 : var5.values()) {
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var7);
               }
            }
         }

         this.plugin.getMessageUtil().sendActionBar(var1, "defense.removed", "%level%", String.valueOf(var2.getLevel()));
         this.plugin.getSoundUtil().play(var1, "defense-remove");
         return true;
      } else {
         return false;
      }
   }

   private void destroy(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null && !this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
         if (this.defenseRepository.delete(var2.getId())) {
            this.defenseCache.remove(this.key(var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()));
            Location var3 = var2.getLocation();
            if (var3 != null && var3.getWorld() != null) {
               var3.getBlock().setType(Material.AIR, false);
            }

            this.plugin.getMessageUtil().sendActionBar(var1, "defense.destroyed");
            OfflinePlayer var4 = this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid());
            if (var4.isOnline() && var4.getPlayer() != null) {
               this.plugin.getMessageUtil().send(var4.getPlayer(), "defense.destroyed-owner", "%attacker%", var1.getName());
            }

            this.plugin.getSoundUtil().play(var1, "defense-break");
            this.xpRewardManager.reward(var1, XpRewardType.DEFENSE_DESTROY);
         }
      }
   }

   public boolean isFriendly(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : this.plugin.getZTeamHook() != null && this.plugin.getZTeamHook().areTeammates(var1, var2);
      }
   }

   public void sendOwnerInfo(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         OfflinePlayer var3 = this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid());
         String var4 = var3.getName() == null ? "Bilinmeyen" : var3.getName();
         this.plugin.getMessageUtil().sendActionBar(var1, "defense.owner-info", "%owner%", var4);
      }
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null) {
         if (!var1.getWorldName().equals(var2.getWorld().getName())) {
            return false;
         }

         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = var1.getRadius();
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   public int getMaxLevel() {
      return this.getMaxLevel("DEFENSE_BLOCK");
   }

   public int getMaxLevel(String var1) {
      return Math.max(1, this.plugin.getConfigManager().getDefenses().getInt(this.root(var1) + ".max-level", 15));
   }

   public int getHealth(int var1) {
      return this.getHealth("DEFENSE_BLOCK", var1);
   }

   public int getHealth(String var1, int var2) {
      return this.plugin.getConfigManager().getDefenses().getInt(this.root(var1) + ".levels." + var2 + ".health", 150);
   }

   public double getUpgradePrice(int var1) {
      return this.getUpgradePrice("DEFENSE_BLOCK", var1);
   }

   public double getUpgradePrice(String var1, int var2) {
      return this.plugin.getConfigManager().getDefenses().getDouble(this.root(var1) + ".levels." + var2 + ".upgrade-price", 0.0);
   }

   public Material getMaterial(int var1) {
      return this.getMaterial("DEFENSE_BLOCK", var1);
   }

   public Material getMaterial(String var1, int var2) {
      String var3 = this.plugin.getConfigManager().getDefenses().getString(this.root(var1) + ".levels." + var2 + ".material", "MOSSY_COBBLESTONE");
      Material var4 = Material.matchMaterial(var3 == null ? "MOSSY_COBBLESTONE" : var3);
      return var4 == null ? Material.MOSSY_COBBLESTONE : var4;
   }

   public String displayName(String var1) {
      return "Defans Bloğu";
   }

   public boolean typeEnabled(String var1) {
      return this.plugin.getConfigManager().getDefenses().getBoolean("defense-block.enabled", true);
   }

   private String normalizeType(String var1) {
      return "DEFENSE_BLOCK";
   }

   private String root(String var1) {
      return "defense-block";
   }

   private String key(Location var1) {
      return this.key(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
   }

   private String key(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }

   private String format(double var1) {
      return String.format("%,.0f", var1);
   }
}
