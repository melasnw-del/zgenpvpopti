package com.zzwproject.zgenboss.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class BossCombatFix {
   private static final Map<String, Long> LAST_HIT = new ConcurrentHashMap<>();
   private static final Object NO_METHOD = new Object();

   private BossCombatFix() {
   }

   public static void ensureTarget(Object var0, Object var1) {
      try {
         Object var2 = invoke(var0, "getConfig");
         if (!getBoolean(var2, "combat.attack-players", true)) {
            return;
         }

         Object var3 = field(var1, "entity");
         if (var3 == null || bool(invoke(var3, "isDead"), false)) {
            return;
         }

         tryInvoke(var3, "setAI", true);
         tryInvoke(var3, "setAware", true);
         tryInvoke(var3, "setPersistent", true);
         tryInvoke(var3, "setRemoveWhenFarAway", false);
         double var4 = getDouble(var2, "combat.target-radius", 24.0);
         Object var6x;
         if (var3 instanceof org.bukkit.entity.Entity var5x) {
            var6x = var5x.getWorld().getNearbyPlayers(var5x.getLocation(), var4);
         } else {
            var6x = invoke(var3, "getNearbyEntities", var4, var4, var4);
         }

         if (!(var6x instanceof Iterable var7)) {
            return;
         }

         Object var8 = invoke(var3, "getLocation");
         Object var9 = null;
         double var10 = Double.MAX_VALUE;

         for (Object var13 : var7) {
            if (var13 != null && isPlayer(var13) && !bool(tryInvoke(var13, "isDead"), false)) {
               String var14 = String.valueOf(tryInvoke(var13, "getGameMode"));
               if (!"CREATIVE".equalsIgnoreCase(var14) && !"SPECTATOR".equalsIgnoreCase(var14) && !bool(tryInvoke(var13, "isInvulnerable"), false)) {
                  Object var15 = tryInvoke(var13, "getLocation");
                  if (var15 != null) {
                     double var16 = number(tryInvoke(var8, "distanceSquared", var15), Double.MAX_VALUE);
                     if (var16 < var10) {
                        var10 = var16;
                        var9 = var13;
                     }
                  }
               }
            }
         }

         if (var9 == null) {
            return;
         }

         tryInvoke(var3, "setTarget", var9);

         try {
            Object var27 = invoke(var3, "getPathfinder");
            if (var27 != null) {
               Object var29 = tryInvoke(var27, "moveTo", var9);
               if (var29 == NO_METHOD || var29 == null) {
                  Object var30 = tryInvoke(var9, "getLocation");
                  if (var30 != null) {
                     tryInvoke(var27, "moveTo", var30);
                  }
               }
            }
         } catch (Throwable var25) {
         }

         if (!getBoolean(var2, "combat.manual-melee.enabled", true)) {
            return;
         }

         double var28 = getDouble(var2, "combat.manual-melee.range", 3.25);
         if (var10 > var28 * var28) {
            return;
         }

         String var31 = String.valueOf(tryInvoke(var3, "getUniqueId"));
         long var32 = System.currentTimeMillis();
         long var17 = Math.max(500L, getLong(var2, "combat.manual-melee.cooldown-milliseconds", 1050L));
         long var19 = LAST_HIT.getOrDefault(var31, 0L);
         if (var32 - var19 < var17) {
            return;
         }

         LAST_HIT.put(var31, var32);
         double var21 = 4.0;

         try {
            Object var23 = field(var1, "type");
            var21 = number(field(var23, "damage"), var21);
         } catch (Throwable var24) {
         }

         var21 = Math.max(0.5, var21 * getDouble(var2, "combat.manual-melee.damage-multiplier", 1.0));
         var21 = BossLevelBalance.scaleDamage(var0, var1, var21);
         guaranteedDamage(var0, var2, var9, var3, var21);
      } catch (Throwable var26) {
         warn(var0, "Boss combat v2 hatasi: " + var26.getClass().getSimpleName() + ": " + var26.getMessage());
      }
   }

   private static void guaranteedDamage(Object var0, Object var1, Object var2, Object var3, double var4) {
      try {
         double var6 = number(tryInvoke(var2, "getHealth"), -1.0);
         double var8 = Math.max(0.0, number(tryInvoke(var2, "getAbsorptionAmount"), 0.0));
         Object var10 = tryInvoke(var2, "damage", var4, var3);
         if (var10 == NO_METHOD) {
            tryInvoke(var2, "damage", var4);
         }

         double var11 = number(tryInvoke(var2, "getHealth"), var6);
         double var13 = Math.max(0.0, number(tryInvoke(var2, "getAbsorptionAmount"), var8));
         boolean var15 = var11 + 0.001 < var6 || var13 + 0.001 < var8;
         if (var15) {
            return;
         }

         if (!getBoolean(var1, "combat.manual-melee.force-if-cancelled", true)) {
            return;
         }

         if (var6 <= 0.0) {
            return;
         }

         double var16 = var4;
         if (var8 > 0.0) {
            double var18 = Math.min(var8, var16);
            double var20 = Math.max(0.0, var8 - var18);
            Object var22 = tryInvoke(var2, "setAbsorptionAmount", var20);
            if (var22 != NO_METHOD) {
               var16 -= var18;
            }
         }

         if (var16 > 0.0) {
            double var24 = Math.max(0.0, var6 - var16);
            tryInvoke(var2, "setHealth", var24);
         }

         tryInvoke(var2, "setNoDamageTicks", 20);
         tryInvoke(var2, "playHurtAnimation", 0.0F);
         if (getBoolean(var1, "combat.manual-melee.debug", false)) {
            warn(var0, "Boss hasari event tarafında iptal edildi; force fallback uygulandi. Damage=" + var4);
         }
      } catch (Throwable var23) {
         warn(var0, "Boss guaranteed damage hatasi: " + var23.getClass().getSimpleName() + ": " + var23.getMessage());
      }
   }

   private static boolean isPlayer(Object var0) {
      try {
         return Class.forName("org.bukkit.entity.Player").isInstance(var0);
      } catch (Throwable var2) {
         return false;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object invoke(Object var0, String var1, Object... var2) throws Exception {
      Object var3 = invoke0(var0, var1, var2);
      if (var3 == NO_METHOD) {
         throw new NoSuchMethodException(var1);
      } else {
         return var3;
      }
   }

   private static Object tryInvoke(Object var0, String var1, Object... var2) {
      if (var0 == null) {
         return NO_METHOD;
      }

      try {
         return invoke0(var0, var1, var2);
      } catch (Throwable var4) {
         return NO_METHOD;
      }
   }

   private static Object invoke0(Object var0, String var1, Object... var2) throws Exception {
      for (Method var6 : var0.getClass().getMethods()) {
         if (var6.getName().equals(var1) && var6.getParameterCount() == var2.length && matches(var6.getParameterTypes(), var2)) {
            try {
               var6.setAccessible(true);
            } catch (Throwable var9) {
            }

            return var6.invoke(var0, var2);
         }
      }

      for (Class var11 = var0.getClass(); var11 != null; var11 = var11.getSuperclass()) {
         for (Method var7 : var11.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length && matches(var7.getParameterTypes(), var2)) {
               try {
                  var7.setAccessible(true);
               } catch (Throwable var10) {
               }

               return var7.invoke(var0, var2);
            }
         }
      }

      return NO_METHOD;
   }

   private static boolean matches(Class<?>[] var0, Object[] var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else {
            Class var3 = wrap(var0[var2]);
            if (!var3.isAssignableFrom(var1[var2].getClass()) && (!Number.class.isAssignableFrom(var3) || !(var1[var2] instanceof Number))) {
               return false;
            }
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static double number(Object var0, double var1) {
      return var0 instanceof Number var3 ? var3.doubleValue() : var1;
   }

   private static boolean bool(Object var0, boolean var1) {
      return var0 instanceof Boolean var2 ? var2 : var1;
   }

   private static boolean getBoolean(Object var0, String var1, boolean var2) {
      Object var3 = tryInvoke(var0, "getBoolean", var1, var2);
      return var3 == NO_METHOD ? var2 : bool(var3, var2);
   }

   private static double getDouble(Object var0, String var1, double var2) {
      Object var4 = tryInvoke(var0, "getDouble", var1, var2);
      return var4 == NO_METHOD ? var2 : number(var4, var2);
   }

   private static long getLong(Object var0, String var1, long var2) {
      Object var4 = tryInvoke(var0, "getLong", var1, var2);
      return var4 == NO_METHOD ? var2 : (long)number(var4, var2);
   }

   private static void warn(Object var0, String var1) {
      try {
         Object var2 = invoke(var0, "getLogger");
         tryInvoke(var2, "warning", var1);
      } catch (Throwable var3) {
      }
   }
}
