package com.zzwproject.zgenpvp.access;

public enum DefenseAccessType {
   DOOR("DEFENSE_DOOR", "door"),
   TRAPDOOR("DEFENSE_TRAPDOOR", "trapdoor");

   private final String databaseType;
   private final String configPath;

   DefenseAccessType(String databaseType, String configPath) {
      this.databaseType = databaseType;
      this.configPath = configPath;
   }

   public String getDatabaseType() {
      return this.databaseType;
   }

   public String getConfigPath() {
      return this.configPath;
   }
}
