package com.zzwproject.zgenpvp.util;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class MessageUtil {
   private final ZGenPvP plugin;

   public MessageUtil(ZGenPvP plugin) {
      this.plugin = plugin;
   }

   public void send(CommandSender sender, String path, String... replacements) {
      sender.sendMessage(this.get(path, replacements));
   }

   public void sendList(CommandSender sender, String path, String... replacements) {
      FileConfiguration messages = this.plugin.getConfigManager().getMessages();

      for (String line : messages.getStringList(path)) {
         sender.sendMessage(ColorUtil.color(this.replace(line, replacements)));
      }
   }

   public void sendActionBar(Player player, String path, String... replacements) {
      String legacy = this.get(path, replacements);
      Component component = LegacyComponentSerializer.legacySection().deserialize(legacy);
      player.sendActionBar(component);
   }

   public String get(String path, String... replacements) {
      FileConfiguration messages = this.plugin.getConfigManager().getMessages();
      String message = messages.getString(path, path);
      return ColorUtil.color(this.replace(message, replacements));
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }
}
