package com.zzwproject.zgenpvp.generator.sellwand;

import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class SellWandListener implements Listener {
   private final SellWandManager sellWandManager;

   public SellWandListener(SellWandManager sellWandManager) {
      this.sellWandManager = sellWandManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (this.sellWandManager.isSellWand(event.getItem())) {
               Block block = event.getClickedBlock();
               if (block != null) {
                  if (block.getState() instanceof Container) {
                     event.setCancelled(true);
                     this.sellWandManager.sell(event.getPlayer(), block);
                  }
               }
            }
         }
      }
   }
}
