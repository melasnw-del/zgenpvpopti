package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.hotfix.HotfixHooks;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.BeaconBreakGuard;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.RaidSessionBridge;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class BeaconListener implements Listener {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final BeaconMenu beaconMenu;
   private final SpecialItemFactory itemFactory;

   public BeaconListener(ZGenPvP var1, BeaconManager var2, BeaconMenu var3, SpecialItemFactory var4) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.beaconMenu = var3;
      this.itemFactory = var4;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      Block var2 = var1.getBlockPlaced();
      Block var3 = var2.getRelative(BlockFace.DOWN);
      if (var3.getType() == Material.BEACON
         && this.beaconManager.getBeacon(var3.getLocation()).isPresent()
         && !this.itemFactory.isDefenseTrapdoor(var1.getItemInHand())) {
         var1.setCancelled(true);
         this.plugin.getMessageUtil().send(var1.getPlayer(), "beacon.block-above-blocked");
         this.plugin.getSoundUtil().play(var1.getPlayer(), "error");
         StructureSupportGuard.restore(this, var1);
      } else if (!this.itemFactory.isRespawnBeacon(var1.getItemInHand())) {
         StructureSupportGuard.restore(this, var1);
      } else {
         boolean var4 = this.beaconManager.createBeacon(var1.getPlayer(), var2.getLocation());
         if (!var4) {
            var1.setCancelled(true);
         }

         StructureSupportGuard.restore(this, var1);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND) {
         if (var1.getAction().isRightClick()) {
            Block var2 = var1.getClickedBlock();
            if (var2 != null && var2.getType() == Material.BEACON) {
               Optional var3 = this.beaconManager.getBeacon(var2.getLocation());
               if (!var3.isEmpty()) {
                  var1.setUseInteractedBlock(Result.DENY);
                  ItemStack var4 = var1.getItem();
                  if (var4 != null && !var4.getType().isAir() && this.itemFactory.isDefenseTrapdoor(var4) && var1.getBlockFace() == BlockFace.UP) {
                     var1.setUseItemInHand(Result.ALLOW);
                  } else if (var4 != null && !var4.getType().isAir() && var4.getType().isBlock() && var1.getBlockFace() == BlockFace.UP) {
                     var1.setUseItemInHand(Result.DENY);
                     this.plugin.getMessageUtil().send(var1.getPlayer(), "beacon.block-above-blocked");
                     this.plugin.getSoundUtil().play(var1.getPlayer(), "error");
                  } else if (var4 != null && !var4.getType().isAir() && var4.getType().isBlock()) {
                     var1.setUseItemInHand(Result.ALLOW);
                  } else if (var4 != null && !var4.getType().isAir()) {
                     var1.setUseItemInHand(Result.DEFAULT);
                  } else {
                     var1.setCancelled(true);
                     Player var5 = var1.getPlayer();
                     BeaconData var6 = (BeaconData)var3.get();
                     if (!this.beaconManager.canUseBeacon(var5, var6)) {
                        this.beaconManager.sendOwnerInfo(var5, var6);
                        this.plugin.getSoundUtil().play(var5, "error");
                     } else {
                        this.beaconMenu.open(var5, var6);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      HotfixHooks.forceBeaconCancelSettings(this);
      if (!RaidSessionBridge.handleBeaconDamage(var1)) {
         if (var1.getBlock().getType() == Material.BEACON) {
            Optional var2 = this.beaconManager.getBeacon(var1.getBlock().getLocation());
            if (!var2.isEmpty()) {
               Player var3 = var1.getPlayer();
               BeaconData var4 = (BeaconData)var2.get();
               if (!TeamPermissionBridge.beaconBreakAllowed(this.beaconManager, var3, var4)) {
                  if (!StructureMiningUtil.isPickaxe(var3)) {
                     var1.setCancelled(true);
                     StructureMiningUtil.stopMining(var3);
                     return;
                  }

                  StructureMiningUtil.stopMining(var3);
                  var1.setCancelled(false);
                  return;
               }
            }
         }

         if (var1.getBlock().getType() == Material.BEACON) {
            Optional var7 = this.beaconManager.getBeacon(var1.getBlock().getLocation());
            if (!var7.isEmpty()) {
               var1.setCancelled(true);
               if (this.plugin.getConfigManager().getConfig().getBoolean("beacon.remove.mine-to-remove", true)) {
                  Player var8 = var1.getPlayer();
                  Block var9 = var1.getBlock();
                  BeaconData var5 = (BeaconData)var7.get();
                  if (!StructureMiningUtil.isPickaxe(var8)) {
                     StructureMiningUtil.stopMining(var8);
                     this.plugin.getMessageUtil().sendActionBar(var8, "beacon.use-pickaxe-to-remove");
                  } else if (!TeamPermissionBridge.beaconBreakAllowed(this.beaconManager, var8, var5)) {
                     StructureMiningUtil.stopMining(var8);
                     this.beaconManager.sendOwnerInfo(var8, var5);
                  } else {
                     if (this.plugin.getBaseRepository() != null) {
                        BaseData var6 = this.plugin.getBaseRepository().findByOwner(var5.getOwnerUuid()).orElse(null);
                        if (var6 != null && var6.getBeaconId() == var5.getId()) {
                           StructureMiningUtil.stopMining(var8);
                           this.plugin.getMessageUtil().send(var8, "beacon.remove-base-first");
                           this.plugin.getSoundUtil().play(var8, "error");
                           return;
                        }
                     }

                     StructureMiningUtil.startOwnerMining(
                        this.plugin,
                        var8,
                        var9,
                        "BEACON:" + var5.getId(),
                        () -> this.beaconManager.getBeacon(var9.getLocation()).isPresent(),
                        () -> this.beaconManager.removeBeacon(var8, var5)
                     );
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onBreak(BlockBreakEvent var1) {
      if (!BeaconBreakGuard.handle(this, var1)) {
         if (!RaidSessionBridge.handleBeaconBreak(var1)) {
            if (var1.getBlock().getType() == Material.BEACON) {
               Optional var2 = this.beaconManager.getBeacon(var1.getBlock().getLocation());
               if (!var2.isEmpty()) {
                  Player var3 = var1.getPlayer();
                  BeaconData var4 = (BeaconData)var2.get();
                  if (!TeamPermissionBridge.beaconBreakAllowed(this.beaconManager, var3, var4)) {
                     var1.setCancelled(true);
                     var1.setDropItems(false);
                     var1.setExpToDrop(0);
                     StructureMiningUtil.stopMining(var3);
                     if (!this.plugin.getBeaconRepository().deleteById(var4.getId())) {
                        return;
                     }

                     if (this.plugin.getBaseRepository() != null) {
                        this.plugin.getBaseRepository().clearCache();
                     }

                     this.beaconManager.cancelRespawn(var4.getOwnerUuid());
                     var1.getBlock().setType(Material.AIR, false);
                     return;
                  }
               }
            }

            if (var1.getBlock().getType() == Material.BEACON) {
               Optional var5 = this.beaconManager.getBeacon(var1.getBlock().getLocation());
               if (!var5.isEmpty()) {
                  var1.setCancelled(true);
                  Player var6 = var1.getPlayer();
                  BeaconData var7 = (BeaconData)var5.get();
                  if (!TeamPermissionBridge.beaconBreakAllowed(this.beaconManager, var6, var7)) {
                     this.beaconManager.sendOwnerInfo(var6, var7);
                  } else {
                     if (!StructureMiningUtil.isPickaxe(var6)) {
                        this.plugin.getMessageUtil().sendActionBar(var6, "beacon.use-pickaxe-to-remove");
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onDamage(EntityDamageEvent var1) {
      HotfixHooks.forceBeaconCancelSettings(this);
      HotfixHooks.handleBeaconDamageDealt(this, var1);
      if (var1.getEntity() instanceof Player var2) {
         if (this.beaconManager.isTeleporting(var2.getUniqueId())) {
            if (this.plugin.getConfigManager().getConfig().getBoolean("beacon.respawn.cancel-on-damage", true)) {
               if (!(var1.getFinalDamage() <= 0.0)) {
                  this.beaconManager.cancelRespawn(var2, "respawn.cancelled-damage");
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onMove(PlayerMoveEvent var1) {
      HotfixHooks.forceBeaconCancelSettings(this);
      Player var2 = var1.getPlayer();
      if (this.beaconManager.isTeleporting(var2.getUniqueId())) {
         if (this.plugin.getConfigManager().getConfig().getBoolean("beacon.respawn.cancel-on-move", false)) {
            if (var1.getTo() != null) {
               boolean var3 = var1.getFrom().getBlockX() != var1.getTo().getBlockX()
                  || var1.getFrom().getBlockY() != var1.getTo().getBlockY()
                  || var1.getFrom().getBlockZ() != var1.getTo().getBlockZ()
                  || var1.getFrom().getWorld() != var1.getTo().getWorld();
               if (var3) {
                  this.beaconManager.cancelRespawn(var2, "respawn.cancelled-move");
               }
            }
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      this.beaconManager.cancelRespawn(var1.getPlayer().getUniqueId());
   }
}
