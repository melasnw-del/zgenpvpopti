package com.zzwproject.zgenpvp.defense;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.hotfix.StructureSupportGuard;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.util.StructureMiningUtil;
import java.util.Optional;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class DefenseListener implements Listener {
   private final ZGenPvP plugin;
   private final DefenseManager defenseManager;
   private final SpecialItemFactory itemFactory;

   public DefenseListener(ZGenPvP var1, DefenseManager var2, SpecialItemFactory var3) {
      this.plugin = var1;
      this.defenseManager = var2;
      this.itemFactory = var3;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onPlace(BlockPlaceEvent var1) {
      StructureSupportGuard.capture(this, var1);
      if (this.itemFactory.isDefenseBlock(var1.getItemInHand())) {
         int var2 = this.itemFactory.getDefenseLevel(var1.getItemInHand());
         if (!this.defenseManager.place(var1.getPlayer(), var1.getBlockPlaced().getLocation(), this.itemFactory.getDefenseType(var1.getItemInHand()), var2)) {
            var1.setCancelled(true);
         }
      }

      StructureSupportGuard.restore(this, var1);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInteract(PlayerInteractEvent var1) {
      if (var1.getHand() == EquipmentSlot.HAND) {
         Block var2 = var1.getClickedBlock();
         if (var2 != null) {
            Optional var3 = this.defenseManager.getDefense(var2.getLocation());
            if (!var3.isEmpty()) {
               DefenseData var4 = (DefenseData)var3.get();
               Player var5 = var1.getPlayer();
               if (var1.getAction().isRightClick()) {
                  ItemStack var6 = var1.getItem();
                  if (var6 == null || var6.getType().isAir() || !var6.getType().isBlock()) {
                     var1.setCancelled(true);
                     if (this.defenseManager.canManageDefense(var5, var4) && var5.isSneaking()) {
                        this.defenseManager.upgrade(var5, var4);
                     } else {
                        this.defenseManager.showInfo(var5, var4);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDamage(BlockDamageEvent var1) {
      Optional var2 = this.defenseManager.getDefense(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         Player var3 = var1.getPlayer();
         DefenseData var4 = (DefenseData)var2.get();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var3.getInventory().getItemInMainHand())) {
            var1.setCancelled(true);
            String var5 = "DEFENSE:" + var4.getId();
            if (TeamPermissionBridge.defenseBlockOwnerOrAllowed(var4.getOwnerUuid(), var3.getUniqueId())) {
               StructureMiningUtil.startOwnerMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  () -> this.defenseManager.getDefense(var1.getBlock().getLocation()).isPresent(),
                  () -> this.defenseManager.getDefense(var1.getBlock().getLocation()).ifPresent(var3x -> {
                     if (this.defenseManager.removeByOwner(var3, var3x)) {
                        var1.getBlock().setType(Material.AIR, false);
                     }
                  })
               );
            } else if (this.defenseManager.isFriendly(var3.getUniqueId(), var4.getOwnerUuid())) {
               StructureMiningUtil.stopMining(var3);
               this.defenseManager.sendOwnerInfo(var3, var4);
            } else {
               StructureMiningUtil.startEnemyMining(
                  this.plugin,
                  var3,
                  var1.getBlock(),
                  var5,
                  var4::getCurrentHp,
                  var4::getMaxHp,
                  () -> this.defenseManager.getDefense(var1.getBlock().getLocation()).isPresent(),
                  () -> this.defenseManager.getDefense(var1.getBlock().getLocation()).ifPresent(var2xx -> this.defenseManager.damage(var3, var2xx))
               );
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDamageAbort(BlockDamageAbortEvent var1) {
      StructureMiningUtil.stopMining(var1.getPlayer(), var1.getBlock());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBreak(BlockBreakEvent var1) {
      Optional var2 = this.defenseManager.getDefense(var1.getBlock().getLocation());
      if (!var2.isEmpty()) {
         var1.setCancelled(true);
         var1.setDropItems(false);
         var1.setExpToDrop(0);
         DefenseData var3 = (DefenseData)var2.get();
         Player var4 = var1.getPlayer();
         if (this.plugin.getInstabreakerManager() == null || !this.plugin.getInstabreakerManager().isInstabreaker(var4.getInventory().getItemInMainHand())) {
            if (TeamPermissionBridge.defenseBlockOwnerOrAllowed(var3.getOwnerUuid(), var4.getUniqueId())) {
               if (this.defenseManager.removeByOwner(var4, var3)) {
                  var1.getBlock().setType(Material.AIR, false);
               }
            } else if (this.defenseManager.isFriendly(var4.getUniqueId(), var3.getOwnerUuid())) {
               this.defenseManager.sendOwnerInfo(var4, var3);
            } else {
               this.defenseManager.damage(var4, var3);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onEntityExplode(EntityExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.defenseManager.getDefense(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBlockExplode(BlockExplodeEvent var1) {
      var1.blockList().removeIf(var1x -> this.defenseManager.getDefense(var1x.getLocation()).isPresent());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonExtend(BlockPistonExtendEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.defenseManager.getDefense(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPistonRetract(BlockPistonRetractEvent var1) {
      for (Block var3 : var1.getBlocks()) {
         if (this.defenseManager.getDefense(var3.getLocation()).isPresent()) {
            var1.setCancelled(true);
            return;
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEntityChangeBlock(EntityChangeBlockEvent var1) {
      if (this.defenseManager.getDefense(var1.getBlock().getLocation()).isPresent()) {
         var1.setCancelled(true);
      }
   }
}
