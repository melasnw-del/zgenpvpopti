package com.zzwproject.zbazooka;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

public final class ZBazooka extends LegacyPluginBase {
   private static final String DEFAULT_BAZOOKA_ID = "zzwraid:bazooka";
   private static final String DEFAULT_AMMO_ID = "zzwraid:bazooka_ammo";
   private final Map<UUID, Long> cooldownUntil = new ConcurrentHashMap<>();
   private final Map<UUID, ZBazooka.Shot> shots = new ConcurrentHashMap<>();
   private final Map<Long, ZBazooka.WatchedBase> baseWatches = new ConcurrentHashMap<>();
   private final List<Object> proxyRefs = new ArrayList<>();
   private Object trailTask;
   private Object baseWatchTask;
   private boolean enabled;
   private int damage;
   private long cooldownMillis;
   private double maxDistance;
   private double projectileSpeed;
   private int bazookaPrice;
   private int ammoPrice;
   private int bazookaSlot;
   private int ammoSlot;
   private int shiftAmmoAmount;
   private boolean preventMultipleBazookas;
   private String bazookaId;
   private String ammoId;

   @Override
   public void onEnable() {
      try {
         this.saveDefaultConfig();
         this.loadSettings();
         this.registerEvent("org.bukkit.event.player.PlayerInteractEvent", this::onInteract, "HIGHEST", false);
         this.registerEvent("org.bukkit.event.entity.ProjectileHitEvent", this::onProjectileHit, "HIGHEST", false);
         this.registerEvent("org.bukkit.event.inventory.InventoryOpenEvent", this::onInventoryOpen, "MONITOR", false);
         this.registerEvent("org.bukkit.event.inventory.InventoryClickEvent", this::onInventoryClick, "HIGHEST", false);
         this.registerEvent("org.bukkit.event.player.PlayerQuitEvent", this::onPlayerQuit, "MONITOR", false);
         this.registerAdminCommand();
         this.startTrailTask();
         if (!this.itemsAdderReady()) {
            this.getLogger().warning("[ZBazooka] ItemsAdder API bulunamadi. Model paketi kurulmadan bazuka verilemez/satin alinamaz.");
         }

         this.getLogger()
            .info(
               "[ZBazooka] Bazuka raid sistemi aktif. Hasar="
                  + this.damage
                  + ", cooldown="
                  + this.cooldownMillis / 1000.0
                  + "s, menzil="
                  + this.maxDistance
                  + ", fiyat="
                  + this.bazookaPrice
                  + " shard, mermi="
                  + this.ammoPrice
                  + " shard."
            );
      } catch (Throwable var2) {
         this.getLogger().log(Level.SEVERE, "[ZBazooka] Sistem baslatilamadi.", var2);
      }
   }

   @Override
   public void onDisable() {
      this.shots.clear();
      this.baseWatches.clear();
      this.cooldownUntil.clear();
      if (this.trailTask != null) {
         try {
            invoke(this.trailTask, "cancel");
         } catch (Throwable var3) {
         }
      }

      if (this.baseWatchTask != null) {
         try {
            invoke(this.baseWatchTask, "cancel");
         } catch (Throwable var2) {
         }
      }

      this.proxyRefs.clear();
   }

   private void loadSettings() throws Exception {
      Object var1 = invoke(this, "getConfig");
      this.enabled = boolCfg(var1, "enabled", true);
      this.damage = Math.max(1, intCfg(var1, "combat.damage", 250));
      this.cooldownMillis = Math.max(0L, (long)(doubleCfg(var1, "combat.cooldown-seconds", 4.0) * 1000.0));
      this.maxDistance = Math.max(5.0, doubleCfg(var1, "combat.max-distance", 35.0));
      this.projectileSpeed = clamp(doubleCfg(var1, "combat.projectile-speed", 2.35), 0.5, 4.0);
      this.bazookaPrice = Math.max(1, intCfg(var1, "market.bazooka-price-shard", 500));
      this.ammoPrice = Math.max(1, intCfg(var1, "market.ammo-price-shard", 25));
      this.bazookaSlot = clampInt(intCfg(var1, "market.bazooka-slot", 22), 0, 53);
      this.ammoSlot = clampInt(intCfg(var1, "market.ammo-slot", 23), 0, 53);
      this.shiftAmmoAmount = clampInt(intCfg(var1, "market.shift-ammo-amount", 8), 1, 64);
      this.preventMultipleBazookas = boolCfg(var1, "market.prevent-multiple-bazookas", true);
      this.bazookaId = strCfg(var1, "itemsadder.bazooka-id", "zzwraid:bazooka");
      this.ammoId = strCfg(var1, "itemsadder.ammo-id", "zzwraid:bazooka_ammo");
   }

   private void registerEvent(String var1, Consumer<Object> var2, String var3, boolean var4) throws Exception {
      ClassLoader var5 = this.getClass().getClassLoader();
      Class var6 = Class.forName("org.bukkit.event.Listener");
      Class var7 = Class.forName("org.bukkit.plugin.EventExecutor");
      Class var8 = Class.forName(var1);
      Class var9 = Class.forName("org.bukkit.event.EventPriority");
      Class var10 = Class.forName("org.bukkit.plugin.Plugin");
      Enum var11 = Enum.valueOf(var9, var3);
      Object var12 = Proxy.newProxyInstance(var5, new Class[]{var6}, (var0, var1x, var2x) -> objectMethod(var0, var1x, var2x, "ZBazookaListener"));
      Object var13 = Proxy.newProxyInstance(var5, new Class[]{var7}, (var3x, var4x, var5x) -> {
         if (var4x.getName().equals("execute") && var5x != null && var5x.length >= 2) {
            try {
               var2.accept(var5x[1]);
            } catch (Throwable var7x) {
               this.getLogger().log(Level.WARNING, "[ZBazooka] Event hatasi: " + var1, unwrap(var7x));
            }
         }

         return null;
      });
      this.proxyRefs.add(var12);
      this.proxyRefs.add(var13);
      Class var14 = Class.forName("org.bukkit.Bukkit");
      Object var15 = var14.getMethod("getPluginManager").invoke(null);
      Method var16 = var15.getClass().getMethod("registerEvent", Class.class, var6, var9, var7, var10, boolean.class);
      var16.invoke(var15, var8, var12, var11, var13, this, var4);
   }

   private void registerAdminCommand() {
      try {
         Object var1 = invoke(this, "getCommand", "zbazooka");
         if (var1 == null) {
            return;
         }

         Class var2 = Class.forName("org.bukkit.command.CommandExecutor");
         Object var3 = Proxy.newProxyInstance(this.getClass().getClassLoader(), new Class[]{var2}, (var1x, var2x, var3x) -> {
            if (!var2x.getName().equals("onCommand")) {
               return false;
            }

            Object var4x = var3x[0];
            String[] var5 = (String[])var3x[3];
            return this.onAdminCommand(var4x, var5);
         });
         this.proxyRefs.add(var3);
         invoke(var1, "setExecutor", var3);
      } catch (Throwable var4) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Admin komutu kaydedilemedi.", unwrap(var4));
      }
   }

   private boolean onAdminCommand(Object var1, String[] var2) {
      try {
         if (var2.length == 1 && var2[0].equalsIgnoreCase("reload")) {
            invoke(this, "reloadConfig");
            this.loadSettings();
            this.send(var1, "&aZBazooka ayarlari yenilendi.");
            return true;
         }

         if (var2.length >= 3 && var2[0].equalsIgnoreCase("give")) {
            Object var3 = bukkitStatic("getPlayerExact", var2[1]);
            if (var3 == null) {
               this.send(var1, "&cOyuncu bulunamadi.");
               return true;
            }

            String var4 = var2[2].toLowerCase(Locale.ROOT);
            int var5 = 1;
            if (var2.length >= 4) {
               try {
                  var5 = clampInt(Integer.parseInt(var2[3]), 1, 64);
               } catch (NumberFormatException var8) {
               }
            }

            Object var6;
            if (!var4.equals("bazuka") && !var4.equals("bazooka")) {
               if (!var4.equals("mermi") && !var4.equals("ammo")) {
                  this.send(var1, "&cKullanim: /zbazooka give <oyuncu> <bazuka|mermi> [miktar]");
                  return true;
               }

               var6 = this.createCustomItem(this.ammoId);
            } else {
               var6 = this.createCustomItem(this.bazookaId);
               var5 = 1;
            }

            if (var6 == null) {
               this.send(var1, "&cItemsAdder itemi bulunamadi. Once zzwraid content packini kur.");
               return true;
            } else {
               invoke(var6, "setAmount", var5);
               if (!this.canFit(var3, var6, var5)) {
                  this.send(var1, "&cOyuncunun envanteri dolu.");
                  return true;
               } else {
                  Object var7 = invoke(var3, "getInventory");
                  addItemToInventory(var7, var6);
                  this.send(var1, "&aEsya verildi.");
                  return true;
               }
            }
         } else {
            this.send(var1, "&e/zbazooka give <oyuncu> <bazuka|mermi> [miktar] &7veya &e/zbazooka reload");
            return true;
         }
      } catch (Throwable var9) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Komut hatasi.", unwrap(var9));
         this.send(var1, "&cKomut islenirken hata olustu.");
         return true;
      }
   }

   private void onInteract(Object var1) {
      if (this.enabled) {
         try {
            Object var2 = invoke(var1, "getHand");
            if (var2 != null && !String.valueOf(var2).equals("HAND") && !String.valueOf(var2).equals("MAIN_HAND")) {
               return;
            }

            String var3 = String.valueOf(invoke(var1, "getAction"));
            if (!var3.startsWith("RIGHT_CLICK")) {
               return;
            }

            Object var4 = invoke(var1, "getPlayer");
            Object var5 = invoke(var1, "getItem");
            if (var5 == null) {
               var5 = invoke(invoke(var4, "getInventory"), "getItemInMainHand");
            }

            if (!this.isCustomItem(var5, this.bazookaId)) {
               return;
            }

            invoke(var1, "setCancelled", true);
            UUID var6 = (UUID)invoke(var4, "getUniqueId");
            long var7 = System.currentTimeMillis();
            long var9 = this.cooldownUntil.getOrDefault(var6, 0L);
            if (var9 > var7) {
               double var16 = Math.ceil((var9 - var7) / 100.0) / 10.0;
               this.send(var4, "&cBazuka yeniden doluyor. &f" + var16 + " saniye");
               this.playSound(var4, "block.note_block.hat", 0.6F, 0.7F);
               return;
            }

            if (!this.consumeOneAmmo(var4)) {
               this.send(var4, "&cBazuka mermin yok. &7Market > Raid bolumunden satin alabilirsin.");
               this.playSound(var4, "entity.villager.no", 0.7F, 0.9F);
               return;
            }

            Object var11 = this.launchProjectile(var4);
            if (var11 == null) {
               this.giveItem(var4, this.ammoId, 1);
               this.send(var4, "&cBazuka atisi baslatilamadi. Mermin iade edildi.");
               return;
            }

            UUID var12 = (UUID)invoke(var11, "getUniqueId");
            Object var13 = invoke(var4, "getEyeLocation");
            this.shots.put(var12, new ZBazooka.Shot(var6, var13, var7 + 4000L));
            this.cooldownUntil.put(var6, var7 + this.cooldownMillis);
            this.playSound(var4, "entity.firework_rocket.launch", 1.0F, 0.72F);
            this.playSound(var4, "item.crossbow.shoot", 0.55F, 0.65F);
            Object var14 = invoke(var4, "getEyeLocation");
            this.spawnParticleAt(var14, "SMOKE", 8);
            this.spawnParticleAt(var14, "FLAME", 5);
            this.spawnParticleAt(var14, "FLASH", 1);
         } catch (Throwable var15) {
            this.getLogger().log(Level.WARNING, "[ZBazooka] Atesleme hatasi.", unwrap(var15));
         }
      }
   }

   private Object launchProjectile(Object var1) throws Exception {
      Class var2 = Class.forName("org.bukkit.entity.Snowball");
      Object var3 = invoke(var1, "launchProjectile", var2);
      if (var3 == null) {
         return null;
      }

      try {
         invoke(var3, "setGravity", false);
      } catch (Throwable var12) {
      }

      try {
         invoke(var3, "setInvulnerable", true);
      } catch (Throwable var11) {
      }

      Object var4 = invoke(var1, "getEyeLocation");
      Object var5 = invoke(var4, "getDirection");

      try {
         Method var6 = var5.getClass().getMethod("multiply", double.class);
         var6.invoke(var5, this.projectileSpeed);
      } catch (NoSuchMethodException var10) {
         invoke(var5, "multiply", this.projectileSpeed);
      }

      invoke(var3, "setVelocity", var5);
      Object var13 = this.createCustomItem(this.ammoId);
      if (var13 != null) {
         try {
            invoke(var3, "setItem", var13);
         } catch (Throwable var9) {
         }
      }

      try {
         invoke(var3, "setGlowing", true);
      } catch (Throwable var8) {
      }

      return var3;
   }

   private void onProjectileHit(Object var1) {
      try {
         Object var2 = invoke(var1, "getEntity");
         if (var2 == null) {
            return;
         }

         UUID var3 = (UUID)invoke(var2, "getUniqueId");
         ZBazooka.Shot var4 = this.shots.remove(var3);
         if (var4 == null) {
            return;
         }

         Object var5 = invoke(var2, "getLocation");
         if (var4.origin != null && var5 != null) {
            double var6 = number(invoke(var5, "distance", var4.origin)).doubleValue();
            if (var6 > this.maxDistance + 1.5) {
               this.removeEntity(var2);
               return;
            }
         }

         Object var10 = invoke(var1, "getHitBlock");
         Object var7 = bukkitStatic("getPlayer", var4.shooter);
         boolean var8 = false;
         if (var10 != null && var7 != null) {
            var8 = this.damageDefense(var7, var10);
         }

         if (var5 != null) {
            this.spawnParticleAt(var5, var8 ? "EXPLOSION" : "SMOKE", var8 ? 3 : 6);
            this.spawnParticleAt(var5, "FLAME", var8 ? 14 : 4);
            this.spawnParticleAt(var5, "CAMPFIRE_COSY_SMOKE", var8 ? 5 : 2);
            this.spawnParticleAt(var5, "ELECTRIC_SPARK", var8 ? 8 : 2);
            this.playWorldSound(var5, var8 ? "entity.generic.explode" : "block.stone.hit", var8 ? 0.95F : 0.45F, var8 ? 1.15F : 0.8F);
            if (var8) {
               this.playWorldSound(var5, "entity.firework_rocket.blast", 0.55F, 0.85F);
            }
         }

         if (!var8 && var7 != null) {
            this.send(var7, "&7Bazuka mermisi bir savunma yapisina isabet etmedi.");
         }

         this.removeEntity(var2);
      } catch (Throwable var9) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Mermi isabet hatasi.", unwrap(var9));
      }
   }

   private boolean damageDefense(Object var1, Object var2) {
      try {
         Object var3 = this.getPlugin("ZGenPvP");
         if (var3 == null) {
            return false;
         }

         Object var4 = invoke(var2, "getLocation");
         Object var5 = invoke(var3, "getDefenseManager");
         Object var6 = invoke(var5, "getDefense", var4);
         Object var7 = this.optionalValue(var6);
         if (var7 != null) {
            invoke(var5, "damage", var1, var7, this.damage, false);
            return true;
         }

         Object var8 = invoke(var3, "getDefenseAccessManager");
         Object var9 = invoke(var8, "get", var2);
         Object var10 = this.optionalValue(var9);
         if (var10 != null) {
            invoke(var8, "damage", var1, var10, this.damage, false);
            return true;
         }
      } catch (Throwable var11) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Savunma hasari uygulanamadi.", unwrap(var11));
      }

      return false;
   }

   private void onInventoryOpen(Object var1) {
      try {
         Object var2 = invoke(var1, "getView");
         if (!this.isRaidView(var2)) {
            return;
         }

         Object var3 = invoke(var1, "getInventory");
         this.setMarketIcon(var3, this.bazookaSlot, true);
         this.setMarketIcon(var3, this.ammoSlot, false);
      } catch (Throwable var4) {
         this.getLogger().log(Level.FINE, "[ZBazooka] Market ikonu guncellenemedi.", unwrap(var4));
      }
   }

   private void onInventoryClick(Object var1) {
      try {
         Object var2 = invoke(var1, "getView");
         if (!this.isRaidView(var2)) {
            return;
         }

         int var3 = number(invoke(var1, "getRawSlot")).intValue();
         boolean var4 = var3 == this.bazookaSlot;
         boolean var5 = var3 == this.ammoSlot;
         if (!var4 && !var5) {
            return;
         }

         invoke(var1, "setCancelled", true);
         Object var6 = invoke(var1, "getWhoClicked");
         int var7 = 1;
         if (var5 && bool(invoke(var1, "isShiftClick"))) {
            var7 = this.shiftAmmoAmount;
         }

         this.purchase(var6, var4, var7);
      } catch (Throwable var8) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Market satin alma hatasi.", unwrap(var8));
      }
   }

   private void purchase(Object var1, boolean var2, int var3) throws Exception {
      if (!this.itemsAdderReady()) {
         this.send(var1, "&cItemsAdder modeli yuklu degil. zzwraid content packini kurup /iareload kullan.");
         this.playSound(var1, "entity.villager.no", 0.7F, 0.9F);
      } else if (var2 && this.preventMultipleBazookas && this.inventoryHas(var1, this.bazookaId)) {
         this.send(var1, "&cEnvanterinde zaten bir Bazuka var.");
         this.playSound(var1, "entity.villager.no", 0.7F, 0.9F);
      } else {
         String var4 = var2 ? this.bazookaId : this.ammoId;
         Object var5 = this.createCustomItem(var4);
         if (var5 == null) {
            this.send(var1, "&cItemsAdder itemi bulunamadi: &f" + var4);
         } else {
            var3 = var2 ? 1 : clampInt(var3, 1, 64);
            invoke(var5, "setAmount", var3);
            if (!this.canFit(var1, var5, var3)) {
               this.send(var1, "&cEnvanterinde yeterli bos yer yok.");
               this.playSound(var1, "entity.villager.no", 0.7F, 0.9F);
            } else {
               long var6 = var2 ? this.bazookaPrice : this.ammoPrice;
               long var8 = var6 * var3;
               Object var10 = this.shardApi();
               if (var10 == null) {
                  this.send(var1, "&cShard sistemi bulunamadi.");
               } else {
                  UUID var11 = (UUID)invoke(var1, "getUniqueId");
                  boolean var12 = bool(invoke(var10, "hasShards", var11, var8));
                  if (!var12) {
                     long var19 = number(invoke(var10, "getBalance", var11)).longValue();
                     this.send(var1, "&cYeterli Shard yok. &7Gerekli: &d✦" + var8 + " &8• &7Bakiyen: &d✦" + var19);
                     this.playSound(var1, "entity.villager.no", 0.7F, 0.9F);
                  } else if (!bool(invoke(var10, "removeShards", var11, var8))) {
                     this.send(var1, "&cShard bakiyesi dusurulemedi. Tekrar dene.");
                  } else {
                     try {
                        Object var13 = invoke(var1, "getInventory");
                        if (addItemToInventory(var13, var5) instanceof Map var15 && !var15.isEmpty()) {
                           invoke(var10, "addShards", var11, var8);
                           this.send(var1, "&cEnvanter dolu oldugu icin satin alma iptal edildi; Shard iade edildi.");
                           return;
                        }
                     } catch (Throwable var17) {
                        try {
                           invoke(var10, "addShards", var11, var8);
                        } catch (Throwable var16) {
                        }

                        throw var17;
                     }

                     this.send(var1, var2 ? "&aBazuka satin aldin. &7Odenen: &d✦" + var8 : "&a" + var3 + "x Bazuka Mermisi satin aldin. &7Odenen: &d✦" + var8);
                     this.playSound(var1, "entity.experience_orb.pickup", 0.8F, 1.25F);
                  }
               }
            }
         }
      }
   }

   private void setMarketIcon(Object var1, int var2, boolean var3) throws Exception {
      Object var4 = this.createCustomItem(var3 ? this.bazookaId : this.ammoId);
      if (var4 == null) {
         var4 = this.createVanillaItem(var3 ? "BARRIER" : "GRAY_DYE");
      }

      if (var4 != null) {
         String var5 = var3 ? "&cBazuka" : "&6Bazuka Mermisi";
         ArrayList var6 = new ArrayList();
         var6.add("");
         if (var3) {
            var6.add("&7Savunma bloklari, kapilar ve");
            var6.add("&7tuzak kapilarina uzaktan hasar verir.");
            var6.add("");
            var6.add("&7Hasar: &c" + this.damage);
            var6.add("&7Cooldown: &f" + trimSeconds(this.cooldownMillis) + " saniye");
            var6.add("&7Menzil: &f" + (int)this.maxDistance + " blok");
            var6.add("&7Mermi: &fBazuka Mermisi");
            var6.add("");
            var6.add("&7Fiyat: &d✦" + this.bazookaPrice);
         } else {
            var6.add("&7Bazuka ile kullanilan ozel");
            var6.add("&7raid muhimmati.");
            var6.add("");
            var6.add("&7Fiyat: &d✦" + this.ammoPrice + " &7/ adet");
            var6.add("&8Shift + tik: " + this.shiftAmmoAmount + " adet");
         }

         var6.add("");
         var6.add("&a› Satin almak icin tikla!");
         this.decorate(var4, var5, var6);
         invoke(var1, "setItem", var2, var4);
      }
   }

   private void onBaseDamageWatch(Object var1) {
      try {
         Object var2 = this.getPlugin("ZGenPvP");
         if (var2 == null) {
            return;
         }

         Object var3 = invoke(var1, "getBlock");
         if (var3 == null) {
            return;
         }

         Object var4 = invoke(var3, "getLocation");
         Object var5 = invoke(var2, "getBaseManager");
         Object var6 = this.optionalValue(invoke(var5, "getBase", var4));
         if (var6 == null) {
            return;
         }

         long var7 = number(invoke(var6, "getId")).longValue();
         if (var7 <= 0L) {
            return;
         }

         this.baseWatches.put(var7, new ZBazooka.WatchedBase(var6, var4, System.currentTimeMillis() + 30000L));
      } catch (Throwable var9) {
         this.getLogger().log(Level.FINE, "[ZBazooka] Base cascade izleme baslatilamadi.", unwrap(var9));
      }
   }

   private void startBaseWatchTask() {
      try {
         Class var1 = Class.forName("org.bukkit.Bukkit");
         Object var2 = var1.getMethod("getScheduler").invoke(null);
         Runnable var3 = () -> {
            long var1x = System.currentTimeMillis();

            try {
               Object var3x = this.getPlugin("ZGenPvP");
               if (var3x == null) {
                  return;
               }

               Object var4x = invoke(var3x, "getBaseManager");
               Iterator var5 = this.baseWatches.entrySet().iterator();

               while (var5.hasNext()) {
                  Entry var6 = (Entry)var5.next();
                  ZBazooka.WatchedBase var7 = (ZBazooka.WatchedBase)var6.getValue();
                  if (var1x > var7.expiresAt) {
                     var5.remove();
                  } else {
                     Object var8 = this.optionalValue(invoke(var4x, "getBase", var7.location));
                     boolean var9 = var8 == null;
                     if (!var9) {
                        long var10 = number(invoke(var8, "getId")).longValue();
                        var9 = var10 != (Long)var6.getKey();
                     }

                     if (var9) {
                        try {
                           Class var14 = Class.forName("com.zzwproject.zgenpvp.hotfix.BaseCascade");
                           invokeStatic(var14, "remove", var3x, var7.baseData);
                           this.spawnParticleAt(var7.location, "SMOKE", 8);
                           this.getLogger().info("[ZBazooka] Base silindi; bagli defans/taret yapilari otomatik temizlendi. baseId=" + var6.getKey());
                        } catch (Throwable var12) {
                           this.getLogger().log(Level.WARNING, "[ZBazooka] Base cascade temizligi basarisiz.", unwrap(var12));
                        }

                        var5.remove();
                     }
                  }
               }
            } catch (Throwable var13) {
               this.getLogger().log(Level.FINE, "[ZBazooka] Base cascade izleme gorevi hatasi.", unwrap(var13));
            }
         };
         this.baseWatchTask = invoke(var2, "runTaskTimer", this, var3, 5L, 5L);
      } catch (Throwable var4) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Base cascade izleme gorevi baslatilamadi.", unwrap(var4));
      }
   }

   private void onPlayerQuit(Object var1) {
      try {
         Object var2 = invoke(var1, "getPlayer");
         UUID var3 = (UUID)invoke(var2, "getUniqueId");
         this.cooldownUntil.remove(var3);
         this.shots.entrySet().removeIf(var1x -> var1x.getValue().shooter.equals(var3));
      } catch (Throwable var4) {
      }
   }

   private void startTrailTask() {
      try {
         Class var1 = Class.forName("org.bukkit.Bukkit");
         Object var2 = var1.getMethod("getScheduler").invoke(null);
         Runnable var3 = () -> {
            try {
               long var1x = System.currentTimeMillis();
               Iterator var3x = this.shots.entrySet().iterator();

               while (var3x.hasNext()) {
                  Entry var4x = (Entry)var3x.next();
                  Object var5 = bukkitStatic("getEntity", var4x.getKey());
                  if (var5 == null) {
                     var3x.remove();
                  } else {
                     Object var6 = invoke(var5, "getLocation");
                     boolean var7 = var1x > ((ZBazooka.Shot)var4x.getValue()).expiresAt;
                     if (!var7 && ((ZBazooka.Shot)var4x.getValue()).origin != null && var6 != null) {
                        try {
                           double var8 = number(invoke(var6, "distance", ((ZBazooka.Shot)var4x.getValue()).origin)).doubleValue();
                           var7 = var8 > this.maxDistance;
                        } catch (Throwable var10) {
                        }
                     }

                     if (var7) {
                        this.removeEntity(var5);
                        var3x.remove();
                     } else if (var6 != null) {
                        this.spawnParticleAt(var6, "SMOKE", 2);
                        this.spawnParticleAt(var6, "FLAME", 1);
                        this.spawnParticleAt(var6, "ELECTRIC_SPARK", 1);
                     }
                  }
               }
            } catch (Throwable var11) {
               this.getLogger().log(Level.FINE, "[ZBazooka] Mermi izi gorevi hatasi.", unwrap(var11));
            }
         };
         this.trailTask = invoke(var2, "runTaskTimer", this, var3, 1L, 2L);
      } catch (Throwable var4) {
         this.getLogger().log(Level.WARNING, "[ZBazooka] Mermi izi gorevi baslatilamadi.", unwrap(var4));
      }
   }

   private boolean consumeOneAmmo(Object var1) throws Exception {
      Object var2 = invoke(var1, "getInventory");
      if (invoke(var2, "getContents") instanceof Object[] var4) {
         for (int var5 = 0; var5 < var4.length; var5++) {
            Object var6 = var4[var5];
            if (this.isCustomItem(var6, this.ammoId)) {
               int var7 = number(invoke(var6, "getAmount")).intValue();
               if (var7 <= 1) {
                  invoke(var2, "setItem", var5, null);
               } else {
                  invoke(var6, "setAmount", var7 - 1);
               }

               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean inventoryHas(Object var1, String var2) throws Exception {
      Object var3 = invoke(var1, "getInventory");
      if (invoke(var3, "getContents") instanceof Object[] var5) {
         for (Object var9 : var5) {
            if (this.isCustomItem(var9, var2)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean canFit(Object var1, Object var2, int var3) throws Exception {
      Object var4 = invoke(var1, "getInventory");
      if (!(invoke(var4, "getStorageContents") instanceof Object[] var6)) {
         return true;
      } else {
         int var7 = number(invoke(var2, "getMaxStackSize")).intValue();
         int var8 = 0;

         for (Object var12 : var6) {
            if (var12 != null && !this.isAir(var12)) {
               try {
                  if (bool(invoke(var12, "isSimilar", var2))) {
                     int var13 = number(invoke(var12, "getAmount")).intValue();
                     var8 += Math.max(0, var7 - var13);
                  }
               } catch (Throwable var14) {
               }
            } else {
               var8 += var7;
            }

            if (var8 >= var3) {
               return true;
            }
         }

         return var8 >= var3;
      }
   }

   private boolean isAir(Object var1) {
      try {
         Object var2 = invoke(var1, "getType");
         return var2 == null || String.valueOf(var2).equals("AIR") || bool(invoke(var2, "isAir"));
      } catch (Throwable var3) {
         return false;
      }
   }

   private void giveItem(Object var1, String var2, int var3) {
      try {
         Object var4 = this.createCustomItem(var2);
         if (var4 == null) {
            return;
         }

         invoke(var4, "setAmount", var3);
         addItemToInventory(invoke(var1, "getInventory"), var4);
      } catch (Throwable var5) {
      }
   }

   private boolean itemsAdderReady() {
      try {
         Class.forName("dev.lone.itemsadder.api.CustomStack");
         return this.getPlugin("ItemsAdder") != null;
      } catch (Throwable var2) {
         return false;
      }
   }

   private Object createCustomItem(String var1) {
      try {
         Class var2 = Class.forName("dev.lone.itemsadder.api.CustomStack");
         Object var3 = invokeStatic(var2, "getInstance", var1);
         return var3 == null ? null : invoke(var3, "getItemStack");
      } catch (Throwable var4) {
         return null;
      }
   }

   private boolean isCustomItem(Object var1, String var2) {
      if (var1 == null) {
         return false;
      }

      try {
         Class var3 = Class.forName("dev.lone.itemsadder.api.CustomStack");
         Object var4 = null;

         try {
            var4 = invokeStatic(var3, "byItemStack", var1);
         } catch (Throwable var11) {
         }

         if (var4 == null) {
            for (Method var8 : var3.getMethods()) {
               if (var8.getName().equals("getInstance") && var8.getParameterCount() == 1) {
                  Class var9 = var8.getParameterTypes()[0];
                  if (var9.isInstance(var1)) {
                     var4 = var8.invoke(null, var1);
                     break;
                  }
               }
            }
         }

         if (var4 == null) {
            return false;
         }

         for (String var16 : new String[]{"getNamespacedID", "getNamespacedId", "getId"}) {
            try {
               Object var17 = invoke(var4, var16);
               if (var17 != null && var2.equalsIgnoreCase(String.valueOf(var17))) {
                  return true;
               }
            } catch (Throwable var10) {
            }
         }
      } catch (Throwable var12) {
      }

      return false;
   }

   private Object createVanillaItem(String var1) {
      try {
         Class var2 = Class.forName("org.bukkit.Material");
         Enum var3 = Enum.valueOf(var2, var1);
         Class var4 = Class.forName("org.bukkit.inventory.ItemStack");
         Constructor var5 = var4.getConstructor(var2);
         return var5.newInstance(var3);
      } catch (Throwable var6) {
         return null;
      }
   }

   private void decorate(Object var1, String var2, List<String> var3) {
      try {
         Object var4 = invoke(var1, "getItemMeta");
         if (var4 == null) {
            return;
         }

         try {
            invoke(var4, "setDisplayName", color(var2));
         } catch (Throwable var8) {
         }

         try {
            ArrayList var5 = new ArrayList();

            for (String var7 : var3) {
               var5.add(color(var7));
            }

            invoke(var4, "setLore", var5);
         } catch (Throwable var9) {
         }

         invoke(var1, "setItemMeta", var4);
      } catch (Throwable var10) {
      }
   }

   private Object shardApi() {
      try {
         Object var1 = this.getPlugin("ZShard");
         if (var1 == null) {
            return null;
         }

         try {
            return invoke(var1, "getAPI");
         } catch (Throwable var3) {
            return invoke(var1, "getApi");
         }
      } catch (Throwable var4) {
         return null;
      }
   }

   private Object getPlugin(String var1) throws Exception {
      Class var2 = Class.forName("org.bukkit.Bukkit");
      Object var3 = var2.getMethod("getPluginManager").invoke(null);
      Object var4 = BundleResolver.getPlugin(var3, var1);
      return var4 != null ? var4 : invoke(var3, "getPlugin", var1);
   }

   private boolean isRaidView(Object var1) {
      try {
         String var2 = String.valueOf(invoke(var1, "getTitle")).toLowerCase(Locale.ROOT);
         return var2.contains("ʀᴀɪᴅ") || var2.contains("raid");
      } catch (Throwable var3) {
         return false;
      }
   }

   private void playSound(Object var1, String var2, float var3, float var4) {
      try {
         Object var5 = invoke(var1, "getLocation");
         invoke(var1, "playSound", var5, var2, var3, var4);
      } catch (Throwable var6) {
      }
   }

   private void playWorldSound(Object var1, String var2, float var3, float var4) {
      try {
         Object var5 = invoke(var1, "getWorld");
         if (var5 != null) {
            invoke(var5, "playSound", var1, var2, var3, var4);
         }
      } catch (Throwable var6) {
      }
   }

   private void spawnParticleAt(Object var1, String var2, int var3) {
      if (var1 != null) {
         try {
            Class var4 = Class.forName("org.bukkit.Particle");
            Enum var5 = Enum.valueOf(var4, var2);
            Object var6 = invoke(var1, "getWorld");
            if (var6 != null) {
               invoke(var6, "spawnParticle", var5, var1, var3);
            }
         } catch (Throwable var7) {
         }
      }
   }

   private void removeEntity(Object var1) {
      try {
         invoke(var1, "remove");
      } catch (Throwable var3) {
      }
   }

   private Object optionalValue(Object var1) {
      if (var1 == null) {
         return null;
      }

      try {
         return !bool(invoke(var1, "isPresent")) ? null : invoke(var1, "get");
      } catch (Throwable var3) {
         return null;
      }
   }

   private void send(Object var1, String var2) {
      try {
         invoke(var1, "sendMessage", color(var2));
      } catch (Throwable var4) {
      }
   }

   private static String color(String var0) {
      return var0 == null ? "" : var0.replace('&', '§');
   }

   private static String trimSeconds(long var0) {
      double var2 = var0 / 1000.0;
      return Math.floor(var2) == var2 ? Integer.toString((int)var2) : Double.toString(var2);
   }

   private static Object objectMethod(Object var0, Method var1, Object[] var2, String var3) {
      return switch (var1.getName()) {
         case "toString" -> var3;
         case "hashCode" -> System.identityHashCode(var0);
         case "equals" -> var2 != null && var2.length == 1 && var0 == var2[0];
         default -> null;
      };
   }

   private static Object addItemToInventory(Object var0, Object var1) throws Exception {
      if (var0 != null && var1 != null) {
         for (Method var5 : var0.getClass().getMethods()) {
            if (var5.getName().equals("addItem") && var5.getParameterCount() == 1) {
               Class var6 = var5.getParameterTypes()[0];
               if (var6.isArray()) {
                  Class var7 = var6.getComponentType();
                  if (var7.isInstance(var1)) {
                     Object var8 = Array.newInstance(var7, 1);
                     Array.set(var8, 0, var1);
                     var5.setAccessible(true);
                     return var5.invoke(var0, var8);
                  }
               }
            }
         }

         throw new NoSuchMethodException(var0.getClass().getName() + ".addItem(ItemStack[])");
      } else {
         return null;
      }
   }

   private static Object bukkitStatic(String var0, Object... var1) throws Exception {
      return invokeStatic(Class.forName("org.bukkit.Bukkit"), var0, var1);
   }

   private static Object invokeStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = findMethod(var0, var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(null, adaptArgs(var3.getParameterTypes(), var2));
   }

   private static Object invoke(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException("target for " + var1);
      }

      Method var3 = findMethod(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, adaptArgs(var3.getParameterTypes(), var2));
   }

   private static Object[] adaptArgs(Class<?>[] var0, Object[] var1) {
      if (var1 != null && var1.length != 0) {
         Object[] var2 = (Object[])var1.clone();

         for (int var3 = 0; var3 < var2.length; var3++) {
            if (var2[var3] instanceof Number var5) {
               Class var6 = var0[var3];
               Class var7 = wrap(var6);
               if (var7 == Byte.class) {
                  var2[var3] = var5.byteValue();
               } else if (var7 == Short.class) {
                  var2[var3] = var5.shortValue();
               } else if (var7 == Integer.class) {
                  var2[var3] = var5.intValue();
               } else if (var7 == Long.class) {
                  var2[var3] = var5.longValue();
               } else if (var7 == Float.class) {
                  var2[var3] = var5.floatValue();
               } else if (var7 == Double.class) {
                  var2[var3] = var5.doubleValue();
               }
            }
         }

         return var2;
      } else {
         return var1;
      }
   }

   private static Method findMethod(Class<?> var0, String var1, Object[] var2) {
      for (Method var6 : var0.getMethods()) {
         if (var6.getName().equals(var1) && var6.getParameterCount() == var2.length) {
            Class[] var7 = var6.getParameterTypes();
            boolean var8 = true;

            for (int var9 = 0; var9 < var7.length; var9++) {
               Object var10 = var2[var9];
               if (var10 == null) {
                  if (var7[var9].isPrimitive()) {
                     var8 = false;
                     break;
                  }
               } else {
                  Class var11 = wrap(var7[var9]);
                  if (!var11.isInstance(var10) && (!Number.class.isAssignableFrom(var11) || !(var10 instanceof Number))) {
                     var8 = false;
                     break;
                  }
               }
            }

            if (var8) {
               return var6;
            }
         }
      }

      for (Class var13 = var0; var13 != null; var13 = var13.getSuperclass()) {
         for (Method var17 : var13.getDeclaredMethods()) {
            if (var17.getName().equals(var1) && var17.getParameterCount() == var2.length) {
               Class[] var18 = var17.getParameterTypes();
               boolean var19 = true;

               for (int var20 = 0; var20 < var18.length; var20++) {
                  Object var21 = var2[var20];
                  if (var21 == null) {
                     if (var18[var20].isPrimitive()) {
                        var19 = false;
                     }
                  } else {
                     Class var12 = wrap(var18[var20]);
                     if (!var12.isInstance(var21) && (!Number.class.isAssignableFrom(var12) || !(var21 instanceof Number))) {
                        var19 = false;
                        break;
                     }
                  }
               }

               if (var19) {
                  return var17;
               }
            }
         }
      }

      return null;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static boolean bool(Object var0) {
      return var0 instanceof Boolean var1 && var1;
   }

   private static Number number(Object var0) {
      return var0 instanceof Number var1 ? var1 : 0;
   }

   private static boolean boolCfg(Object var0, String var1, boolean var2) {
      try {
         return bool(invoke(var0, "getBoolean", var1, var2));
      } catch (Throwable var4) {
         return var2;
      }
   }

   private static int intCfg(Object var0, String var1, int var2) {
      try {
         return number(invoke(var0, "getInt", var1, var2)).intValue();
      } catch (Throwable var4) {
         return var2;
      }
   }

   private static double doubleCfg(Object var0, String var1, double var2) {
      try {
         return number(invoke(var0, "getDouble", var1, var2)).doubleValue();
      } catch (Throwable var5) {
         return var2;
      }
   }

   private static String strCfg(Object var0, String var1, String var2) {
      try {
         Object var3 = invoke(var0, "getString", var1, var2);
         return var3 == null ? var2 : String.valueOf(var3);
      } catch (Throwable var4) {
         return var2;
      }
   }

   private static double clamp(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   private static int clampInt(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   private static Throwable unwrap(Throwable var0) {
      Throwable var1 = var0;

      while (var1.getCause() != null && (var1 instanceof InvocationTargetException || var1 instanceof UndeclaredThrowableException)) {
         var1 = var1.getCause();
      }

      return var1;
   }

   private static final class Shot {
      final UUID shooter;
      final Object origin;
      final long expiresAt;

      Shot(UUID var1, Object var2, long var3) {
         this.shooter = var1;
         this.origin = var2;
         this.expiresAt = var3;
      }
   }

   private static final class WatchedBase {
      final Object baseData;
      final Object location;
      final long expiresAt;

      WatchedBase(Object var1, Object var2, long var3) {
         this.baseData = var1;
         this.location = var2;
         this.expiresAt = var3;
      }
   }
}
