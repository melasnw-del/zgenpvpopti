package com.zzwproject.zgenpvp.hotfix;

import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.DoubleChest;
import org.bukkit.inventory.InventoryHolder;

public final class DoubleChestFix {
   private DoubleChestFix() {
   }

   public static Location canonical(Location var0) {
      if (var0 != null && var0.getWorld() != null) {
         Location[] var1 = pair(var0);
         if (var1 == null) {
            return var0;
         } else {
            Location var2 = var1[0];
            Location var3 = var1[1];
            if (var2 == null) {
               return var3 == null ? var0 : var3;
            } else if (var3 == null) {
               return var2;
            } else {
               return compare(var2, var3) <= 0 ? var2 : var3;
            }
         }
      } else {
         return var0;
      }
   }

   public static Location otherHalf(Location var0) {
      if (var0 != null && var0.getWorld() != null) {
         Location[] var1 = pair(var0);
         if (var1 == null) {
            return null;
         } else {
            Location var2 = var1[0];
            Location var3 = var1[1];
            if (sameBlock(var0, var2)) {
               return var3;
            } else {
               return sameBlock(var0, var3) ? var2 : null;
            }
         }
      } else {
         return null;
      }
   }

   public static boolean sameContainer(Location var0, Location var1) {
      if (sameBlock(var0, var1)) {
         return true;
      }

      Location var2 = canonical(var0);
      Location var3 = canonical(var1);
      return sameBlock(var2, var3);
   }

   private static Location[] pair(Location var0) {
      try {
         if (var0.getBlock().getState() instanceof Chest var2) {
            return var2.getInventory().getHolder() instanceof DoubleChest var4
               ? new Location[]{holderLocation(var4.getLeftSide()), holderLocation(var4.getRightSide())}
               : null;
         } else {
            return null;
         }
      } catch (Throwable var5) {
         return null;
      }
   }

   private static Location holderLocation(InventoryHolder var0) {
      return var0 instanceof BlockState var1 ? var1.getLocation() : null;
   }

   private static boolean sameBlock(Location var0, Location var1) {
      return var0 != null && var1 != null && var0.getWorld() != null && var1.getWorld() != null
         ? var0.getWorld() == var1.getWorld()
            && var0.getBlockX() == var1.getBlockX()
            && var0.getBlockY() == var1.getBlockY()
            && var0.getBlockZ() == var1.getBlockZ()
         : false;
   }

   private static int compare(Location var0, Location var1) {
      int var2 = Integer.compare(var0.getBlockX(), var1.getBlockX());
      if (var2 != 0) {
         return var2;
      }

      var2 = Integer.compare(var0.getBlockY(), var1.getBlockY());
      return var2 != 0 ? var2 : Integer.compare(var0.getBlockZ(), var1.getBlockZ());
   }
}
