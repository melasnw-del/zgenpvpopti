package com.zzwproject.beaconfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class BeaconTeleportFallback {
   private BeaconTeleportFallback() {
   }

   public static Object find(Object var0, Object var1, float var2, float var3) {
      try {
         Method var4 = var0.getClass().getDeclaredMethod("findSameFloorSafeLocation", var1.getClass(), float.class, float.class);
         var4.setAccessible(true);
         Object var5 = var4.invoke(var0, var1, var2, var3);
         if (var5 != null) {
            return var5;
         }

         Object var6 = var1.getClass().getMethod("getWorld").invoke(var1);
         if (var6 == null) {
            return null;
         }

         int var7 = ((Number)var1.getClass().getMethod("getBlockX").invoke(var1)).intValue();
         int var8 = ((Number)var1.getClass().getMethod("getBlockY").invoke(var1)).intValue();
         int var9 = ((Number)var1.getClass().getMethod("getBlockZ").invoke(var1)).intValue();
         int var10 = -64;

         try {
            var10 = ((Number)var6.getClass().getMethod("getMinHeight").invoke(var6)).intValue();
         } catch (Throwable var19) {
         }

         Field var11 = var0.getClass().getDeclaredField("searchRadius");
         var11.setAccessible(true);
         int var12 = Math.max(6, ((Number)var11.get(var0)).intValue());
         Method var13 = null;
         Method var14 = null;

         for (Method var18 : var0.getClass().getDeclaredMethods()) {
            if (var18.getName().equals("isSafe") && var18.getParameterCount() == 4) {
               var18.setAccessible(true);
               var13 = var18;
            }

            if (var18.getName().equals("centered") && var18.getParameterCount() == 6) {
               var18.setAccessible(true);
               var14 = var18;
            }
         }

         if (var13 == null || var14 == null) {
            return null;
         }

         for (int var21 = var8; var21 >= var10 + 1; var21--) {
            for (int var22 = 0; var22 <= var12; var22++) {
               for (int var23 = -var22; var23 <= var22; var23++) {
                  for (int var24 = -var22; var24 <= var22; var24++) {
                     if (Math.max(Math.abs(var23), Math.abs(var24)) == var22
                        && Boolean.TRUE.equals(var13.invoke(var0, var6, var7 + var23, var21, var9 + var24))) {
                        return var14.invoke(var0, var6, var7 + var23, var21, var9 + var24, var2, var3);
                     }
                  }
               }
            }
         }
      } catch (Throwable var20) {
      }

      return null;
   }
}
