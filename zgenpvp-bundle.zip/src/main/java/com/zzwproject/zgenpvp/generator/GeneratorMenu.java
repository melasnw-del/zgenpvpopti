package com.zzwproject.zgenpvp.generator;

import com.zzwproject.compat.ItemMetaCompat;
import com.zzwproject.compat.Paper12111Compat;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GeneratorMenu {
   private final ZGenPvP plugin;
   private final GeneratorManager generatorManager;
   private final NamespacedKey actionKey;

   public GeneratorMenu(ZGenPvP var1, GeneratorManager var2) {
      this.plugin = var1;
      this.generatorManager = var2;
      this.actionKey = new NamespacedKey(var1, "generator_menu_action");
   }

   public void open(Player var1, GeneratorData var2) {
      GeneratorData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         int var4 = this.normalizeSize(this.plugin.getConfigManager().getMenus().getInt("generator.size", 27));
         String var5 = ColorUtil.color(this.plugin.getConfigManager().getMenus().getString("generator.title", "&8ᴊᴇɴᴇʀᴀᴛᴏʀ ʏᴏɴᴇᴛɪᴍɪ"));
         GeneratorMenu.GeneratorMenuHolder var6 = new GeneratorMenu.GeneratorMenuHolder(var3.getId(), var3.getOwnerUuid(), GeneratorMenu.Screen.MAIN);
         Inventory var7 = Bukkit.createInventory(var6, var4, var5);
         var6.inventory = var7;
         this.fill(var7, "generator.filler");
         OfflinePlayer var8 = Bukkit.getOfflinePlayer(var3.getOwnerUuid());
         String var9 = var8.getName() == null ? "Bilinmeyen" : var8.getName();
         int var10 = var3.getLevel();
         int var11 = this.generatorManager.getMaxLevel();
         int var12 = Math.min(var11, var10 + 1);
         int var13 = Math.max(1, this.plugin.getConfigManager().getGenerators().getInt("menu.levels-per-class", 10));
         int var14 = (Math.max(1, var10) - 1) / var13 + 1;
         this.setItem(var7, "generator.owner", (String)null, var3.getOwnerUuid(), (Material)null, "%owner%", var9);
         this.setItem(
            var7,
            "generator.info",
            (String)null,
            (UUID)null,
            this.generatorManager.getModelMaterial(var10),
            "%level%",
            String.valueOf(var10),
            "%max_level%",
            String.valueOf(var11),
            "%production%",
            this.format(this.generatorManager.getMoneyPerCycle(var10)),
            "%class%",
            String.valueOf(var14)
         );
         this.applyGeneratorModelData(var7, "generator.info", var10);
         this.setItem(
            var7,
            "generator.upgrade",
            "OPEN_UPGRADE_CONFIRM",
            (UUID)null,
            (Material)null,
            "%level%",
            String.valueOf(var10),
            "%next_level%",
            String.valueOf(var12),
            "%production%",
            this.format(this.generatorManager.getMoneyPerCycle(var10)),
            "%next_production%",
            this.format(this.generatorManager.getMoneyPerCycle(var12)),
            "%price%",
            this.format(this.generatorManager.getUpgradePrice(var10)),
            "%max_level%",
            String.valueOf(var11)
         );
         Paper12111Compat.openInventory(var1, var7);
         this.plugin.getSoundUtil().play(var1, "generator-menu-open");
      }
   }

   public void openUpgradeConfirm(Player var1, GeneratorData var2) {
      GeneratorData var3 = this.resolve(var1, var2);
      if (var3 != null) {
         int var4 = this.normalizeSize(this.plugin.getConfigManager().getMenus().getInt("generator.upgrade-confirm.size", 27));
         String var5 = ColorUtil.color(this.plugin.getConfigManager().getMenus().getString("generator.upgrade-confirm.title", "&8Jeneratör &8• &fOnay"));
         GeneratorMenu.GeneratorMenuHolder var6 = new GeneratorMenu.GeneratorMenuHolder(var3.getId(), var3.getOwnerUuid(), GeneratorMenu.Screen.UPGRADE_CONFIRM);
         Inventory var7 = Bukkit.createInventory(var6, var4, var5);
         var6.inventory = var7;
         this.fill(var7, "generator.upgrade-confirm.filler");
         int var8 = var3.getLevel();
         int var9 = this.generatorManager.getMaxLevel();
         int var10 = Math.min(var9, var8 + 1);
         this.setItem(
            var7,
            "generator.upgrade-confirm.confirm",
            "CONFIRM_UPGRADE",
            (UUID)null,
            Material.LIME_DYE,
            "%level%",
            String.valueOf(var8),
            "%next_level%",
            String.valueOf(var10),
            "%price%",
            this.format(this.generatorManager.getUpgradePrice(var8)),
            "%production%",
            this.format(this.generatorManager.getMoneyPerCycle(var8)),
            "%next_production%",
            this.format(this.generatorManager.getMoneyPerCycle(var10))
         );
         this.setItem(
            var7,
            "generator.upgrade-confirm.info",
            (String)null,
            (UUID)null,
            this.generatorManager.getModelMaterial(var10),
            "%level%",
            String.valueOf(var8),
            "%next_level%",
            String.valueOf(var10),
            "%price%",
            this.format(this.generatorManager.getUpgradePrice(var8)),
            "%production%",
            this.format(this.generatorManager.getMoneyPerCycle(var8)),
            "%next_production%",
            this.format(this.generatorManager.getMoneyPerCycle(var10))
         );
         this.setItem(var7, "generator.upgrade-confirm.cancel", "BACK_MAIN", (UUID)null, Material.RED_DYE);
         Paper12111Compat.openInventory(var1, var7);
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public boolean isMenu(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof GeneratorMenu.GeneratorMenuHolder;
   }

   public GeneratorMenu.Screen getScreen(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof GeneratorMenu.GeneratorMenuHolder var2 ? var2.screen : null;
   }

   public Optional<GeneratorData> getGenerator(Inventory var1) {
      return var1 != null && var1.getHolder() instanceof GeneratorMenu.GeneratorMenuHolder var3
         ? this.generatorManager.getGenerator(var3.generatorId, var3.ownerUuid)
         : Optional.empty();
   }

   public String getAction(ItemStack var1) {
      return var1 != null && !var1.getType().isAir() && var1.hasItemMeta()
         ? (String)var1.getItemMeta().getPersistentDataContainer().get(this.actionKey, PersistentDataType.STRING)
         : null;
   }

   private GeneratorData resolve(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         GeneratorData var3 = this.generatorManager.getGenerator(var2.getId(), var2.getOwnerUuid()).orElse(null);
         if (var3 == null) {
            var1.closeInventory();
            return null;
         } else if (!this.generatorManager.canUpgradeGenerator(var3.getOwnerUuid(), var1.getUniqueId())) {
            this.generatorManager.sendOwnerInfo(var1, var3);
            return null;
         } else {
            return var3;
         }
      } else {
         return null;
      }
   }

   private void fill(Inventory var1, String var2) {
      if (this.plugin.getConfigManager().getMenus().getBoolean(var2 + ".enabled", false)) {
         ItemStack var3 = this.createItem(var2, (String)null, (UUID)null, (Material)null);

         for (int var4 = 0; var4 < var1.getSize(); var4++) {
            var1.setItem(var4, var3);
         }
      }
   }

   private void setItem(Inventory var1, String var2, String var3, UUID var4, Material var5, String... var6) {
      int var7 = this.plugin.getConfigManager().getMenus().getInt(var2 + ".slot", -1);
      if (var7 >= 0 && var7 < var1.getSize()) {
         var1.setItem(var7, this.createItem(var2, var3, var4, var5, var6));
      }
   }

   private ItemStack createItem(String var1, String var2, UUID var3, Material var4, String... var5) {
      Material var6 = var4;
      if (var4 == null) {
         String var7 = this.plugin.getConfigManager().getMenus().getString(var1 + ".material", "STONE");
         var6 = Material.matchMaterial(var7 == null ? "STONE" : var7);
      }

      if (var6 == null || var6.isAir()) {
         var6 = Material.STONE;
      }

      ItemStack var12 = new ItemStack(var6);
      ItemMeta var8 = var12.getItemMeta();
      if (var8 == null) {
         return var12;
      }

      var8.setDisplayName(ColorUtil.color(this.replace(this.plugin.getConfigManager().getMenus().getString(var1 + ".name", " "), var5)));
      ArrayList var9 = new ArrayList();

      for (String var11 : this.plugin.getConfigManager().getMenus().getStringList(var1 + ".lore")) {
         var9.add(ColorUtil.color(this.replace(var11, var5)));
      }

      var8.setLore(var9);
      if (var3 != null && var8 instanceof SkullMeta var13) {
         Paper12111Compat.setOwningPlayer(var13, Bukkit.getOfflinePlayer(var3));
      }

      if (var2 != null) {
         var8.getPersistentDataContainer().set(this.actionKey, PersistentDataType.STRING, var2);
      }

      ItemMetaCompat.apply(var12, var8);
      return var12;
   }

   private void applyGeneratorModelData(Inventory var1, String var2, int var3) {
      int var4 = this.plugin.getConfigManager().getMenus().getInt(var2 + ".slot", -1);
      if (var4 >= 0 && var4 < var1.getSize()) {
         ItemStack var5 = var1.getItem(var4);
         if (var5 != null && var5.hasItemMeta()) {
            int var6 = this.generatorManager.getModelCustomModelData(var3);
            if (var6 > 0) {
               ItemMeta var7 = var5.getItemMeta();
               var7.setCustomModelData(var6);
               ItemMetaCompat.apply(var5, var7);
            }
         }
      }
   }

   private String replace(String var1, String... var2) {
      String var3 = var1 == null ? "" : var1;

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(var2[var4], var2[var4 + 1]);
      }

      return var3;
   }

   private int normalizeSize(int var1) {
      int var2 = Math.max(9, Math.min(54, var1));
      if (var2 % 9 != 0) {
         var2 += 9 - var2 % 9;
      }

      return Math.min(54, var2);
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private static final class GeneratorMenuHolder implements InventoryHolder {
      private final long generatorId;
      private final UUID ownerUuid;
      private final GeneratorMenu.Screen screen;
      private Inventory inventory;

      private GeneratorMenuHolder(long var1, UUID var3, GeneratorMenu.Screen var4) {
         this.generatorId = var1;
         this.ownerUuid = var3;
         this.screen = var4;
      }

      public Inventory getInventory() {
         return this.inventory;
      }
   }

   public enum Screen {
      MAIN,
      UPGRADE_CONFIRM;
   }
}
