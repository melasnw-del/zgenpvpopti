package com.zzwproject.zgenpvp.model;

import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class DefenseData {
   private final long id;
   private final long baseId;
   private final UUID ownerUuid;
   private final String type;
   private final String worldName;
   private final int x;
   private final int y;
   private final int z;
   private int level;
   private int currentHp;
   private int maxHp;
   private int storedArrows;

   public DefenseData(long id, long baseId, UUID ownerUuid, String type, String worldName, int x, int y, int z, int level, int currentHp, int maxHp) {
      this(id, baseId, ownerUuid, type, worldName, x, y, z, level, currentHp, maxHp, 0);
   }

   public DefenseData(
      long id, long baseId, UUID ownerUuid, String type, String worldName, int x, int y, int z, int level, int currentHp, int maxHp, int storedArrows
   ) {
      this.id = id;
      this.baseId = baseId;
      this.ownerUuid = ownerUuid;
      this.type = type;
      this.worldName = worldName;
      this.x = x;
      this.y = y;
      this.z = z;
      this.level = level;
      this.currentHp = currentHp;
      this.maxHp = maxHp;
      this.storedArrows = Math.max(0, storedArrows);
   }

   public long getId() {
      return this.id;
   }

   public long getBaseId() {
      return this.baseId;
   }

   public UUID getOwnerUuid() {
      return this.ownerUuid;
   }

   public String getType() {
      return this.type;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public int getLevel() {
      return this.level;
   }

   public int getCurrentHp() {
      return this.currentHp;
   }

   public int getMaxHp() {
      return this.maxHp;
   }

   public int getStoredArrows() {
      return this.storedArrows;
   }

   public void setLevel(int level) {
      this.level = level;
   }

   public void setCurrentHp(int currentHp) {
      this.currentHp = currentHp;
   }

   public void setMaxHp(int maxHp) {
      this.maxHp = maxHp;
   }

   public void setStoredArrows(int storedArrows) {
      this.storedArrows = Math.max(0, storedArrows);
   }

   public Location getLocation() {
      World world = Bukkit.getWorld(this.worldName);
      return world == null ? null : new Location(world, this.x, this.y, this.z);
   }
}
