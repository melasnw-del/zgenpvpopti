package com.zzwproject.zraid.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;

public final class ConfigurableRaidRules {
   private ConfigurableRaidRules() {
   }

   public static boolean bombStartsSession(Object var0) {
      return cfgB(var0, "integration.raid-bomb-starts-session", true);
   }

   public static boolean requireOwnerKill(Object var0) {
      return cfgB(var0, "objectives.require-owner-kill", true);
   }

   public static boolean requireAllGenerators(Object var0) {
      return cfgB(var0, "objectives.require-all-generators", true);
   }

   public static boolean strictOrder(Object var0) {
      return cfgB(var0, "objectives.strict-order", true);
   }

   public static boolean customBeaconHealth(Object var0) {
      return cfgB(var0, "objectives.beacon-custom-health-enabled", true);
   }

   public static boolean beaconRequiresPickaxe(Object var0) {
      return cfgB(var0, "objectives.beacon-require-pickaxe", true);
   }

   public static boolean cleanupLinkedStructures(Object var0) {
      return cfgB(var0, "success.cleanup-linked-structures", true);
   }

   public static boolean blockGeneratorBeforeOwner(Object var0, Object var1) {
      if (var0 != null && var1 != null && strictOrder(var0) && requireOwnerKill(var0)) {
         try {
            Object var2 = call(var1, "getPlayer");
            Object var3 = call(var1, "getBlock");
            if (var2 != null && var3 != null) {
               Object var4 = call(var3, "getLocation");
               Object var5 = field(var0, "core");
               Object var6 = call(var5, "getGeneratorManager");
               Object var7 = unwrap(call(var6, "getGenerator", var4));
               if (var7 == null) {
                  return false;
               }

               long var8 = num(call(var7, "getId"));
               Object var10 = tryCall(var0, "sessionByGeneratorId", var8);
               if (var10 == null) {
                  var10 = tryCall(var0, "sessionByLocation", var4);
               }

               if (var10 == null) {
                  return false;
               }

               Object var11 = call(var2, "getUniqueId");
               if (!truth(tryCall(var0, "isRaider", var10, var11))) {
                  return false;
               }

               if (truth(field(var10, "ownerKilled"))) {
                  return false;
               }

               tryCall(var1, "setCancelled", true);

               try {
                  Class var12 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var0.getClass().getClassLoader());

                  try {
                     callStatic(var12, "stopMining", var2, var3);
                  } catch (Throwable var14) {
                     callStatic(var12, "stopMining", var2);
                  }
               } catch (Throwable var15) {
               }

               Object var17 = tryCall(var0, "color", "&cRaid sırası aktif: önce üs sahibini öldürmelisin.");
               tryCall(var2, "sendMessage", var17 != null ? String.valueOf(var17) : "§cRaid sırası aktif: önce üs sahibini öldürmelisin.");
               return true;
            } else {
               return false;
            }
         } catch (Throwable var16) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean cfgB(Object var0, String var1, boolean var2) {
      try {
         return call(var0, "cfgB", var1, var2) instanceof Boolean var9 ? var9 : var2;
      } catch (Throwable var8) {
         try {
            Object var4 = call(var0, "getConfig");
            return call(var4, "getBoolean", var1, var2) instanceof Boolean var6 ? var6 : var2;
         } catch (Throwable var7) {
            return var2;
         }
      }
   }

   private static Object unwrap(Object var0) {
      return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
   }

   private static long num(Object var0) {
      return var0 instanceof Number var1 ? var1.longValue() : Long.parseLong(String.valueOf(var0));
   }

   private static boolean truth(Object var0) {
      return var0 instanceof Boolean var1 ? var1 : var0 != null && Boolean.parseBoolean(String.valueOf(var0));
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = find(var0.getClass(), var1, false, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0, var1, true, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var1);
      }

      var3.setAccessible(true);
      return var3.invoke(null, var2);
   }

   private static Method find(Class<?> var0, String var1, boolean var2, Object... var3) {
      for (Class var4 = var0; var4 != null; var4 = var4.getSuperclass()) {
         for (Method var8 : var4.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && (!var2 || Modifier.isStatic(var8.getModifiers())) && var8.getParameterCount() == var3.length) {
               boolean var9 = true;
               Class[] var10 = var8.getParameterTypes();

               for (int var11 = 0; var11 < var10.length; var11++) {
                  if (!fits(var10[var11], var3[var11])) {
                     var9 = false;
                     break;
                  }
               }

               if (var9) {
                  return var8;
               }
            }
         }
      }

      for (Method var15 : var0.getMethods()) {
         if (var15.getName().equals(var1) && (!var2 || Modifier.isStatic(var15.getModifiers())) && var15.getParameterCount() == var3.length) {
            boolean var16 = true;
            Class[] var17 = var15.getParameterTypes();

            for (int var18 = 0; var18 < var17.length; var18++) {
               if (!fits(var17[var18], var3[var18])) {
                  var16 = false;
                  break;
               }
            }

            if (var16) {
               return var15;
            }
         }
      }

      return null;
   }

   private static boolean fits(Class<?> var0, Object var1) {
      if (var1 == null) {
         return !var0.isPrimitive();
      } else if (var0.isInstance(var1)) {
         return true;
      } else {
         return !var0.isPrimitive()
            ? false
            : var0 == boolean.class && var1 instanceof Boolean
               || var0 == int.class && var1 instanceof Integer
               || var0 == long.class && var1 instanceof Long
               || var0 == double.class && var1 instanceof Double
               || var0 == float.class && var1 instanceof Float
               || var0 == short.class && var1 instanceof Short
               || var0 == byte.class && var1 instanceof Byte
               || var0 == char.class && var1 instanceof Character;
      }
   }
}
