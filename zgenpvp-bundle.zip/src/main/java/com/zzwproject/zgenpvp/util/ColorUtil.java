package com.zzwproject.zgenpvp.util;

import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String text) {
      text = PlaceholderFix.replace(text, null);
      if (text == null) {
         return "";
      }

      Matcher matcher = HEX_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         matcher.appendReplacement(buffer, ChatColor.of("#" + hex).toString());
      }

      matcher.appendTail(buffer);
      return ChatColor.translateAlternateColorCodes('&', buffer.toString());
   }

   public static String strip(String text) {
      return text == null ? "" : ChatColor.stripColor(color(text));
   }
}
