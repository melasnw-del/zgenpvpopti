package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class RaidReflectionCache {
   private static volatile Object module;
   private static final ConcurrentMap<String, Method> METHODS = new ConcurrentHashMap<>();

   private RaidReflectionCache() {
   }

   public static Object findModule() throws Exception {
      Object var0 = module;
      if (var0 != null) {
         return var0;
      }

      synchronized (RaidReflectionCache.class) {
         var0 = module;
         if (var0 != null) {
            return var0;
         }

         Class var2 = Class.forName("com.zzwproject.zgenpvp.integration.RaidSessionBridge");
         Method var3 = var2.getDeclaredMethod("findRaidModule$hotfixUncached");
         var3.setAccessible(true);

         try {
            var0 = var3.invoke(null);
         } catch (InvocationTargetException var6) {
            throw unwrap(var6);
         }

         if (var0 != null) {
            module = var0;
         }

         return var0;
      }
   }

   public static Method findCompatible(Class<?> var0, String var1, Object[] var2) {
      if (var0 != null && var1 != null) {
         String var3 = key(var0, var1, var2);
         Method var4 = METHODS.get(var3);
         if (var4 != null) {
            return var4;
         }

         try {
            Class var5 = Class.forName("com.zzwproject.zgenpvp.integration.RaidSessionBridge");
            Method var6 = var5.getDeclaredMethod("findCompatible$hotfixUncached", Class.class, String.class, Object[].class);
            var6.setAccessible(true);
            Method var7 = (Method)var6.invoke(null, var0, var1, var2);
            if (var7 != null) {
               var7.setAccessible(true);
               METHODS.putIfAbsent(var3, var7);
            }

            return var7;
         } catch (Throwable var8) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static String key(Class<?> var0, String var1, Object[] var2) {
      StringBuilder var3 = new StringBuilder(var0.getName()).append('#').append(var1).append('(');
      if (var2 != null) {
         for (Object var7 : var2) {
            var3.append(var7 == null ? "null" : var7.getClass().getName()).append(';');
         }
      }

      return var3.append(')').toString();
   }

   private static Exception unwrap(InvocationTargetException var0) {
      Throwable var1 = var0.getCause();
      return var1 instanceof Exception var2 ? var2 : new Exception(var1 == null ? var0 : var1);
   }
}
