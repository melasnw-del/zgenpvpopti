package com.zzwproject.zgenpvp.listener;

import com.zzwproject.zgenpvp.repository.PlayerRepository;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class PlayerConnectionListener implements Listener {
   private final PlayerRepository playerRepository;

   public PlayerConnectionListener(PlayerRepository playerRepository) {
      this.playerRepository = playerRepository;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.playerRepository.touchPlayer(event.getPlayer().getUniqueId(), event.getPlayer().getName());
   }
}
