package com.zzwproject.zgenpvp.raid;

import java.util.UUID;

@FunctionalInterface
public interface RaidRelationService {
   boolean isFriendly(UUID var1, UUID var2);
}
