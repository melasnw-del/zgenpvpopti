package com.zzwproject.zgenpvp.instabreaker;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.access.DefenseAccessManager;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.base.BaseManager;
import com.zzwproject.zgenpvp.defense.DefenseManager;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.turret.TurretManager;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class InstabreakerManager {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private final ZGenPvP plugin;
   private final BaseManager baseManager;
   private final DefenseManager defenseManager;
   private final TurretManager turretManager;
   private final DefenseAccessManager accessManager;
   private final NamespacedKey instabreakerKey;
   private FileConfiguration config;

   public InstabreakerManager(
      ZGenPvP plugin, BaseManager baseManager, DefenseManager defenseManager, TurretManager turretManager, DefenseAccessManager accessManager
   ) {
      this.plugin = plugin;
      this.baseManager = baseManager;
      this.defenseManager = defenseManager;
      this.turretManager = turretManager;
      this.accessManager = accessManager;
      this.instabreakerKey = new NamespacedKey(plugin, "instabreaker");
      this.load();
   }

   public void load() {
      File file = new File(this.plugin.getDataFolder(), "instabreaker.yml");
      if (!file.exists()) {
         this.plugin.saveResource("instabreaker.yml", false);
      }

      this.reload();
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "instabreaker.yml");
      this.config = YamlConfiguration.loadConfiguration(file);
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public boolean isEnabled() {
      return this.config.getBoolean("enabled", true);
   }

   public ItemStack createItem() {
      String materialName = this.config.getString("item.material", "GOLDEN_PICKAXE");
      Material material = Material.matchMaterial(materialName == null ? "GOLDEN_PICKAXE" : materialName);
      if (material == null || material.isAir()) {
         material = Material.GOLDEN_PICKAXE;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.getPersistentDataContainer().set(this.instabreakerKey, PersistentDataType.BYTE, (byte)1);
      String name = this.config.getString("item.name", "&6Instabreaker");
      meta.displayName(this.component(name));
      List<Component> lore = new ArrayList<>();

      for (String line : this.config.getStringList("item.lore")) {
         lore.add(this.component(line));
      }

      meta.lore(lore);
      meta.setUnbreakable(this.config.getBoolean("item.unbreakable", true));
      meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES});
      int customModelData = this.config.getInt("item.custom-model-data", 0);
      if (customModelData > 0) {
         meta.setCustomModelData(customModelData);
      }

      item.setItemMeta(meta);
      return item;
   }

   public boolean isInstabreaker(ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         Byte value = (Byte)item.getItemMeta().getPersistentDataContainer().get(this.instabreakerKey, PersistentDataType.BYTE);
         return value != null && value == 1;
      } else {
         return false;
      }
   }

   public boolean give(Player player, int amount) {
      if (player != null && amount >= 1) {
         for (int i = 0; i < amount; i++) {
            ItemStack item = this.createItem();
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(new ItemStack[]{item});

            for (ItemStack leftover : overflow.values()) {
               player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
         }

         this.sendMessage(player, "messages.received", "%amount%", String.valueOf(amount));
         return true;
      } else {
         return false;
      }
   }

   public boolean tryUse(Player player, Block block) {
      if (player == null || block == null) {
         return false;
      }

      if (!this.isEnabled()) {
         this.sendMessage(player, "messages.disabled");
         return false;
      }

      if (!player.hasPermission("zgenpvp.instabreaker.use")) {
         this.sendMessage(player, "messages.no-permission");
         return false;
      }

      Optional<BaseData> baseOptional = this.baseManager.getBase(block.getLocation());
      if (baseOptional.isPresent()) {
         this.sendMessage(player, "messages.base-blocked");
         return false;
      }

      Optional<DefenseData> defenseOptional = this.defenseManager.getDefense(block.getLocation());
      if (defenseOptional.isPresent()) {
         DefenseData defense = defenseOptional.get();
         if (this.isFriendly(player.getUniqueId(), defense.getOwnerUuid())) {
            this.sendFriendlyStructureMessage(player);
            return false;
         } else {
            Location location = defense.getLocation();
            this.defenseManager.damage(player, defense, 1, true);
            boolean destroyed = location == null || this.defenseManager.getDefense(location).isEmpty();
            if (!destroyed) {
               this.sendMessage(player, "messages.destroy-failed");
               return false;
            } else {
               this.finishSuccessfulUse(player, block.getLocation(), "Defans bloğu");
               return true;
            }
         }
      } else {
         Optional<DefenseData> turretOptional = this.turretManager.getTurret(block.getLocation());
         if (turretOptional.isPresent()) {
            DefenseData turret = turretOptional.get();
            if (this.isFriendly(player.getUniqueId(), turret.getOwnerUuid())) {
               this.sendFriendlyStructureMessage(player);
               return false;
            } else {
               Location location = turret.getLocation();
               this.turretManager.damage(player, turret, 1, true);
               boolean destroyed = location == null || this.turretManager.getTurret(location).isEmpty();
               if (!destroyed) {
                  this.sendMessage(player, "messages.destroy-failed");
                  return false;
               } else {
                  this.finishSuccessfulUse(player, block.getLocation(), "Taret");
                  return true;
               }
            }
         } else {
            Optional<DefenseData> accessOptional = this.accessManager.get(block);
            if (accessOptional.isPresent()) {
               DefenseData access = accessOptional.get();
               if (this.isFriendly(player.getUniqueId(), access.getOwnerUuid())) {
                  this.sendFriendlyStructureMessage(player);
                  return false;
               } else {
                  DefenseAccessType accessType = this.accessManager.getType(access);
                  this.accessManager.damage(player, access, 1, true);
                  boolean destroyed = this.accessManager.get(block).isEmpty();
                  if (!destroyed) {
                     this.sendMessage(player, "messages.destroy-failed");
                     return false;
                  } else {
                     this.finishSuccessfulUse(player, block.getLocation(), accessType == DefenseAccessType.DOOR ? "Kapı" : "Trapdoor");
                     return true;
                  }
               }
            } else {
               this.sendMessage(player, "messages.normal-block");
               return false;
            }
         }
      }
   }

   private void sendFriendlyStructureMessage(Player player) {
      if (this.config.contains("messages.friendly-structure")) {
         this.sendMessage(player, "messages.friendly-structure");
      } else {
         this.sendMessage(player, "messages.own-structure");
      }
   }

   private void finishSuccessfulUse(Player player, Location location, String structureName) {
      this.consumeItem(player);
      this.playSuccessEffect(location);
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (player.isOnline()) {
            this.sendActionBar(player, "messages.destroyed-actionbar", "%structure%", structureName);
         }
      }, 6L);
   }

   private void consumeItem(Player player) {
      if (player.getGameMode() != GameMode.CREATIVE || this.config.getBoolean("consume-in-creative", false)) {
         ItemStack item = player.getInventory().getItemInMainHand();
         if (this.isInstabreaker(item)) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
         }
      }
   }

   private boolean isFriendly(UUID attacker, UUID owner) {
      if (attacker == null || owner == null) {
         return false;
      } else if (attacker.equals(owner)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().areTeammates(attacker, owner);
      }
   }

   private void playSuccessEffect(Location location) {
      if (location != null && location.getWorld() != null) {
         World world = location.getWorld();
         Location effectLocation = location.clone().add(0.5, 0.5, 0.5);
         Particle particle = this.resolveParticle(this.config.getString("effects.success.particle", "CRIT"));
         int count = Math.max(0, this.config.getInt("effects.success.particle-count", 20));
         if (particle != null && count > 0) {
            world.spawnParticle(particle, effectLocation, count, 0.35, 0.35, 0.35, 0.05);
         }

         String sound = this.normalizeSound(this.config.getString("effects.success.sound", "ENTITY_ITEM_BREAK"));
         float volume = (float)this.config.getDouble("effects.success.volume", 1.0);
         float pitch = (float)this.config.getDouble("effects.success.pitch", 0.8);
         world.playSound(effectLocation, sound, volume, pitch);
      }
   }

   private Particle resolveParticle(String configured) {
      if (configured != null && !configured.isBlank()) {
         String raw = configured.trim().toLowerCase(Locale.ROOT);
         if (!raw.contains(":")) {
            raw = "minecraft:" + raw;
         }

         NamespacedKey key = NamespacedKey.fromString(raw);
         if (key == null) {
            return Particle.CRIT;
         }

         Particle particle = (Particle)Registry.PARTICLE_TYPE.get(key);
         return particle == null ? Particle.CRIT : particle;
      } else {
         return Particle.CRIT;
      }
   }

   private String normalizeSound(String configured) {
      if (configured != null && !configured.isBlank()) {
         String sound = configured.trim().toLowerCase(Locale.ROOT);
         return sound.contains(":") ? sound : "minecraft:" + sound.replace('_', '.');
      } else {
         return "minecraft:entity.item.break";
      }
   }

   public void sendMessage(CommandSender var1, String var2, String... var3) {
      if (var1 != null) {
         String var4 = this.config.getString(var2);
         if (var4 != null && !var4.isBlank()) {
            String var5 = this.config.getString("messages.prefix", "&6Instabreaker &8» &r");
            if (var5 == null) {
               var5 = "";
            }

            var4 = var4.replace("%prefix%", var5).replace("%Prefix%", var5);
            var4 = this.replace(var4, var3);
            var1.sendMessage(this.component(var4));
         }
      }
   }

   public void sendHelp(CommandSender sender) {
      if (sender != null) {
         for (String line : this.config.getStringList("messages.help")) {
            sender.sendMessage(this.component(line));
         }
      }
   }

   private void sendActionBar(Player player, String path, String... replacements) {
      if (player != null) {
         String message = this.config.getString(path);
         if (message != null && !message.isBlank()) {
            message = this.replace(message, replacements);
            player.sendActionBar(this.component(message));
         }
      }
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private Component component(String input) {
      return LegacyComponentSerializer.legacySection().deserialize(this.colorize(input));
   }

   private String colorize(String input) {
      if (input == null) {
         return "";
      }

      Matcher matcher = HEX_PATTERN.matcher(input);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         StringBuilder replacement = new StringBuilder("§X");

         for (char character : hex.toCharArray()) {
            replacement.append('§').append(character);
         }

         matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement.toString()));
      }

      matcher.appendTail(buffer);
      return buffer.toString().replace('&', '§');
   }
}
