package com.zzwproject.zgenpvp.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;

public final class GeneratorConfigFix {
   private GeneratorConfigFix() {
   }

   public static boolean migrateIndependentDefaults(Object var0, Object var1) {
      try {
         if (call(var1, "getKeys", Boolean.TRUE) instanceof Set var3 && var3.contains("generator.require-inside-base")) {
            return false;
         } else {
            call(var1, "set", "generator.require-inside-base", Boolean.TRUE);
            Object var6 = field(var0, "plugin");
            Object var4 = var6 == null ? null : call(var6, "getLogger");
            if (var4 != null) {
               tryCall(
                  var4,
                  "info",
                  "Config migration: generator.require-inside-base eksikti; güvenli varsayılan true olarak eklendi. Beacon/Base ayarları korunmuştur."
               );
            }

            return true;
         }
      } catch (Throwable var5) {
         return false;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }

   private static Object tryCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      Method var3 = find(var0.getClass(), var1, var2);
      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method find(Class<?> var0, String var1, Object[] var2) throws Exception {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && fit(var7.getParameterTypes(), var2)) {
               return var7;
            }
         }
      }

      for (Method var11 : var0.getMethods()) {
         if (var11.getName().equals(var1) && fit(var11.getParameterTypes(), var2)) {
            return var11;
         }
      }

      throw new NoSuchMethodException(var1);
   }

   private static boolean fit(Class<?>[] var0, Object[] var1) {
      if (var0.length != var1.length) {
         return false;
      }

      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isInstance(var1[var2])) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == int.class) {
         return Integer.class;
      } else {
         return var0 == long.class ? Long.class : var0;
      }
   }
}
