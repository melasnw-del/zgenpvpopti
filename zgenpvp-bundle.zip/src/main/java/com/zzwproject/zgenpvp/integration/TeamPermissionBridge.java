package com.zzwproject.zgenpvp.integration;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class TeamPermissionBridge {
   private TeamPermissionBridge() {
   }

   public static boolean generatorOwnerOrAllowed(UUID var0, Object var1) {
      return var1 instanceof UUID var2 && var0 != null ? var0.equals(var2) || memberPermission(var0, var2, "GENERATOR_BREAK") : false;
   }

   public static boolean generatorManage(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "DEFENSE_ACCESS"));
   }

   public static boolean generatorRewardCollect(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "GENERATOR_REWARD_COLLECT"));
   }

   public static boolean generatorLinkChest(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "DEFENSE_ACCESS"));
   }

   public static boolean generatorChestAccess(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "DEFENSE_ACCESS"));
   }

   public static boolean defenseManage(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "DEFENSE_ACCESS"));
   }

   public static boolean defenseAccess(Object var0, UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : memberPermission(var1, var2, "DEFENSE_ACCESS") || memberPermission(var1, var2, "DEFENSE_ACCESS");
      }
   }

   public static boolean defenseBlockOwnerOrAllowed(UUID var0, Object var1) {
      return var1 instanceof UUID var2 && var0 != null ? var0.equals(var2) || memberPermission(var0, var2, "DEFENSE_BREAK") : false;
   }

   public static boolean turretManage(Object var0, UUID var1, UUID var2) {
      return var1 != null && var2 != null && (var1.equals(var2) || memberPermission(var1, var2, "DEFENSE_ACCESS"));
   }

   public static boolean turretOwnerOrAllowed(UUID var0, Object var1) {
      return var1 instanceof UUID var2 && var0 != null ? var0.equals(var2) || memberPermission(var0, var2, "DEFENSE_BREAK") : false;
   }

   public static boolean accessManageIds(Object var0, UUID var1, UUID var2, DefenseData var3) {
      if (var1 == null || var2 == null || var3 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : memberPermission(var1, var2, accessSetting(var3, false));
      }
   }

   public static boolean accessManage(Object var0, Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         UUID var3 = var2.getOwnerUuid();
         UUID var4 = var1.getUniqueId();
         if (var3 == null || var4 == null) {
            return false;
         } else {
            return var3.equals(var4) ? true : memberPermission(var3, var4, accessSetting(var2, false));
         }
      } else {
         return false;
      }
   }

   public static boolean accessBreakOwnerOrAllowed(UUID var0, Object var1, DefenseData var2) {
      if (!(var1 instanceof UUID var3 && var0 != null && var2 != null)) {
         return false;
      } else {
         return var0.equals(var3) ? true : memberPermission(var0, var3, accessSetting(var2, true));
      }
   }

   private static String accessSetting(DefenseData var0, boolean var1) {
      String var2 = var0.getType() == null ? "" : var0.getType().toUpperCase(Locale.ROOT);
      if (var2.contains("TRAPDOOR")) {
         return var1 ? "DEFENSE_BREAK" : "DEFENSE_ACCESS";
      } else {
         return var1 ? "DEFENSE_BREAK" : "DEFENSE_ACCESS";
      }
   }

   public static boolean beaconBreakAllowed(Object var0, Player var1, BeaconData var2) {
      if (var1 != null && var2 != null && var2.getOwnerUuid() != null) {
         UUID var3 = var2.getOwnerUuid();
         UUID var4 = var1.getUniqueId();
         return var3.equals(var4) || memberPermission(var3, var4, "DEFENSE_BREAK");
      } else {
         return false;
      }
   }

   public static boolean baseFriendlyProtected(Object var0, UUID var1, UUID var2) {
      if (var1 == null || var2 == null || var1.equals(var2)) {
         return false;
      } else {
         return !areTeammates(var2, var1) ? false : !memberPermission(var2, var1, "DEFENSE_BREAK");
      }
   }

   public static Optional<BaseData> findOwnOrTeamBase(BaseRepository var0, UUID var1) {
      if (var0 != null && var1 != null) {
         try {
            Object var2 = api();
            if (var2 != null) {
               Method var3 = var2.getClass().getMethod("getTeam", UUID.class);
               if (var3.invoke(var2, var1) instanceof Optional var5 && var5.isPresent()) {
                  Object var6 = var5.get();
                  UUID var7 = (UUID)var6.getClass().getMethod("getLeaderUuid").invoke(var6);
                  if (var7 != null && !var7.equals(var1)) {
                     Optional var8 = var0.findByOwner(var7);
                     if (var8.isPresent()) {
                        return var8;
                     }
                  }
               }
            }
         } catch (Throwable var9) {
         }

         return var0.findByOwner(var1);
      } else {
         return Optional.empty();
      }
   }

   private static boolean memberPermission(UUID var0, UUID var1, String var2) {
      if (var0 == null || var1 == null) {
         return false;
      }

      if (var0.equals(var1)) {
         return true;
      }

      try {
         Object var3 = api();
         if (var3 == null || !areTeammates(var3, var0, var1)) {
            return false;
         }

         try {
            Method var4 = var3.getClass().getMethod("getTeam", UUID.class);
            Object var5 = var4.invoke(var3, var0);
            if (var5 instanceof Optional) {
               Optional var6 = (Optional)var5;
               if (var6.isPresent()) {
                  Object var7 = var6.get();
                  UUID var8 = (UUID)var7.getClass().getMethod("getLeaderUuid").invoke(var7);
               }
            }
         } catch (Throwable var9) {
         }

         Class var10 = Class.forName("com.zzwproject.zteam.model.MemberSetting", true, var3.getClass().getClassLoader());
         Enum var11 = Enum.valueOf(var10.asSubclass(Enum.class), var2);
         Method var12 = var3.getClass().getMethod("getMemberSetting", UUID.class, var10);
         Object var13 = var12.invoke(var3, var1, var11);
         return var13 instanceof Boolean && (Boolean)var13;
      } catch (Throwable var14) {
         return false;
      }
   }

   private static boolean areTeammates(UUID var0, UUID var1) {
      Object var2 = api();
      return var2 != null && areTeammates(var2, var0, var1);
   }

   private static boolean areTeammates(Object var0, UUID var1, UUID var2) {
      try {
         return var0.getClass().getMethod("areTeammates", UUID.class, UUID.class).invoke(var0, var1, var2) instanceof Boolean var4 && var4;
      } catch (Throwable var5) {
         return false;
      }
   }

   private static Object api() {
      Plugin var0 = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZTeam");
      if (var0 != null && var0.isEnabled()) {
         try {
            try {
               return var0.getClass().getMethod("getAPI").invoke(var0);
            } catch (NoSuchMethodException var2) {
               return var0.getClass().getMethod("getApi").invoke(var0);
            }
         } catch (Throwable var3) {
            return null;
         }
      } else {
         return null;
      }
   }
}