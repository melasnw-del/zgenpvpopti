package com.zzwproject.zgenpvp.instabreaker;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public final class InstabreakerListener implements Listener {
   private final InstabreakerManager manager;

   public InstabreakerListener(InstabreakerManager var1) {
      this.manager = var1;
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void onBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItemInMainHand();
      if (this.manager.isInstabreaker(var3)) {
         boolean var4 = this.manager.tryUse(var2, var1.getBlock());
         if (var4 || this.manager.getConfig().getBoolean("prevent-normal-block-breaking", true)) {
            var1.setCancelled(true);
            var1.setDropItems(false);
            var1.setExpToDrop(0);
         }
      }
   }
}
