package com.zzwproject.zgenpvp.death;

import com.destroystokyo.paper.event.player.PlayerPostRespawnEvent;
import com.destroystokyo.paper.event.player.PlayerStartSpectatingEntityEvent;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public final class DeathListener implements Listener {
   private final DeathManager deathManager;

   public DeathListener(DeathManager deathManager) {
      this.deathManager = deathManager;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onDeath(PlayerDeathEvent event) {
      Player victim = event.getEntity();
      Player killer = victim.getKiller();
      this.deathManager.handleDeath(victim, killer);
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPostRespawn(PlayerPostRespawnEvent event) {
      this.deathManager.startSpectatorCountdown(event.getPlayer());
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (this.deathManager.isFrozen(player.getUniqueId())) {
         Location to = event.getTo();
         if (to != null) {
            Location anchor = this.deathManager.getFreezeLocation(player.getUniqueId());
            if (anchor != null) {
               boolean moved = anchor.getWorld() != to.getWorld()
                  || Double.compare(anchor.getX(), to.getX()) != 0
                  || Double.compare(anchor.getY(), to.getY()) != 0
                  || Double.compare(anchor.getZ(), to.getZ()) != 0;
               if (moved) {
                  Location corrected = anchor.clone();
                  corrected.setYaw(to.getYaw());
                  corrected.setPitch(to.getPitch());
                  event.setTo(corrected);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onTeleport(PlayerTeleportEvent event) {
      Player player = event.getPlayer();
      if (this.deathManager.isFrozen(player.getUniqueId())) {
         if (event.getCause() != TeleportCause.PLUGIN) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onStartSpectating(PlayerStartSpectatingEntityEvent event) {
      Player player = event.getPlayer();
      if (this.deathManager.isFrozen(player.getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onGameModeChange(PlayerGameModeChangeEvent event) {
      Player player = event.getPlayer();
      if (this.deathManager.isFrozen(player.getUniqueId())) {
         if (event.getNewGameMode() != GameMode.SPECTATOR) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.deathManager.handleQuit(event.getPlayer());
   }
}
