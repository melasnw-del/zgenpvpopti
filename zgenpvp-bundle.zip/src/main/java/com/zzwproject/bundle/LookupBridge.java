package com.zzwproject.bundle;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public final class LookupBridge {
   private LookupBridge() {
   }

   public static Map<Object, Object> resolve(Object var0) {
      ArrayList var1 = new ArrayList();
      Set var2 = Collections.newSetFromMap(new IdentityHashMap());
      Set var3 = Collections.newSetFromMap(new IdentityHashMap());

      try {
         Object var4 = invokeNoArgs(var0, "getServer");
         Object var5 = var4 == null ? null : invokeNoArgs(var4, "getPluginManager");
         scan(var5, 0, var2, var3, var1);
         scan(var4, 0, var2, var3, var1);
      } catch (Throwable var6) {
      }

      return var1.isEmpty() ? new ConcurrentHashMap<>() : new LookupBridge.BroadcastMap(var1);
   }

   private static Object invokeNoArgs(Object var0, String var1) {
      if (var0 == null) {
         return null;
      }

      try {
         Method var2 = var0.getClass().getMethod(var1);
         var2.setAccessible(true);
         return var2.invoke(var0);
      } catch (Throwable var3) {
         return null;
      }
   }

   private static void scan(Object var0, int var1, Set<Object> var2, Set<Map<Object, Object>> var3, List<Map<Object, Object>> var4) {
      if (var0 != null && var1 <= 5 && !var2.contains(var0)) {
         var2.add(var0);
         Class var5 = var0.getClass();

         for (Class var6 = var5; var6 != null && var6 != Object.class; var6 = var6.getSuperclass()) {
            Field[] var7;
            try {
               var7 = var6.getDeclaredFields();
            } catch (Throwable var17) {
               continue;
            }

            for (Field var11 : var7) {
               if (!Modifier.isStatic(var11.getModifiers())) {
                  Object var12;
                  try {
                     var11.setAccessible(true);
                     var12 = var11.get(var0);
                  } catch (Throwable var16) {
                     continue;
                  }

                  if (var12 != null) {
                     String var13 = var11.getName().toLowerCase(Locale.ROOT);
                     if (var12 instanceof Map var14) {
                        Map var15 = var14;
                        if ((var13.contains("lookup") || looksLikePluginLookup(var15)) && var3.add(var15)) {
                           var4.add(var15);
                        }
                     }

                     if (var1 < 5 && shouldTraverse(var12.getClass(), var13)) {
                        scan(var12, var1 + 1, var2, var3, var4);
                     }
                  }
               }
            }
         }
      }
   }

   private static boolean looksLikePluginLookup(Map<?, ?> var0) {
      if (var0.isEmpty()) {
         return false;
      }

      int var1 = 0;

      try {
         for (Entry var3 : var0.entrySet()) {
            if (++var1 > 12) {
               break;
            }

            Object var4 = var3.getKey();
            Object var5 = var3.getValue();
            if (var4 instanceof String && var5 != null) {
               Class var6 = var5.getClass();
               if (implementsNamedInterface(var6, "org.bukkit.plugin.Plugin") || var6.getName().toLowerCase(Locale.ROOT).contains("plugin")) {
                  return true;
               }
            }
         }
      } catch (Throwable var7) {
      }

      return false;
   }

   private static boolean implementsNamedInterface(Class<?> var0, String var1) {
      for (Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         for (Class var6 : var2.getInterfaces()) {
            if (var6.getName().equals(var1) || implementsNamedInterface(var6, var1)) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean shouldTraverse(Class<?> var0, String var1) {
      if (!var0.isPrimitive() && !var0.isEnum() && !var0.isArray()) {
         String var2 = var0.getName();
         return !var2.startsWith("java.") && !var2.startsWith("javax.") && !var2.startsWith("jdk.")
            ? var2.startsWith("org.bukkit")
               || var2.startsWith("io.papermc")
               || var2.startsWith("org.bukkit.craftbukkit")
               || var2.startsWith("com.destroystokyo")
               || var1.contains("plugin")
               || var1.contains("manager")
               || var1.contains("instance")
            : false;
      } else {
         return false;
      }
   }

   private static final class BroadcastMap extends AbstractMap<Object, Object> {
      private final List<Map<Object, Object>> delegates;

      BroadcastMap(List<Map<Object, Object>> var1) {
         this.delegates = List.copyOf(var1);
      }

      @Override
      public Object get(Object var1) {
         for (Map var3 : this.delegates) {
            try {
               Object var4 = var3.get(var1);
               if (var4 != null) {
                  return var4;
               }
            } catch (Throwable var5) {
            }
         }

         return null;
      }

      @Override
      public boolean containsKey(Object var1) {
         for (Map var3 : this.delegates) {
            try {
               if (var3.containsKey(var1)) {
                  return true;
               }
            } catch (Throwable var5) {
            }
         }

         return false;
      }

      @Override
      public Object put(Object var1, Object var2) {
         Object var3 = null;
         boolean var4 = false;

         for (Map var6 : this.delegates) {
            try {
               Object var7 = var6.put(var1, var2);
               if (!var4 && var7 != null) {
                  var3 = var7;
                  var4 = true;
               }
            } catch (Throwable var8) {
            }
         }

         return var3;
      }

      @Override
      public Object putIfAbsent(Object var1, Object var2) {
         Object var3 = null;
         boolean var4 = false;

         for (Map var6 : this.delegates) {
            try {
               Object var7 = var6.putIfAbsent(var1, var2);
               if (!var4 && var7 != null) {
                  var3 = var7;
                  var4 = true;
               }
            } catch (Throwable var8) {
            }
         }

         return var3;
      }

      @Override
      public Object remove(Object var1) {
         Object var2 = null;

         for (Map var4 : this.delegates) {
            try {
               Object var5 = var4.remove(var1);
               if (var2 == null) {
                  var2 = var5;
               }
            } catch (Throwable var6) {
            }
         }

         return var2;
      }

      @Override
      public boolean remove(Object var1, Object var2) {
         boolean var3 = false;

         for (Map var5 : this.delegates) {
            try {
               var3 |= var5.remove(var1, var2);
            } catch (Throwable var7) {
            }
         }

         return var3;
      }

      @Override
      public Set<Entry<Object, Object>> entrySet() {
         LinkedHashSet var1 = new LinkedHashSet();

         for (Map var3 : this.delegates) {
            try {
               var1.addAll(var3.entrySet());
            } catch (Throwable var5) {
            }
         }

         return var1;
      }
   }
}
