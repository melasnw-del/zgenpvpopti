package com.zzwproject.zmenu.listener;

import com.zzwproject.zmenu.ZMenu;
import com.zzwproject.zmenu.gui.MenuAction;
import com.zzwproject.zmenu.gui.MenuHolder;
import com.zzwproject.zmenu.util.ColorUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class MenuListener implements Listener {
   private final ZMenu plugin;
   private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacySection();

   public MenuListener(ZMenu var1) {
      this.plugin = var1;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onClick(InventoryClickEvent var1) {
      if (var1.getInventory().getHolder() instanceof MenuHolder var2) {
         var1.setCancelled(true);
         if (var1.getWhoClicked() instanceof Player var7) {
            if (var1.getClickedInventory() != null && var1.getClickedInventory() == var1.getView().getTopInventory()) {
               MenuAction var8 = var2.action(var1.getRawSlot());
               if (var8 != null) {
                  this.plugin.sound().play(var7, "click");
                  if (var8.close()) {
                     var7.closeInventory();
                  }

                  switch (var8.type()) {
                     case "PLAYER_COMMAND":
                        this.runPlayerCommand(var7, var8.value());
                        break;
                     case "CONSOLE_COMMAND":
                        this.runConsoleCommand(var7, var8.value());
                        break;
                     case "MESSAGE":
                        var7.sendMessage(ColorUtil.color(var8.value().replace("%player%", var7.getName())));
                        break;
                     case "URL":
                        this.sendUrl(var7, var8.value());
                        break;
                     case "NIGHT_VISION":
                        this.toggleNightVision(var7);
                        break;
                     case "OPEN_WIKI":
                        this.plugin.wiki().open(var7, 0);
                        break;
                     case "OPEN_RULES":
                        this.plugin.rules().open(var7, 0);
                        break;
                     case "RULES_PAGE":
                        this.plugin.rules().open(var7, this.integer(var8.value(), 0));
                        break;
                     case "WIKI_INDEX":
                        this.plugin.wiki().open(var7, this.integer(var8.value(), 0));
                        break;
                     case "WIKI_PAGE":
                        this.plugin.wiki().openPage(var7, var8.value());
                        break;
                     case "OPEN_GENERATORS":
                        this.plugin.generators().open(var7, 0);
                        break;
                     case "GENERATOR_PAGE":
                        this.plugin.generators().open(var7, this.integer(var8.value(), 0));
                        break;
                     case "GENERATOR_REMOVE":
                        this.plugin.generators().remove(var7, var8.value());
                        break;
                     case "GENERATOR_UPGRADE_ALL":
                        this.plugin.generators().upgradeAll(var7, this.integer(var8.value(), var2.page()));
                        break;
                     case "MAIN_MENU":
                        this.plugin.menu().open(var7);
                        break;
                     case "CLOSE":
                        var7.closeInventory();
                        break;
                     default:
                        this.plugin.message().send(var7, "unknown-action");
                        this.plugin.sound().play(var7, "error");
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDrag(InventoryDragEvent var1) {
      if (var1.getInventory().getHolder() instanceof MenuHolder) {
         var1.setCancelled(true);
      }
   }

   private void runPlayerCommand(Player var1, String var2) {
      String var3 = var2 == null ? "" : var2;
      if (var3.startsWith("/")) {
         var3 = var3.substring(1);
      }

      if (!var3.isBlank()) {
         var1.performCommand(var3);
      }
   }

   private void runConsoleCommand(Player var1, String var2) {
      String var3 = var2 == null ? "" : var2.replace("%player%", var1.getName());
      if (var3.startsWith("/")) {
         var3 = var3.substring(1);
      }

      if (!var3.isBlank()) {
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), var3);
      }
   }

   private void sendUrl(Player var1, String var2) {
      String var3 = this.plugin.messages().getString("prefix", "");
      String var4 = this.plugin.messages().getString("url-prefix", "&7Baglanti: ");
      var4 = var4.replace("%prefix%", var3 == null ? "" : var3);
      TextComponent var5 = this.legacy.deserialize(ColorUtil.color(var4));
      TextComponent var6 = Component.text(var2);
      Component var8 = var6.clickEvent(ClickEvent.openUrl(var2));
      var1.sendMessage(var5.append(var8));
   }

   private void toggleNightVision(Player var1) {
      boolean var2 = this.plugin.nightVision().toggle(var1);
      this.plugin.message().send(var1, var2 ? "nightvision-on" : "nightvision-off");
      this.plugin.sound().play(var1, var2 ? "nightvision-on" : "nightvision-off");
      this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.plugin.menu().open(var1));
   }

   private int integer(String var1, int var2) {
      try {
         return Integer.parseInt(var1);
      } catch (Exception var4) {
         return var2;
      }
   }
}
