package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import com.zzwproject.zgenpvp.hotfix.DoubleChestFix;
import com.zzwproject.zgenpvp.model.GeneratorData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Location;

public final class GeneratorRepository {
   private final DatabaseManager databaseManager;
   private final java.util.concurrent.ConcurrentHashMap<String, long[]> linkedChestProbe = new java.util.concurrent.ConcurrentHashMap<>();

   public GeneratorRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public List<GeneratorData> findAll() {
      ArrayList var1 = new ArrayList();
      String var2 = "SELECT *\nFROM generators;\n";

      try (
         PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2);
         ResultSet var4 = var3.executeQuery();
      ) {
         while (var4.next()) {
            var1.add(this.read(var4));
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return var1;
   }

   private List<GeneratorData> findByLinkedChestExact(Location var1) {
      ArrayList var2 = new ArrayList();
      if (var1 != null && var1.getWorld() != null) {
         String var3 = "SELECT *\n\nFROM generators\n\nWHERE linked_world = ?\n  AND linked_x = ?\n  AND linked_y = ?\n  AND linked_z = ?;\n";

         try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
            var4.setString(1, var1.getWorld().getName());
            var4.setInt(2, var1.getBlockX());
            var4.setInt(3, var1.getBlockY());
            var4.setInt(4, var1.getBlockZ());

            try (ResultSet var5 = var4.executeQuery()) {
               while (var5.next()) {
                  var2.add(this.read(var5));
               }
            }
         } catch (SQLException var12) {
            var12.printStackTrace();
         }

         return var2;
      } else {
         return var2;
      }
   }

   public long create(long var1, UUID var3, Location var4, int var5, long var6) {
      if (var4.getWorld() == null) {
         return -1L;
      }

      String var8 = "INSERT INTO generators (\n\n    base_id,\n    owner_uuid,\n\n    world,\n    x,\n    y,\n    z,\n\n    level,\n\n    stored_money,\n    stored_shards,\n\n    last_money_generation,\n    last_shard_generation,\n\n    linked_world,\n    linked_x,\n    linked_y,\n    linked_z,\n\n    created_at\n)\n\nVALUES (\n    ?, ?,\n    ?, ?, ?, ?,\n    ?,\n    0, 0,\n    ?, ?,\n    NULL, NULL, NULL, NULL,\n    ?\n);\n";

      try (PreparedStatement var9 = this.databaseManager.getConnection().prepareStatement(var8, 1)) {
         if (var1 > 0L) {
            var9.setLong(1, var1);
         } else {
            var9.setNull(1, 4);
         }

         var9.setString(2, var3.toString());
         var9.setString(3, var4.getWorld().getName());
         var9.setInt(4, var4.getBlockX());
         var9.setInt(5, var4.getBlockY());
         var9.setInt(6, var4.getBlockZ());
         var9.setInt(7, var5);
         var9.setLong(8, var6);
         var9.setLong(9, var6);
         var9.setLong(10, var6);
         var9.executeUpdate();

         try (ResultSet var10 = var9.getGeneratedKeys()) {
            if (var10.next()) {
               return var10.getLong(1);
            }
         }
      } catch (SQLException var17) {
         var17.printStackTrace();
      }

      return -1L;
   }

   public boolean updateGenerationState(long var1, double var3, int var5, long var6, long var8) {
      String var10 = "UPDATE generators\n\nSET\n    stored_money = ?,\n    stored_shards = ?,\n    last_money_generation = ?,\n    last_shard_generation = ?\n\nWHERE id = ?;\n";

      try (PreparedStatement var11 = this.databaseManager.getConnection().prepareStatement(var10)) {
         var11.setDouble(1, Math.max(0.0, var3));
         var11.setInt(2, Math.max(0, var5));
         var11.setLong(3, var6);
         var11.setLong(4, var8);
         var11.setLong(5, var1);
         return var11.executeUpdate() > 0;
      } catch (SQLException var16) {
         var16.printStackTrace();
         return false;
      }
   }

   public boolean setStoredMoney(long var1, double var3) {
      String var5 = "UPDATE generators\n\nSET stored_money = ?\n\nWHERE id = ?;\n";

      try (PreparedStatement var6 = this.databaseManager.getConnection().prepareStatement(var5)) {
         var6.setDouble(1, Math.max(0.0, var3));
         var6.setLong(2, var1);
         return var6.executeUpdate() > 0;
      } catch (SQLException var11) {
         var11.printStackTrace();
         return false;
      }
   }

   public boolean setStoredShards(long var1, int var3) {
      String var4 = "UPDATE generators\n\nSET stored_shards = ?\n\nWHERE id = ?;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setInt(1, Math.max(0, var3));
         var5.setLong(2, var1);
         return var5.executeUpdate() > 0;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return false;
      }
   }

   public boolean updateLevel(long var1, int var3) {
      String var4 = "UPDATE generators\n\nSET level = ?\n\nWHERE id = ?;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setInt(1, var3);
         var5.setLong(2, var1);
         return var5.executeUpdate() > 0;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return false;
      }
   }

   public boolean isLinkedChestCached(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         String var2 = var1.getWorld().getName() + ":" + var1.getBlockX() + ":" + var1.getBlockY() + ":" + var1.getBlockZ();
         long var3 = System.currentTimeMillis();
         long[] var5 = this.linkedChestProbe.get(var2);
         if (var5 != null && var3 - var5[0] < 1500L) {
            return var5[1] == 1L;
         }

         boolean var6 = !this.findByLinkedChest(var1).isEmpty();
         if (this.linkedChestProbe.size() > 2048) {
            this.linkedChestProbe.clear();
         }

         this.linkedChestProbe.put(var2, new long[]{var3, var6 ? 1L : 0L});
         return var6;
      } else {
         return false;
      }
   }

   public boolean updateLinkedChest(long var1, Location var3) {
      this.linkedChestProbe.clear();
      if (var3 != null && var3.getWorld() != null) {
         String var4 = "UPDATE generators\n\nSET\n    linked_world = ?,\n    linked_x = ?,\n    linked_y = ?,\n    linked_z = ?\n\nWHERE id = ?;\n";

         try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
            var5.setString(1, var3.getWorld().getName());
            var5.setInt(2, var3.getBlockX());
            var5.setInt(3, var3.getBlockY());
            var5.setInt(4, var3.getBlockZ());
            var5.setLong(5, var1);
            return var5.executeUpdate() > 0;
         } catch (SQLException var10) {
            var10.printStackTrace();
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean clearLinkedChest(long var1) {
      this.linkedChestProbe.clear();
      String var3 = "UPDATE generators\n\nSET\n    linked_world = NULL,\n    linked_x = NULL,\n    linked_y = NULL,\n    linked_z = NULL\n\nWHERE id = ?;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);
         return var4.executeUpdate() > 0;
      } catch (SQLException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public boolean delete(long var1) {
      this.linkedChestProbe.clear();
      String var3 = "DELETE FROM generators\n\nWHERE id = ?;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);
         return var4.executeUpdate() > 0;
      } catch (SQLException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public boolean existsById(long var1) {
      String var3 = "SELECT 1 FROM generators WHERE id = ? LIMIT 1;";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            return var5.next();
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
         return true;
      }
   }

   public List<GeneratorData> findAllByBase(long var1) {
      ArrayList var3 = new ArrayList();
      String var4 = "SELECT *\nFROM generators\nWHERE base_id = ?\nORDER BY id ASC;\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
         var5.setLong(1, var1);

         try (ResultSet var6 = var5.executeQuery()) {
            while (var6.next()) {
               var3.add(this.read(var6));
            }
         }
      } catch (SQLException var13) {
         var13.printStackTrace();
      }

      return var3;
   }

   public int countStructures(long var1) {
      String var3 = "SELECT\n    (\n        SELECT COUNT(*)\n        FROM generators\n        WHERE base_id = ?\n    )\n    +\n    (\n        SELECT COUNT(*)\n        FROM defenses\n        WHERE base_id = ?\n    )\n\n    AS total;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setLong(1, var1);
         var4.setLong(2, var1);

         try (ResultSet var5 = var4.executeQuery()) {
            if (var5.next()) {
               return var5.getInt("total");
            }
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
      }

      return 0;
   }

   private GeneratorData read(ResultSet var1) throws SQLException {
      Integer var2 = this.getNullableInteger(var1, "linked_x");
      Integer var3 = this.getNullableInteger(var1, "linked_y");
      Integer var4 = this.getNullableInteger(var1, "linked_z");
      return new GeneratorData(
         var1.getLong("id"),
         this.getNullableLong(var1, "base_id"),
         UUID.fromString(var1.getString("owner_uuid")),
         var1.getString("world"),
         var1.getInt("x"),
         var1.getInt("y"),
         var1.getInt("z"),
         var1.getInt("level"),
         var1.getDouble("stored_money"),
         var1.getInt("stored_shards"),
         var1.getLong("last_money_generation"),
         var1.getLong("last_shard_generation"),
         var1.getString("linked_world"),
         var2,
         var3,
         var4
      );
   }

   private long getNullableLong(ResultSet var1, String var2) throws SQLException {
      long var3 = var1.getLong(var2);
      return var1.wasNull() ? 0L : var3;
   }

   private Integer getNullableInteger(ResultSet var1, String var2) throws SQLException {
      int var3 = var1.getInt(var2);
      return var1.wasNull() ? null : var3;
   }

   public List<GeneratorData> findByLinkedChest(Location var1) {
      List var2 = this.findByLinkedChestExact(var1);
      if (!var2.isEmpty()) {
         return var2;
      }

      Location var3 = DoubleChestFix.otherHalf(var1);
      return var3 == null ? var2 : this.findByLinkedChestExact(var3);
   }
}
