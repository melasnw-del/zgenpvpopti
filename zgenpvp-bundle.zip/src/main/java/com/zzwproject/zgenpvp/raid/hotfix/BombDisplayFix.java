package com.zzwproject.zgenpvp.raid.hotfix;

import java.lang.reflect.Method;

public final class BombDisplayFix {
   private BombDisplayFix() {
   }

   public static void apply(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            int var2 = ((Number)invoke(var1, "getId")).intValue();

            String var3 = switch (var2) {
               case 2 -> "OBSIDIAN";
               case 3 -> "RESPAWN_ANCHOR";
               default -> "TNT";
            };
            Class var4 = null;

            try {
               var4 = Class.forName("org.bukkit.Material", false, var0.getClass().getClassLoader());
            } catch (Throwable var11) {
               for (Method var9 : var0.getClass().getMethods()) {
                  if (var9.getName().equals("setBlock") && var9.getParameterCount() == 1) {
                     ClassLoader var10 = var9.getParameterTypes()[0].getClassLoader();
                     var4 = Class.forName("org.bukkit.Material", false, var10);
                     break;
                  }
               }
            }

            if (var4 == null) {
               return;
            }

            Enum var5 = Enum.valueOf(var4.asSubclass(Enum.class), var3);
            Object var13 = invoke(var5, "createBlockData");
            invoke(var0, "setBlock", var13);
         } catch (Throwable var12) {
         }
      }
   }

   private static Object invoke(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         return null;
      }

      Method var3 = null;

      for (Method var7 : var0.getClass().getMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
            Class[] var8 = var7.getParameterTypes();
            boolean var9 = true;

            for (int var10 = 0; var10 < var8.length; var10++) {
               if (var2[var10] == null) {
                  if (var8[var10].isPrimitive()) {
                     var9 = false;
                  }
               } else if (!wrap(var8[var10]).isAssignableFrom(var2[var10].getClass())) {
                  var9 = false;
               }
            }

            if (var9) {
               var3 = var7;
               break;
            }
         }
      }

      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
