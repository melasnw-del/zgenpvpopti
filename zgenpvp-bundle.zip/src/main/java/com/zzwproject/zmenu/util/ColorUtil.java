package com.zzwproject.zmenu.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String var0) {
      if (var0 == null) {
         return "";
      }

      Matcher var1 = HEX.matcher(var0);
      StringBuffer var2 = new StringBuffer();

      while (var1.find()) {
         var1.appendReplacement(var2, ChatColor.of("#" + var1.group(1)).toString());
      }

      var1.appendTail(var2);
      return ChatColor.translateAlternateColorCodes('&', var2.toString());
   }
}
