package com.zzwproject.zmenu.service;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zmenu.ZMenu;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class GeneratorService {
   private final ZMenu plugin;
   private final DecimalFormat numberFormat = new DecimalFormat("#,##0.##");
   private boolean warned;

   public GeneratorService(ZMenu var1) {
      this.plugin = var1;
   }

   public boolean isAvailable() {
      try {
         return this.core() != null && this.manager() != null;
      } catch (ReflectiveOperationException var2) {
         this.warn(var2);
         return false;
      }
   }

   public List<GeneratorService.GeneratorView> list(Player var1) {
      if (var1 == null) {
         return List.of();
      }

      try {
         Plugin var2 = this.core();
         Object var3 = this.manager(var2);
         if (var2 != null && var3 != null) {
            Object var4 = this.call(var2, "getGeneratorRepository");
            if (this.call(var4, "findAll") instanceof List var6) {
               UUID var7 = var1.getUniqueId();
               ArrayList var8 = new ArrayList();

               for (Object var10 : var6) {
                  if (var10 != null && var7.equals(this.call(var10, "getOwnerUuid"))) {
                     long var11 = longValue(this.call(var10, "getId"));
                     Object var13 = this.current(var3, var11, var7).orElse(null);
                     if (var13 != null) {
                        int var14 = intValue(this.call(var13, "getLevel"));
                        Material var15 = this.modelMaterial(var3, var14);
                        var8.add(
                           new GeneratorService.GeneratorView(
                              var11,
                              var14,
                              stringValue(this.call(var13, "getWorldName")),
                              intValue(this.call(var13, "getX")),
                              intValue(this.call(var13, "getY")),
                              intValue(this.call(var13, "getZ")),
                              doubleValue(this.call(var13, "getStoredMoney")),
                              intValue(this.call(var13, "getStoredShards")),
                              doubleValue(this.call(var3, "getMoneyPerCycle", new Class[]{int.class}, var14)),
                              doubleValue(this.call(var3, "getUpgradePrice", new Class[]{int.class}, var14)),
                              var15
                           )
                        );
                     }
                  }
               }

               var8.sort(Comparator.comparingLong(GeneratorService.GeneratorView::id));
               return var8;
            } else {
               return List.of();
            }
         } else {
            return List.of();
         }
      } catch (ReflectiveOperationException var16) {
         this.warn(var16);
         return List.of();
      }
   }

   public int count(Player var1) {
      if (var1 == null) {
         return 0;
      }

      try {
         Object var2 = this.manager();
         return var2 == null ? 0 : intValue(this.call(var2, "countGenerators", new Class[]{UUID.class}, var1.getUniqueId()));
      } catch (ReflectiveOperationException var3) {
         this.warn(var3);
         return 0;
      }
   }

   public int limit(Player var1) {
      if (var1 == null) {
         return 0;
      }

      try {
         Plugin var2 = this.core();
         Object var3 = this.manager(var2);
         if (var2 != null && var3 != null) {
            Object var4 = this.call(var2, "getLevelManager");
            int var5 = intValue(this.call(var4, "getLevel", new Class[]{UUID.class}, var1.getUniqueId()));
            return intValue(this.call(var3, "getGeneratorLimit", new Class[]{int.class}, var5));
         } else {
            return 0;
         }
      } catch (ReflectiveOperationException var6) {
         this.warn(var6);
         return 0;
      }
   }

   public int maxLevel() {
      try {
         Object var1 = this.manager();
         return var1 == null ? 35 : Math.max(1, intValue(this.call(var1, "getMaxLevel")));
      } catch (ReflectiveOperationException var2) {
         this.warn(var2);
         return 35;
      }
   }

   public double intervalSeconds() {
      try {
         Object var1 = this.manager();
         return var1 == null ? 5.0 : doubleValue(this.call(var1, "getMoneyIntervalSeconds"));
      } catch (ReflectiveOperationException var2) {
         this.warn(var2);
         return 5.0;
      }
   }

   public boolean remove(Player var1, long var2) {
      if (var1 == null) {
         return false;
      }

      try {
         Object var4 = this.manager();
         if (var4 == null) {
            return false;
         }

         Object var5 = this.current(var4, var2, var1.getUniqueId()).orElse(null);
         if (var5 == null) {
            return false;
         }

         if (doubleValue(this.call(var5, "getStoredMoney")) > 0.0 || intValue(this.call(var5, "getStoredShards")) > 0) {
            this.call(var4, "collectMoney", new Class[]{Player.class, var5.getClass()}, var1, var5);
         }

         if (!(doubleValue(this.call(var5, "getStoredMoney")) > 0.0) && intValue(this.call(var5, "getStoredShards")) <= 0) {
            Location var6 = (Location)this.call(var5, "getLocation");
            boolean var7 = booleanValue(this.call(var4, "removeByOwner", new Class[]{Player.class, var5.getClass()}, var1, var5));
            if (var7) {
               this.clearPhysicalBlock(var6);
            }

            return var7;
         } else {
            return false;
         }
      } catch (ReflectiveOperationException var8) {
         this.warn(var8);
         return false;
      }
   }

   public GeneratorService.UpgradeSummary upgradeAll(Player var1) {
      if (var1 == null) {
         return new GeneratorService.UpgradeSummary(0, 0.0);
      }

      try {
         Plugin var2 = this.core();
         Object var3 = this.manager(var2);
         if (var2 != null && var3 != null) {
            ArrayList<GeneratorService.GeneratorView> var4 = new ArrayList<>(this.list(var1));
            var4.sort(Comparator.comparingDouble(GeneratorService.GeneratorView::upgradePrice).thenComparingLong(GeneratorService.GeneratorView::id));
            Object var5 = this.call(var2, "getEconomyManager");
            int var6 = this.maxLevel();
            int var7 = 0;
            double var8 = 0.0;

            for (GeneratorService.GeneratorView var11 : var4) {
               Object var12 = this.current(var3, var11.id(), var1.getUniqueId()).orElse(null);
               if (var12 != null) {
                  int var13 = intValue(this.call(var12, "getLevel"));
                  if (var13 < var6) {
                     double var14 = doubleValue(this.call(var3, "getUpgradePrice", new Class[]{int.class}, var13));
                     double var16 = doubleValue(this.call(var5, "getBalance", new Class[]{Player.class}, var1));
                     if (!(var14 > var16 + 1.0E-4)) {
                        boolean var18 = booleanValue(this.call(var3, "upgrade", new Class[]{Player.class, var12.getClass()}, var1, var12));
                        if (var18) {
                           var7++;
                           var8 += var14;
                        }
                     }
                  }
               }
            }

            return new GeneratorService.UpgradeSummary(var7, var8);
         } else {
            return new GeneratorService.UpgradeSummary(0, 0.0);
         }
      } catch (ReflectiveOperationException var19) {
         this.warn(var19);
         return new GeneratorService.UpgradeSummary(0, 0.0);
      }
   }

   public String format(double var1) {
      return this.numberFormat.format(Math.max(0.0, var1));
   }

   private Optional<?> current(Object var1, long var2, UUID var4) throws ReflectiveOperationException {
      return this.call(var1, "getGenerator", new Class[]{long.class, UUID.class}, var2, var4) instanceof Optional var6 ? var6 : Optional.empty();
   }

   private Material modelMaterial(Object var1, int var2) {
      try {
         return this.call(var1, "getModelMaterial", new Class[]{int.class}, var2) instanceof Material var4 ? var4 : Material.LIGHT_GRAY_STAINED_GLASS;
      } catch (ReflectiveOperationException var5) {
         return Material.LIGHT_GRAY_STAINED_GLASS;
      }
   }

   private void clearPhysicalBlock(Location var1) {
      if (var1 != null && var1.getWorld() != null) {
         World var2 = var1.getWorld();
         int var3 = var1.getBlockX() >> 4;
         int var4 = var1.getBlockZ() >> 4;
         Runnable var5 = () -> var1.getBlock().setType(Material.AIR, false);
         if (var2.isChunkLoaded(var3, var4)) {
            var5.run();
         } else {
            var2.getChunkAtAsync(var3, var4, true).thenAccept(var2x -> this.plugin.getServer().getScheduler().runTask(this.plugin, var5));
         }
      }
   }

   private Plugin core() {
      Plugin var1 = (Plugin)BundleResolver.getPlugin(this.plugin.getServer().getPluginManager(), "ZGenPvP");
      return var1 != null && var1.isEnabled() ? var1 : null;
   }

   private Object manager() throws ReflectiveOperationException {
      return this.manager(this.core());
   }

   private Object manager(Plugin var1) throws ReflectiveOperationException {
      return var1 == null ? null : this.call(var1, "getGeneratorManager");
   }

   private Object call(Object var1, String var2) throws ReflectiveOperationException {
      return this.call(var1, var2, new Class[0]);
   }

   private Object call(Object var1, String var2, Class<?>[] var3, Object... var4) throws ReflectiveOperationException {
      if (var1 == null) {
         return null;
      }

      Method var5 = var1.getClass().getMethod(var2, var3);
      return var5.invoke(var1, var4);
   }

   private void warn(Exception var1) {
      if (!this.warned) {
         this.warned = true;
         this.plugin.getLogger().warning("ZGenPvP jeneratör entegrasyonu kullanılamadı: " + var1.getMessage());
      }
   }

   private static int intValue(Object var0) {
      return var0 instanceof Number var1 ? var1.intValue() : 0;
   }

   private static long longValue(Object var0) {
      return var0 instanceof Number var1 ? var1.longValue() : 0L;
   }

   private static double doubleValue(Object var0) {
      return var0 instanceof Number var1 ? var1.doubleValue() : 0.0;
   }

   private static boolean booleanValue(Object var0) {
      return var0 instanceof Boolean var1 && var1;
   }

   private static String stringValue(Object var0) {
      return var0 == null ? "Bilinmiyor" : String.valueOf(var0);
   }

   public record GeneratorView(
      long id, int level, String world, int x, int y, int z, double storedMoney, int storedShards, double moneyPerCycle, double upgradePrice, Material material
   ) {
   }

   public record UpgradeSummary(int upgraded, double spent) {
   }
}
