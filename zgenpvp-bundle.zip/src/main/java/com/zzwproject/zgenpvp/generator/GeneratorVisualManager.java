package com.zzwproject.zgenpvp.generator;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.money.MoneyItemManager;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Display.Billboard;
import org.bukkit.entity.ItemDisplay.ItemDisplayTransform;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class GeneratorVisualManager {
   private final ZGenPvP plugin;
   private final MoneyItemManager moneyItemManager;
   private final Map<Long, GeneratorVisualManager.GeneratorVisual> visuals = new HashMap<>();

   public GeneratorVisualManager(ZGenPvP plugin, MoneyItemManager moneyItemManager) {
      this.plugin = plugin;
      this.moneyItemManager = moneyItemManager;
   }

   public void refreshAll(Collection<GeneratorData> generators) {
      for (GeneratorData generator : generators) {
         this.refresh(generator);
      }
   }

   public void refresh(GeneratorData generator) {
      Location blockLocation = generator.getLocation();
      if (blockLocation != null && blockLocation.getWorld() != null) {
         int chunkX = blockLocation.getBlockX() >> 4;
         int chunkZ = blockLocation.getBlockZ() >> 4;
         if (blockLocation.getWorld().isChunkLoaded(chunkX, chunkZ)) {
            GeneratorVisualManager.GeneratorVisual visual = this.visuals.get(generator.getId());
            if (visual == null || !visual.isValid()) {
               if (visual != null) {
                  visual.remove();
               }

               visual = this.createVisual(generator);
               this.visuals.put(generator.getId(), visual);
            }

            this.updateModel(visual.modelDisplay(), generator);
            this.updateMoney(visual.moneyDisplay(), generator);
            this.updateShard(visual.shardDisplay(), generator);
            this.updateLink(visual.linkDisplay(), generator);
            this.teleportVisuals(visual, blockLocation);
         }
      }
   }

   public void remove(long generatorId) {
      GeneratorVisualManager.GeneratorVisual visual = this.visuals.remove(generatorId);
      if (visual != null) {
         visual.remove();
      }
   }

   public void shutdown() {
      for (GeneratorVisualManager.GeneratorVisual visual : this.visuals.values()) {
         visual.remove();
      }

      this.visuals.clear();
   }

   private GeneratorVisualManager.GeneratorVisual createVisual(GeneratorData generator) {
      Location base = generator.getLocation();
      if (base != null && base.getWorld() != null) {
         ItemDisplay model = (ItemDisplay)base.getWorld().spawn(this.modelLocation(base), ItemDisplay.class);
         this.setupItemDisplay(model, this.getModelScale(), Billboard.FIXED);
         ItemDisplay money = (ItemDisplay)base.getWorld().spawn(this.moneyLocation(base), ItemDisplay.class);
         this.setupItemDisplay(money, this.getMoneyScale(), Billboard.CENTER);
         ItemDisplay shard = (ItemDisplay)base.getWorld().spawn(this.shardLocation(base), ItemDisplay.class);
         this.setupItemDisplay(shard, this.getShardScale(), Billboard.CENTER);
         ItemDisplay link = (ItemDisplay)base.getWorld().spawn(this.linkLocation(base), ItemDisplay.class);
         this.setupItemDisplay(link, this.getLinkScale(), Billboard.FIXED);
         return new GeneratorVisualManager.GeneratorVisual(model, money, shard, link);
      } else {
         throw new IllegalStateException("generator dünyası bulunamadı.");
      }
   }

   private void setupItemDisplay(ItemDisplay display, float scale, Billboard billboard) {
      display.setPersistent(false);
      display.setBillboard(billboard);
      display.setItemDisplayTransform(ItemDisplayTransform.FIXED);
      display.setInterpolationDuration(0);
      display.setTeleportDuration(0);
      display.setTransformation(new Transformation(new Vector3f(0.0F, 0.0F, 0.0F), new Quaternionf(), new Vector3f(scale, scale, scale), new Quaternionf()));
   }

   private void updateModel(ItemDisplay display, GeneratorData generator) {
      FileConfiguration config = this.plugin.getConfigManager().getGenerators();
      String path = "levels." + generator.getLevel() + ".model";
      String materialName = config.getString(path + ".material", "COAL_ORE");
      Material material = Material.matchMaterial(materialName == null ? "COAL_ORE" : materialName);
      if (material == null) {
         material = Material.COAL_ORE;
      }

      ItemStack item = new ItemStack(material);
      int modelData = config.getInt(path + ".custom-model-data", 0);
      if (modelData > 0) {
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            meta.setCustomModelData(modelData);
            item.setItemMeta(meta);
         }
      }

      display.setItemStack(item);
   }

   private void updateMoney(ItemDisplay display, GeneratorData generator) {
      if (generator.getStoredMoney() <= 0.0) {
         display.setItemStack(new ItemStack(Material.AIR));
      } else {
         display.setItemStack(this.moneyItemManager.createMoney(generator.getStoredMoney()));
      }
   }

   private void updateShard(ItemDisplay display, GeneratorData generator) {
      if (generator.getStoredShards() <= 0) {
         display.setItemStack(new ItemStack(Material.AIR));
      } else {
         FileConfiguration config = this.plugin.getConfigManager().getGenerators();
         String materialName = config.getString("visuals.shard.material", "PRISMARINE_SHARD");
         Material material = Material.matchMaterial(materialName == null ? "PRISMARINE_SHARD" : materialName);
         if (material == null) {
            material = Material.PRISMARINE_SHARD;
         }

         ItemStack item = new ItemStack(material);
         int customModelData = config.getInt("visuals.shard.custom-model-data", 0);
         if (customModelData > 0) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
               meta.setCustomModelData(customModelData);
               item.setItemMeta(meta);
            }
         }

         display.setItemStack(item);
      }
   }

   private void updateLink(ItemDisplay display, GeneratorData generator) {
      if (!generator.hasLinkedChest()) {
         display.setItemStack(new ItemStack(Material.AIR));
      } else {
         display.setItemStack(new ItemStack(Material.HOPPER));
      }
   }

   private void teleportVisuals(GeneratorVisualManager.GeneratorVisual visual, Location base) {
      visual.modelDisplay().teleport(this.modelLocation(base));
      visual.moneyDisplay().teleport(this.moneyLocation(base));
      visual.shardDisplay().teleport(this.shardLocation(base));
      visual.linkDisplay().teleport(this.linkLocation(base));
   }

   private Location modelLocation(Location base) {
      return base.clone().add(0.5, this.getDouble("visuals.model.y", 0.52), 0.5);
   }

   private Location moneyLocation(Location base) {
      return base.clone().add(this.getDouble("visuals.money.x", 0.28), this.getDouble("visuals.money.y", 1.3), this.getDouble("visuals.money.z", 0.5));
   }

   private Location shardLocation(Location base) {
      return base.clone().add(this.getDouble("visuals.shard.x", 0.72), this.getDouble("visuals.shard.y", 1.3), this.getDouble("visuals.shard.z", 0.5));
   }

   private Location linkLocation(Location base) {
      return base.clone().add(this.getDouble("visuals.link.x", 0.5), this.getDouble("visuals.link.y", 0.18), this.getDouble("visuals.link.z", 0.86));
   }

   private float getModelScale() {
      return (float)this.getDouble("visuals.model.scale", 0.62);
   }

   private float getMoneyScale() {
      return (float)this.getDouble("visuals.money.scale", 0.45);
   }

   private float getShardScale() {
      return (float)this.getDouble("visuals.shard.scale", 0.4);
   }

   private float getLinkScale() {
      return (float)this.getDouble("visuals.link.scale", 0.34);
   }

   private double getDouble(String path, double fallback) {
      return this.plugin.getConfigManager().getGenerators().getDouble(path, fallback);
   }

   private record GeneratorVisual(ItemDisplay modelDisplay, ItemDisplay moneyDisplay, ItemDisplay shardDisplay, ItemDisplay linkDisplay) {
      private boolean isValid() {
         return this.modelDisplay != null
            && this.moneyDisplay != null
            && this.shardDisplay != null
            && this.linkDisplay != null
            && this.modelDisplay.isValid()
            && this.moneyDisplay.isValid()
            && this.shardDisplay.isValid()
            && this.linkDisplay.isValid();
      }

      private void remove() {
         if (this.modelDisplay != null && this.modelDisplay.isValid()) {
            this.modelDisplay.remove();
         }

         if (this.moneyDisplay != null && this.moneyDisplay.isValid()) {
            this.moneyDisplay.remove();
         }

         if (this.shardDisplay != null && this.shardDisplay.isValid()) {
            this.shardDisplay.remove();
         }

         if (this.linkDisplay != null && this.linkDisplay.isValid()) {
            this.linkDisplay.remove();
         }
      }
   }
}
