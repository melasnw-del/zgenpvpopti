package com.zzwproject.zgenpvp.placeholder;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.level.LevelManager;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public final class ZGenPvPPlaceholder extends PlaceholderExpansion {
   private final ZGenPvP plugin;
   private final LevelManager levelManager;
   private final GeneratorManager generatorManager;

   public ZGenPvPPlaceholder(ZGenPvP var1, LevelManager var2, GeneratorManager var3) {
      this.plugin = var1;
      this.levelManager = var2;
      this.generatorManager = var3;
   }

   public String getIdentifier() {
      return "zgenpvp";
   }

   public String getAuthor() {
      return this.plugin.getDescription().getAuthors().isEmpty() ? "Unknown" : String.join(", ", this.plugin.getDescription().getAuthors());
   }

   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player var1, String var2) {
      if (var1 == null) {
         return "0";
      }

      int var3 = this.levelManager.getLevel(var1.getUniqueId());
      double var4 = this.levelManager.getXp(var1.getUniqueId());
      double var6 = this.levelManager.getRequiredXp(var3);
      double var8 = this.levelManager.getXpPercentage(var1.getUniqueId());
      int var10 = this.generatorManager.countGenerators(var1.getUniqueId());
      int var11 = this.generatorManager.getGeneratorLimit(var3);
      int var12 = Math.max(0, var11 - var10);

      return switch (var2.toLowerCase()) {
         case "level" -> String.valueOf(var3);
         case "xp" -> this.raw(var4);
         case "xp_required" -> var3 >= this.levelManager.getMaxLevel() ? "0" : this.raw(var6);
         case "xp_percentage" -> this.raw(var8);
         case "xp_formatted" -> this.format(var4);
         case "xp_required_formatted" -> var3 >= this.levelManager.getMaxLevel() ? "0" : this.format(var6);
         case "xp_percentage_formatted" -> this.format(var8);
         case "generators" -> String.valueOf(var10);
         case "generator_limit" -> String.valueOf(var11);
         case "generator_remaining" -> String.valueOf(var12);
         default -> null;
      };
   }

   private String raw(double var1) {
      if (!Double.isFinite(var1)) {
         return "0";
      }

      BigDecimal var3 = BigDecimal.valueOf(var1).stripTrailingZeros();
      return var3.toPlainString();
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }
}
