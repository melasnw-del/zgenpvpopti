package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.block.Block;

public final class PlacedBlockRepository {
   private final DatabaseManager databaseManager;
   private final Set<String> cache = ConcurrentHashMap.newKeySet();

   public PlacedBlockRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public void loadCache() {
      this.cache.clear();
      String var1 = "SELECT world, x, y, z FROM placed_blocks;";

      try (
         PreparedStatement var2 = this.databaseManager.getConnection().prepareStatement(var1);
         ResultSet var3 = var2.executeQuery();
      ) {
         while (var3.next()) {
            this.cache.add(this.key(var3.getString("world"), var3.getInt("x"), var3.getInt("y"), var3.getInt("z")));
         }
      } catch (SQLException var10) {
         var10.printStackTrace();
      }
   }

   public boolean isTracked(Location var1) {
      String var2 = this.key(var1);
      return var2 != null && this.cache.contains(var2);
   }

   public void track(Location var1, UUID var2) {
      String var3 = this.key(var1);
      if (var3 != null) {
         this.cache.add(var3);
         String var4 = "INSERT INTO placed_blocks (\n    world, x, y, z,\n    owner_uuid, placed_at\n) VALUES (?, ?, ?, ?, ?, ?)\nON CONFLICT(world, x, y, z)\nDO UPDATE SET\n    owner_uuid = excluded.owner_uuid,\n    placed_at = excluded.placed_at;\n";

         try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4)) {
            var5.setString(1, var1.getWorld().getName());
            var5.setInt(2, var1.getBlockX());
            var5.setInt(3, var1.getBlockY());
            var5.setInt(4, var1.getBlockZ());
            if (var2 == null) {
               var5.setNull(5, 12);
            } else {
               var5.setString(5, var2.toString());
            }

            var5.setLong(6, System.currentTimeMillis());
            var5.executeUpdate();
         } catch (SQLException var10) {
            this.cache.remove(var3);
            var10.printStackTrace();
         }
      }
   }

   public void remove(Location var1) {
      String var2 = this.key(var1);
      if (var2 != null && this.cache.remove(var2)) {
         String var3 = "DELETE FROM placed_blocks\nWHERE world = ? AND x = ? AND y = ? AND z = ?;\n";

         try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
            var4.setString(1, var1.getWorld().getName());
            var4.setInt(2, var1.getBlockX());
            var4.setInt(3, var1.getBlockY());
            var4.setInt(4, var1.getBlockZ());
            var4.executeUpdate();
         } catch (SQLException var9) {
            var9.printStackTrace();
         }
      }
   }

   public void removeBlocks(Collection<Block> var1) {
      if (var1 != null && !var1.isEmpty()) {
         for (Block var3 : var1) {
            if (var3 != null) {
               this.remove(var3.getLocation());
            }
         }
      }
   }

   public int size() {
      return this.cache.size();
   }

   private String key(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.key(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ()) : null;
   }

   private String key(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }
}
