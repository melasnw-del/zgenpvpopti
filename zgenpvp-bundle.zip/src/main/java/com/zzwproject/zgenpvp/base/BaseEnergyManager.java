package com.zzwproject.zgenpvp.base;

import com.zzwproject.hotfix.HotfixHooks;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.DefenseRepository;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.data.Bisected.Half;
import org.bukkit.block.data.type.Door;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public final class BaseEnergyManager {
   private final ZGenPvP plugin;
   private final BaseRepository baseRepository;
   private final DefenseRepository defenseRepository;
   private final BaseEnergyRepository energyRepository;
   private final EconomyManager economyManager;
   private final Map<Long, Integer> warningStages = new HashMap<>();
   private BukkitTask task;
   private long lastTickMillis;

   public BaseEnergyManager(ZGenPvP var1, BaseRepository var2, DefenseRepository var3, BaseEnergyRepository var4, EconomyManager var5) {
      this.plugin = var1;
      this.baseRepository = var2;
      this.defenseRepository = var3;
      this.energyRepository = var4;
      this.economyManager = var5;
   }

   public void start() {
      this.stop();
      this.lastTickMillis = System.currentTimeMillis();
      long var1 = Math.max(5L, this.plugin.getConfigManager().getConfig().getLong("base.energy.task-interval-seconds", 60L));
      this.task = this.plugin.getServer().getScheduler().runTaskTimer(this.plugin, this::tick, 20L * var1, 20L * var1);
   }

   public void stop() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.warningStages.clear();
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("base.energy.enabled", true);
   }

   private void tick() {
      if (!this.isEnabled()) {
         this.lastTickMillis = System.currentTimeMillis();
      } else {
         long var1 = System.currentTimeMillis();
         double var3 = Math.max(0.0, (var1 - this.lastTickMillis) / 3600000.0);
         this.lastTickMillis = var1;
         if (!(var3 <= 0.0)) {
            for (BaseData var6 : this.baseRepository.findAll()) {
               this.drain(var6, var3);
            }
         }
      }
   }

   private void drain(BaseData var1, double var2) {
      BaseEnergyManager.EnergySnapshot var4 = this.getSnapshot(var1);
      if (!(var4.consumptionPerHour() <= 0.0)) {
         double var5 = Math.max(0.0, var4.remainingHours() - var2);
         if (this.energyRepository.set(var1.getId(), var5)) {
            BaseEnergyManager.EnergySnapshot var7 = this.snapshot(var1, var5);
            this.handleWarnings(var1, var7);
            if (var4.remainingHours() > 0.0 && var5 <= 0.0) {
               this.handleDepleted(var1);
            }
         }
      }
   }

   public boolean isPowered(BaseData var1) {
      if (var1 == null) {
         return false;
      }

      double var2 = this.getMaxHours();
      double var4 = Math.max(0.0, Math.min(var2, this.plugin.getConfigManager().getConfig().getDouble("base.energy.initial-fill-hours", var2)));
      return this.energyRepository.getOrCreate(var1.getId(), var4) > 0.0;
   }

   public BaseEnergyManager.EnergySnapshot getSnapshot(BaseData var1) {
      if (var1 == null) {
         return new BaseEnergyManager.EnergySnapshot(false, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
      }

      double var2 = this.getMaxHours();
      double var4 = Math.max(0.0, Math.min(var2, this.plugin.getConfigManager().getConfig().getDouble("base.energy.initial-fill-hours", var2)));
      double var6 = this.energyRepository.getOrCreate(var1.getId(), var4);
      if (var6 > var2) {
         var6 = var2;
         this.energyRepository.set(var1.getId(), var6);
      }

      return this.snapshot(var1, var6);
   }

   private BaseEnergyManager.EnergySnapshot snapshot(BaseData var1, double var2) {
      double var4 = this.getConsumptionPerHour(var1.getId());
      double var6 = this.getMaxHours();
      double var8 = Math.max(0.0, Math.min(var2, var6));
      double var10 = var8 * var4;
      double var12 = var6 * var4;
      double var14 = Math.max(0.0, var6 - var8);
      double var16 = var14 * var4 * this.getPricePerFu();
      return new BaseEnergyManager.EnergySnapshot(var8 > 0.0, var10, var12, var4, var8, var6, var16);
   }

   public BaseEnergyManager.PurchasePreview previewHours(BaseData var1, double var2) {
      BaseEnergyManager.EnergySnapshot var4 = this.getSnapshot(var1);
      double var5 = Math.max(0.0, var4.maxHours() - var4.remainingHours());
      double var7 = Math.min(Math.max(0.0, var2), var5);
      double var9 = var4.consumptionPerHour() * var7;
      return new BaseEnergyManager.PurchasePreview(var9, var9 * this.getPricePerFu(), var7);
   }

   public BaseEnergyManager.PurchasePreview previewFull(BaseData var1) {
      BaseEnergyManager.EnergySnapshot var2 = this.getSnapshot(var1);
      double var3 = Math.max(0.0, var2.maxHours() - var2.remainingHours());
      double var5 = var2.consumptionPerHour() * var3;
      return new BaseEnergyManager.PurchasePreview(var5, var5 * this.getPricePerFu(), var3);
   }

   public boolean buyHours(Player var1, BaseData var2, double var3) {
      return this.buy(var1, var2, this.previewHours(var2, var3));
   }

   public boolean buyFull(Player var1, BaseData var2) {
      return this.buy(var1, var2, this.previewFull(var2));
   }

   private boolean buy(Player var1, BaseData var2, BaseEnergyManager.PurchasePreview var3) {
      if (var1 != null && var2 != null && !(var3.addFu() <= 0.0) && !(var3.addHours() <= 0.0)) {
         if (!this.plugin.getBaseManager().canManageBase(var1, var2)) {
            this.plugin.getBaseManager().sendOwnerInfo(var1, var2);
            return false;
         } else if (!this.economyManager.has(var1, var3.price())) {
            this.plugin.getMessageUtil().send(var1, "base-energy.not-enough-money", "%price%", this.format(var3.price()));
            this.plugin.getSoundUtil().play(var1, "error");
            return false;
         } else if (!this.economyManager.withdraw(var1, var3.price())) {
            this.plugin.getMessageUtil().send(var1, "general.economy-error");
            this.plugin.getSoundUtil().play(var1, "error");
            return false;
         } else {
            BaseEnergyManager.EnergySnapshot var4 = this.getSnapshot(var2);
            double var5 = Math.min(var4.maxHours(), var4.remainingHours() + var3.addHours());
            if (!this.energyRepository.set(var2.getId(), var5)) {
               this.economyManager.deposit(var1, var3.price());
               this.plugin.getMessageUtil().send(var1, "general.database-error");
               this.plugin.getSoundUtil().play(var1, "error");
               return false;
            } else {
               this.warningStages.remove(var2.getId());
               BaseEnergyManager.EnergySnapshot var7 = this.snapshot(var2, var5);
               this.plugin
                  .getMessageUtil()
                  .send(
                     var1,
                     "base-energy.purchased",
                     "%fu%",
                     this.format(var3.addFu()),
                     "%price%",
                     this.format(var3.price()),
                     "%remaining%",
                     this.formatDuration(var7.remainingHours())
                  );
               this.plugin.getSoundUtil().play(var1, "base-energy-purchase");
               return true;
            }
         }
      } else {
         if (var1 != null) {
            this.plugin.getMessageUtil().send(var1, "base-energy.already-full");
            this.plugin.getSoundUtil().play(var1, "error");
         }

         return false;
      }
   }

   private final java.util.concurrent.ConcurrentHashMap<Long, double[]> consumptionCache = new java.util.concurrent.ConcurrentHashMap<>();

   public double getConsumptionPerHour(long var1) {
      long var3 = System.currentTimeMillis();
      double[] var5 = this.consumptionCache.get(var1);
      if (var5 != null && var3 - (long)var5[0] < 3000L) {
         return var5[1];
      }

      double var6 = HotfixHooks.energyConsumption(this, var1);
      this.consumptionCache.put(var1, new double[]{(double)var3, var6});
      return var6;
   }

   public double getMaxHours() {
      return Math.max(1.0, this.plugin.getConfigManager().getConfig().getDouble("base.energy.max-hours", 24.0));
   }

   public double getPricePerFu() {
      return Math.max(0.0, this.plugin.getConfigManager().getConfig().getDouble("base.energy.price-per-fu", 5.0));
   }

   private double cfg(String var1, double var2) {
      return Math.max(0.0, this.plugin.getConfigManager().getConfig().getDouble(var1, var2));
   }

   private void handleWarnings(BaseData var1, BaseEnergyManager.EnergySnapshot var2) {
      if (var2.active()) {
         double var3 = var2.remainingHours();
         double var8 = this.cfg("base.energy.warnings.critical-hours", 0.25);
         double var10 = this.cfg("base.energy.warnings.medium-hours", 1.0);
         double var12 = this.cfg("base.energy.warnings.early-hours", 3.0);
         byte var5;
         String var6;
         String var7;
         if (var3 <= var8) {
            var5 = 3;
            var6 = "base-energy.warning-critical";
            var7 = "&cEnerji çok az";
         } else if (var3 <= var10) {
            var5 = 2;
            var6 = "base-energy.warning-one-hour";
            var7 = "&#FF8A00Enerji azalıyor";
         } else {
            if (!(var3 <= var12)) {
               this.warningStages.remove(var1.getId());
               return;
            }

            var5 = 1;
            var6 = "base-energy.warning-three-hours";
            var7 = "&eEnerji uyarısı";
         }

         int var14 = this.warningStages.getOrDefault(var1.getId(), 0);
         if (var5 > var14) {
            this.warningStages.put(var1.getId(), Integer.valueOf(var5));
            Player var15 = this.onlineOwner(var1);
            if (var15 != null) {
               this.plugin
                  .getMessageUtil()
                  .send(
                     var15,
                     var6,
                     "%remaining%",
                     this.formatDuration(var3),
                     "%energy%",
                     this.format(var2.energy()),
                     "%max_energy%",
                     this.format(var2.maxEnergy())
                  );
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(
                     var15,
                     "base-energy.warning-actionbar",
                     "%remaining%",
                     this.formatDuration(var3),
                     "%energy%",
                     this.format(var2.energy()),
                     "%max_energy%",
                     this.format(var2.maxEnergy())
                  );
               var15.sendTitle(this.color(var7), this.color("&7Kalan süre: &f" + this.formatDuration(var3)), 10, 50, 10);
               this.plugin.getSoundUtil().play(var15, "base-energy-warning");
            }
         }
      }
   }

   private void handleDepleted(BaseData var1) {
      this.warningStages.put(var1.getId(), 4);
      byte var2 = 0;
      Player var3 = this.onlineOwner(var1);
      if (var3 != null) {
         this.plugin.getMessageUtil().send(var3, "base-energy.depleted", "%destroyed%", String.valueOf(var2));
         this.plugin.getMessageUtil().sendActionBar(var3, "base-energy.depleted-actionbar", "%destroyed%", String.valueOf(var2));
         var3.sendTitle(this.color("&cEnerji tukendi!"), this.color("&7Base sistemleri %50 verimle çalışıyor."), 10, 70, 15);
         this.plugin.getSoundUtil().play(var3, "base-energy-empty");
      }
   }

   public int destroyDefenses(BaseData var1) {
      if (var1 == null) {
         return 0;
      }

      List<DefenseData> var2 = this.defenseRepository.findAllByBase(var1.getId());
      int var3 = 0;

      for (DefenseData var5 : var2) {
         if (this.isEnergyStructure(var5.getType())) {
            this.clearPhysicalBlock(var5);
            if (this.defenseRepository.delete(var5.getId())) {
               var3++;
            }
         }
      }

      if (this.plugin.getDefenseManager() != null) {
         this.plugin.getDefenseManager().loadCache();
      }

      if (this.plugin.getTurretManager() != null) {
         this.plugin.getTurretManager().loadCache();
      }

      if (this.plugin.getDefenseAccessManager() != null) {
         this.plugin.getDefenseAccessManager().loadCache();
      }

      return var3;
   }

   private boolean isEnergyStructure(String var1) {
      return "DEFENSE_BLOCK".equalsIgnoreCase(var1)
         || "TURRET".equalsIgnoreCase(var1)
         || "DEFENSE_DOOR".equalsIgnoreCase(var1)
         || "DEFENSE_TRAPDOOR".equalsIgnoreCase(var1);
   }

   private void clearPhysicalBlock(DefenseData var1) {
      Location var2 = var1.getLocation();
      if (var2 != null && var2.getWorld() != null) {
         Block var3 = var2.getBlock();
         if (var3.getBlockData() instanceof Door var5) {
            Block var6 = var5.getHalf() == Half.BOTTOM ? var3 : var3.getRelative(0, -1, 0);
            Block var7 = var6.getRelative(0, 1, 0);
            var7.setType(Material.AIR, false);
            var6.setType(Material.AIR, false);
         } else {
            var3.setType(Material.AIR, false);
         }
      }
   }

   private Player onlineOwner(BaseData var1) {
      OfflinePlayer var2 = this.plugin.getServer().getOfflinePlayer(var1.getOwnerUuid());
      return var2.isOnline() ? var2.getPlayer() : null;
   }

   public void deleteEnergy(long var1) {
      this.warningStages.remove(var1);
      this.energyRepository.delete(var1);
   }

   public String formatDuration(double var1) {
      if (Double.isFinite(var1) && !(var1 <= 0.0)) {
         long var3 = Math.max(1L, Math.round(var1 * 60.0));
         long var5 = var3 / 1440L;
         long var7 = var3 % 1440L / 60L;
         long var9 = var3 % 60L;
         if (var5 > 0L) {
            return var5 + " gun " + var7 + " sa";
         } else {
            return var7 > 0L ? var7 + " sa " + var9 + " dk" : var9 + " dk";
         }
      } else {
         return "0 dk";
      }
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private String color(String var1) {
      return ColorUtil.color(var1);
   }

   public record EnergySnapshot(
      boolean active, double energy, double maxEnergy, double consumptionPerHour, double remainingHours, double maxHours, double fullPrice
   ) {
   }

   public record PurchasePreview(double addFu, double price, double addHours) {
   }
}
