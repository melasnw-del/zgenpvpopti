package com.zzwproject.zgenpvp.command;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class EmptyTabCompleter implements TabCompleter {
   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var2.getName().equalsIgnoreCase("level") && var1.hasPermission("zgenpvp.level.admin")) {
         if (var4.length == 1) {
            return this.filter(List.of("ver", "ayarla"), var4[0]);
         }

         if (var4.length != 2) {
            return var4.length == 3 ? this.filter(List.of("1", "5", "10", "25", "50"), var4[2]) : Collections.emptyList();
         }

         ArrayList var5 = new ArrayList();

         for (Player var7 : Bukkit.getOnlinePlayers()) {
            var5.add(var7.getName());
         }

         return this.filter(var5, var4[1]);
      } else {
         return Collections.emptyList();
      }
   }

   private List<String> filter(List<String> var1, String var2) {
      String var3 = var2 == null ? "" : var2.toLowerCase(Locale.ROOT);
      ArrayList var4 = new ArrayList();

      for (String var6 : var1) {
         if (var6.toLowerCase(Locale.ROOT).startsWith(var3)) {
            var4.add(var6);
         }
      }

      return var4;
   }
}
