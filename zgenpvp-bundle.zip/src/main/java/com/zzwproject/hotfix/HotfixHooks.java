package com.zzwproject.hotfix;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public final class HotfixHooks {
   private static final Map<String, HotfixHooks.MapPoint> JUMP_PADS = new LinkedHashMap<>();
   private static final Map<String, HotfixHooks.MapPoint> AFK_GENS = new LinkedHashMap<>();
   private static final Map<UUID, Long> JUMP_COOLDOWN = new ConcurrentHashMap<>();
   private static final Map<UUID, Long> BOSS_FALLBACK_COOLDOWN = new ConcurrentHashMap<>();
   private static Object mapPlugin;
   private static File mapDataFile;
   private static long mapTicks;

   private HotfixHooks() {
   }

   private static Field field(Class<?> var0, String var1) throws Exception {
      for (Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3;
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object get(Object var0, String var1) throws Exception {
      return field(var0.getClass(), var1).get(var0);
   }

   private static void set(Object var0, String var1, Object var2) throws Exception {
      field(var0.getClass(), var1).set(var0, var2);
   }

   private static final java.util.concurrent.ConcurrentHashMap<String, Method> METHOD_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

   private static Method methodByName(Object var0, String var1, int var2) throws Exception {
      Class var3 = var0 instanceof Class ? (Class)var0 : var0.getClass();
      String var4 = var3.getName() + "#" + var1 + "/" + var2;
      Method var5 = METHOD_CACHE.get(var4);
      if (var5 == null) {
         var5 = methodByNameUncached(var0, var1, var2);
         METHOD_CACHE.put(var4, var5);
      }

      return var5;
   }

   private static Method methodByNameUncached(Object var0, String var1, int var2) throws Exception {
      Class var3 = var0 instanceof Class ? (Class)var0 : var0.getClass();

      for (Method var7 : var3.getMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == var2) {
            var7.setAccessible(true);
            return var7;
         }
      }

      while (var3 != null) {
         for (Method var11 : var3.getDeclaredMethods()) {
            if (var11.getName().equals(var1) && var11.getParameterCount() == var2) {
               var11.setAccessible(true);
               return var11;
            }
         }

         var3 = var3.getSuperclass();
      }

      throw new NoSuchMethodException(var1 + "/" + var2);
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      return methodByName(var0, var1, var2.length).invoke(var0, var2);
   }

   private static Object invoke(Method var0, Object var1, Object... var2) throws Exception {
      var0.setAccessible(true);
      return var0.invoke(var1, var2);
   }

   private static Class<?> c(String var0) throws Exception {
      return Class.forName(var0);
   }

   private static void log(Object var0, String var1) {
      try {
         Object var2 = call(var0, "getLogger");
         methodByName(var2, "info", 1).invoke(var2, "[Update 31] " + var1);
      } catch (Throwable var3) {
      }
   }

   private static void warn(Object var0, String var1) {
      try {
         Object var2 = call(var0, "getLogger");
         methodByName(var2, "warning", 1).invoke(var2, "[Update 31] " + var1);
      } catch (Throwable var3) {
      }
   }

   private static double num(Object var0, double var1) {
      return var0 instanceof Number ? ((Number)var0).doubleValue() : var1;
   }

   private static long lng(Object var0, long var1) {
      return var0 instanceof Number ? ((Number)var0).longValue() : var1;
   }

   private static int integer(Object var0, int var1) {
      return var0 instanceof Number ? ((Number)var0).intValue() : var1;
   }

   private static boolean bool(Object var0, boolean var1) {
      return var0 instanceof Boolean ? (Boolean)var0 : var1;
   }

   public static boolean grantToast(Object var0, Object var1, String var2) {
      try {
         Map var3 = (Map)get(var0, "toastObjects");
         Object var4 = var3.get(var2);
         if (var4 == null) {
            return false;
         }

         Class var5 = c("org.bukkit.advancement.Advancement");
         Method var6 = var1.getClass().getMethod("getAdvancementProgress", var5);
         Object var7 = var6.invoke(var1, var4);
         Method var8 = methodByName(var7, "getAwardedCriteria", 0);
         Method var9 = methodByName(var7, "revokeCriteria", 1);
         Collection var10 = (Collection)var8.invoke(var7);

         for (Object var12 : new ArrayList(var10)) {
            var9.invoke(var7, String.valueOf(var12));
         }

         Runnable var16 = () -> {
            try {
               Object var4x = var6.invoke(var1, var4);
               Collection var5x = (Collection)methodByName(var4x, "getRemainingCriteria", 0).invoke(var4x);
               Method var6x = methodByName(var4x, "awardCriteria", 1);

               for (Object var8x : new ArrayList(var5x)) {
                  var6x.invoke(var4x, String.valueOf(var8x));
               }
            } catch (Throwable var9x) {
               warn(var0, "Toast gösterilemedi: " + var9x.getClass().getSimpleName());
            }
         };
         Object var17 = c("org.bukkit.Bukkit").getMethod("getScheduler").invoke(null);
         Class var13 = c("org.bukkit.plugin.Plugin");
         Method var14 = var17.getClass().getMethod("runTaskLater", var13, Runnable.class, long.class);
         var14.invoke(var17, var0, var16, 2L);
         return true;
      } catch (Throwable var15) {
         warn(var0, "Toast fallback devreye girdi: " + var15.getClass().getSimpleName());
         return false;
      }
   }

   public static String firstClaimText(long var0) {
      if (var0 <= 0L) {
         return "Henüz başlamadı";
      }

      try {
         DateTimeFormatter var2 = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm", new Locale("tr", "TR")).withZone(ZoneId.systemDefault());
         return var2.format(Instant.ofEpochMilli(var0));
      } catch (Throwable var3) {
         return new Date(var0).toString();
      }
   }

   public static void fixDailyReset(Object var0, Object var1) {
      try {
         Object var2 = get(var0, "plugin");
         Object var3 = call(var2, "data");
         Object var4 = call(var1, "getUniqueId");
         Object var5 = call(var3, "get", var4);
         long var6 = lng(call(var5, "getLastClaimAt"), 0L);
         int var8 = integer(call(var5, "getStreak"), 0);
         if (var6 <= 0L || var8 <= 0) {
            return;
         }

         Object var9 = call(var2, "getConfig");
         long var10 = 48L;

         try {
            var10 = lng(methodByName(var9, "getLong", 2).invoke(var9, "settings.streak-reset-hours", 48L), 48L);
         } catch (Throwable var14) {
         }

         if (System.currentTimeMillis() - var6 > Math.max(1L, var10) * 3600000L) {
            methodByName(var5, "setStreak", 1).invoke(var5, 0);
            methodByName(var5, "setFirstClaimAt", 1).invoke(var5, 0L);

            try {
               call(var3, "save");
            } catch (Throwable var13) {
            }
         }
      } catch (Throwable var15) {
      }
   }

   private static volatile long lastBeaconForce;

   public static void forceBeaconCancelSettings(Object var0) {
      long var6 = System.currentTimeMillis();
      if (var6 - lastBeaconForce < 2000L) {
         return;
      }

      lastBeaconForce = var6;

      try {
         Object var1 = get(var0, "plugin");
         Object var2 = call(var1, "getConfigManager");
         Object var3 = call(var2, "getConfig");
         Method var4 = methodByName(var3, "set", 2);
         var4.invoke(var3, "beacon.respawn.cancel-on-move", true);
         var4.invoke(var3, "beacon.respawn.cancel-on-damage", true);
      } catch (Throwable var5) {
      }
   }

   public static void handleBeaconMove(Object var0, Object var1) {
      try {
         Object var2 = call(var1, "getTo");
         Object var3 = call(var1, "getFrom");
         if (var2 == null || var3 == null) {
            return;
         }

         double var4 = num(call(var3, "getX"), 0.0);
         double var6 = num(call(var3, "getY"), 0.0);
         double var8 = num(call(var3, "getZ"), 0.0);
         double var10 = num(call(var2, "getX"), 0.0);
         double var12 = num(call(var2, "getY"), 0.0);
         double var14 = num(call(var2, "getZ"), 0.0);
         double var16 = var10 - var4;
         double var18 = var12 - var6;
         double var20 = var14 - var8;
         if (var16 * var16 + var18 * var18 + var20 * var20 < 1.0E-4) {
            return;
         }

         Object var22 = call(var1, "getPlayer");
         Object var23 = get(var0, "beaconManager");
         Object var24 = call(var22, "getUniqueId");
         if (!bool(call(var23, "isTeleporting", var24), false)) {
            return;
         }

         methodByName(var23, "cancelRespawn", 2).invoke(var23, var22, "respawn.cancelled-move");
      } catch (Throwable var25) {
      }
   }

   public static void handleBeaconDamageDealt(Object var0, Object var1) {
      try {
         if (!var1.getClass().getName().endsWith("EntityDamageByEntityEvent")) {
            return;
         }

         double var2 = num(call(var1, "getFinalDamage"), 0.0);
         if (var2 <= 0.0) {
            return;
         }

         Object var4 = call(var1, "getDamager");
         Class var5 = c("org.bukkit.entity.Player");
         Object var6 = null;
         if (var5.isInstance(var4)) {
            var6 = var4;
         } else {
            try {
               Object var7 = call(var4, "getShooter");
               if (var5.isInstance(var7)) {
                  var6 = var7;
               }
            } catch (Throwable var10) {
            }
         }

         if (var6 == null) {
            return;
         }

         Object var12 = get(var0, "beaconManager");
         Object var8 = call(var6, "getUniqueId");
         if (!bool(call(var12, "isTeleporting", var8), false)) {
            return;
         }

         Method var9 = methodByName(var12, "cancelRespawn", 2);
         var9.invoke(var12, var6, "respawn.cancelled-damage");
      } catch (Throwable var11) {
      }
   }

   public static double energyConsumption(Object var0, long var1) {
      try {
         Object var3 = get(var0, "plugin");
         Object var4 = get(var0, "defenseRepository");
         Object var5 = get(var0, "baseRepository");
         double var6 = 0.0;
         double var8 = cfg(var3, "base.energy.consumption.base", 0.01);
         int var10 = 1;
         boolean var60 = false;
         try {
            Object var61 = call(var5, "findById", var1);
            if (var61 instanceof java.util.Optional) {
               java.util.Optional<?> var62 = (java.util.Optional<?>) var61;
               if (var62.isPresent()) {
                  var10 = Math.max(1, integer(call(var62.get(), "getLevel"), 1));
                  var60 = true;
               }
            }
         } catch (Throwable var63) {
         }

         if (!var60) {
            Object var11 = call(var5, "findAll");
            if (var11 instanceof Iterable) {
               for (Object var13 : (Iterable)var11) {
                  if (lng(call(var13, "getId"), -1L) == var1) {
                     var10 = Math.max(1, integer(call(var13, "getLevel"), 1));
                     break;
                  }
               }
            }
         }

         var6 += scaled(var8, var10, cfg(var3, "base.energy.level-scaling.base-per-level", 0.05));
         double var40 = cfg(var3, "base.energy.consumption.turret", 1.2);
         double var41 = cfg(var3, "base.energy.level-scaling.turret-per-level", 0.1);
         double var42 = cfg(var3, "base.energy.consumption.defense-door", 0.08);
         double var43 = cfg(var3, "base.energy.level-scaling.door-per-level", 0.1);
         double var44 = cfg(var3, "base.energy.consumption.defense-trapdoor", 0.08);
         double var45 = cfg(var3, "base.energy.level-scaling.trapdoor-per-level", 0.1);
         double var46 = cfg(var3, "base.energy.consumption.defense-block", 0.1);
         double var47 = cfg(var3, "base.energy.level-scaling.defense-block-per-level", 0.06);
         Object var25 = call(var4, "findAllByBase", var1);
         if (var25 instanceof Iterable) {
            for (Object var14 : (Iterable)var25) {
               String var15 = String.valueOf(call(var14, "getType"));
               int var16 = Math.max(1, integer(call(var14, "getLevel"), 1));
               double var17;
               double var19;
               switch (var15) {
                  case "TURRET":
                     var17 = var40;
                     var19 = var41;
                     break;
                  case "DEFENSE_DOOR":
                     var17 = var42;
                     var19 = var43;
                     break;
                  case "DEFENSE_TRAPDOOR":
                     var17 = var44;
                     var19 = var45;
                     break;
                  default:
                     var17 = var46;
                     var19 = var47;
               }

               var6 += scaled(var17, var16, var19);
            }
         }

         Object var27 = call(var3, "getGeneratorRepository");
         Object var28 = call(var27, "findAllByBase", var1);
         if (var28 instanceof Iterable) {
            double var48 = cfg(var3, "base.energy.consumption.generator", 0.2);
            double var49 = cfg(var3, "base.energy.level-scaling.generator-per-level", 0.04);

            for (Object var31 : (Iterable)var28) {
               int var32 = Math.max(1, integer(call(var31, "getLevel"), 1));
               var6 += scaled(var48, var32, var49);
            }
         }

         double var30 = cfg(var3, "base.energy.level-scaling.global-multiplier", 1.15);
         return Math.max(0.0, var6 * var30);
      } catch (Throwable var23) {
         return 0.0;
      }
   }

   private static double scaled(double var0, int var2, double var3) {
      return Math.max(0.0, var0) * (1.0 + Math.max(0, var2 - 1) * Math.max(0.0, var3));
   }

   private static double cfg(Object var0, String var1, double var2) {
      try {
         Object var4 = call(var0, "getConfigManager");
         Object var8 = call(var4, "getConfig");
         return num(methodByName(var8, "getDouble", 2).invoke(var8, var1, var2), var2);
      } catch (Throwable var7) {
         try {
            Object var5 = call(var0, "getConfig");
            return num(methodByName(var5, "getDouble", 2).invoke(var5, var1, var2), var2);
         } catch (Throwable var6) {
            return var2;
         }
      }
   }

   public static void ensureBossTarget(Object var0, Object var1) {
      try {
         Object var2 = get(var1, "entity");

         try {
            methodByName(var2, "setAI", 1).invoke(var2, true);
         } catch (Throwable var37) {
         }

         try {
            methodByName(var2, "setAware", 1).invoke(var2, true);
         } catch (Throwable var36) {
         }

         try {
            methodByName(var2, "setRemoveWhenFarAway", 1).invoke(var2, false);
         } catch (Throwable var35) {
         }

         try {
            methodByName(var2, "setPersistent", 1).invoke(var2, true);
         } catch (Throwable var34) {
         }

         Object var3 = call(var0, "getConfig");
         double var4 = 18.0;

         try {
            var4 = num(methodByName(var3, "getDouble", 2).invoke(var3, "combat.target-radius", 18.0), 18.0);
         } catch (Throwable var33) {
         }

         Object var6 = methodByName(var2, "getNearbyEntities", 3).invoke(var2, var4, var4, var4);
         Class var7 = c("org.bukkit.entity.Player");
         Object var8 = null;
         double var9 = Double.MAX_VALUE;
         Object var11 = call(var2, "getLocation");
         if (var6 instanceof Iterable) {
            Iterator var12 = ((Iterable)var6).iterator();

            label234:
            while (true) {
               Object var13;
               while (true) {
                  while (true) {
                     if (!var12.hasNext()) {
                        break label234;
                     }

                     var13 = var12.next();
                     if (var7.isInstance(var13)) {
                        try {
                           if (bool(call(var13, "isDead"), false)) {
                              continue;
                           }
                        } catch (Throwable var41) {
                        }
                        break;
                     }
                  }

                  try {
                     String var14 = String.valueOf(call(var13, "getGameMode"));
                     if (!var14.equals("CREATIVE") && !var14.equals("SPECTATOR")) {
                        break;
                     }
                  } catch (Throwable var42) {
                     break;
                  }
               }

               Object var49 = call(var13, "getLocation");
               double var15 = num(methodByName(var11, "distanceSquared", 1).invoke(var11, var49), Double.MAX_VALUE);
               if (var15 < var9) {
                  var9 = var15;
                  var8 = var13;
               }
            }
         }

         if (var8 == null) {
            return;
         }

         boolean var44 = false;

         for (Method var16 : var2.getClass().getMethods()) {
            if (var16.getName().equals("setTarget") && var16.getParameterCount() == 1) {
               Class var17 = var16.getParameterTypes()[0];
               if (var17.isAssignableFrom(var8.getClass())) {
                  try {
                     var16.invoke(var2, var8);
                     var44 = true;
                     break;
                  } catch (Throwable var40) {
                  }
               }
            }
         }

         if (!var44) {
            try {
               Class var46 = c("org.bukkit.entity.LivingEntity");
               var2.getClass().getMethod("setTarget", var46).invoke(var2, var8);
            } catch (Throwable var32) {
            }
         }

         try {
            Object var47 = call(var2, "getPathfinder");
            boolean var51 = false;

            for (Method var18 : var47.getClass().getMethods()) {
               if (var18.getName().equals("moveTo") && var18.getParameterCount() == 1 && var18.getParameterTypes()[0].isAssignableFrom(var8.getClass())) {
                  var18.invoke(var47, var8);
                  var51 = true;
                  break;
               }
            }

            if (!var51) {
               Object var55 = call(var8, "getLocation");

               for (Method var19 : var47.getClass().getMethods()) {
                  if (var19.getName().equals("moveTo") && var19.getParameterCount() == 1 && var19.getParameterTypes()[0].isAssignableFrom(var55.getClass())) {
                     var19.invoke(var47, var55);
                     break;
                  }
               }
            }
         } catch (Throwable var39) {
         }

         boolean var48 = true;

         try {
            var48 = bool(methodByName(var3, "getBoolean", 2).invoke(var3, "combat.fallback-melee.enabled", true), true);
         } catch (Throwable var31) {
         }

         double var52 = 2.8;
         long var58 = 1200L;

         try {
            var52 = num(methodByName(var3, "getDouble", 2).invoke(var3, "combat.fallback-melee.range", 2.8), 2.8);
         } catch (Throwable var30) {
         }

         try {
            var58 = lng(methodByName(var3, "getLong", 2).invoke(var3, "combat.fallback-melee.cooldown-milliseconds", 1200L), 1200L);
         } catch (Throwable var29) {
         }

         if (var48 && var9 <= var52 * var52) {
            UUID var62 = (UUID)call(var2, "getUniqueId");
            long var63 = System.currentTimeMillis();
            if (var63 - BOSS_FALLBACK_COOLDOWN.getOrDefault(var62, 0L) >= Math.max(500L, var58)) {
               BOSS_FALLBACK_COOLDOWN.put(var62, var63);
               boolean var21 = false;

               for (Method var25 : var2.getClass().getMethods()) {
                  if (var25.getName().equals("attack") && var25.getParameterCount() == 1 && var25.getParameterTypes()[0].isAssignableFrom(var8.getClass())) {
                     try {
                        var25.invoke(var2, var8);
                        var21 = true;
                        break;
                     } catch (Throwable var38) {
                     }
                  }
               }

               if (!var21) {
                  double var64 = 4.0;

                  try {
                     Object var65 = get(var1, "type");
                     var64 = num(get(var65, "damage"), 4.0);
                  } catch (Throwable var28) {
                  }

                  try {
                     Class var66 = c("org.bukkit.entity.Entity");
                     var8.getClass().getMethod("damage", double.class, var66).invoke(var8, Math.max(0.5, var64), var2);
                  } catch (Throwable var27) {
                  }
               }
            }
         }
      } catch (Throwable var43) {
         warn(var0, "Boss hedefleme hatasi: " + var43.getClass().getSimpleName());
      }
   }

   public static Object buildingSpec(Object var0, int var1, int var2, int var3) {
      try {
         Class<?> var4 = Class.forName("com.zzwproject.hotfix.HotfixHooksV2", true, HotfixHooks.class.getClassLoader());
         return var4.getMethod("buildingSpec", Object.class, int.class, int.class, int.class).invoke(null, var0, var1, var2, var3);
      } catch (Throwable var5) {
         return null;
      }
   }

   public static void disableAutoSpawn(Object var0) {
   }

   public static void registerMapCustomization(Object var0) {
      try {
         mapPlugin = var0;
         File var1 = (File)call(var0, "getDataFolder");
         if (!var1.exists()) {
            var1.mkdirs();
         }

         mapDataFile = new File(var1, "custom-layout.properties");
         loadMapPoints();
         registerCommand(var0, "zjumpad", true);
         registerCommand(var0, "zafkgen", false);
         Object var2 = c("org.bukkit.Bukkit").getMethod("getScheduler").invoke(null);
         Class var3 = c("org.bukkit.plugin.Plugin");
         Method var4 = var2.getClass().getMethod("runTaskTimer", var3, Runnable.class, long.class, long.class);
         var4.invoke(var2, var0, (Runnable) HotfixHooks::tickMap, 1L, 1L);
         log(var0, "Custom jump pad/AFK generator editor aktif. /zjumpad ve /zafkgen");
      } catch (Throwable var5) {
         warn(var0, "Custom map sistemi başlatilamadi: " + var5.getClass().getSimpleName());
      }
   }

   private static void registerCommand(Object var0, String var1, boolean var2) throws Exception {
      Object var3 = var0.getClass().getMethod("getCommand", String.class).invoke(var0, var1);
      if (var3 != null) {
         Class var4 = c("org.bukkit.command.CommandExecutor");
         Class var5 = c("org.bukkit.command.TabCompleter");
         Object var6 = Proxy.newProxyInstance(var0.getClass().getClassLoader(), new Class[]{var4, var5}, (var1x, var2x, var3x) -> {
            if (var2x.getName().equals("onCommand")) {
               return handleMapCommand(var3x[0], (String[])var3x[3], var2);
            } else if (var2x.getName().equals("onTabComplete")) {
               return tabMap((String[])var3x[3]);
            } else {
               return var2x.getName().equals("toString") ? "ZZWMapCustomProxy" : null;
            }
         });
         var3.getClass().getMethod("setExecutor", var4).invoke(var3, var6);
         var3.getClass().getMethod("setTabCompleter", var5).invoke(var3, var6);
      }
   }

   private static List<String> tabMap(String[] var0) {
      return var0.length == 1 ? Arrays.asList("add", "remove", "list", "clear") : Collections.emptyList();
   }

   private static boolean handleMapCommand(Object var0, String[] var1, boolean var2) {
      try {
         Map var3 = var2 ? JUMP_PADS : AFK_GENS;
         if (var1.length == 0) {
            send(var0, "§bZZW §8• §f" + (var2 ? "/zjumpad" : "/zafkgen") + " add <isim> | remove <isim> | list | clear");
            return true;
         }

         String var4 = var1[0].toLowerCase(Locale.ROOT);
         if (var4.equals("list")) {
            send(var0, "§b" + (var2 ? "Jump pad" : "AFK jeneratör") + " Noktaları: §f" + (var3.isEmpty() ? "yok" : String.join(", ", var3.keySet())));
            return true;
         }

         if (var4.equals("clear")) {
            var3.clear();
            saveMapPoints();
            send(var0, "§aTüm noktalar silindi.");
            return true;
         }

         if (var4.equals("remove") && var1.length >= 2) {
            var3.remove(var1[1].toLowerCase(Locale.ROOT));
            saveMapPoints();
            send(var0, "§aNokta silindi: §f" + var1[1]);
            return true;
         }

         if (!var4.equals("add") || var1.length < 2) {
            send(var0, "§cKullanım: " + (var2 ? "/zjumpad" : "/zafkgen") + " add <isim> | remove <isim> | list | clear");
            return true;
         }

         if (!c("org.bukkit.entity.Player").isInstance(var0)) {
            send(var0, "§cBu komut oyunda kullanılmalı.");
            return true;
         }

         Object var5 = targetLocation(var0);
         Object var6 = call(var5, "getWorld");
         String var7 = String.valueOf(call(var6, "getName"));
         int var8 = integer(call(var5, "getBlockX"), 0);
         int var9 = integer(call(var5, "getBlockY"), 0);
         int var10 = integer(call(var5, "getBlockZ"), 0);
         if (!hasTargetBlock(var0)) {
            var9--;
         }

         double var11 = 1.45;
         double var13 = 1.05;

         try {
            Object var15 = call(mapPlugin, "getConfig");
            var11 = num(methodByName(var15, "getDouble", 2).invoke(var15, "spawn-v2.jump-pads.horizontal-power", 1.45), 1.45);
            var13 = num(methodByName(var15, "getDouble", 2).invoke(var15, "spawn-v2.jump-pads.vertical-power", 1.05), 1.05);
         } catch (Throwable var16) {
         }

         var3.put(var1[1].toLowerCase(Locale.ROOT), new HotfixHooks.MapPoint(var7, var8, var9, var10, var11, var13));
         saveMapPoints();
         send(var0, "§a" + (var2 ? "Jump pad" : "AFK jeneratör") + " Kaydedildi: §f" + var1[1] + " §8(" + var8 + ", " + var9 + ", " + var10 + ")");
         return true;
      } catch (Throwable var17) {
         send(var0, "§cİşlem başarısız: " + var17.getClass().getSimpleName());
         return true;
      }
   }

   private static boolean hasTargetBlock(Object var0) {
      try {
         return methodByName(var0, "getTargetBlockExact", 1).invoke(var0, 6) != null;
      } catch (Throwable var2) {
         return false;
      }
   }

   private static Object targetLocation(Object var0) throws Exception {
      try {
         Object var1 = methodByName(var0, "getTargetBlockExact", 1).invoke(var0, 6);
         if (var1 != null) {
            return call(var1, "getLocation");
         }
      } catch (Throwable var2) {
      }

      return call(var0, "getLocation");
   }

   private static void send(Object var0, String var1) {
      try {
         methodByName(var0, "sendMessage", 1).invoke(var0, var1);
      } catch (Throwable var3) {
      }
   }

   private static void tickMap() {
      mapTicks++;

      try {
         Object var0 = c("org.bukkit.Bukkit").getMethod("getOnlinePlayers").invoke(null);
         if (var0 instanceof Iterable) {
            for (Object var2 : (Iterable)var0) {
               tickJump(var2);
            }
         }

         if (mapTicks % 20L == 0L) {
            tickAfk();
         }
      } catch (Throwable var3) {
      }
   }

   private static void tickJump(Object var0) {
      try {
         Object var1 = call(var0, "getLocation");
         Object var2 = call(var1, "getWorld");
         String var3 = String.valueOf(call(var2, "getName"));
         int var4 = integer(call(var1, "getBlockX"), 0);
         int var5 = integer(call(var1, "getBlockY"), 0) - 1;
         int var6 = integer(call(var1, "getBlockZ"), 0);
         HotfixHooks.MapPoint var7 = null;

         for (HotfixHooks.MapPoint var9 : JUMP_PADS.values()) {
            if (var9.world.equals(var3) && var9.x == var4 && var9.y == var5 && var9.z == var6) {
               var7 = var9;
               break;
            }
         }

         if (var7 == null) {
            return;
         }

         UUID var21 = (UUID)call(var0, "getUniqueId");
         long var22 = System.currentTimeMillis();
         if (var22 - JUMP_COOLDOWN.getOrDefault(var21, 0L) < 700L) {
            return;
         }

         JUMP_COOLDOWN.put(var21, var22);
         float var11 = ((Number)call(var1, "getYaw")).floatValue();
         double var12 = Math.toRadians(var11);
         double var14 = -Math.sin(var12) * var7.h;
         double var16 = Math.cos(var12) * var7.h;
         Class var18 = c("org.bukkit.util.Vector");
         Object var19 = var18.getConstructor(double.class, double.class, double.class).newInstance(var14, var7.v, var16);
         var0.getClass().getMethod("setVelocity", var18).invoke(var0, var19);
      } catch (Throwable var20) {
      }
   }

   private static void tickAfk() {
      try {
         Object var0 = call(mapPlugin, "getConfig");
         int var1 = 5;
         int var2 = 1800;
         double var3 = 14.0;

         try {
            var1 = integer(methodByName(var0, "getInt", 2).invoke(var0, "spawn-v2.afk-generators.money-interval-seconds", 5), 5);
         } catch (Throwable var14) {
         }

         try {
            var2 = integer(methodByName(var0, "getInt", 2).invoke(var0, "spawn-v2.afk-generators.shard-interval-seconds", 1800), 1800);
         } catch (Throwable var13) {
         }

         try {
            var3 = num(methodByName(var0, "getDouble", 2).invoke(var0, "spawn-v2.afk-generators.active-radius", 14.0), 14.0);
         } catch (Throwable var12) {
         }

         long var5 = mapTicks / 20L;
         Object var7 = spawnService();
         if (var7 == null) {
            return;
         }

         for (HotfixHooks.MapPoint var9 : AFK_GENS.values()) {
            Object var10 = c("org.bukkit.Bukkit").getMethod("getWorld", String.class).invoke(null, var9.world);
            if (var10 != null) {
               Object var11 = locationAt(var10, var9.x, var9.y, var9.z);
               if (playerNear(var11, var3)) {
                  if (var1 > 0 && var5 % var1 == 0L) {
                     invokePrivate2(var7, "spawnMoney", var10, var11);
                  }

                  if (var2 > 0 && var5 % var2 == 0L) {
                     invokePrivate2(var7, "spawnShard", var10, var11);
                  }
               }
            }
         }
      } catch (Throwable var15) {
      }
   }

   private static Object spawnService() {
      try {
         Class var0 = Class.forName("com.zzwproject.zgenmap.v2.SpawnV2Bootstrap", true, mapPlugin.getClass().getClassLoader());
         Field var1 = var0.getDeclaredField("service");
         var1.setAccessible(true);
         return var1.get(null);
      } catch (Throwable var2) {
         return null;
      }
   }

   private static void invokePrivate2(Object var0, String var1, Object var2, Object var3) throws Exception {
      for (Method var7 : var0.getClass().getDeclaredMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == 2) {
            var7.setAccessible(true);
            var7.invoke(var0, var2, var3);
            return;
         }
      }
   }

   private static Object locationAt(Object var0, int var1, int var2, int var3) throws Exception {
      Object var4 = methodByName(var0, "getBlockAt", 3).invoke(var0, var1, var2, var3);
      Object var5 = call(var4, "getLocation");

      try {
         methodByName(var5, "add", 3).invoke(var5, 0.5, 1.15, 0.5);
      } catch (Throwable var7) {
      }

      return var5;
   }

   private static boolean playerNear(Object var0, double var1) {
      try {
         Object var3 = call(var0, "getWorld");
         Object var4 = call(var3, "getPlayers");
         if (var4 instanceof Iterable) {
            for (Object var6 : (Iterable)var4) {
               Object var7 = call(var6, "getLocation");
               double var8 = num(methodByName(var0, "distanceSquared", 1).invoke(var0, var7), Double.MAX_VALUE);
               if (var8 <= var1 * var1) {
                  return true;
               }
            }
         }
      } catch (Throwable var10) {
      }

      return false;
   }

   private static void loadMapPoints() {
      JUMP_PADS.clear();
      AFK_GENS.clear();
      if (mapDataFile != null && mapDataFile.isFile()) {
         Properties var0 = new Properties();

         try (FileInputStream var1 = new FileInputStream(mapDataFile)) {
            var0.load(var1);
         } catch (IOException var7) {
            return;
         }

         for (String var2 : var0.stringPropertyNames()) {
            try {
               HotfixHooks.MapPoint var3 = HotfixHooks.MapPoint.parse(var0.getProperty(var2));
               if (var2.startsWith("jump.")) {
                  JUMP_PADS.put(var2.substring(5), var3);
               } else if (var2.startsWith("gen.")) {
                  AFK_GENS.put(var2.substring(4), var3);
               }
            } catch (Throwable var5) {
            }
         }
      }
   }

   private static void saveMapPoints() {
      if (mapDataFile != null) {
         Properties var0 = new Properties();

         for (Entry var2 : JUMP_PADS.entrySet()) {
            var0.setProperty("jump." + (String)var2.getKey(), ((HotfixHooks.MapPoint)var2.getValue()).encode());
         }

         for (Entry var9 : AFK_GENS.entrySet()) {
            var0.setProperty("gen." + (String)var9.getKey(), ((HotfixHooks.MapPoint)var9.getValue()).encode());
         }

         try (FileOutputStream var8 = new FileOutputStream(mapDataFile)) {
            var0.store(var8, "ZZW Project ZGenMap custom layout - Update 31");
         } catch (IOException var6) {
         }
      }
   }

   private static final class MapPoint {
      final String world;
      final int x;
      final int y;
      final int z;
      final double h;
      final double v;

      MapPoint(String var1, int var2, int var3, int var4, double var5, double var7) {
         this.world = var1;
         this.x = var2;
         this.y = var3;
         this.z = var4;
         this.h = var5;
         this.v = var7;
      }

      String encode() {
         return this.world + "," + this.x + "," + this.y + "," + this.z + "," + this.h + "," + this.v;
      }

      static HotfixHooks.MapPoint parse(String var0) {
         String[] var1 = var0.split(",");
         return new HotfixHooks.MapPoint(
            var1[0],
            Integer.parseInt(var1[1]),
            Integer.parseInt(var1[2]),
            Integer.parseInt(var1[3]),
            var1.length > 4 ? Double.parseDouble(var1[4]) : 1.45,
            var1.length > 5 ? Double.parseDouble(var1[5]) : 1.05
         );
      }
   }
}
