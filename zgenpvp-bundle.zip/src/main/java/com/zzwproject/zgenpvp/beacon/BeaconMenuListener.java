package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BeaconData;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

public final class BeaconMenuListener implements Listener {
   private final ZGenPvP plugin;
   private final BeaconManager beaconManager;
   private final BeaconMenu beaconMenu;
   private final Map<UUID, BeaconMenuListener.RenameTarget> renameWaiting = new ConcurrentHashMap<>();

   public BeaconMenuListener(ZGenPvP var1, BeaconManager var2, BeaconMenu var3) {
      this.plugin = var1;
      this.beaconManager = var2;
      this.beaconMenu = var3;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInventoryClick(InventoryClickEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      boolean var3 = this.beaconMenu.isMainMenu(var2);
      boolean var4 = this.beaconMenu.isConfirmationMenu(var2);
      if (var3 || var4) {
         var1.setCancelled(true);
         if (var1.getWhoClicked() instanceof Player var5) {
            int var12 = var1.getRawSlot();
            if (var12 >= 0 && var12 < var2.getSize()) {
               String var7 = this.beaconMenu.getAction(var1.getCurrentItem());
               if (var7 != null) {
                  Optional var8 = this.beaconMenu.getBeacon(var2);
                  if (var8.isEmpty()) {
                     var5.closeInventory();
                     this.plugin.getMessageUtil().send(var5, "beacon.not-found");
                  } else {
                     BeaconData var9 = (BeaconData)var8.get();
                     switch (var7) {
                        case "TELEPORT":
                           if (!this.beaconManager.canUseBeacon(var5, var9)) {
                              var5.closeInventory();
                              this.beaconManager.sendOwnerInfo(var5, var9);
                              return;
                           }

                           var5.closeInventory();
                           this.beaconManager.startRespawn(var5, var9);
                           break;
                        case "RENAME":
                           if (!this.beaconManager.isOwner(var5, var9)) {
                              var5.closeInventory();
                              this.beaconManager.sendOwnerInfo(var5, var9);
                              return;
                           }

                           var5.closeInventory();
                           this.renameWaiting.put(var5.getUniqueId(), new BeaconMenuListener.RenameTarget(var9.getId(), var9.getOwnerUuid()));
                           this.plugin.getMessageUtil().send(var5, "beacon.rename-enter");
                           this.plugin.getSoundUtil().play(var5, "button");
                           break;
                        case "REMOVE":
                           if (!this.beaconManager.isOwner(var5, var9)) {
                              var5.closeInventory();
                              this.beaconManager.sendOwnerInfo(var5, var9);
                              return;
                           }

                           if (!this.requireRemovalDistance(var5, var9)) {
                              var5.closeInventory();
                              return;
                           }

                           this.beaconMenu.openConfirmation(var5, var9);
                           this.plugin.getSoundUtil().play(var5, "button");
                           break;
                        case "CONFIRM_YES":
                           if (!this.beaconManager.isOwner(var5, var9)) {
                              var5.closeInventory();
                              this.beaconManager.sendOwnerInfo(var5, var9);
                              return;
                           }

                           if (!this.requireRemovalDistance(var5, var9)) {
                              var5.closeInventory();
                              return;
                           }

                           var5.closeInventory();
                           this.beaconManager.removeBeacon(var5, var9);
                           break;
                        case "CONFIRM_NO":
                           this.beaconMenu.open(var5, var9);
                           this.plugin.getSoundUtil().play(var5, "button");
                     }
                  }
               }
            }
         }
      }
   }

   private boolean requireRemovalDistance(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         Location var3 = var2.getLocation();
         double var4 = this.plugin.getConfigManager().getConfig().getDouble("beacon.remove.max-distance", 6.0);
         var4 = Math.max(1.0, var4);
         boolean var6 = var3 != null
            && var3.getWorld() != null
            && var1.getWorld() == var3.getWorld()
            && var1.getLocation().distanceSquared(var3.clone().add(0.5, 0.5, 0.5)) <= var4 * var4;
         if (var6) {
            return true;
         }

         String var7 = var4 == Math.rint(var4) ? String.valueOf((int)var4) : String.valueOf(var4);
         this.plugin.getMessageUtil().send(var1, "beacon.remove-too-far", "%distance%", var7);
         this.plugin.getSoundUtil().play(var1, "error");
         return false;
      } else {
         return false;
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onChat(AsyncPlayerChatEvent var1) {
      Player var2 = var1.getPlayer();
      UUID var3 = var2.getUniqueId();
      BeaconMenuListener.RenameTarget var4 = this.renameWaiting.remove(var3);
      if (var4 != null) {
         var1.setCancelled(true);
         String var5 = var1.getMessage().trim();
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (var2.isOnline()) {
               if (var5.equalsIgnoreCase("iptal")) {
                  this.plugin.getMessageUtil().send(var2, "beacon.rename-cancelled");
               } else {
                  Optional var4x = this.beaconManager.getBeacon(var4.ownerUuid());
                  if (var4x.isEmpty()) {
                     this.plugin.getMessageUtil().send(var2, "beacon.not-found");
                  } else {
                     BeaconData var5x = (BeaconData)var4x.get();
                     if (var5x.getId() != var4.beaconId()) {
                        this.plugin.getMessageUtil().send(var2, "beacon.not-found");
                     } else if (!this.beaconManager.isOwner(var2, var5x)) {
                        this.beaconManager.sendOwnerInfo(var2, var5x);
                     } else {
                        this.beaconManager.renameBeacon(var2, var5x, var5);
                     }
                  }
               }
            }
         });
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      this.renameWaiting.remove(var1.getPlayer().getUniqueId());
   }

   private record RenameTarget(long beaconId, UUID ownerUuid) {
   }
}
