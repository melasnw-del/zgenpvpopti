package com.zzwproject.zraid.hotfix;

import java.util.Locale;
import java.util.UUID;

public final class RaidAnnounceFix {
   private RaidAnnounceFix() {
   }

   public static void send(Object var0, Object var1, String var2) {
      try {
         ClassLoader var3 = var0.getClass().getClassLoader();
         Class var4 = Class.forName("org.bukkit.Bukkit", true, var3);
         if (!(R.callStatic(var4, "getOnlinePlayers") instanceof Iterable var6)) {
            return;
         }

         Object var7 = R.field(var1, "snapshot");
         UUID var8 = (UUID)R.field(var7, "owner");
         UUID var9 = (UUID)R.field(var1, "initiator");
         String var10 = String.valueOf(R.call(var0, "nameOf", var8));
         String var11 = String.valueOf(R.call(var0, "nameOf", var9));
         boolean var12 = isStartMessage(var2);

         for (Object var14 : var6) {
            UUID var15 = (UUID)R.call(var14, "getUniqueId");
            boolean var16 = Boolean.TRUE.equals(R.call(var0, "isRaider", var1, var15));
            boolean var17 = Boolean.TRUE.equals(R.call(var0, "isDefender", var8, var15));
            if (var16 || var17) {
               String var18 = var2;
               if (var12) {
                  var18 = var16
                     ? "&c⚔ Raid başladı &8• &7Hedef: &f" + var10 + " &8• &7Fener kilitli"
                     : "&c⚠ Üssüne raid başladı &8• &7Saldıran: &f" + var11 + " &8• &7Fener kilitli";
               }

               String var19 = String.valueOf(R.call(var0, "color", var18));
               R.call(var14, "sendMessage", var19);
            }
         }
      } catch (Throwable var20) {
      }
   }

   private static boolean isStartMessage(String var0) {
      if (var0 == null) {
         return false;
      }

      String var1 = var0.toLowerCase(Locale.ROOT);
      return var1.contains("raid") && (var1.contains("süre") || var1.contains("sure")) && (var1.contains("baş") || var1.contains("ba?"));
   }
}
