package com.zzwproject.zgenpvp.generator;

import com.zzwproject.zgenpvp.ZGenPvP;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

public final class GeneratorTask {
   private final ZGenPvP plugin;
   private final GeneratorManager generatorManager;
   private BukkitTask task;

   public GeneratorTask(ZGenPvP var1, GeneratorManager var2) {
      this.plugin = var1;
      this.generatorManager = var2;
   }

   public void start() {
      this.stop();
      BukkitScheduler var1 = this.plugin.getServer().getScheduler();
      this.task = var1.runTaskTimer(this.plugin, () -> {
         this.generatorManager.tickGeneration();
         this.generatorManager.tickHopperTransfers();
      }, 20L, 1L);
   }

   public void stop() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }
   }
}
