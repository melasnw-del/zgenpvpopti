package com.zzwproject.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public final class MoneyItemsAdderHook {
   private MoneyItemsAdderHook() {
   }

   public static Object createMoney(Object var0, double var1) {
      var1 = Math.max(0.01, var1);

      try {
         ClassLoader var3 = var0.getClass().getClassLoader();
         Object var4 = null;
         boolean var5 = false;

         try {
            Object var6 = field(var0, "plugin");
            Object var7 = invoke(var6, "getServer");
            Object var8 = invoke(var7, "getPluginManager");
            Object var9 = invoke(var8, "getPlugin", new Class[]{String.class}, new Object[]{"ItemsAdder"});
            if (var9 != null && Boolean.TRUE.equals(invoke(var9, "isEnabled"))) {
               String var10 = "zzw_money:banknote";

               try {
                  Object var11 = invoke(var6, "getConfigManager");
                  Object var12 = invoke(var11, "getItems");
                  Object var13 = invoke(var12, "getString", new Class[]{String.class, String.class}, new Object[]{"money.itemsadder-id", var10});
                  if (var13 instanceof String && !((String)var13).isBlank()) {
                     var10 = (String)var13;
                  }
               } catch (Throwable var24) {
               }

               ClassLoader var36 = var9.getClass().getClassLoader();
               Class var38 = Class.forName("dev.lone.itemsadder.api.CustomStack", true, var36);
               Method var42 = var38.getMethod("getInstance", String.class);
               Object var14 = var42.invoke(null, var10);
               if (var14 != null) {
                  var4 = var38.getMethod("getItemStack").invoke(var14);
                  var5 = var4 != null;
               }
            }
         } catch (Throwable var25) {
         }

         if (var4 == null) {
            Object var28 = field(var0, "material");
            Class var30 = Class.forName("org.bukkit.inventory.ItemStack", true, var3);
            Class var32 = Class.forName("org.bukkit.Material", true, var3);
            var4 = var30.getConstructor(var32).newInstance(var28);
         }

         Object var29 = invoke(var4, "getItemMeta");
         if (var29 == null) {
            return var4;
         }

         String var31 = new DecimalFormat("#,##0.##").format(var1);
         String var33 = String.valueOf(field(var0, "nameTemplate"));
         String var34 = color(var3, var33.replace("%amount%", var31));
         invoke(var29, "setDisplayName", new Class[]{String.class}, new Object[]{var34});
         List<String> var35 = (List<String>)field(var0, "loreTemplates");
         ArrayList var37 = new ArrayList();
         if (var35 != null) {
            for (String var43 : var35) {
               var37.add(color(var3, var43.replace("%amount%", var31)));
            }
         }

         invoke(var29, "setLore", new Class[]{List.class}, new Object[]{var37});
         if (!var5) {
            int var40 = ((Number)field(var0, "customModelData")).intValue();
            if (var40 > 0) {
               try {
                  invoke(var29, "setCustomModelData", new Class[]{Integer.class}, new Object[]{var40});
               } catch (Throwable var23) {
               }
            }
         }

         Object var41 = invoke(var29, "getPersistentDataContainer");
         Class var44 = Class.forName("org.bukkit.NamespacedKey", true, var3);
         Class var45 = Class.forName("org.bukkit.persistence.PersistentDataType", true, var3);
         Class var15 = Class.forName("org.bukkit.persistence.PersistentDataContainer", true, var3);
         Object var16 = var45.getField("BYTE").get(null);
         Object var17 = var45.getField("DOUBLE").get(null);
         Method var18 = var15.getMethod("set", var44, var45, Object.class);
         var18.invoke(var41, field(var0, "moneyItemKey"), var16, (byte)1);
         var18.invoke(var41, field(var0, "moneyValueKey"), var17, var1);

         for (Method var22 : var4.getClass().getMethods()) {
            if (var22.getName().equals("setItemMeta") && var22.getParameterCount() == 1) {
               var22.invoke(var4, var29);
               break;
            }
         }

         return var4;
      } catch (Throwable var26) {
         throw new RuntimeException("ZZW money item creation failed", var26);
      }
   }

   private static String color(ClassLoader var0, String var1) {
      try {
         Class var2 = Class.forName("com.zzwproject.zgenpvp.util.ColorUtil", true, var0);
         return String.valueOf(var2.getMethod("color", String.class).invoke(null, var1));
      } catch (Throwable var3) {
         return var1;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static Object invoke(Object var0, String var1) throws Exception {
      return MoneyItemsAdderHookFix.invokeNoArgs(var0, var1);
   }

   private static Object invoke(Object var0, String var1, Class<?>[] var2, Object[] var3) throws Exception {
      return MoneyItemsAdderHookFix.invokeArgs(var0, var1, var2, var3);
   }
}
