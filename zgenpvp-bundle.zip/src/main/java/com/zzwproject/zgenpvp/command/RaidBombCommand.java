package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.raid.RaidBombManager;
import com.zzwproject.zgenpvp.raid.RaidBombType;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class RaidBombCommand implements CommandExecutor, TabCompleter {
   private final ZGenPvP plugin;
   private final RaidBombManager raidBombManager;

   public RaidBombCommand(ZGenPvP var1, RaidBombManager var2) {
      this.plugin = var1;
      this.raidBombManager = var2;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("zgenpvp.raidbomb.admin")) {
         this.raidBombManager.sendMessage(var1, "messages.no-permission");
         return true;
      }

      if (var4.length == 0) {
         this.raidBombManager.sendHelp(var1);
         return true;
      }

      if (var4[0].equalsIgnoreCase("reload")) {
         this.plugin.getConfigManager().reload();
         this.raidBombManager.sendMessage(var1, "messages.reload");
         return true;
      }

      if (!var4[0].equalsIgnoreCase("give")) {
         this.raidBombManager.sendHelp(var1);
         return true;
      }

      if (var4.length < 3) {
         this.raidBombManager.sendHelp(var1);
         return true;
      }

      Player var5 = Bukkit.getPlayerExact(var4[1]);
      if (var5 == null) {
         this.raidBombManager.sendMessage(var1, "messages.player-not-found");
         return true;
      }

      int var6;
      try {
         var6 = Integer.parseInt(var4[2]);
      } catch (NumberFormatException var11) {
         this.raidBombManager.sendMessage(var1, "messages.invalid-tier");
         return true;
      }

      Optional var7 = RaidBombType.fromId(var6);
      if (var7.isEmpty()) {
         this.raidBombManager.sendMessage(var1, "messages.invalid-tier");
         return true;
      }

      int var8 = 1;
      if (var4.length >= 4) {
         try {
            var8 = Integer.parseInt(var4[3]);
         } catch (NumberFormatException var10) {
            this.raidBombManager.sendMessage(var1, "messages.invalid-amount");
            return true;
         }
      }

      if (var8 >= 1 && var8 <= 64) {
         if (!this.raidBombManager.giveBomb(var5, (RaidBombType)var7.get(), var8)) {
            return true;
         }

         this.raidBombManager
            .sendMessage(
               var1,
               "messages.admin-given",
               "%player%",
               var5.getName(),
               "%amount%",
               String.valueOf(var8),
               "%tier%",
               ((RaidBombType)var7.get()).getDisplayName()
            );
         return true;
      } else {
         this.raidBombManager.sendMessage(var1, "messages.invalid-amount");
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("zgenpvp.raidbomb.admin")) {
         return List.of();
      }

      if (var4.length == 1) {
         return this.filter(var4[0], List.of("give", "reload"));
      }

      if (var4.length == 2 && var4[0].equalsIgnoreCase("give")) {
         ArrayList var5 = new ArrayList();

         for (Player var7 : Bukkit.getOnlinePlayers()) {
            var5.add(var7.getName());
         }

         return this.filter(var4[1], var5);
      } else if (var4.length == 3 && var4[0].equalsIgnoreCase("give")) {
         return this.filter(var4[2], List.of("1", "2", "3"));
      } else {
         return var4.length == 4 && var4[0].equalsIgnoreCase("give") ? this.filter(var4[3], List.of("1", "8", "16", "32", "64")) : List.of();
      }
   }

   private List<String> filter(String var1, List<String> var2) {
      String var3 = var1 == null ? "" : var1.toLowerCase(Locale.ROOT);
      return var2.stream().filter(var1x -> var1x.toLowerCase(Locale.ROOT).startsWith(var3)).toList();
   }
}
