package com.zzwproject.zoverclock;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.hotfix.OverclockEconomyFix;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

public final class ZOverclock extends LegacyPluginBase implements Listener {
   private Plugin zGenPvP;
   private final Map<Long, ZOverclock.State> states = new HashMap<>();
   private final Map<UUID, Long> ownerCooldown = new HashMap<>();
   private final Map<UUID, ZOverclock.Confirmation> confirmations = new HashMap<>();
   private File dataFile;
   private long tickCounter;

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      this.zGenPvP = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenPvP");
      if (this.zGenPvP != null && this.zGenPvP.isEnabled()) {
         this.dataFile = new File(this.getDataFolder(), "data.properties");
         this.loadData();
         Bukkit.getPluginManager().registerEvents(this, this);
         long var1 = Math.max(10L, this.getConfig().getLong("system.tick-interval-ticks", 20L));
         Bukkit.getScheduler().runTaskTimer(this, this::tickStates, 40L, var1);
         Bukkit.getScheduler().runTaskTimer(this, this::refreshOpenMenus, 60L, 40L);
         this.getLogger().info("ZOverclock 1.0.2 aktif. Paper 1.21.11 inventory event uyumluluğu hazır.");
      } else {
         this.getLogger().severe("ZGenPvP bulunamadı. ZOverclock devre dışı.");
      }
   }

   @Override
   public void onDisable() {
      this.saveData();
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var2.getName().equalsIgnoreCase("zoverclock")) {
         return false;
      } else if (!var1.hasPermission("zoverclock.admin")) {
         var1.sendMessage(this.color("&cBu komut için yetkin yok."));
         return true;
      } else if (var4.length == 0 || var4[0].equalsIgnoreCase("status")) {
         long var5 = System.currentTimeMillis();
         long var7 = this.states.values().stream().filter(var2x -> var2x.activeUntil > var5).count();
         long var9 = this.states.values().stream().filter(var2x -> var2x.brokenUntil > var5).count();
         var1.sendMessage(this.color("&8[&cZOverclock&8] &fAktif: &c" + var7 + " &8| &farızalı: &e" + var9 + " &8| &fkayıt: &7" + this.states.size()));
         return true;
      } else if (var4[0].equalsIgnoreCase("reload")) {
         this.reloadConfig();
         var1.sendMessage(this.color("&8[&cZOverclock&8] &aAyarlar yeniden yüklendi."));
         return true;
      } else {
         var1.sendMessage(this.color("&7Kullanım: &f/zoverclock status &8| &f/zoverclock reload"));
         return true;
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onOpen(InventoryOpenEvent var1) {
      if (var1.getPlayer() instanceof Player var2) {
         Inventory var5 = var1.getInventory();
         Object var4 = this.getGeneratorFromMenu(var5);
         if (var4 != null) {
            Bukkit.getScheduler().runTask(this, () -> this.injectButton(var2, var5, var4));
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player var2) {
         Inventory var14 = var1.getInventory();
         ZOverclock.Confirmation var4 = this.confirmations.get(var2.getUniqueId());
         if (var4 != null && this.isConfirmationView(var1)) {
            var1.setCancelled(true);
            if (System.currentTimeMillis() > var4.expiresAt) {
               this.confirmations.remove(var2.getUniqueId());
               var2.closeInventory();
               this.msg(var2, "messages.confirm-expired", "&cOverclock onayının süresi doldu.");
            } else {
               if (var1.getRawSlot() == 11) {
                  this.confirmations.remove(var2.getUniqueId());
                  var2.closeInventory();
                  this.activate(var2, var4.generatorId, var4.ownerUuid);
               } else if (var1.getRawSlot() == 15) {
                  this.confirmations.remove(var2.getUniqueId());
                  var2.closeInventory();
                  this.playSound(var2.getLocation(), "minecraft:block.note_block.hat", 0.45F, 0.8F);
               }
            }
         } else {
            Object var5 = this.getGeneratorFromMenu(var14);
            if (var5 != null) {
               long var6 = this.longCall(var5, "getId", -1L);
               UUID var8 = (UUID)this.call(var5, "getOwnerUuid");
               if (var6 > 0L && var8 != null) {
                  ZOverclock.State var9 = this.states.computeIfAbsent(var6, var3 -> new ZOverclock.State(var6, var8));
                  long var10 = System.currentTimeMillis();
                  if ((var9.activeUntil > var10 || var9.brokenUntil > var10) && var1.getRawSlot() == 16) {
                     var1.setCancelled(true);
                     this.msg(var2, "messages.upgrade-locked", "&cOverclock durumunda jeneratör yükseltilemez.");
                     this.playError(var2);
                  } else if (var1.getRawSlot() == this.getConfig().getInt("menu.slot", 22)) {
                     var1.setCancelled(true);
                     if (!var2.hasPermission("zoverclock.use")) {
                        this.msg(var2, "messages.no-permission", "&cOverclock kullanma yetkin yok.");
                        this.playError(var2);
                     } else if (!this.canManage(var2, var8)) {
                        this.msg(var2, "messages.not-owner", "&cBu jeneratörün overclock ayarını değiştiremezsin.");
                        this.playError(var2);
                     } else if (var9.brokenUntil <= var10) {
                        if (var9.activeUntil > var10) {
                           this.msg(
                              var2,
                              "messages.already-active",
                              "&eOverclock zaten aktif. &7Kalan: &f%time%",
                              "%time%",
                              this.formatTime(var9.activeUntil - var10)
                           );
                        } else if (var9.cooldownUntil > var10) {
                           this.msg(
                              var2, "messages.cooldown", "&cJeneratör hâlâ soğuyor. &7Kalan: &f%time%", "%time%", this.formatTime(var9.cooldownUntil - var10)
                           );
                           this.playError(var2);
                        } else {
                           int var12 = this.intCall(var5, "getLevel", 1);
                           int var13 = Math.max(1, this.getConfig().getInt("balance.minimum-generator-level", 10));
                           if (var12 < var13) {
                              this.msg(var2, "messages.low-level", "&cOverclock için en az seviye &f%level% &cGerekli.", "%level%", String.valueOf(var13));
                              this.playError(var2);
                           } else {
                              this.openConfirmation(var2, var5);
                           }
                        }
                     } else {
                        if (var1.isShiftClick() && this.getConfig().getBoolean("repair.emergency-repair-enabled", true)) {
                           this.emergencyRepair(var2, var5, var9);
                        } else {
                           this.msg(var2, "messages.broken", "&cJeneratör arızalı. &7Kalan: &f%time%", "%time%", this.formatTime(var9.brokenUntil - var10));
                           this.playError(var2);
                        }

                        this.injectButton(var2, var14, var5);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onBreak(BlockBreakEvent var1) {
      Object var2 = this.getGeneratorAt(var1.getBlock().getLocation());
      if (var2 != null) {
         long var3 = this.longCall(var2, "getId", -1L);
         ZOverclock.State var5 = this.states.get(var3);
         if (var5 != null) {
            long var6 = System.currentTimeMillis();
            if (var5.activeUntil > var6 || var5.brokenUntil > var6) {
               var1.setCancelled(true);
               this.msg(var1.getPlayer(), "messages.break-locked", "&cAktif/arızalı overclock jeneratörü kırılamaz.");
               this.playError(var1.getPlayer());
            }
         }
      }
   }

   private void openConfirmation(Player var1, Object var2) {
      long var3 = this.longCall(var2, "getId", -1L);
      UUID var5 = (UUID)this.call(var2, "getOwnerUuid");
      int var6 = this.intCall(var2, "getLevel", 1);
      if (var3 > 0L && var5 != null) {
         double var7 = this.activationMoneyCost(var6);
         long var9 = Math.max(0L, this.getConfig().getLong("balance.activation-shard-cost", 2L));
         int var11 = Math.max(60, this.getConfig().getInt("overclock.duration-seconds", 600));
         double var12 = Math.max(1.0, this.getConfig().getDouble("overclock.speed-multiplier", 3.0));
         String var14 = this.color(this.getConfig().getString("menu.confirm-title", "&8ᴏᴠᴇʀᴄʟᴏᴄᴋ &8• &fᴏɴᴀʏ"));
         Inventory var15 = Bukkit.createInventory(null, 27, var14);
         this.fill(var15);
         var15.setItem(
            11,
            this.item(
               "LIME_DYE",
               "&aOverclock'i başlat",
               "",
               "&7Hız: &c×" + this.trim(var12),
               "&7Süre: &f" + this.formatTime(var11 * 1000L),
               "&7Para maliyeti: &e$" + this.money(var7),
               "&7Kristal: &b" + var9,
               "",
               "&cRisk: &fSüre sonunda arıza oluşabilir.",
               "",
               "&a› Onaylamak için tıkla"
            )
         );
         var15.setItem(15, this.item("RED_DYE", "&cİptal", "", "&7Jeneratörünü normal çalışmada bırak."));
         this.confirmations.put(var1.getUniqueId(), new ZOverclock.Confirmation(var3, var5, System.currentTimeMillis() + 30000L));
         var1.openInventory(var15);
         this.playSound(var1.getLocation(), "minecraft:block.beacon.power_select", 0.65F, 1.25F);
      }
   }

   private void activate(Player var1, long var2, UUID var4) {
      Object var5 = this.getGenerator(var2, var4);
      if (var5 == null) {
         this.msg(var1, "messages.not-found", "&cJeneratör bulunamadı.");
      } else {
         long var6 = System.currentTimeMillis();
         ZOverclock.State var8 = this.states.computeIfAbsent(var2, var3 -> new ZOverclock.State(var2, var4));
         if (var8.activeUntil > var6 || var8.brokenUntil > var6 || var8.cooldownUntil > var6) {
            this.msg(var1, "messages.state-changed", "&cJeneratör durumu değişti. Menüyü yenile.");
         } else if (this.canManage(var1, var4)) {
            int var9 = Math.max(1, this.getConfig().getInt("balance.max-active-per-owner", 1));
            long var10 = this.states.values().stream().filter(var3 -> var4.equals(var3.ownerUuid) && var3.activeUntil > var6).count();
            if (var10 >= var9) {
               this.msg(
                  var1, "messages.owner-active-limit", "&cAynı anda en fazla &f%limit% &cjeneratörü overclock yapabilirsin.", "%limit%", String.valueOf(var9)
               );
               this.playError(var1);
            } else {
               long var12 = this.ownerCooldown.getOrDefault(var4, 0L);
               if (var12 > var6) {
                  this.msg(var1, "messages.owner-cooldown", "&cYeni bir overclock için &f%time% &cbekle.", "%time%", this.formatTime(var12 - var6));
                  this.playError(var1);
               } else {
                  int var14 = this.intCall(var5, "getLevel", 1);
                  double var15 = this.activationMoneyCost(var14);
                  long var17 = Math.max(0L, this.getConfig().getLong("balance.activation-shard-cost", 2L));
                  if (!this.withdrawMoney(var1, var15)) {
                     this.msg(var1, "messages.no-money", "&cYeterli paran yok. &7Gerekli: &f$%money%", "%money%", this.money(var15));
                     this.playError(var1);
                  } else if (var17 > 0L && !this.removeShards(var4, var17)) {
                     this.depositMoney(var1, var15);
                     this.msg(var1, "messages.no-shard", "&cYeterli kristalin yok. &7Gerekli: &f%shard%", "%shard%", String.valueOf(var17));
                     this.playError(var1);
                  } else {
                     int var19 = Math.max(60, this.getConfig().getInt("overclock.duration-seconds", 600));
                     var8.ownerUuid = var4;
                     var8.activeUntil = var6 + var19 * 1000L;
                     var8.pendingOutcome = true;
                     var8.brokenUntil = 0L;
                     int var20 = Math.max(0, this.getConfig().getInt("balance.owner-global-cooldown-seconds", 1200));
                     this.ownerCooldown.put(var4, var6 + var20 * 1000L);
                     this.saveData();
                     this.msg(
                        var1,
                        "messages.activated",
                        "&c⚡ Overclock aktif! &7%time% boyunca &f×%multiplier% &7hız.",
                        "%time%",
                        this.formatTime(var19 * 1000L),
                        "%multiplier%",
                        this.trim(this.getConfig().getDouble("overclock.speed-multiplier", 3.0))
                     );
                     this.playActivationEffect(this.location(var5));
                  }
               }
            }
         }
      }
   }

   private void emergencyRepair(Player var1, Object var2, ZOverclock.State var3) {
      int var4 = this.intCall(var2, "getLevel", 1);
      double var5 = Math.max(
         this.getConfig().getDouble("repair.minimum-money-cost", 750.0), var4 * this.getConfig().getDouble("repair.money-cost-per-level", 120.0)
      );
      if (!this.withdrawMoney(var1, var5)) {
         this.msg(var1, "messages.repair-no-money", "&cAcil tamir için &f$%money% &cGerekli.", "%money%", this.money(var5));
         this.playError(var1);
      } else {
         var3.brokenUntil = 0L;
         this.saveData();
         this.msg(var1, "messages.repaired", "&aJeneratör acil tamir ile yeniden çalıştı.");
         Location var7 = this.location(var2);
         this.playSound(var7, "minecraft:block.anvil.use", 0.8F, 1.35F);
         this.particle(var7, "HAPPY_VILLAGER", 20, 0.45, 0.55, 0.45, 0.05);
      }
   }

   private void tickStates() {
      if (this.getConfig().getBoolean("system.enabled", true)) {
         this.tickCounter++;
         long var1 = System.currentTimeMillis();
         double var3 = Math.max(1.0, this.getConfig().getDouble("overclock.speed-multiplier", 3.0));
         long var5 = Math.max(10L, this.getConfig().getLong("system.tick-interval-ticks", 20L));
         long var7 = var5 * 50L;
         long var9 = Math.max(0L, Math.round(var7 * (var3 - 1.0)));
         boolean var11 = false;

         for (ZOverclock.State var13 : new ArrayList<>(this.states.values())) {
            Object var14 = this.getGenerator(var13.generatorId, var13.ownerUuid);
            if (var14 == null) {
               if (var13.activeUntil <= var1 && var13.brokenUntil <= var1 && var13.cooldownUntil <= var1) {
                  this.states.remove(var13.generatorId);
                  var11 = true;
               }
            } else {
               if (var13.activeUntil > var1) {
                  this.accelerate(var14, var9);
                  if (this.tickCounter % Math.max(1, this.getConfig().getInt("effects.active-pulse-every-seconds", 3)) == 0L) {
                     this.playActivePulse(var14);
                  }

                  Player var15 = Bukkit.getPlayer(var13.ownerUuid);
                  int var16 = Math.max(5, this.getConfig().getInt("messages.active-reminder-seconds", 30));
                  if (var15 != null && var15.isOnline() && this.tickCounter % var16 == 0L) {
                     this.msg(var15, "messages.active-reminder", "&c⚡ &fOverclock &8• &7Kalan: &f%time%", "%time%", this.formatTime(var13.activeUntil - var1));
                  }
               } else if (var13.pendingOutcome) {
                  var13.activeUntil = 0L;
                  var13.pendingOutcome = false;
                  this.resolveOutcome(var14, var13, var1);
                  var11 = true;
               }

               if (var13.brokenUntil > var1) {
                  this.freeze(var14, var1);
                  if (this.tickCounter % 4L == 0L) {
                     this.playBrokenPulse(var14);
                  }
               } else if (var13.brokenUntil != 0L) {
                  var13.brokenUntil = 0L;
                  var11 = true;
                  Player var17 = Bukkit.getPlayer(var13.ownerUuid);
                  if (var17 != null && var17.isOnline()) {
                     this.msg(var17, "messages.auto-repaired", "&aJeneratör soğudu ve yeniden çalışmaya başladı.");
                     this.playSound(this.location(var14), "minecraft:block.beacon.activate", 0.6F, 1.4F);
                  }
               }
            }
         }

         if (var11) {
            this.saveData();
         }
      }
   }

   private void resolveOutcome(Object var1, ZOverclock.State var2, long var3) {
      int var5 = Math.max(60, this.getConfig().getInt("balance.generator-cooldown-seconds", 3600));
      var2.cooldownUntil = var3 + var5 * 1000L;
      double var6 = ThreadLocalRandom.current().nextDouble(100.0);
      double var8 = this.pct("risk.safe.percent", 55.0);
      double var10 = this.pct("risk.overheat.percent", 28.0);
      double var12 = this.pct("risk.malfunction.percent", 14.0);
      double var14 = this.pct("risk.explosion.percent", 3.0);
      double var16 = var8 + var10 + var12 + var14;
      if (var16 <= 0.0) {
         var8 = 100.0;
         var16 = 100.0;
      }

      var6 = var6 * var16 / 100.0;
      Player var18 = Bukkit.getPlayer(var2.ownerUuid);
      Location var19 = this.location(var1);
      if (var6 < var8) {
         if (var18 != null && var18.isOnline()) {
            this.msg(var18, "messages.outcome-safe", "&a✓ Overclock sorunsuz tamamlandı.");
         }

         this.playSound(var19, "minecraft:block.beacon.deactivate", 0.7F, 1.35F);
         this.particle(var19, "HAPPY_VILLAGER", 18, 0.5, 0.5, 0.5, 0.03);
      } else {
         var6 -= var8;
         if (var6 < var10) {
            int var25 = Math.max(30, this.getConfig().getInt("risk.overheat.disabled-seconds", 300));
            var2.brokenUntil = var3 + var25 * 1000L;
            if (var18 != null && var18.isOnline()) {
               this.msg(var18, "messages.outcome-overheat", "&e⚠ Jeneratör aşırı ısındı! &7%time% üretim durdu.", "%time%", this.formatTime(var25 * 1000L));
            }

            this.playSound(var19, "minecraft:block.fire.extinguish", 0.9F, 0.7F);
            this.particle(var19, "SMOKE", 30, 0.5, 0.7, 0.5, 0.03);
         } else {
            var6 -= var10;
            if (var6 < var12) {
               int var24 = Math.max(60, this.getConfig().getInt("risk.malfunction.disabled-seconds", 720));
               var2.brokenUntil = var3 + var24 * 1000L;
               if (var18 != null && var18.isOnline()) {
                  this.msg(var18, "messages.outcome-malfunction", "&c⚠ Jeneratör arızalandı! &7%time% üretim durdu.", "%time%", this.formatTime(var24 * 1000L));
               }

               this.playSound(var19, "minecraft:block.anvil.land", 0.8F, 0.55F);
               this.particle(var19, "ELECTRIC_SPARK", 38, 0.6, 0.7, 0.6, 0.08);
            } else {
               int var20 = Math.max(60, this.getConfig().getInt("risk.explosion.disabled-seconds", 1500));
               var2.brokenUntil = var3 + var20 * 1000L;
               if (var18 != null && var18.isOnline()) {
                  this.msg(
                     var18,
                     "messages.outcome-explosion",
                     "&4☄ Overclock patlaması! &7Jeneratör &f%time% &7boyunca devre dışı.",
                     "%time%",
                     this.formatTime(var20 * 1000L)
                  );
               }

               this.playExplosionEffect(var19);
            }
         }
      }
   }

   private void accelerate(Object var1, long var2) {
      if (var2 > 0L) {
         long var4 = this.longCall(var1, "getLastMoneyGeneration", System.currentTimeMillis());
         long var6 = this.longCall(var1, "getLastShardGeneration", System.currentTimeMillis());
         long var8 = Math.max(0L, var4 - var2);
         long var10 = this.getConfig().getBoolean("overclock.boost-shards", true) ? Math.max(0L, var6 - var2) : var6;
         this.invoke(var1, "setLastMoneyGeneration", new Class[]{long.class}, var8);
         if (this.getConfig().getBoolean("overclock.boost-shards", true)) {
            this.invoke(var1, "setLastShardGeneration", new Class[]{long.class}, var10);
         }

         this.persistGenerationState(var1, var8, var10);
      }
   }

   private void freeze(Object var1, long var2) {
      this.invoke(var1, "setLastMoneyGeneration", new Class[]{long.class}, var2);
      this.invoke(var1, "setLastShardGeneration", new Class[]{long.class}, var2);
      this.persistGenerationState(var1, var2, var2);
   }

   private void persistGenerationState(Object var1, long var2, long var4) {
      try {
         Object var6 = this.zGenPvP.getClass().getMethod("getGeneratorRepository").invoke(this.zGenPvP);
         long var7 = this.longCall(var1, "getId", -1L);
         double var9 = this.doubleCall(var1, "getStoredMoney", 0.0);
         int var11 = this.intCall(var1, "getStoredShards", 0);
         var6.getClass()
            .getMethod("updateGenerationState", long.class, double.class, int.class, long.class, long.class)
            .invoke(var6, var7, var9, var11, var2, var4);
      } catch (Throwable var12) {
      }
   }

   private void injectButton(Player var1, Inventory var2, Object var3) {
      if (var2 != null && var3 != null) {
         int var4 = Math.max(0, Math.min(var2.getSize() - 1, this.getConfig().getInt("menu.slot", 22)));
         long var5 = this.longCall(var3, "getId", -1L);
         UUID var7 = (UUID)this.call(var3, "getOwnerUuid");
         int var8 = this.intCall(var3, "getLevel", 1);
         ZOverclock.State var9 = this.states.computeIfAbsent(var5, var3x -> new ZOverclock.State(var5, var7));
         long var10 = System.currentTimeMillis();
         ItemStack var12;
         if (var9.activeUntil > var10) {
            var12 = this.item(
               "BLAZE_POWDER",
               "&c⚡ Overclock &8• &cAktif",
               "",
               "&7Hız: &f×" + this.trim(this.getConfig().getDouble("overclock.speed-multiplier", 3.0)),
               "&7Kalan: &f" + this.formatTime(var9.activeUntil - var10),
               "",
               "&cJeneratör yüksek ısıda çalışıyor."
            );
         } else if (var9.brokenUntil > var10) {
            double var13 = Math.max(
               this.getConfig().getDouble("repair.minimum-money-cost", 750.0), var8 * this.getConfig().getDouble("repair.money-cost-per-level", 120.0)
            );
            var12 = this.item(
               "DAMAGED_ANVIL",
               "&c⚠ Jeneratör arızalı",
               "",
               "&7Kalan: &f" + this.formatTime(var9.brokenUntil - var10),
               "&7Acil tamir: &e$" + this.money(var13),
               "",
               "&e› Shift + tık: acil tamir"
            );
         } else if (var9.cooldownUntil > var10) {
            var12 = this.item(
               "CLOCK", "&e⌛ Overclock &8• &esoğuma", "", "&7Kalan: &f" + this.formatTime(var9.cooldownUntil - var10), "", "&7Jeneratör yeniden hazırlanıyor."
            );
         } else {
            double var18 = this.activationMoneyCost(var8);
            long var15 = Math.max(0L, this.getConfig().getLong("balance.activation-shard-cost", 2L));
            int var17 = Math.max(1, this.getConfig().getInt("balance.minimum-generator-level", 10));
            var12 = this.item(
               "REDSTONE_TORCH",
               "&c⚡ Overclock",
               "",
               "&7Hız: &f×" + this.trim(this.getConfig().getDouble("overclock.speed-multiplier", 3.0)),
               "&7Süre: &f" + this.formatTime(this.getConfig().getInt("overclock.duration-seconds", 600) * 1000L),
               "&7Minimum seviye: &f" + var17,
               "",
               "&7Maliyet: &e$" + this.money(var18) + " &8+ &b" + var15 + " kristal",
               "",
               "&cRiskli üretim modu",
               "&a› Detaylar için tıkla"
            );
         }

         var2.setItem(var4, var12);
      }
   }

   private void refreshOpenMenus() {
      for (Player var2 : Bukkit.getOnlinePlayers()) {
         try {
            Inventory var3 = var2.getOpenInventory().getTopInventory();
            Object var4 = this.getGeneratorFromMenu(var3);
            if (var4 != null) {
               this.injectButton(var2, var3, var4);
            }
         } catch (Throwable var5) {
         }
      }
   }

   private boolean canManage(Player var1, UUID var2) {
      if (var1.getUniqueId().equals(var2)) {
         return true;
      }

      if (!this.getConfig().getBoolean("permissions.allow-team-generator-managers", false)) {
         return false;
      }

      try {
         Object var3 = this.zGenPvP.getClass().getMethod("getGeneratorManager").invoke(this.zGenPvP);
         Object var4 = var3.getClass().getMethod("canUpgradeGenerator", UUID.class, UUID.class).invoke(var3, var1.getUniqueId(), var2);
         return Boolean.TRUE.equals(var4);
      } catch (Throwable var5) {
         return false;
      }
   }

   private Object getGeneratorFromMenu(Inventory var1) {
      try {
         Object var2 = this.zGenPvP.getClass().getMethod("getGeneratorMenu").invoke(this.zGenPvP);
         Object var3 = var2.getClass().getMethod("isMenu", Inventory.class).invoke(var2, var1);
         if (!Boolean.TRUE.equals(var3)) {
            return null;
         }

         if (var2.getClass().getMethod("getGenerator", Inventory.class).invoke(var2, var1) instanceof Optional var5) {
            return var5.orElse(null);
         }
      } catch (Throwable var6) {
      }

      return null;
   }

   private Object getGeneratorAt(Location var1) {
      try {
         Object var2 = this.zGenPvP.getClass().getMethod("getGeneratorManager").invoke(this.zGenPvP);
         if (var2.getClass().getMethod("getGenerator", Location.class).invoke(var2, var1) instanceof Optional var4) {
            return var4.orElse(null);
         }
      } catch (Throwable var5) {
      }

      return null;
   }

   private Object getGenerator(long var1, UUID var3) {
      try {
         Object var4 = this.zGenPvP.getClass().getMethod("getGeneratorManager").invoke(this.zGenPvP);
         if (var4.getClass().getMethod("getGenerator", long.class, UUID.class).invoke(var4, var1, var3) instanceof Optional var6) {
            return var6.orElse(null);
         }
      } catch (Throwable var7) {
      }

      return null;
   }

   private Location location(Object var1) {
      return this.call(var1, "getLocation") instanceof Location var3 ? var3.clone().add(0.5, 1.0, 0.5) : null;
   }

   private double activationMoneyCost(int var1) {
      double var2 = Math.max(0.0, this.getConfig().getDouble("balance.activation-money-per-level", 75.0));
      double var4 = Math.max(0.0, this.getConfig().getDouble("balance.minimum-activation-money", 500.0));
      return Math.max(var4, var2 * Math.max(1, var1));
   }

   private boolean withdrawMoney(Player var1, double var2) {
      return OverclockEconomyFix.withdraw(this.zGenPvP, var1, var2);
   }

   private void depositMoney(Player var1, double var2) {
      try {
         Object var4 = this.zGenPvP.getClass().getMethod("getEconomyManager").invoke(this.zGenPvP);
         var4.getClass().getMethod("deposit", Player.class, double.class).invoke(var4, var1, var2);
      } catch (Throwable var5) {
      }
   }

   private boolean removeShards(UUID var1, long var2) {
      if (var2 <= 0L) {
         return true;
      }

      try {
         Object var4 = this.zGenPvP.getClass().getMethod("getZShardHook").invoke(this.zGenPvP);
         long var5 = ((Number)var4.getClass().getMethod("getBalance", UUID.class).invoke(var4, var1)).longValue();
         return var5 < var2 ? false : Boolean.TRUE.equals(var4.getClass().getMethod("removeShards", UUID.class, long.class).invoke(var4, var1, var2));
      } catch (Throwable var7) {
         return false;
      }
   }

   private void playActivationEffect(Location var1) {
      if (var1 != null && this.getConfig().getBoolean("effects.enabled", true)) {
         this.particle(var1, "ELECTRIC_SPARK", 42, 0.65, 0.75, 0.65, 0.08);
         this.particle(var1, "ENCHANT", 30, 0.55, 0.7, 0.55, 0.05);
         this.playSound(var1, "minecraft:block.beacon.activate", 0.85F, 1.6F);
         this.playSound(var1, "minecraft:block.respawn_anchor.charge", 0.65F, 1.2F);
      }
   }

   private void playActivePulse(Object var1) {
      Location var2 = this.location(var1);
      if (var2 != null && this.getConfig().getBoolean("effects.enabled", true)) {
         this.particle(var2, "ELECTRIC_SPARK", 10, 0.45, 0.45, 0.45, 0.03);
         this.particle(var2, "SMALL_FLAME", 4, 0.35, 0.35, 0.35, 0.01);
      }
   }

   private void playBrokenPulse(Object var1) {
      Location var2 = this.location(var1);
      if (var2 != null && this.getConfig().getBoolean("effects.enabled", true)) {
         this.particle(var2, "SMOKE", 8, 0.4, 0.45, 0.4, 0.02);
         this.particle(var2, "ELECTRIC_SPARK", 4, 0.35, 0.35, 0.35, 0.04);
      }
   }

   private void playExplosionEffect(Location var1) {
      if (var1 != null) {
         this.particle(var1, "EXPLOSION", 5, 0.55, 0.55, 0.55, 0.08);
         this.particle(var1, "LARGE_SMOKE", 35, 0.8, 0.9, 0.8, 0.06);
         this.particle(var1, "ELECTRIC_SPARK", 50, 0.85, 0.85, 0.85, 0.12);
         this.playSound(var1, "minecraft:entity.generic.explode", 1.0F, 0.75F);
         this.playSound(var1, "minecraft:block.anvil.land", 0.75F, 0.5F);
      }
   }

   private void particle(Location var1, String var2, int var3, double var4, double var6, double var8, double var10) {
      if (var1 != null && var1.getWorld() != null && this.getConfig().getBoolean("effects.particles", true)) {
         try {
            Class var12 = Class.forName("org.bukkit.Particle");
            Enum var13 = Enum.valueOf(var12.asSubclass(Enum.class), var2);
            Method var14 = var1.getWorld()
               .getClass()
               .getMethod("spawnParticle", var12, Location.class, int.class, double.class, double.class, double.class, double.class);
            var14.invoke(var1.getWorld(), var13, var1, var3, var4, var6, var8, var10);
         } catch (Throwable var15) {
         }
      }
   }

   private void playSound(Location var1, String var2, float var3, float var4) {
      if (var1 != null && var1.getWorld() != null && this.getConfig().getBoolean("effects.sounds", true)) {
         try {
            var1.getWorld()
               .getClass()
               .getMethod("playSound", Location.class, String.class, float.class, float.class)
               .invoke(var1.getWorld(), var1, var2, var3, var4);
         } catch (Throwable var6) {
         }
      }
   }

   private void playError(Player var1) {
      this.playSound(var1.getLocation(), "minecraft:block.note_block.bass", 0.55F, 0.6F);
   }

   private void fill(Inventory var1) {
      if (this.getConfig().getBoolean("menu.confirm-filler", true)) {
         ItemStack var2 = this.item("BLACK_STAINED_GLASS_PANE", " ");

         for (int var3 = 0; var3 < var1.getSize(); var3++) {
            var1.setItem(var3, var2);
         }
      }
   }

   private ItemStack item(String var1, String var2, String... var3) {
      Material var4;
      try {
         var4 = Material.valueOf(var1);
      } catch (Throwable var12) {
         var4 = Material.valueOf("PAPER");
      }

      ItemStack var5 = new ItemStack(var4);
      ItemMeta var6 = var5.getItemMeta();
      if (var6 != null) {
         ArrayList var7 = new ArrayList();

         for (String var11 : var3) {
            var7.add(this.color(var11));
         }

         if (!this.applyAdventureText(var6, this.color(var2), var7)) {
            var6.setDisplayName(this.color(var2));
            var6.setLore(var7);
         }

         var5.setItemMeta(var6);
      }

      return var5;
   }

   private boolean applyAdventureText(ItemMeta var1, String var2, List<String> var3) {
      try {
         Class var4 = Class.forName("net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer");
         Object var5 = var4.getMethod("legacySection").invoke(null);
         Method var6 = var4.getMethod("deserialize", String.class);
         Class var7 = Class.forName("net.kyori.adventure.text.Component");
         Class var8 = Class.forName("net.kyori.adventure.text.format.TextDecoration");
         Class var9 = Class.forName("net.kyori.adventure.text.format.TextDecoration$State");
         Enum var10 = Enum.valueOf(var8.asSubclass(Enum.class), "ITALIC");
         Enum var11 = Enum.valueOf(var8.asSubclass(Enum.class), "BOLD");
         Enum var12 = Enum.valueOf(var9.asSubclass(Enum.class), "FALSE");
         Method var13 = var7.getMethod("decoration", var8, var9);
         Object var14 = var6.invoke(var5, var2);
         var14 = var13.invoke(var14, var10, var12);
         var14 = var13.invoke(var14, var11, var12);
         var1.getClass().getMethod("displayName", var7).invoke(var1, var14);
         ArrayList var15 = new ArrayList();

         for (String var17 : var3) {
            Object var18 = var6.invoke(var5, var17);
            var18 = var13.invoke(var18, var10, var12);
            var18 = var13.invoke(var18, var11, var12);
            var15.add(var18);
         }

         var1.getClass().getMethod("lore", List.class).invoke(var1, var15);
         return true;
      } catch (Throwable var19) {
         return false;
      }
   }

   private boolean isConfirmationView(InventoryClickEvent var1) {
      try {
         String var2 = var1.getView().getTitle();
         return var2.equals(this.color(this.getConfig().getString("menu.confirm-title", "&8ᴏᴠᴇʀᴄʟᴏᴄᴋ &8• &fᴏɴᴀʏ")));
      } catch (Throwable var3) {
         return false;
      }
   }

   private void loadData() {
      this.states.clear();
      this.ownerCooldown.clear();
      if (this.dataFile != null && this.dataFile.isFile()) {
         Properties var1 = new Properties();

         try (InputStreamReader var2 = new InputStreamReader(new FileInputStream(this.dataFile), StandardCharsets.UTF_8)) {
            var1.load(var2);
            HashSet<Long> var3 = new HashSet<>();

            for (String var5 : var1.stringPropertyNames()) {
               if (var5.startsWith("g.")) {
                  String[] var6 = var5.split("\\.");
                  if (var6.length >= 3) {
                     try {
                        var3.add(Long.parseLong(var6[1]));
                     } catch (Exception var12) {
                     }
                  }
               }
            }

            for (long var18 : var3) {
               String var7 = "g." + var18 + ".";

               UUID var8;
               try {
                  var8 = UUID.fromString(var1.getProperty(var7 + "owner"));
               } catch (Exception var13) {
                  continue;
               }

               ZOverclock.State var9 = new ZOverclock.State(var18, var8);
               var9.activeUntil = this.lng(var1.getProperty(var7 + "activeUntil"));
               var9.cooldownUntil = this.lng(var1.getProperty(var7 + "cooldownUntil"));
               var9.brokenUntil = this.lng(var1.getProperty(var7 + "brokenUntil"));
               var9.pendingOutcome = Boolean.parseBoolean(var1.getProperty(var7 + "pendingOutcome", "false"));
               this.states.put(var18, var9);
            }

            for (String var19 : var1.stringPropertyNames()) {
               if (var19.startsWith("owner.")) {
                  try {
                     this.ownerCooldown.put(UUID.fromString(var19.substring(6)), this.lng(var1.getProperty(var19)));
                  } catch (Exception var11) {
                  }
               }
            }
         } catch (IOException var15) {
            this.getLogger().warning("data.properties okunamadi: " + var15.getMessage());
         }
      }
   }

   private void saveData() {
      if (this.dataFile != null) {
         try {
            if (!this.getDataFolder().exists()) {
               this.getDataFolder().mkdirs();
            }
         } catch (Throwable var8) {
         }

         Properties var1 = new Properties();

         for (ZOverclock.State var3 : this.states.values()) {
            String var4 = "g." + var3.generatorId + ".";
            var1.setProperty(var4 + "owner", var3.ownerUuid.toString());
            var1.setProperty(var4 + "activeUntil", String.valueOf(var3.activeUntil));
            var1.setProperty(var4 + "cooldownUntil", String.valueOf(var3.cooldownUntil));
            var1.setProperty(var4 + "brokenUntil", String.valueOf(var3.brokenUntil));
            var1.setProperty(var4 + "pendingOutcome", String.valueOf(var3.pendingOutcome));
         }

         for (Entry var11 : this.ownerCooldown.entrySet()) {
            var1.setProperty("owner." + var11.getKey(), String.valueOf(var11.getValue()));
         }

         try (OutputStreamWriter var10 = new OutputStreamWriter(new FileOutputStream(this.dataFile), StandardCharsets.UTF_8)) {
            var1.store(var10, "ZOverclock runtime data");
         } catch (IOException var7) {
            this.getLogger().warning("data.properties yazilamadi: " + var7.getMessage());
         }
      }
   }

   private double pct(String var1, double var2) {
      return Math.max(0.0, this.getConfig().getDouble(var1, var2));
   }

   private long lng(String var1) {
      try {
         return Long.parseLong(var1);
      } catch (Exception var3) {
         return 0L;
      }
   }

   private Object call(Object var1, String var2) {
      try {
         return var1.getClass().getMethod(var2).invoke(var1);
      } catch (Throwable var4) {
         return null;
      }
   }

   private long longCall(Object var1, String var2, long var3) {
      return this.call(var1, var2) instanceof Number var6 ? var6.longValue() : var3;
   }

   private int intCall(Object var1, String var2, int var3) {
      return this.call(var1, var2) instanceof Number var5 ? var5.intValue() : var3;
   }

   private double doubleCall(Object var1, String var2, double var3) {
      return this.call(var1, var2) instanceof Number var6 ? var6.doubleValue() : var3;
   }

   private Object invoke(Object var1, String var2, Class<?>[] var3, Object... var4) {
      try {
         return var1.getClass().getMethod(var2, var3).invoke(var1, var4);
      } catch (Throwable var6) {
         return null;
      }
   }

   private void msg(Player var1, String var2, String var3, String... var4) {
      String var5 = this.getConfig().getString(var2, var3);
      if (var5 == null) {
         var5 = var3;
      }

      for (byte var6 = 0; var6 + 1 < var4.length; var6 += 2) {
         var5 = var5.replace(var4[var6], var4[var6 + 1]);
      }

      var1.sendMessage(this.color(var5));
   }

   private String color(String var1) {
      return var1 == null ? "" : var1.replace('&', '§');
   }

   private String money(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private String trim(double var1) {
      return Math.rint(var1) == var1 ? String.valueOf((long)var1) : new DecimalFormat("0.##").format(var1);
   }

   private String formatTime(long var1) {
      long var3 = Math.max(0L, var1 / 1000L);
      long var5 = var3 / 60L;
      long var7 = var3 % 60L;
      long var9 = var5 / 60L;
      var5 %= 60L;
      if (var9 > 0L) {
         return var9 + "s " + var5 + "dk";
      } else {
         return var5 > 0L ? var5 + "dk " + var7 + "sn" : var7 + "sn";
      }
   }

   private record Confirmation(long generatorId, UUID ownerUuid, long expiresAt) {
   }

   private static final class State {
      final long generatorId;
      UUID ownerUuid;
      long activeUntil;
      long cooldownUntil;
      long brokenUntil;
      boolean pendingOutcome;

      State(long var1, UUID var3) {
         this.generatorId = var1;
         this.ownerUuid = var3;
      }
   }
}
