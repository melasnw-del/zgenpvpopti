package com.zzwproject.zgenpvp.generator.link;

import com.zzwproject.zgenpvp.ZGenPvP;
import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.block.DoubleChest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class GeneratorChestAccessListener implements Listener {
   private final ZGenPvP plugin;
   private final GeneratorLinkManager linkManager;

   public GeneratorChestAccessListener(ZGenPvP plugin, GeneratorLinkManager linkManager) {
      this.plugin = plugin;
      this.linkManager = linkManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onOpen(InventoryOpenEvent event) {
      if (event.getPlayer() instanceof Player player) {
         Location linkedLocation = this.resolveLinkedLocation(event.getInventory().getHolder(false));
         if (linkedLocation != null && !this.canAccess(player, linkedLocation)) {
            event.setCancelled(true);
            this.deny(player);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player player) {
         Inventory var5 = event.getView().getTopInventory();
         Location linkedLocation = this.resolveLinkedLocation(var5.getHolder(false));
         if (linkedLocation != null && !this.canAccess(player, linkedLocation)) {
            event.setCancelled(true);
            this.deny(player);
            player.closeInventory();
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDrag(InventoryDragEvent event) {
      if (event.getWhoClicked() instanceof Player player) {
         Inventory var5 = event.getView().getTopInventory();
         Location linkedLocation = this.resolveLinkedLocation(var5.getHolder(false));
         if (linkedLocation != null && !this.canAccess(player, linkedLocation)) {
            event.setCancelled(true);
            this.deny(player);
            player.closeInventory();
         }
      }
   }

   private boolean canAccess(Player player, Location linkedLocation) {
      return this.linkManager.canOpenLinkedChest(player, linkedLocation);
   }

   private void deny(Player player) {
      this.plugin.getMessageUtil().sendActionBar(player, "generator-link.chest-private");
   }

   private Location resolveLinkedLocation(InventoryHolder holder) {
      if (holder instanceof BlockState state) {
         return this.linkManager.isLinkedChest(state.getLocation()) ? state.getLocation() : null;
      } else {
         if (holder instanceof DoubleChest doubleChest) {
            Location left = this.holderLocation(doubleChest.getLeftSide());
            if (left != null && this.linkManager.isLinkedChest(left)) {
               return left;
            }

            Location right = this.holderLocation(doubleChest.getRightSide());
            if (right != null && this.linkManager.isLinkedChest(right)) {
               return right;
            }
         }

         return null;
      }
   }

   private Location holderLocation(InventoryHolder holder) {
      return holder instanceof BlockState state ? state.getLocation() : null;
   }
}
