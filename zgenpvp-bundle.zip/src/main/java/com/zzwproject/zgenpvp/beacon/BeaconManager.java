package com.zzwproject.zgenpvp.beacon;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.integration.ZGenMapTeleportBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.repository.BeaconRepository;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

public final class BeaconManager {
   private final ZGenPvP plugin;
   private final BeaconRepository repository;
   private final SpecialItemFactory itemFactory;
   private final NamespacedKey selectedSpawnTypeKey;
   private final NamespacedKey selectedBeaconIdKey;
   private final Map<UUID, BukkitTask> respawnTasks = new HashMap<>();
   private final Map<UUID, Integer> respawnSeconds = new HashMap<>();
   private final Map<UUID, BeaconManager.RespawnTarget> respawnTargets = new HashMap<>();

   public BeaconManager(ZGenPvP var1, BeaconRepository var2, SpecialItemFactory var3) {
      this.plugin = var1;
      this.repository = var2;
      this.itemFactory = var3;
      this.selectedSpawnTypeKey = new NamespacedKey(var1, "selected_respawn_type");
      this.selectedBeaconIdKey = new NamespacedKey(var1, "selected_respawn_beacon_id");
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("modules.beacon", true);
   }

   public boolean hasBeacon(UUID var1) {
      return var1 == null ? false : this.repository.findByOwner(var1).isPresent();
   }

   public Optional<BeaconData> getBeacon(UUID var1) {
      return var1 == null ? Optional.empty() : this.repository.findByOwner(var1);
   }

   public Optional<BeaconData> getBeacon(Location var1) {
      return var1 != null && var1.getWorld() != null ? this.repository.findByLocation(var1) : Optional.empty();
   }

   public boolean canUseBeacon(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canUseBeacon(var1, var2);
      }
   }

   public boolean canUseBeacon(Player var1, BeaconData var2) {
      return var1 != null && var2 != null ? this.canUseBeacon(var2.getOwnerUuid(), var1.getUniqueId()) : false;
   }

   public boolean isOwner(Player var1, BeaconData var2) {
      return var1 != null && var2 != null && var2.getOwnerUuid() != null ? var2.getOwnerUuid().equals(var1.getUniqueId()) : false;
   }

   public void sendOwnerInfo(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null && var2.getOwnerUuid() != null) {
         OfflinePlayer var3 = Bukkit.getOfflinePlayer(var2.getOwnerUuid());
         String var4 = var3.getName() == null ? "Bilinmeyen" : var3.getName();
         this.plugin.getMessageUtil().send(var1, "beacon.owner-info", "%owner%", var4);
      }
   }

   public boolean createBeacon(Player var1, Location var2) {
      if (var1 == null || var2 == null || var2.getWorld() == null) {
         return false;
      }

      if (!this.isEnabled()) {
         this.plugin.getMessageUtil().send(var1, "general.module-disabled");
         return false;
      }

      if (!this.isWorldAllowed(var2)) {
         this.plugin.getMessageUtil().send(var1, "general.world-disabled");
         return false;
      }

      int var3 = this.repository.countByOwner(var1.getUniqueId());
      int var4 = this.getBeaconLimit(var1);
      if (var3 >= var4) {
         this.plugin.getMessageUtil().send(var1, "beacon.limit-reached", "%current%", String.valueOf(var3), "%limit%", String.valueOf(var4));
         this.plugin.getSoundUtil().play(var1, "error");
         return false;
      }

      String var5 = this.plugin.getConfigManager().getConfig().getString("beacon.default-name", "%player%'ɪɴ ᴜꜱꜱᴜ");
      if (var5 == null) {
         var5 = var1.getName() + "'ɪɴ ᴜꜱꜱᴜ";
      }

      var5 = var5.replace("%player%", var1.getName());
      long var6 = this.repository.create(var1.getUniqueId(), var5, var2);
      if (var6 <= 0L) {
         this.plugin.getMessageUtil().send(var1, "beacon.place-error");
         return false;
      } else {
         this.plugin.getMessageUtil().sendActionBar(var1, "beacon.placed", "%current%", String.valueOf(var3 + 1), "%limit%", String.valueOf(var4));
         this.plugin.getSoundUtil().play(var1, "beacon-place");
         return true;
      }
   }

   public boolean renameBeacon(Player var1, String var2) {
      if (var1 == null) {
         return false;
      } else {
         Optional var3 = this.getBeacon(var1.getUniqueId());
         if (var3.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
            return false;
         } else {
            return this.renameBeacon(var1, (BeaconData)var3.get(), var2);
         }
      }
   }

   public boolean renameBeacon(Player var1, BeaconData var2, String var3) {
      if (var1 != null && var2 != null) {
         Optional var4 = this.getLiveBeacon(var2);
         if (var4.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
            return false;
         } else {
            BeaconData var5 = (BeaconData)var4.get();
            if (!this.isOwner(var1, var5)) {
               this.sendOwnerInfo(var1, var5);
               return false;
            } else {
               String var6 = var3 == null ? "" : var3.trim();
               if (var6.isBlank()) {
                  this.plugin.getMessageUtil().send(var1, "beacon.rename-empty");
                  return false;
               } else {
                  int var7 = Math.max(1, this.plugin.getConfigManager().getConfig().getInt("beacon.rename.max-length", 24));
                  if (var6.length() > var7) {
                     this.plugin.getMessageUtil().send(var1, "beacon.rename-too-long", "%max%", String.valueOf(var7));
                     return false;
                  } else {
                     boolean var8 = this.repository.updateName(var5.getId(), var6);
                     if (!var8) {
                        this.plugin.getMessageUtil().send(var1, "beacon.not-found");
                        return false;
                     } else {
                        this.plugin.getMessageUtil().send(var1, "beacon.renamed", "%name%", var6);
                        this.plugin.getSoundUtil().play(var1, "beacon-rename");
                        return true;
                     }
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean removeBeacon(Player var1) {
      if (var1 == null) {
         return false;
      } else {
         Optional var2 = this.getBeacon(var1.getUniqueId());
         if (var2.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
            return false;
         } else {
            return this.removeBeacon(var1, (BeaconData)var2.get());
         }
      }
   }

   public boolean removeBeacon(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         Optional var3 = this.getLiveBeacon(var2);
         if (var3.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
            return false;
         }

         BeaconData var4 = (BeaconData)var3.get();
         if (!TeamPermissionBridge.beaconBreakAllowed(this, var1, var4)) {
            this.sendOwnerInfo(var1, var4);
            return false;
         }

         Location var5 = var4.getLocation();
         boolean var6 = this.repository.deleteById(var4.getId());
         if (!var6) {
            this.plugin.getMessageUtil().send(var1, "beacon.remove-error");
            return false;
         }

         if (this.isBeaconSelected(var1, var4.getId())) {
            this.selectServerSpawnSilently(var1);
            this.plugin.getMessageUtil().send(var1, "beacon.spawn-select.reset-after-remove");
         }

         this.cancelTasksUsingBeacon(var4);
         if (var5 != null && var5.getWorld() != null && var5.getBlock().getType() == Material.BEACON) {
            var5.getBlock().setType(Material.AIR, false);
         }

         boolean var7 = this.plugin.getConfigManager().getConfig().getBoolean("beacon.remove.give-item-back", true);
         if (var7) {
            ItemStack var8 = this.itemFactory.createRespawnBeacon();
            if (var8 != null) {
               HashMap<Integer, ItemStack> var9 = var1.getInventory().addItem(new ItemStack[]{var8});
               if (!var9.isEmpty() && var5 != null && var5.getWorld() != null) {
                  for (ItemStack var11 : var9.values()) {
                     var5.getWorld().dropItemNaturally(var5, var11);
                  }
               }
            }
         }

         this.plugin.getMessageUtil().send(var1, "beacon.removed");
         this.plugin.getSoundUtil().play(var1, "beacon-remove");
         return true;
      } else {
         return false;
      }
   }

   public Optional<BeaconData> getBeacon(long var1) {
      return this.repository.findById(var1);
   }

   public List<BeaconData> getOwnedBeacons(UUID var1) {
      return var1 == null ? List.of() : this.repository.findAllByOwner(var1);
   }

   public void selectServerSpawn(Player var1) {
      if (var1 != null) {
         var1.getPersistentDataContainer().set(this.selectedSpawnTypeKey, PersistentDataType.STRING, "SPAWN");
         var1.getPersistentDataContainer().remove(this.selectedBeaconIdKey);
         this.plugin.getMessageUtil().send(var1, "beacon.spawn-select.server-selected");
         this.plugin.getSoundUtil().play(var1, "button");
      }
   }

   public boolean selectBeaconSpawn(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         BeaconData var3 = this.repository.findById(var2.getId()).orElse(null);
         if (var3 != null && var1.getUniqueId().equals(var3.getOwnerUuid())) {
            var1.getPersistentDataContainer().set(this.selectedSpawnTypeKey, PersistentDataType.STRING, "BEACON");
            var1.getPersistentDataContainer().set(this.selectedBeaconIdKey, PersistentDataType.LONG, var3.getId());
            this.plugin.getMessageUtil().send(var1, "beacon.spawn-select.beacon-selected", "%beacon_name%", var3.getName());
            this.plugin.getSoundUtil().play(var1, "button");
            return true;
         } else {
            this.plugin.getMessageUtil().send(var1, "beacon.not-found");
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isServerSpawnSelected(Player var1) {
      if (var1 == null) {
         return true;
      }

      String var2 = (String)var1.getPersistentDataContainer().get(this.selectedSpawnTypeKey, PersistentDataType.STRING);
      return var2 == null || !var2.equalsIgnoreCase("BEACON");
   }

   public boolean isBeaconSelected(Player var1, long var2) {
      if (var1 == null) {
         return false;
      }

      String var4 = (String)var1.getPersistentDataContainer().get(this.selectedSpawnTypeKey, PersistentDataType.STRING);
      Long var5 = (Long)var1.getPersistentDataContainer().get(this.selectedBeaconIdKey, PersistentDataType.LONG);
      return "BEACON".equalsIgnoreCase(var4) && var5 != null && var5 == var2;
   }

   public Location resolveSelectedDeathSpawn(Player var1) {
      if (var1 == null) {
         return null;
      }

      if (!this.isServerSpawnSelected(var1)) {
         Long var2 = (Long)var1.getPersistentDataContainer().get(this.selectedBeaconIdKey, PersistentDataType.LONG);
         if (var2 != null) {
            BeaconData var3 = this.repository.findById(var2).orElse(null);
            if (var3 != null && var1.getUniqueId().equals(var3.getOwnerUuid()) && this.getLiveBeacon(var3).isPresent()) {
               Location var4 = var3.getLocation();
               if (var4 != null && var4.getWorld() != null) {
                  return var4.clone()
                     .add(
                        this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.x", 0.5),
                        this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.y", 1.1),
                        this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.z", 0.5)
                     );
               }
            }
         }

         this.selectServerSpawnSilently(var1);
      }

      return this.getServerSpawnLocation(var1);
   }

   public void teleportToServerSpawn(Player var1) {
      if (var1 != null) {
         Location var2 = this.getServerSpawnLocation(var1);
         if (var2 != null && var2.getWorld() != null) {
            var2.setYaw(var1.getLocation().getYaw());
            var2.setPitch(var1.getLocation().getPitch());
            var1.teleport(var2);
            this.plugin.getSoundUtil().play(var1, "respawn-success");
         }
      }
   }

   private Location getServerSpawnLocation(Player var1) {
      World var2 = var1.getWorld();
      String var3 = this.plugin.getConfigManager().getConfig().getString("beacon.spawn-select.server-spawn-world", "");
      if (var3 != null && !var3.isBlank()) {
         World var4 = Bukkit.getWorld(var3);
         if (var4 != null) {
            var2 = var4;
         }
      }

      Location var5 = var2.getSpawnLocation().clone();
      var5.add(
         this.plugin.getConfigManager().getDeath().getDouble("respawn.spawn-offset.x", 0.5),
         this.plugin.getConfigManager().getDeath().getDouble("respawn.spawn-offset.y", 0.0),
         this.plugin.getConfigManager().getDeath().getDouble("respawn.spawn-offset.z", 0.5)
      );
      return var5;
   }

   private void selectServerSpawnSilently(Player var1) {
      var1.getPersistentDataContainer().set(this.selectedSpawnTypeKey, PersistentDataType.STRING, "SPAWN");
      var1.getPersistentDataContainer().remove(this.selectedBeaconIdKey);
   }

   private int getBeaconLimit(Player var1) {
      if (var1.hasPermission("zgenpvp.beacon.bypasslimit")) {
         return Integer.MAX_VALUE;
      } else if (var1.hasPermission("zgenpvp.beacon.limit.sponsor")) {
         return 5;
      } else if (var1.hasPermission("zgenpvp.beacon.limit.mvip")) {
         return 4;
      } else {
         return var1.hasPermission("zgenpvp.beacon.limit.vip") ? 3 : 2;
      }
   }

   public void startServerRespawn(Player var1) {
      if (var1 != null) {
         if (!this.isEnabled()) {
            this.plugin.getMessageUtil().send(var1, "general.module-disabled");
         } else if (!this.plugin.getConfigManager().getConfig().getBoolean("beacon.respawn.enabled", true)) {
            this.plugin.getMessageUtil().send(var1, "respawn.disabled");
         } else {
            UUID var2 = var1.getUniqueId();
            if (!this.isTeleporting(var2) && !ZGenMapTeleportBridge.isTeleporting(var1)) {
               Location var3 = this.getServerSpawnLocation(var1);
               if (var3 != null && var3.getWorld() != null) {
                  var3.setYaw(var1.getLocation().getYaw());
                  var3.setPitch(var1.getLocation().getPitch());
                  int var4 = Math.max(1, this.plugin.getConfigManager().getConfig().getInt("beacon.respawn.countdown-seconds", 5));
                  if (!this.startSharedServerRespawn(var1, var3, var4)) {
                     this.respawnSeconds.put(var2, var4);
                     this.respawnTargets.put(var2, new BeaconManager.RespawnTarget(-1L, (UUID)null));
                     BukkitTask var5 = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> this.tickRespawn(var1), 0L, 20L);
                     this.respawnTasks.put(var2, var5);
                  }
               } else {
                  this.plugin.getMessageUtil().send(var1, "respawn.world-not-found");
               }
            } else {
               this.plugin.getMessageUtil().send(var1, "respawn.already-teleporting");
            }
         }
      }
   }

   public void startRespawn(Player var1) {
      if (var1 != null) {
         Optional var2 = this.getBeacon(var1.getUniqueId());
         if (var2.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "respawn.no-beacon");
         } else {
            this.startRespawn(var1, (BeaconData)var2.get());
         }
      }
   }

   public void startRespawn(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         if (!this.isEnabled()) {
            this.plugin.getMessageUtil().send(var1, "general.module-disabled");
         } else if (!this.plugin.getConfigManager().getConfig().getBoolean("beacon.respawn.enabled", true)) {
            this.plugin.getMessageUtil().send(var1, "respawn.disabled");
         } else {
            UUID var3 = var1.getUniqueId();
            if (!this.isTeleporting(var3) && !ZGenMapTeleportBridge.isTeleporting(var1)) {
               Optional var4 = this.getLiveBeacon(var2);
               if (var4.isEmpty()) {
                  this.plugin.getMessageUtil().send(var1, "respawn.no-beacon");
               } else {
                  BeaconData var5 = (BeaconData)var4.get();
                  if (!this.canUseBeacon(var1, var5)) {
                     this.sendOwnerInfo(var1, var5);
                     this.plugin.getSoundUtil().play(var1, "error");
                  } else {
                     Location var6 = this.getBeaconRespawnTarget(var1, var5);
                     if (var6 != null && var6.getWorld() != null) {
                        int var7 = Math.max(1, this.plugin.getConfigManager().getConfig().getInt("beacon.respawn.countdown-seconds", 5));
                        if (!this.startSharedBeaconRespawn(var1, var5, var6, var7)) {
                           this.respawnSeconds.put(var3, var7);
                           this.respawnTargets.put(var3, new BeaconManager.RespawnTarget(var5.getId(), var5.getOwnerUuid()));
                           BukkitTask var8 = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> this.tickRespawn(var1), 0L, 20L);
                           this.respawnTasks.put(var3, var8);
                        }
                     } else {
                        this.plugin.getMessageUtil().send(var1, "respawn.world-not-found");
                     }
                  }
               }
            } else {
               this.plugin.getMessageUtil().send(var1, "respawn.already-teleporting");
            }
         }
      }
   }

   private boolean startSharedServerRespawn(Player var1, Location var2, int var3) {
      UUID var4 = var1.getUniqueId();
      String var5 = this.plugin.getConfigManager().getMessages().getString("respawn.countdown-title", "&#FF8A00%seconds%");
      String var6 = this.plugin.getConfigManager().getMessages().getString("respawn.countdown-subtitle", "&7Işınlanıyorsun...");
      boolean var7 = ZGenMapTeleportBridge.startValidated(
         var1, "zgenpvp-respawn", var2, var3, var5, var6, false, false, false, 0.0, () -> var1.isOnline() && !var1.isDead() && var2.getWorld() != null, () -> {
            this.respawnTargets.remove(var4);
            this.respawnSeconds.remove(var4);
            this.plugin.getSoundUtil().play(var1, "respawn-success");
         }, () -> {
            this.respawnTargets.remove(var4);
            this.respawnSeconds.remove(var4);
         }
      );
      if (var7) {
         this.respawnTargets.put(var4, new BeaconManager.RespawnTarget(-1L, (UUID)null));
      }

      return var7;
   }

   private boolean startSharedBeaconRespawn(Player var1, BeaconData var2, Location var3, int var4) {
      UUID var5 = var1.getUniqueId();
      String var6 = this.plugin.getConfigManager().getMessages().getString("respawn.countdown-title", "&#FF8A00%seconds%");
      String var7 = this.plugin.getConfigManager().getMessages().getString("respawn.countdown-subtitle", "&7Fenerine ışınlanıyorsun...");
      boolean var8 = ZGenMapTeleportBridge.startValidated(
         var1,
         "zgenpvp-respawn",
         var3,
         var4,
         var6,
         var7,
         false,
         false,
         false,
         0.0,
         () -> this.getLiveBeacon(var2).filter(var2xx -> this.canUseBeacon(var1, var2xx)).isPresent(),
         () -> {
            this.respawnTargets.remove(var5);
            this.respawnSeconds.remove(var5);
            var1.sendTitle(
               this.plugin.getMessageUtil().get("respawn.success-title"),
               this.plugin.getMessageUtil().get("respawn.success-subtitle", "%beacon_name%", var2.getName()),
               5,
               35,
               10
            );
            this.plugin.getMessageUtil().send(var1, "respawn.success");
            this.plugin.getSoundUtil().play(var1, "respawn-success");
         },
         () -> {
            this.respawnTargets.remove(var5);
            this.respawnSeconds.remove(var5);
         }
      );
      if (var8) {
         this.respawnTargets.put(var5, new BeaconManager.RespawnTarget(var2.getId(), var2.getOwnerUuid()));
      }

      return var8;
   }

   private Location getBeaconRespawnTarget(Player var1, BeaconData var2) {
      Location var3 = var2 == null ? null : var2.getLocation();
      if (var3 != null && var3.getWorld() != null) {
         double var4 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.x", 0.5);
         double var6 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.y", 1.1);
         double var8 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.z", 0.5);
         Location var10 = var3.clone().add(var4, var6, var8);
         var10.setYaw(var1.getLocation().getYaw());
         var10.setPitch(var1.getLocation().getPitch());
         return var10;
      } else {
         return null;
      }
   }

   private void tickRespawn(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (var1.isOnline() && !var1.isDead()) {
         Integer var3 = this.respawnSeconds.get(var2);
         BeaconManager.RespawnTarget var4 = this.respawnTargets.get(var2);
         if (var3 != null && var4 != null) {
            boolean var5 = var4.beaconId() < 0L;
            BeaconData var6 = null;
            if (!var5) {
               Optional var7 = this.getRespawnBeacon(var2);
               if (var7.isEmpty()) {
                  this.cancelRespawn(var2);
                  this.plugin.getMessageUtil().send(var1, "respawn.no-beacon");
                  return;
               }

               var6 = (BeaconData)var7.get();
               if (!this.canUseBeacon(var1, var6)) {
                  this.cancelRespawn(var2);
                  this.sendOwnerInfo(var1, var6);
                  return;
               }
            }

            if (var3 <= 0) {
               if (var5) {
                  this.teleportToServerSpawn(var1);
               } else {
                  this.teleportToBeacon(var1, var6);
               }

               this.cancelRespawn(var2);
            } else {
               String var9 = this.plugin.getMessageUtil().get("respawn.countdown-title", "%seconds%", String.valueOf(var3));
               String var8 = this.plugin.getMessageUtil().get("respawn.countdown-subtitle", "%seconds%", String.valueOf(var3));
               var1.sendTitle(var9, var8, 0, 22, 0);
               this.plugin.getSoundUtil().play(var1, "respawn-countdown");
               this.respawnSeconds.put(var2, var3 - 1);
            }
         } else {
            this.cancelRespawn(var2);
         }
      } else {
         this.cancelRespawn(var2);
      }
   }

   public void teleportToBeacon(Player var1) {
      if (var1 != null) {
         Optional var2 = this.getBeacon(var1.getUniqueId());
         if (var2.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "respawn.no-beacon");
         } else {
            this.teleportToBeacon(var1, (BeaconData)var2.get());
         }
      }
   }

   public void teleportToBeacon(Player var1, BeaconData var2) {
      if (var1 != null && var2 != null) {
         Optional var3 = this.getLiveBeacon(var2);
         if (var3.isEmpty()) {
            this.plugin.getMessageUtil().send(var1, "respawn.no-beacon");
         } else {
            BeaconData var4 = (BeaconData)var3.get();
            if (!this.canUseBeacon(var1, var4)) {
               this.sendOwnerInfo(var1, var4);
            } else {
               Location var5 = var4.getLocation();
               if (var5 != null && var5.getWorld() != null) {
                  double var6 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.x", 0.5);
                  double var8 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.y", 1.1);
                  double var10 = this.plugin.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.z", 0.5);
                  Location var12 = var5.clone().add(var6, var8, var10);
                  var12.setYaw(var1.getLocation().getYaw());
                  var12.setPitch(var1.getLocation().getPitch());
                  var1.teleport(var12);
                  var1.sendTitle(
                     this.plugin.getMessageUtil().get("respawn.success-title"),
                     this.plugin.getMessageUtil().get("respawn.success-subtitle", "%beacon_name%", var4.getName()),
                     5,
                     35,
                     10
                  );
                  this.plugin.getMessageUtil().send(var1, "respawn.success");
                  this.plugin.getSoundUtil().play(var1, "respawn-success");
               } else {
                  this.plugin.getMessageUtil().send(var1, "respawn.world-not-found");
               }
            }
         }
      }
   }

   public boolean isTeleporting(UUID var1) {
      if (var1 == null) {
         return false;
      }

      if (this.respawnTasks.containsKey(var1)) {
         return true;
      }

      Player var2 = Bukkit.getPlayer(var1);
      return var2 != null && "zgenpvp-respawn".equalsIgnoreCase(ZGenMapTeleportBridge.getChannel(var2));
   }

   public void cancelRespawn(Player var1, String var2) {
      if (var1 != null && this.isTeleporting(var1.getUniqueId())) {
         this.cancelRespawn(var1.getUniqueId());
         if (var2 != null) {
            this.plugin.getMessageUtil().send(var1, var2);
         }
      }
   }

   public void cancelRespawn(UUID var1) {
      if (var1 != null) {
         BukkitTask var2 = this.respawnTasks.remove(var1);
         if (var2 != null) {
            var2.cancel();
         }

         Player var3 = Bukkit.getPlayer(var1);
         if (var3 != null && "zgenpvp-respawn".equalsIgnoreCase(ZGenMapTeleportBridge.getChannel(var3))) {
            ZGenMapTeleportBridge.cancel(var3);
         }

         this.respawnSeconds.remove(var1);
         this.respawnTargets.remove(var1);
      }
   }

   private Optional<BeaconData> getRespawnBeacon(UUID var1) {
      BeaconManager.RespawnTarget var2 = this.respawnTargets.get(var1);
      return var2 == null ? Optional.empty() : this.repository.findByOwner(var2.ownerUuid()).filter(var1x -> var1x.getId() == var2.beaconId());
   }

   private Optional<BeaconData> getLiveBeacon(BeaconData var1) {
      return var1 != null && var1.getOwnerUuid() != null
         ? this.repository.findById(var1.getId()).filter(var1x -> var1x.getId() == var1.getId())
         : Optional.empty();
   }

   private void cancelTasksUsingBeacon(BeaconData var1) {
      if (var1 != null) {
         for (UUID var3 : this.respawnTargets.entrySet().stream().filter(var1x -> var1x.getValue().beaconId() == var1.getId()).map(Entry::getKey).toList()) {
            this.cancelRespawn(var3);
         }
      }
   }

   public void shutdown() {
      for (BukkitTask var2 : this.respawnTasks.values()) {
         var2.cancel();
      }

      for (UUID var5 : List.copyOf(this.respawnTargets.keySet())) {
         Player var3 = Bukkit.getPlayer(var5);
         if (var3 != null && "zgenpvp-respawn".equalsIgnoreCase(ZGenMapTeleportBridge.getChannel(var3))) {
            ZGenMapTeleportBridge.cancel(var3);
         }
      }

      this.respawnTasks.clear();
      this.respawnSeconds.clear();
      this.respawnTargets.clear();
   }

   private boolean isWorldAllowed(Location var1) {
      if (var1 == null) {
         return false;
      }

      World var2 = var1.getWorld();
      if (var2 == null) {
         return false;
      }

      String var3 = this.plugin.getConfigManager().getConfig().getString("worlds.mode", "BLACKLIST");
      List<String> var4 = this.plugin.getConfigManager().getConfig().getStringList("worlds.list");
      boolean var5 = var4.stream().anyMatch(var1x -> var1x.equalsIgnoreCase(var2.getName()));
      return "WHITELIST".equalsIgnoreCase(var3) ? var5 : !var5;
   }

   private record RespawnTarget(long beaconId, UUID ownerUuid) {
   }
}
