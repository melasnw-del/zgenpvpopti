package com.zzwproject.zgenpvp.generator;

import com.zzwproject.compat.ItemMetaCompat;
import com.zzwproject.compat.Paper12111Compat;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.hotfix.GenerationGate;
import com.zzwproject.zgenpvp.integration.RaidSessionBridge;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.integration.ZGenMapPlacementGuard;
import com.zzwproject.zgenpvp.integration.ZShardHook;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.money.MoneyItemManager;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.BeaconRepository;
import com.zzwproject.zgenpvp.repository.GeneratorRepository;
import com.zzwproject.zgenpvp.repository.PlayerRepository;
import com.zzwproject.zgenpvp.util.ColorUtil;
import com.zzwproject.zgenpvp.v2.EnergySupport;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.Hopper;
import org.bukkit.block.data.Directional;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GeneratorManager {
   private final ZGenPvP plugin;
   private final GeneratorRepository generatorRepository;
   private final BaseRepository baseRepository;
   private final BeaconRepository beaconRepository;
   private final PlayerRepository playerRepository;
   private final EconomyManager economyManager;
   private final MoneyItemManager moneyItemManager;
   private final ZShardHook zShardHook;
   private final GeneratorVisualManager visualManager;
   private final NamespacedKey generatorItemKey;
   private final NamespacedKey generatorLevelKey;
   private final NamespacedKey generatorRewardOwnerKey;
   private final NamespacedKey generatorRewardSourceKey;
   private final NamespacedKey generatorRewardKindKey;
   private final Map<String, GeneratorData> generatorCache = new HashMap<>();
   private final Map<Long, GeneratorData> generatorsById = new HashMap<>();
   private final Map<Long, Long> transferRetryAt = new HashMap<>();
   private static final long TRANSFER_RETRY_MS = 1500L;
   private final ArrayList<GeneratorData> generationSweep = new ArrayList<>();
   private final ArrayList<GeneratorData> hopperTransferSweep = new ArrayList<>();
   private int generationSweepCursor;
   private int hopperTransferSweepCursor;
   private long nextGenerationSweepAt;
   private long nextHopperTransferRunAt;
   private long nextGenerationFailureLogAt;
   private int suppressedGenerationFailures;
   private final Map<UUID, Double> pendingGenerationXpUnits = new HashMap<>();
   private final Map<UUID, Player> onlineGenerationOwners = new HashMap<>();
   private final Set<UUID> offlineGenerationOwners = new HashSet<>();
   private final Map<String, Boolean> poweredSweepCache = new HashMap<>();
   private final Map<Long, UUID> moneyRewardEntities = new HashMap<>();

   public GeneratorManager(
      ZGenPvP var1,
      GeneratorRepository var2,
      BaseRepository var3,
      BeaconRepository var4,
      PlayerRepository var5,
      EconomyManager var6,
      MoneyItemManager var7,
      ZShardHook var8
   ) {
      this.plugin = var1;
      this.generatorRepository = var2;
      this.baseRepository = var3;
      this.beaconRepository = var4;
      this.playerRepository = var5;
      this.economyManager = var6;
      this.moneyItemManager = var7;
      this.zShardHook = var8;
      this.visualManager = new GeneratorVisualManager(var1, var7);
      this.generatorItemKey = new NamespacedKey(var1, "generator_item");
      this.generatorLevelKey = new NamespacedKey(var1, "generator_level");
      this.generatorRewardOwnerKey = new NamespacedKey(var1, "generator_reward_owner");
      this.generatorRewardSourceKey = new NamespacedKey(var1, "generator_reward_source");
      this.generatorRewardKindKey = new NamespacedKey(var1, "generator_reward_kind");
   }

   public void loadCache() {
      this.generatorCache.clear();
      this.generatorsById.clear();
      this.transferRetryAt.clear();
      this.resetGenerationSweep();

      for (GeneratorData var2 : this.generatorRepository.findAll()) {
         this.applyOfflineGeneration(var2);
         this.generatorCache.put(this.key(var2), var2);
         this.generatorsById.put(var2.getId(), var2);
      }

      this.visualManager.refreshAll(this.generatorCache.values());
      this.plugin.getLogger().info(this.generatorCache.size() + " ᴘᴀʀᴀ ᴊᴇɴᴇʀᴀᴛᴏʀᴜ ʏᴜᴋʟᴇɴᴅɪ.");
   }

   public void shutdown() {
      this.visualManager.shutdown();
      this.generatorCache.clear();
      this.generatorsById.clear();
      this.transferRetryAt.clear();
      this.moneyRewardEntities.clear();
      this.resetGenerationSweep();
   }

   public void reload() {
      this.moneyItemManager.reload();
      this.plugin.getXpRewardManager().reload();
      this.visualManager.refreshAll(this.generatorCache.values());
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getConfig().getBoolean("modules.generators", true)
         && this.plugin.getConfigManager().getGenerators().getBoolean("enabled", true);
   }

   public Optional<GeneratorData> getGenerator(Location var1) {
      return var1 != null && var1.getWorld() != null ? Optional.ofNullable(this.generatorCache.get(this.key(var1))) : Optional.empty();
   }

   public Optional<GeneratorData> getGenerator(long var1, UUID var3) {
      if (var3 == null) {
         return Optional.empty();
      }

      GeneratorData var4 = this.generatorsById.get(var1);
      return var4 != null && var3.equals(var4.getOwnerUuid()) ? Optional.of(var4) : Optional.empty();
   }

   public ItemStack createGeneratorItem(int var1) {
      int var2 = Math.max(1, Math.min(this.getMaxLevel(), var1));
      FileConfiguration var3 = this.plugin.getConfigManager().getGenerators();
      Material var4 = this.getMaterial(var3.getString("item.material"), Material.GLASS);
      ItemStack var5 = new ItemStack(var4);
      ItemMeta var6 = var5.getItemMeta();
      if (var6 == null) {
         return var5;
      }

      String var7 = var3.getString("item.name", "&aᴘᴀʀᴀ ᴊᴇɴᴇʀᴀᴛᴏʀᴜ &8• &fʟᴠ.%level%");
      var6.setDisplayName(
         ColorUtil.color(
            this.replace(
               var7,
               "%level%",
               String.valueOf(var2),
               "%max_level%",
               String.valueOf(this.getMaxLevel()),
               "%money%",
               this.format(this.getMoneyPerCycle(var2)),
               "%interval%",
               this.format(this.getMoneyIntervalSeconds())
            )
         )
      );
      ArrayList var8 = new ArrayList();

      for (String var10 : var3.getStringList("item.lore")) {
         var8.add(
            ColorUtil.color(
               this.replace(
                  var10,
                  "%level%",
                  String.valueOf(var2),
                  "%max_level%",
                  String.valueOf(this.getMaxLevel()),
                  "%money%",
                  this.format(this.getMoneyPerCycle(var2)),
                  "%interval%",
                  this.format(this.getMoneyIntervalSeconds())
               )
            )
         );
      }

      var6.setLore(var8);
      int var11 = var3.getInt("item.custom-model-data", 0);
      if (var11 > 0) {
         var6.setCustomModelData(var11);
      }

      var6.getPersistentDataContainer().set(this.generatorItemKey, PersistentDataType.BYTE, (byte)1);
      var6.getPersistentDataContainer().set(this.generatorLevelKey, PersistentDataType.INTEGER, var2);
      ItemMetaCompat.apply(var5, var6);
      return var5;
   }

   public boolean isGeneratorItem(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         Byte var2 = (Byte)var1.getItemMeta().getPersistentDataContainer().get(this.generatorItemKey, PersistentDataType.BYTE);
         return var2 != null && var2 == 1;
      } else {
         return false;
      }
   }

   public int getGeneratorItemLevel(ItemStack var1) {
      if (!this.isGeneratorItem(var1)) {
         return 1;
      }

      Integer var2 = (Integer)var1.getItemMeta().getPersistentDataContainer().get(this.generatorLevelKey, PersistentDataType.INTEGER);
      return var2 == null ? 1 : Math.max(1, var2);
   }

   public boolean place(Player var1, Location var2, int var3) {
      if (!this.isEnabled()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.disabled");
         return false;
      }

      if (var1 == null || var2 == null || var2.getWorld() == null) {
         return false;
      }

      if (ZGenMapPlacementGuard.isSpawnProtected(var2) && !ZGenMapPlacementGuard.canAdminBypass(var1)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.spawn-protected");
         return false;
      }

      if (this.getGenerator(var2).isPresent()) {
         return true;
      }

      UUID var4 = var1.getUniqueId();
      FileConfiguration var5 = this.plugin.getConfigManager().getConfig();
      boolean var6 = var5.getBoolean("generator.require-beacon", false);
      boolean var7 = var5.getBoolean("generator.require-base", false);
      boolean var8 = var5.getBoolean("generator.require-inside-base", var7);
      if (var6 && this.beaconRepository.findByOwner(var4).isEmpty()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.beacon-required");
         return false;
      }

      Optional<BaseData> var9 = this.baseRepository.findByOwner(var4);
      if (var7 && var9.isEmpty()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.base-required");
         return false;
      }

      BaseData var10 = var9.filter(var2x -> this.isInsideBase(var2x, var2)).orElse(null);
      if (var8 && var10 == null) {
         this.plugin.getMessageUtil().sendActionBar(var1, var9.isEmpty() ? "generator.base-required" : "generator.outside-base");
         return false;
      }

      int var11 = this.playerRepository.getLevel(var4);
      int var12 = this.getGeneratorLimit(var11);
      int var13 = this.countGenerators(var4);
      boolean var14 = var1.hasPermission("zgenpvp.generator.bypasslimit");
      if (!var14 && var13 >= var12) {
         this.plugin
            .getMessageUtil()
            .sendActionBar(
               var1, "generator.generator-limit", "%current%", String.valueOf(var13), "%max%", String.valueOf(var12), "%level%", String.valueOf(var11)
            );
         return false;
      }

      long var15 = 0L;
      if (var10 != null) {
         int var17 = this.generatorRepository.countStructures(var10.getId());
         if (!var14 && var17 >= var10.getBlockLimit()) {
            this.plugin
               .getMessageUtil()
               .sendActionBar(var1, "generator.structure-limit", "%current%", String.valueOf(var17), "%max%", String.valueOf(var10.getBlockLimit()));
            return false;
         }

         var15 = var10.getId();
      }

      int var23 = Math.max(1, Math.min(this.getMaxLevel(), var3));
      long var18 = System.currentTimeMillis();
      long var20 = this.generatorRepository.create(var15, var4, var2, var23, var18);
      if (var20 <= 0L) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.place-error");
         return false;
      } else {
         GeneratorData var22 = new GeneratorData(
            var20,
            var15,
            var4,
            var2.getWorld().getName(),
            var2.getBlockX(),
            var2.getBlockY(),
            var2.getBlockZ(),
            var23,
            0.0,
            0,
            var18,
            var18,
            (String)null,
            (Integer)null,
            (Integer)null,
            (Integer)null
         );
         this.generatorCache.put(this.key(var2), var22);
         this.generatorsById.put(var22.getId(), var22);
         var2.getBlock().setType(this.getPhysicalMaterial(), false);
         this.visualManager.refresh(var22);
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.placed", "%level%", String.valueOf(var23), "%max%", String.valueOf(var12));
         return true;
      }
   }

   public void collectMoney(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         UUID var3 = var2.getOwnerUuid();
         UUID var4 = var1.getUniqueId();
         boolean var5 = this.canCollectGeneratorMoney(var3, var4);
         boolean var6 = this.canCollectGeneratorShards(var3, var4);
         if (!var5 && !var6) {
            this.sendOwnerInfo(var1, var2);
         } else {
            double var7 = var2.getStoredMoney();
            int var9 = var2.getStoredShards();
            boolean var10 = var5 && var7 > 0.0;
            boolean var11 = var6 && var9 > 0;
            if (!var10 && !var11) {
               if (var7 <= 0.0 && var9 <= 0) {
                  this.plugin.getMessageUtil().sendActionBar(var1, "generator.nothing-to-collect");
               } else {
                  this.sendOwnerInfo(var1, var2);
               }
            } else {
               if (var10) {
                  this.collectPaperMoney(var1, var2, var7);
               }

               if (var11) {
                  this.collectShards(var1, var2, var9);
               }

               this.visualManager.refresh(var2);
            }
         }
      }
   }

   private void collectPaperMoney(Player var1, GeneratorData var2, double var3) {
      if (!this.generatorRepository.setStoredMoney(var2.getId(), 0.0)) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.collect-error");
      } else {
         ItemStack var5 = this.moneyItemManager.createMoney(var3);
         HashMap<Integer, ItemStack> var6 = var1.getInventory().addItem(new ItemStack[]{var5});

         for (ItemStack var8 : var6.values()) {
            var1.getWorld().dropItemNaturally(var1.getLocation(), var8);
         }

         var2.setStoredMoney(0.0);
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.money-collected", "%money%", this.format(var3));
      }
   }

   private void collectShards(Player var1, GeneratorData var2, int var3) {
      if (!this.zShardHook.isAvailable()) {
         this.plugin.getMessageUtil().sendActionBar(var1, "generator.shard-unavailable", "%shards%", String.valueOf(var3));
      } else {
         boolean var4 = this.zShardHook.addShards(var1.getUniqueId(), var3);
         if (!var4) {
            this.plugin.getMessageUtil().sendActionBar(var1, "generator.shard-error");
         } else if (!this.generatorRepository.setStoredShards(var2.getId(), 0)) {
            this.zShardHook.removeShards(var1.getUniqueId(), var3);
            this.plugin.getMessageUtil().sendActionBar(var1, "generator.shard-error");
         } else {
            var2.setStoredShards(0);
            this.plugin.getMessageUtil().sendActionBar(var1, "generator.shards-collected", "%shards%", String.valueOf(var3));
         }
      }
   }

   public boolean upgrade(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         UUID var3 = var2.getOwnerUuid();
         UUID var4 = var1.getUniqueId();
         if (!this.canUpgradeGenerator(var3, var4)) {
            this.sendOwnerInfo(var1, var2);
            return false;
         } else if (var2.getLevel() >= this.getMaxLevel()) {
            this.plugin.getMessageUtil().sendActionBar(var1, "generator.max-level");
            return false;
         } else {
            double var5 = this.getUpgradePrice(var2.getLevel());
            if (!this.economyManager.has(var1, var5)) {
               this.plugin.getMessageUtil().sendActionBar(var1, "generator.not-enough-money", "%price%", this.format(var5));
               return false;
            } else if (!this.economyManager.withdraw(var1, var5)) {
               this.plugin.getMessageUtil().sendActionBar(var1, "general.economy-error");
               return false;
            } else {
               int var7 = var2.getLevel() + 1;
               if (!this.generatorRepository.updateLevel(var2.getId(), var7)) {
                  this.economyManager.deposit(var1, var5);
                  this.plugin.getMessageUtil().sendActionBar(var1, "general.database-error");
                  return false;
               } else {
                  var2.setLevel(var7);
                  this.visualManager.refresh(var2);
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(
                        var1,
                        "generator.upgraded",
                        "%level%",
                        String.valueOf(var7),
                        "%money%",
                        this.format(this.getMoneyPerCycle(var7)),
                        "%price%",
                        this.format(var5)
                     );
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean removeByOwner(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         if (RaidSessionBridge.isUnderRaid(var1.getUniqueId())) {
            var1.sendMessage("§cRaid yiyorsun! Raid süresi bitene kadar jeneratörlerini kıramazsın.");
            return false;
         }

         if (!TeamPermissionBridge.generatorOwnerOrAllowed(var2.getOwnerUuid(), var1.getUniqueId())) {
            return false;
         }

         if (var1.hasPermission("zgenpvp.generator.adminbreak") || !(var2.getStoredMoney() > 0.0) && var2.getStoredShards() <= 0) {
            boolean var3 = var2.hasLinkedChest();
            boolean var4 = this.generatorRepository.delete(var2.getId());
            if (!var4 && this.generatorRepository.existsById(var2.getId())) {
               return false;
            }

            this.generatorCache.remove(this.key(var2));
            this.generatorsById.remove(var2.getId());
            this.transferRetryAt.remove(var2.getId());
            this.visualManager.remove(var2.getId());
            this.moneyRewardEntities.remove(var2.getId());
            if (this.plugin.getConfigManager().getGenerators().getBoolean("owner-break.return-item", true)) {
               ItemStack var5 = this.createGeneratorItem(var2.getLevel());
               var1.getWorld().dropItemNaturally(var1.getLocation(), var5);
            }

            if (var3) {
               this.giveGeneratorLinker(var1, 1, var2.getLocation());
            }

            this.plugin.getMessageUtil().sendActionBar(var1, "generator.removed", "%level%", String.valueOf(var2.getLevel()));
            return true;
         } else {
            this.plugin.getMessageUtil().sendActionBar(var1, "generator.collect-before-remove");
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean removeByEnemy(Player var1, GeneratorData var2) {
      if (var1 != null && var2 != null) {
         UUID var3 = var1.getUniqueId();
         UUID var4 = var2.getOwnerUuid();
         if (!var4.equals(var3) && !this.areTeammates(var4, var3)) {
            Location var5 = var2.getLocation();
            double var6 = var2.getStoredMoney();
            int var8 = var2.getStoredShards();
            boolean var9 = var2.hasLinkedChest();
            if (!this.generatorRepository.delete(var2.getId())) {
               return false;
            }

            this.generatorCache.remove(this.key(var2));
            this.generatorsById.remove(var2.getId());
            this.transferRetryAt.remove(var2.getId());
            this.visualManager.remove(var2.getId());
            this.moneyRewardEntities.remove(var2.getId());
            if (var5 != null && var5.getWorld() != null) {
               Location var10 = var5.clone().add(0.5, 0.7, 0.5);
               ItemStack var11 = this.createGeneratorItem(var2.getLevel());
               if (var11 != null) {
                  var5.getWorld().dropItemNaturally(var10, var11);
               }

               if (var9) {
                  this.dropGeneratorLinker(var10, 1);
               }

               if (var6 > 0.0) {
                  ItemStack var12 = this.moneyItemManager.createMoney(var6);
                  if (var12 != null) {
                     this.dropReward(var10, var12, var4);
                  }
               }

               for (ItemStack var13 : this.createShardStacks(var8)) {
                  this.dropReward(var10, var13, var4);
               }
            }

            this.plugin.getMessageUtil().sendActionBar(var1, "generator.enemy-removed");
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void giveGeneratorLinker(Player var1, int var2, Location var3) {
      if (var1 != null && var2 > 0 && this.plugin.getGeneratorLinkItem() != null) {
         for (int var4 = 0; var4 < var2; var4++) {
            ItemStack var5 = this.plugin.getGeneratorLinkItem().create();
            if (var5 != null && !var5.getType().isAir()) {
               Location var6 = var3 != null && var3.getWorld() != null ? var3 : var1.getLocation();
               var6.getWorld().dropItemNaturally(var6.clone().add(0.5, 0.5, 0.5), var5);
            }
         }
      }
   }

   private void dropGeneratorLinker(Location var1, int var2) {
      if (var1 != null && var1.getWorld() != null && var2 > 0 && this.plugin.getGeneratorLinkItem() != null) {
         for (int var3 = 0; var3 < var2; var3++) {
            ItemStack var4 = this.plugin.getGeneratorLinkItem().create();
            if (var4 != null && !var4.getType().isAir()) {
               var1.getWorld().dropItemNaturally(var1, var4);
            }
         }
      }
   }

   public void tickGeneration() {
      if (!this.isEnabled()) {
         this.flushPendingGenerationXp();
         this.resetGenerationSweep();
      } else {
         long var1 = System.currentTimeMillis();
         if (this.generationSweepCursor >= this.generationSweep.size()) {
            this.generationSweep.clear();
            this.generationSweepCursor = 0;
            this.onlineGenerationOwners.clear();
            this.offlineGenerationOwners.clear();
            this.poweredSweepCache.clear();
            if (var1 < this.nextGenerationSweepAt) {
               return;
            }

            this.generationSweep.addAll(this.generatorCache.values());
            int var3 = Math.max(1, this.plugin.getConfigManager().getGenerators().getInt("generation.processing.sweep-interval-ticks", 20));
            this.nextGenerationSweepAt = var1 + var3 * 50L;
            if (this.generationSweep.isEmpty()) {
               return;
            }
         }

         long var18 = this.getMoneyIntervalMillis();
         long var5 = this.getShardIntervalMillis();
         FileConfiguration var7 = this.plugin.getConfigManager().getGenerators();
         int var8 = Math.max(1, Math.min(500, var7.getInt("generation.processing.batch-size-per-tick", 50)));
         double var9 = Math.max(0.25, Math.min(10.0, var7.getDouble("generation.processing.max-time-per-tick-ms", 2.0)));
         long var11 = System.nanoTime() + (long)(var9 * 1000000.0);
         int var13 = 0;

         while (this.generationSweepCursor < this.generationSweep.size() && var13 < var8) {
            GeneratorData var14 = this.generationSweep.get(this.generationSweepCursor++);
            var13++;
            if (this.generatorsById.get(var14.getId()) == var14) {
               try {
                  this.processGeneration(var14, var1, var18, var5);
               } catch (Throwable var17) {
                  if (var17 instanceof VirtualMachineError var19) {
                     throw var19;
                  }

                  if (var17 instanceof ThreadDeath var16) {
                     throw var16;
                  }

                  this.reportGenerationFailure(var14, var17);
               }
            }

            if (System.nanoTime() >= var11) {
               break;
            }
         }

         if (this.generationSweepCursor >= this.generationSweep.size()) {
            this.generationSweep.clear();
            this.generationSweepCursor = 0;
            this.flushPendingGenerationXp();
            this.onlineGenerationOwners.clear();
            this.offlineGenerationOwners.clear();
         }
      }
   }

   private void processGeneration(GeneratorData var1, long var2, long var4, long var6) {
      if (GenerationGate.shouldProcess(var1)) {
         if (!this.isPoweredCached(var1)) {
            var4 *= 2L;
            var6 *= 2L;
         }

         double var8 = var1.getStoredMoney();
         int var10 = var1.getStoredShards();
         long var11 = var1.getLastMoneyGeneration();
         long var13 = var1.getLastShardGeneration();
         boolean var15 = false;
         boolean var16 = false;
         long var17 = Math.max(0L, (var2 - var11) / var4);
         if (var17 > 0L) {
            var17 = 1L;
            var11 = var2 - var4;
         }

         if (var17 > 0L) {
            var8 += var17 * this.getMoneyPerCycle(var1.getLevel());
            var11 += var17 * var4;
            var15 = true;
            if (this.isGenerationOwnerOnline(var1.getOwnerUuid())) {
               this.pendingGenerationXpUnits.merge(var1.getOwnerUuid(), (double)var17, Double::sum);
            }
         }

         long var19 = Math.max(0L, (var2 - var13) / var6);
         if (var19 > 0L) {
            var19 = 1L;
            var13 = var2 - var6;
         }

         if (var19 > 0L) {
            long var21 = var19 * this.getShardsPerCycle();
            var10 = (int)Math.min(2147483647L, var10 + var21);
            var13 += var19 * var6;
            var15 = true;
         }

         if (var15) {
            boolean var28 = this.generatorRepository.updateGenerationState(var1.getId(), var8, var10, var11, var13);
            if (var28) {
               var16 = true;
               var1.setStoredMoney(var8);
               var1.setStoredShards(var10);
               var1.setLastMoneyGeneration(var11);
               var1.setLastShardGeneration(var13);
            }
         }

         double var29 = var1.getStoredMoney();
         int var23 = var1.getStoredShards();
         boolean var24 = var1.hasLinkedChest();
         if (var29 > 0.0 || var23 > 0) {
            GeneratorManager.RewardTransferResult var25 = this.tryAutoTransferRewards(var1);
            boolean var26 = var25 != GeneratorManager.RewardTransferResult.TRANSFERRED && this.hasHopperOutputCandidate(var1);
            boolean var27 = var25 != GeneratorManager.RewardTransferResult.NO_TARGET || var26;
            this.dropPhysicalRewards(var1, var27);
         }

         if (var16 || Double.compare(var29, var1.getStoredMoney()) != 0 || var23 != var1.getStoredShards() || var24 != var1.hasLinkedChest()) {
            this.visualManager.refresh(var1);
         }
      }
   }

   private boolean isPoweredCached(GeneratorData var1) {
      String var2 = var1.getOwnerUuid() + ":" + var1.getBaseId();
      Boolean var3 = this.poweredSweepCache.get(var2);
      if (var3 == null) {
         var3 = EnergySupport.isPowered(this.plugin, var1);
         this.poweredSweepCache.put(var2, var3);
      }

      return var3;
   }

   public List<GeneratorData> getCachedGenerators() {
      return new ArrayList<>(this.generatorCache.values());
   }

   private void resetGenerationSweep() {
      this.poweredSweepCache.clear();
      this.transferRetryAt.clear();
      this.generationSweep.clear();
      this.generationSweepCursor = 0;
      this.nextGenerationSweepAt = 0L;
      this.hopperTransferSweep.clear();
      this.hopperTransferSweepCursor = 0;
      this.nextHopperTransferRunAt = 0L;
      this.pendingGenerationXpUnits.clear();
      this.onlineGenerationOwners.clear();
      this.offlineGenerationOwners.clear();
   }

   private void reportGenerationFailure(GeneratorData var1, Throwable var2) {
      long var3 = System.currentTimeMillis();
      if (var3 < this.nextGenerationFailureLogAt) {
         this.suppressedGenerationFailures++;
      } else {
         String var5 = this.suppressedGenerationFailures <= 0 ? "" : " (" + this.suppressedGenerationFailures + " ʙᴇɴᴢᴇʀ ʜᴀᴛᴀ ᴛᴇᴋʀᴀʀ ʏᴀᴢɪʟᴍᴀᴅɪ)";
         Logger var6 = this.plugin.getLogger();
         Level var7 = Level.SEVERE;
         long var8 = var1.getId();
         var6.log(
            var7,
            "ᴊᴇɴᴇʀᴀᴛᴏʀ ᴜʀᴇᴛɪᴍɪ/aktarɪᴍɪ ʙᴀꜱᴀʀɪꜱɪᴢ ᴏʟᴅᴜ; ᴅɪɢᴇʀ ᴊᴇɴᴇʀᴀᴛᴏʀʟᴇʀ ᴄᴀʟɪꜱᴍᴀʏᴀ ᴅᴇᴠᴀᴍ ᴇᴅᴇᴄᴇᴋ. ɢᴇɴᴇʀᴀᴛᴏʀɪᴅ="
               + var8
               + ", ʜᴀᴛᴀ="
               + var2.getClass().getSimpleName()
               + ": "
               + var2.getMessage()
               + var5,
            var2
         );
         this.suppressedGenerationFailures = 0;
         this.nextGenerationFailureLogAt = var3 + 30000L;
      }
   }

   private boolean isGenerationOwnerOnline(UUID var1) {
      if (var1 != null && !this.offlineGenerationOwners.contains(var1)) {
         Player var2 = this.onlineGenerationOwners.get(var1);
         if (var2 != null) {
            return var2.isOnline();
         } else {
            Player var3 = Bukkit.getPlayer(var1);
            if (var3 != null && var3.isOnline()) {
               this.onlineGenerationOwners.put(var1, var3);
               return true;
            } else {
               this.offlineGenerationOwners.add(var1);
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void flushPendingGenerationXp() {
      if (!this.pendingGenerationXpUnits.isEmpty()) {
         for (Entry var2 : this.pendingGenerationXpUnits.entrySet()) {
            Player var3 = Bukkit.getPlayer((UUID)var2.getKey());
            double var4 = (Double)var2.getValue();
            if (var3 != null && var3.isOnline() && var4 > 0.0) {
               this.plugin.getXpRewardManager().reward(var3, XpRewardType.GENERATOR_PRODUCTION, var4);
            }
         }

         this.pendingGenerationXpUnits.clear();
      }
   }

   private void dropPhysicalRewards(GeneratorData var1, boolean var2) {
      if (!var1.hasLinkedChest() && !var2) {
         Location var3 = var1.getLocation();
         if (var3 != null && var3.getWorld() != null && var3.getWorld().isChunkLoaded(var3.getBlockX() >> 4, var3.getBlockZ() >> 4)) {
            double var4 = var1.getStoredMoney();
            int var6 = var1.getStoredShards();
            ArrayList<ItemStack> var7 = this.createShardStacks(var6);
            boolean var8 = var4 > 0.0;
            boolean var9 = var6 > 0 && !var7.isEmpty();
            if (var8 || var9) {
               double var10 = var8 ? 0.0 : var4;
               int var12 = var9 ? 0 : var6;
               if (this.generatorRepository.updateGenerationState(var1.getId(), var10, var12, var1.getLastMoneyGeneration(), var1.getLastShardGeneration())) {
                  Location var13 = GeneratorRewardPosition.resolve(var3);
                  if (var8) {
                     this.dropOrMergeMoneyReward(var13, var4, var1);
                     var1.setStoredMoney(0.0);
                  }

                  if (var9) {
                     for (ItemStack var15 : var7) {
                        this.dropReward(var13, var15, var1.getOwnerUuid());
                     }

                     var1.setStoredShards(0);
                  }
               }
            }
         }
      }
   }

   private ArrayList<ItemStack> createShardStacks(int var1) {
      ArrayList var2 = new ArrayList();
      if (var1 > 0 && this.zShardHook.isPhysicalItemAvailable()) {
         int var4 = var1;

         while (var4 > 0) {
            int var3 = Math.min(64, var4);
            ItemStack var5 = this.zShardHook.createShardItem(var3);
            if (var5 == null) {
               var2.clear();
               return var2;
            }

            var2.add(var5);
            var4 -= var3;
         }

         return var2;
      } else {
         return var2;
      }
   }

   private void dropReward(Location var1, ItemStack var2, UUID var3) {
      if (var1 != null && var1.getWorld() != null && var2 != null && !var2.getType().isAir()) {
         ItemStack var4 = this.protectRewardStack(var2, var3, (Long)null, (String)null);
         Item var5 = var1.getWorld().dropItem(var1, var4);
         this.prepareRewardEntity(var5, var3, (Long)null, (String)null);
      }
   }

   private void dropOrMergeMoneyReward(Location var1, double var2, GeneratorData var4) {
      if (var1 != null && var1.getWorld() != null && !(var2 <= 0.0)) {
         Item var5 = this.findMoneyRewardEntity(var4, var1);
         if (var5 != null) {
            double var6 = this.moneyItemManager.getStackValue(var5.getItemStack()) + var2;
            ItemStack var8 = this.moneyItemManager.createMoney(var6);
            var5.setItemStack(this.protectRewardStack(var8, var4.getOwnerUuid(), var4.getId(), "money"));
            var5.setPickupDelay(Math.min(var5.getPickupDelay(), 10));
         } else {
            ItemStack var9 = this.moneyItemManager.createMoney(var2);
            if (var9 != null && !var9.getType().isAir()) {
               ItemStack var7 = this.protectRewardStack(var9, var4.getOwnerUuid(), var4.getId(), "money");
               Item var10 = var1.getWorld().dropItem(var1, var7);
               this.prepareRewardEntity(var10, var4.getOwnerUuid(), var4.getId(), "money");
               this.moneyRewardEntities.put(var4.getId(), var10.getUniqueId());
            }
         }
      }
   }

   private Item findMoneyRewardEntity(GeneratorData var1, Location var2) {
      UUID var3 = this.moneyRewardEntities.get(var1.getId());
      if (var3 != null) {
         if (Bukkit.getEntity(var3) instanceof Item var5
            && var5.isValid()
            && !var5.isDead()
            && var5.getWorld().equals(var2.getWorld())
            && var5.getLocation().distanceSquared(var2) <= 9.0) {
            return var5;
         }

         this.moneyRewardEntities.remove(var1.getId());
      }

      for (Entity var10 : Paper12111Compat.getNearbyEntities(var2.getWorld(), var2, 1.75, 1.75, 1.75)) {
         if (var10 instanceof Item var6 && var6.isValid() && !var6.isDead()) {
            Long var7 = (Long)var6.getPersistentDataContainer().get(this.generatorRewardSourceKey, PersistentDataType.LONG);
            String var8 = (String)var6.getPersistentDataContainer().get(this.generatorRewardKindKey, PersistentDataType.STRING);
            if (var7 != null && var7 == var1.getId() && "money".equals(var8)) {
               this.moneyRewardEntities.put(var1.getId(), var6.getUniqueId());
               return var6;
            }
         }
      }

      return null;
   }

   private ItemStack protectRewardStack(ItemStack var1, UUID var2, Long var3, String var4) {
      ItemStack var5 = var1.clone();
      ItemMeta var6 = var5.getItemMeta();
      if (var6 == null) {
         return var5;
      }

      if (var2 != null) {
         var6.getPersistentDataContainer().set(this.generatorRewardOwnerKey, PersistentDataType.STRING, var2.toString());
      }

      if (var3 != null) {
         var6.getPersistentDataContainer().set(this.generatorRewardSourceKey, PersistentDataType.LONG, var3);
      }

      if (var4 != null) {
         var6.getPersistentDataContainer().set(this.generatorRewardKindKey, PersistentDataType.STRING, var4);
      }

      ItemMetaCompat.apply(var5, var6);
      return var5;
   }

   private void prepareRewardEntity(Item var1, UUID var2, Long var3, String var4) {
      if (var1 != null) {
         GeneratorRewardPosition.freeze(var1);
         var1.setPickupDelay(10);
         if (var2 != null) {
            var1.getPersistentDataContainer().set(this.generatorRewardOwnerKey, PersistentDataType.STRING, var2.toString());
         }

         if (var3 != null) {
            var1.getPersistentDataContainer().set(this.generatorRewardSourceKey, PersistentDataType.LONG, var3);
         }

         if (var4 != null) {
            var1.getPersistentDataContainer().set(this.generatorRewardKindKey, PersistentDataType.STRING, var4);
         }

         this.scheduleRewardEntityMerge(var1);
      }
   }

   private void scheduleRewardEntityMerge(Item var1) {
      FileConfiguration var2 = this.plugin.getConfigManager().getGenerators();
      if (var2.getBoolean("generation.entity-merge.enabled", true)) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.mergeRewardEntity(var1));
      }
   }

   private void mergeRewardEntity(Item var1) {
      if (var1 != null && var1.isValid() && !var1.isDead()) {
         String var2 = (String)var1.getPersistentDataContainer().get(this.generatorRewardOwnerKey, PersistentDataType.STRING);
         if (var2 != null && !var2.isBlank()) {
            FileConfiguration var3 = this.plugin.getConfigManager().getGenerators();
            double var4 = Math.max(0.75, Math.min(5.0, var3.getDouble("generation.entity-merge.radius", 2.25)));
            int var6 = Math.max(4, Math.min(64, var3.getInt("generation.entity-merge.max-nearby-scan", 24)));
            List<Entity> var7 = Paper12111Compat.getNearbyEntities(var1.getWorld(), var1.getLocation(), var4, var4, var4);
            int var8 = 0;

            for (Entity var10 : var7) {
               var8++;
               if (var8 > var6 || !var1.isValid() || var1.isDead()) {
                  break;
               }

               if (var10 instanceof Item var11 && var11 != var1 && var11.isValid() && !var11.isDead()) {
                  String var12 = (String)var11.getPersistentDataContainer().get(this.generatorRewardOwnerKey, PersistentDataType.STRING);
                  if (var2.equals(var12)) {
                     ItemStack var13 = var1.getItemStack();
                     ItemStack var14 = var11.getItemStack();
                     if (var13.isSimilar(var14)) {
                        int var15 = Math.min(var13.getMaxStackSize(), var14.getMaxStackSize());
                        if (var15 > 1 && var14.getAmount() < var15) {
                           int var16 = Math.min(var13.getAmount(), var15 - var14.getAmount());
                           if (var16 > 0) {
                              var14.setAmount(var14.getAmount() + var16);
                              var11.setItemStack(var14);
                              var13.setAmount(var13.getAmount() - var16);
                              if (var13.getAmount() <= 0) {
                                 var1.remove();
                                 return;
                              }

                              var1.setItemStack(var13);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public NamespacedKey getGeneratorRewardOwnerKey() {
      return this.generatorRewardOwnerKey;
   }

   public void tickHopperTransfers() {
      FileConfiguration var1 = this.plugin.getConfigManager().getGenerators();
      if (!var1.getBoolean("hopper-output.enabled", true)) {
         this.hopperTransferSweep.clear();
         this.hopperTransferSweepCursor = 0;
         this.nextHopperTransferRunAt = 0L;
      } else {
         long var2 = System.currentTimeMillis();
         int var4 = Math.max(1, Math.min(200, var1.getInt("hopper-output.processing.interval-ticks", 5)));
         if (var2 >= this.nextHopperTransferRunAt) {
            this.nextHopperTransferRunAt = var2 + var4 * 50L;
            if (this.hopperTransferSweepCursor >= this.hopperTransferSweep.size()) {
               this.hopperTransferSweep.clear();
               this.hopperTransferSweep.addAll(this.generatorCache.values());
               this.hopperTransferSweepCursor = 0;
               if (this.hopperTransferSweep.isEmpty()) {
                  return;
               }
            }

            int var5 = Math.max(1, Math.min(2000, var1.getInt("hopper-output.processing.generators-per-run", 150)));
            double var6 = Math.max(0.1, Math.min(10.0, var1.getDouble("hopper-output.processing.max-time-per-run-ms", 1.0)));
            long var8 = System.nanoTime() + (long)(var6 * 1000000.0);
            int var10 = 0;

            while (this.hopperTransferSweepCursor < this.hopperTransferSweep.size() && var10 < var5) {
               GeneratorData var11 = this.hopperTransferSweep.get(this.hopperTransferSweepCursor++);
               var10++;
               if (this.generatorsById.get(var11.getId()) == var11 && (var11.getStoredMoney() > 0.0 || var11.getStoredShards() > 0)) {
                  try {
                     GeneratorManager.RewardTransferResult var12 = this.tryAutoTransferToHopper(var11);
                     if (var12 == GeneratorManager.RewardTransferResult.TRANSFERRED) {
                        this.visualManager.refresh(var11);
                     }
                  } catch (Throwable var14) {
                     if (var14 instanceof VirtualMachineError var15) {
                        throw var15;
                     }

                     if (var14 instanceof ThreadDeath var13) {
                        throw var13;
                     }

                     this.reportGenerationFailure(var11, var14);
                  }
               }

               if (System.nanoTime() >= var8) {
                  break;
               }
            }

            if (this.hopperTransferSweepCursor >= this.hopperTransferSweep.size()) {
               this.hopperTransferSweep.clear();
               this.hopperTransferSweepCursor = 0;
            }
         }
      }
   }

   public boolean isHopperOutputEnabled() {
      return this.plugin.getConfigManager().getGenerators().getBoolean("hopper-output.enabled", true);
   }

   private boolean hasHopperOutputCandidate(GeneratorData var1) {
      if (this.isHopperOutputEnabled() && var1 != null) {
         Location var2 = var1.getLocation();
         if (var2 != null && var2.getWorld() != null) {
            int var3 = Math.max(1, this.plugin.getConfigManager().getGenerators().getInt("hopper-output.offset-y", 1));
            Location var4 = var2.clone().add(0.0, var3, 0.0);
            return !var4.getWorld().isChunkLoaded(var4.getBlockX() >> 4, var4.getBlockZ() >> 4) ? false : var4.getBlock().getType() == Material.HOPPER;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private GeneratorManager.RewardTransferResult tryAutoTransferToHopper(GeneratorData var1) {
      FileConfiguration var2 = this.plugin.getConfigManager().getGenerators();
      if (!var2.getBoolean("hopper-output.enabled", true)) {
         return GeneratorManager.RewardTransferResult.NO_TARGET;
      }

      Location var3 = var1.getLocation();
      if (var3 != null && var3.getWorld() != null) {
         int var4 = Math.max(1, var2.getInt("hopper-output.offset-y", 1));
         Location var5 = var3.clone().add(0.0, var4, 0.0);
         if (!var5.getWorld().isChunkLoaded(var5.getBlockX() >> 4, var5.getBlockZ() >> 4)) {
            return GeneratorManager.RewardTransferResult.NO_TARGET;
         } else {
            Block var6 = var5.getBlock();
            if (var6.getType() != Material.HOPPER) {
               return GeneratorManager.RewardTransferResult.NO_TARGET;
            }

            if (!(var6.getState(false) instanceof Hopper var8)) {
               return GeneratorManager.RewardTransferResult.NO_TARGET;
            } else {
               int var9 = Math.max(1, Math.min(32, var2.getInt("hopper-output.processing.max-chain-length", 8)));
               boolean var10 = var2.getBoolean("hopper-output.processing.require-terminal-container", false);
               GeneratorManager.HopperChainStatus var11 = this.inspectHopperChain(var6, var9);
               if (var11 == GeneratorManager.HopperChainStatus.TOO_LONG
                  || var11 == GeneratorManager.HopperChainStatus.LOOP
                  || var11 == GeneratorManager.HopperChainStatus.UNLOADED) {
                  return GeneratorManager.RewardTransferResult.BLOCKED;
               }

               if (var10 && var11 != GeneratorManager.HopperChainStatus.TERMINAL_CONTAINER) {
                  return GeneratorManager.RewardTransferResult.BLOCKED;
               }

               Inventory var12 = var8.getInventory();
               boolean var13 = this.transferMoneyToChest(var1, var12);
               boolean var14 = this.transferShardsToChest(var1, var12);
               return !var13 && !var14 ? GeneratorManager.RewardTransferResult.BLOCKED : GeneratorManager.RewardTransferResult.TRANSFERRED;
            }
         }
      } else {
         return GeneratorManager.RewardTransferResult.NO_TARGET;
      }
   }

   private GeneratorManager.HopperChainStatus inspectHopperChain(Block var1, int var2) {
      HashSet var3 = new HashSet();
      Block var4 = var1;

      for (int var5 = 1; var5 <= var2; var5++) {
         String var6 = var4.getWorld().getUID() + ":" + var4.getX() + ":" + var4.getY() + ":" + var4.getZ();
         if (!var3.add(var6)) {
            return GeneratorManager.HopperChainStatus.LOOP;
         }

         if (!(var4.getState(false) instanceof Hopper)) {
            return GeneratorManager.HopperChainStatus.OPEN_END;
         }

         if (!(var4.getBlockData() instanceof Directional var7)) {
            return GeneratorManager.HopperChainStatus.OPEN_END;
         }

         Block var10 = var4.getRelative(var7.getFacing());
         if (!var10.getWorld().isChunkLoaded(var10.getX() >> 4, var10.getZ() >> 4)) {
            return GeneratorManager.HopperChainStatus.UNLOADED;
         }

         BlockState var9 = var10.getState(false);
         if (!(var9 instanceof Hopper)) {
            if (var9 instanceof Container) {
               return GeneratorManager.HopperChainStatus.TERMINAL_CONTAINER;
            }

            return GeneratorManager.HopperChainStatus.OPEN_END;
         }

         if (var5 >= var2) {
            return GeneratorManager.HopperChainStatus.TOO_LONG;
         }

         var4 = var10;
      }

      return GeneratorManager.HopperChainStatus.TOO_LONG;
   }

   private GeneratorManager.RewardTransferResult tryAutoTransferRewards(GeneratorData var1) {
      long var30 = System.currentTimeMillis();
      Long var31 = this.transferRetryAt.get(var1.getId());
      if (var31 != null && var30 < var31) {
         return GeneratorManager.RewardTransferResult.BLOCKED;
      }

      GeneratorManager.RewardTransferResult var32 = this.tryAutoTransferRewardsNow(var1);
      if (var32 == GeneratorManager.RewardTransferResult.BLOCKED) {
         this.transferRetryAt.put(var1.getId(), var30 + TRANSFER_RETRY_MS);
      } else if (var31 != null) {
         this.transferRetryAt.remove(var1.getId());
      }

      return var32;
   }

   private GeneratorManager.RewardTransferResult tryAutoTransferRewardsNow(GeneratorData var1) {
      FileConfiguration var2 = this.plugin.getConfigManager().getGenerators();
      if (var2.getBoolean("linking.auto-transfer", true) && var1.hasLinkedChest()) {
         Location var3 = var1.getLinkedChestLocation();
         if (var3 != null && var3.getWorld() != null) {
            int var4 = var3.getBlockX() >> 4;
            int var5 = var3.getBlockZ() >> 4;
            if (!var3.getWorld().isChunkLoaded(var4, var5)) {
               return GeneratorManager.RewardTransferResult.BLOCKED;
            }

            if (!(var3.getBlock().getState(false) instanceof Container var7)) {
               if (this.generatorRepository.clearLinkedChest(var1.getId())) {
                  var1.clearLinkedChest();
                  this.visualManager.refresh(var1);
               }

               return GeneratorManager.RewardTransferResult.NO_TARGET;
            } else {
               Inventory var8 = var7.getInventory();
               boolean var9 = this.transferMoneyToChest(var1, var8);
               boolean var10 = this.transferShardsToChest(var1, var8);
               return !var9 && !var10 ? GeneratorManager.RewardTransferResult.BLOCKED : GeneratorManager.RewardTransferResult.TRANSFERRED;
            }
         } else {
            return GeneratorManager.RewardTransferResult.BLOCKED;
         }
      } else {
         return GeneratorManager.RewardTransferResult.NO_TARGET;
      }
   }

   private boolean transferMoneyToChest(GeneratorData var1, Inventory var2) {
      double var3 = var1.getStoredMoney();
      if (var3 <= 0.0) {
         return false;
      }

      ItemStack var5 = this.moneyItemManager.createMoney(var3);
      if (var5 == null) {
         return false;
      }

      HashMap var6 = var2.addItem(new ItemStack[]{var5});
      if (!var6.isEmpty()) {
         return false;
      }

      if (!this.generatorRepository.setStoredMoney(var1.getId(), 0.0)) {
         boolean var7 = this.removeOneMoneyItem(var2, var3);
         if (!var7) {
            Logger var8 = this.plugin.getLogger();
            long var9 = var1.getId();
            var8.severe("ᴋʀɪᴛɪᴋ: ɢᴇɴᴇʀᴀᴛᴏʀ ᴘᴀʀᴀ ᴀᴜᴛᴏ-ᴛʀᴀɴꜱꜰᴇʀ ʀᴏʟʟʙᴀᴄᴋ ʙᴀꜱᴀʀɪꜱɪᴢ! ɢᴇɴᴇʀᴀᴛᴏʀɪᴅ=" + var9 + ", ᴠᴀʟᴜᴇ=" + var3);
         }

         return false;
      } else {
         var1.setStoredMoney(0.0);
         return true;
      }
   }

   private boolean transferShardsToChest(GeneratorData var1, Inventory var2) {
      int var3 = var1.getStoredShards();
      if (var3 <= 0) {
         return false;
      }

      ArrayList<ItemStack> var4 = this.createShardStacks(var3);
      if (var4.isEmpty()) {
         return false;
      }

      ItemStack[] var5 = this.cloneInventoryContents(var2.getContents());

      for (ItemStack var7 : var4) {
         HashMap var8 = var2.addItem(new ItemStack[]{var7});
         if (!var8.isEmpty()) {
            var2.setContents(var5);
            return false;
         }
      }

      if (!this.generatorRepository.setStoredShards(var1.getId(), 0)) {
         var2.setContents(var5);
         return false;
      } else {
         var1.setStoredShards(0);
         return true;
      }
   }

   private ItemStack[] cloneInventoryContents(ItemStack[] var1) {
      ItemStack[] var2 = new ItemStack[var1.length];

      for (int var3 = 0; var3 < var1.length; var3++) {
         var2[var3] = var1[var3] == null ? null : var1[var3].clone();
      }

      return var2;
   }

   private boolean removeOneMoneyItem(Inventory var1, double var2) {
      for (int var4 = 0; var4 < var1.getSize(); var4++) {
         ItemStack var5 = var1.getItem(var4);
         if (this.moneyItemManager.isMoneyItem(var5)) {
            double var6 = this.moneyItemManager.getMoneyValue(var5);
            if (!(Math.abs(var6 - var2) > 1.0E-4)) {
               if (var5.getAmount() <= 1) {
                  var1.setItem(var4, (ItemStack)null);
               } else {
                  var5.setAmount(var5.getAmount() - 1);
                  var1.setItem(var4, var5);
               }

               return true;
            }
         }
      }

      return false;
   }

   public void refreshChunk(Chunk var1) {
      if (this.generatorCache.isEmpty()) {
         return;
      }

      String var2 = var1.getWorld().getName();

      for (GeneratorData var3 : this.generatorCache.values()) {
         if (var3.getX() >> 4 == var1.getX() && var3.getZ() >> 4 == var1.getZ() && var2.equals(var3.getWorldName())) {
            this.visualManager.refresh(var3);
         }
      }
   }

   private void applyOfflineGeneration(GeneratorData var1) {
      FileConfiguration var2 = this.plugin.getConfigManager().getGenerators();
      long var3 = System.currentTimeMillis();
      if (!var2.getBoolean("offline-generation.enabled", true)) {
         var1.setLastMoneyGeneration(var3);
         var1.setLastShardGeneration(var3);
         this.generatorRepository.updateGenerationState(var1.getId(), var1.getStoredMoney(), var1.getStoredShards(), var3, var3);
      } else {
         long var5 = var2.getLong("offline-generation.max-seconds", 21600L);
         long var7 = Math.max(0L, var3 - var1.getLastMoneyGeneration());
         long var9 = Math.max(0L, var3 - var1.getLastShardGeneration());
         if (var5 >= 0L) {
            long var11 = var5 * 1000L;
            var7 = Math.min(var7, var11);
            var9 = Math.min(var9, var11);
         }

         long var20 = var7 / this.getMoneyIntervalMillis();
         long var13 = var9 / this.getShardIntervalMillis();
         double var15 = var1.getStoredMoney() + var20 * this.getMoneyPerCycle(var1.getLevel());
         long var17 = var1.getStoredShards() + var13 * this.getShardsPerCycle();
         int var19 = (int)Math.min(2147483647L, var17);
         if (this.generatorRepository.updateGenerationState(var1.getId(), var15, var19, var3, var3)) {
            var1.setStoredMoney(var15);
            var1.setStoredShards(var19);
            var1.setLastMoneyGeneration(var3);
            var1.setLastShardGeneration(var3);
         }
      }
   }

   public boolean canCollectGeneratorMoney(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canCollectGeneratorMoney(var1, var2);
      }
   }

   public boolean canCollectGeneratorShards(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canCollectGeneratorShards(var1, var2);
      }
   }

   public boolean canUpgradeGenerator(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canUpgradeGenerator(var1, var2);
      }
   }

   public boolean canLinkGeneratorChest(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().canLinkGeneratorChest(var1, var2);
      }
   }

   public void refreshVisual(GeneratorData var1) {
      if (var1 != null) {
         this.visualManager.refresh(var1);
      }
   }

   public boolean areTeammates(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else {
         return var1.equals(var2) ? true : this.plugin.getZTeamHook() != null && this.plugin.getZTeamHook().areTeammates(var1, var2);
      }
   }

   public boolean canAccessGeneratorChest(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return !this.areTeammates(var1, var2)
            ? true
            : this.plugin.getZTeamHook() != null && TeamPermissionBridge.generatorChestAccess(this.plugin.getZTeamHook(), var1, var2);
      }
   }

   public boolean canPickupGeneratorDrop(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return !this.areTeammates(var1, var2) ? true : this.plugin.getZTeamHook() != null && this.plugin.getZTeamHook().canPickupGeneratorDrop(var1, var2);
      }
   }

   public int getMaxLevel() {
      return Math.max(1, this.plugin.getConfigManager().getGenerators().getInt("max-level", 35));
   }

   public double getMoneyPerCycle(int var1) {
      return this.plugin.getConfigManager().getGenerators().getDouble("levels." + var1 + ".money-per-cycle", var1);
   }

   public double getUpgradePrice(int var1) {
      return this.plugin.getConfigManager().getGenerators().getDouble("levels." + var1 + ".upgrade-price", 0.0);
   }

   public double getMoneyIntervalSeconds() {
      return this.plugin.getConfigManager().getGenerators().getDouble("generation.money-interval-seconds", 5.0);
   }

   private int getShardsPerCycle() {
      return Math.max(0, this.plugin.getConfigManager().getGenerators().getInt("generation.shards-per-cycle", 1));
   }

   private long getMoneyIntervalMillis() {
      return Math.max(100L, (long)(this.getMoneyIntervalSeconds() * 1000.0));
   }

   private long getShardIntervalMillis() {
      double var1 = this.plugin.getConfigManager().getGenerators().getDouble("generation.shard-interval-seconds", 300.0);
      return Math.max(1000L, (long)(var1 * 1000.0));
   }

   public int getGeneratorLimit(int var1) {
      ConfigurationSection var2 = this.plugin.getConfigManager().getConfig().getConfigurationSection("level-system.generator-limits");
      if (var2 == null) {
         return 2;
      }

      int var3 = -1;
      int var4 = 2;

      for (String var6 : var2.getKeys(false)) {
         int var7;
         try {
            var7 = Integer.parseInt(var6);
         } catch (NumberFormatException var9) {
            continue;
         }

         if (var7 <= var1 && var7 > var3) {
            var3 = var7;
            var4 = var2.getInt(var6, var4);
         }
      }

      return Math.max(0, var4);
   }

   public int countGenerators(UUID var1) {
      int var2 = 0;

      for (GeneratorData var4 : this.generatorCache.values()) {
         if (var4.getOwnerUuid().equals(var1)) {
            var2++;
         }
      }

      return var2;
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var2.getWorld() != null && var2.getWorld().getName().equals(var1.getWorldName())) {
         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         double var7 = var1.getRadius();
         return var3 * var3 + var5 * var5 <= var7 * var7;
      } else {
         return false;
      }
   }

   public void sendOwnerInfo(Player var1, GeneratorData var2) {
      OfflinePlayer var3 = this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid());
      String var4 = var3.getName() == null ? "Bilinmeyen" : var3.getName();
      this.plugin.getMessageUtil().sendActionBar(var1, "generator.owner-info", "%owner%", var4);
   }

   public Material getModelMaterial(int var1) {
      int var2 = Math.max(1, Math.min(this.getMaxLevel(), var1));
      return this.getMaterial(this.plugin.getConfigManager().getGenerators().getString("levels." + var2 + ".model.material"), Material.COAL_ORE);
   }

   public int getModelCustomModelData(int var1) {
      int var2 = Math.max(1, Math.min(this.getMaxLevel(), var1));
      return Math.max(0, this.plugin.getConfigManager().getGenerators().getInt("levels." + var2 + ".model.custom-model-data", 0));
   }

   private Material getPhysicalMaterial() {
      return this.getMaterial(this.plugin.getConfigManager().getGenerators().getString("physical-block"), Material.GLASS);
   }

   private Material getMaterial(String var1, Material var2) {
      if (var1 == null) {
         return var2;
      }

      Material var3 = Material.matchMaterial(var1);
      return var3 == null ? var2 : var3;
   }

   private String key(GeneratorData var1) {
      return this.key(var1.getWorldName(), var1.getX(), var1.getY(), var1.getZ());
   }

   private String key(Location var1) {
      return this.key(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
   }

   private String key(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }

   private String replace(String var1, String... var2) {
      if (var1 == null) {
         return "";
      }

      String var3 = var1;

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(var2[var4], var2[var4 + 1]);
      }

      return var3;
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private enum HopperChainStatus {
      TERMINAL_CONTAINER,
      OPEN_END,
      TOO_LONG,
      LOOP,
      UNLOADED;
   }

   private enum RewardTransferResult {
      NO_TARGET,
      TRANSFERRED,
      BLOCKED;
   }
}
