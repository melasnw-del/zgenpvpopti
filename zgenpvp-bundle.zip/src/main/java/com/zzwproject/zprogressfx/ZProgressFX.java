package com.zzwproject.zprogressfx;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

public final class ZProgressFX extends LegacyPluginBase implements Listener {
   private Plugin daily;
   private Plugin genpvp;
   private final Map<UUID, Integer> levelCache = new ConcurrentHashMap<>();
   private final Map<UUID, ZProgressFX.DailyAttempt> dailyAttempts = new ConcurrentHashMap<>();
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

   @Override
   public void onEnable() {
      this.saveDefaultConfig();
      this.daily = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZDailyRewards");
      this.genpvp = (Plugin)BundleResolver.getPlugin(Bukkit.getPluginManager(), "ZGenPvP");
      Bukkit.getPluginManager().registerEvents(this, this);
      long var1 = Math.max(5L, this.getConfig().getLong("level-up.scan-interval-ticks", 10L));
      Bukkit.getScheduler().runTaskTimer(this, this::scanLevels, 20L, var1);
      this.getLogger().info("ZProgressFX aktif: günlük ödül ve seviye animasyonları hazır.");
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void captureDailyClick(InventoryClickEvent var1) {
      if (this.getConfig().getBoolean("daily-claim.enabled", true) && this.daily != null && this.daily.isEnabled()) {
         if (var1.getWhoClicked() instanceof Player var2) {
            Inventory var10 = var1.getView() == null ? null : var1.getView().getTopInventory();
            if (this.isDailyMenu(var10)) {
               int var4 = this.dailyDayAtSlot(var1.getRawSlot());
               if (var4 >= 1) {
                  Object var5 = this.dailyState(var2);
                  if (var5 != null) {
                     boolean var6 = this.boolCall(var5, "canClaim", false);
                     int var7 = this.intCall(var5, "nextDay", -1);
                     int var8 = this.intCall(var5, "weekProgress", -1);
                     int var9 = this.intCall(var5, "streak", -1);
                     if (var6 && var7 == var4) {
                        this.dailyAttempts.put(var2.getUniqueId(), new ZProgressFX.DailyAttempt(var4, var8, var9, System.currentTimeMillis()));
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void verifyDailyClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player var2) {
         ZProgressFX.DailyAttempt var4 = this.dailyAttempts.remove(var2.getUniqueId());
         if (var4 != null && System.currentTimeMillis() - var4.at <= 3000L) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
               Object var3 = this.dailyState(var2);
               if (var3 != null) {
                  int var4x = this.intCall(var3, "weekProgress", -1);
                  int var5 = this.intCall(var3, "streak", -1);
                  if (var4x != var4.progress || var5 != var4.streak) {
                     this.playDailyClaim(var2, var4.day, Math.max(var5, var4.streak + 1));
                  }
               }
            }, 1L);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onDailyOpen(InventoryOpenEvent var1) {
      if (var1.getPlayer() instanceof Player var2) {
         if (this.isDailyMenu(var1.getInventory())) {
            if (this.getConfig().getBoolean("daily-menu-open.enabled", true)) {
               this.playSound(
                  var2,
                  "daily-menu-open.sound",
                  "BLOCK_AMETHYST_BLOCK_CHIME",
                  (float)this.getConfig().getDouble("daily-menu-open.volume", 0.35),
                  (float)this.getConfig().getDouble("daily-menu-open.pitch", 1.55)
               );
               this.particle(var2, this.getConfig().getString("daily-menu-open.particle", "ENCHANT"), 10, 0.35, 0.35, 0.35, 0.01, 0.9);
            }
         }
      }
   }

   private void scanLevels() {
      if (this.getConfig().getBoolean("level-up.enabled", true) && this.genpvp != null && this.genpvp.isEnabled()) {
         HashSet var1 = new HashSet();

         for (Player var3 : Bukkit.getOnlinePlayers()) {
            var1.add(var3.getUniqueId());
            int var4 = this.genLevel(var3.getUniqueId());
            if (var4 >= 1) {
               Integer var5 = this.levelCache.putIfAbsent(var3.getUniqueId(), var4);
               if (var5 != null) {
                  if (var4 > var5) {
                     this.levelCache.put(var3.getUniqueId(), var4);
                     this.playLevelUp(var3, var5, var4);
                  } else if (var4 < var5) {
                     this.levelCache.put(var3.getUniqueId(), var4);
                  }
               }
            }
         }

         this.levelCache.keySet().removeIf(var1x -> !var1.contains(var1x));
      }
   }

   private void playDailyClaim(Player var1, int var2, int var3) {
      FileConfiguration var4 = this.getConfig();
      if (var4.getBoolean("daily-claim.title.enabled", true)) {
         String var5 = this.replace(var4.getString("daily-claim.title.title", "&#55E6C1ÖDÜL ALINDI!"), "%day%", var2, "%streak%", var3);
         String var6 = this.replace(var4.getString("daily-claim.title.subtitle", "&fGün %day% &8• &aSeri %streak%"), "%day%", var2, "%streak%", var3);
         var1.sendTitle(
            this.color(var5),
            this.color(var6),
            var4.getInt("daily-claim.title.fade-in", 5),
            var4.getInt("daily-claim.title.stay", 32),
            var4.getInt("daily-claim.title.fade-out", 10)
         );
      }

      this.playSound(var1, "daily-claim.sounds.first.sound", "ENTITY_EXPERIENCE_ORB_PICKUP", 0.7F, 1.4F);
      this.ring(var1, "daily-claim.particles.primary", "HAPPY_VILLAGER", 1.0, 0.15, 18);
      Bukkit.getScheduler().runTaskLater(this, () -> {
         this.ring(var1, "daily-claim.particles.secondary", "END_ROD", 1.35, 0.55, 22);
         this.playSound(var1, "daily-claim.sounds.second.sound", "BLOCK_AMETHYST_BLOCK_CHIME", 0.8F, 1.45F);
      }, 5L);
      Bukkit.getScheduler()
         .runTaskLater(
            this,
            () -> {
               this.particle(var1, var4.getString("daily-claim.particles.burst", "TOTEM_OF_UNDYING"), var2 == 7 ? 38 : 22, 0.55, 0.8, 0.55, 0.08, 1.0);
               this.playSound(
                  var1, "daily-claim.sounds.final.sound", var2 == 7 ? "UI_TOAST_CHALLENGE_COMPLETE" : "ENTITY_PLAYER_LEVELUP", 0.85F, var2 == 7 ? 1.15F : 1.35F
               );
            },
            11L
         );
   }

   private void playLevelUp(Player var1, int var2, int var3) {
      FileConfiguration var4 = this.getConfig();
      boolean var5 = this.isMilestone(var3);
      if (var4.getBoolean("level-up.title.enabled", true)) {
         String var6 = LevelTextFix.fixTitle(
            this.replace(var4.getString("level-up.title.title", "&#FFB347seviye atladin!"), "%level%", var3, "%old_level%", var2)
         );
         String var7 = LevelTextFix.fixSubtitle(
            this.replace(var4.getString("level-up.title.subtitle", "&7yeni seviyen: &f%level%"), "%level%", var3, "%old_level%", var2)
         );
         var1.sendTitle(
            this.color(var6),
            this.color(var7),
            var4.getInt("level-up.title.fade-in", 6),
            var4.getInt("level-up.title.stay", 38),
            var4.getInt("level-up.title.fade-out", 12)
         );
      }

      this.playSound(var1, "level-up.sounds.first.sound", "BLOCK_BEACON_POWER_SELECT", 0.65F, 1.25F);
      this.ring(var1, "level-up.particles.ring", "END_ROD", 1.05, 0.2, 20);
      Bukkit.getScheduler().runTaskLater(this, () -> {
         this.ring(var1, "level-up.particles.ring-two", "ENCHANT", 1.45, 0.75, 26);
         this.particle(var1, var4.getString("level-up.particles.rise", "ELECTRIC_SPARK"), 24, 0.35, 1.0, 0.35, 0.04, 1.2);
         this.playSound(var1, "level-up.sounds.second.sound", "ENTITY_PLAYER_LEVELUP", 0.9F, 1.22F);
      }, 6L);
      Bukkit.getScheduler()
         .runTaskLater(
            this,
            () -> {
               this.particle(
                  var1,
                  var4.getString(var5 ? "level-up.particles.milestone-burst" : "level-up.particles.burst", var5 ? "TOTEM_OF_UNDYING" : "HAPPY_VILLAGER"),
                  var5 ? 48 : 26,
                  0.65,
                  0.8,
                  0.65,
                  0.06,
                  1.0
               );
               if (var5) {
                  this.playSound(var1, "level-up.sounds.milestone.sound", "UI_TOAST_CHALLENGE_COMPLETE", 1.0F, 1.1F);
               }
            },
            13L
         );
   }

   private boolean isMilestone(int var1) {
      String var2 = this.getConfig().getString("level-up.milestone-levels", "10,25,50,75,100,150,200");

      for (String var6 : var2.split(",")) {
         try {
            if (Integer.parseInt(var6.trim()) == var1) {
               return true;
            }
         } catch (Exception var8) {
         }
      }

      return false;
   }

   private boolean isDailyMenu(Inventory var1) {
      return var1 != null && var1.getHolder() != null
         ? "com.zzwproject.zdailyrewards.gui.DailyMenuHolder".equals(var1.getHolder().getClass().getName())
         : false;
   }

   private int dailyDayAtSlot(int var1) {
      try {
         Object var2 = this.daily.getClass().getMethod("menu").invoke(this.daily);
         Object var3 = var2.getClass().getMethod("dayAtSlot", int.class).invoke(var2, var1);
         return ((Number)var3).intValue();
      } catch (Exception var4) {
         return -1;
      }
   }

   private Object dailyState(Player var1) {
      try {
         Object var2 = this.daily.getClass().getMethod("rewards").invoke(this.daily);
         return var2.getClass().getMethod("state", Player.class).invoke(var2, var1);
      } catch (Exception var3) {
         return null;
      }
   }

   private int genLevel(UUID var1) {
      try {
         Object var2 = this.genpvp.getClass().getMethod("getLevelManager").invoke(this.genpvp);
         Object var3 = var2.getClass().getMethod("getLevel", UUID.class).invoke(var2, var1);
         return ((Number)var3).intValue();
      } catch (Exception var4) {
         return -1;
      }
   }

   private int intCall(Object var1, String var2, int var3) {
      try {
         return ((Number)var1.getClass().getMethod(var2).invoke(var1)).intValue();
      } catch (Exception var5) {
         return var3;
      }
   }

   private boolean boolCall(Object var1, String var2, boolean var3) {
      try {
         return (Boolean)var1.getClass().getMethod(var2).invoke(var1);
      } catch (Exception var5) {
         return var3;
      }
   }

   private void ring(Player var1, String var2, String var3, double var4, double var6, int var8) {
      String var9 = this.getConfig().getString(var2, var3);

      Particle var10;
      try {
         var10 = Particle.valueOf(var9.toUpperCase(Locale.ROOT));
      } catch (Exception var16) {
         return;
      }

      Location var11 = var1.getLocation().clone().add(0.0, var6, 0.0);

      for (int var12 = 0; var12 < var8; var12++) {
         double var13 = (Math.PI * 2) * var12 / var8;
         Location var15 = var11.clone().add(Math.cos(var13) * var4, 0.12 * Math.sin(var13 * 2.0), Math.sin(var13) * var4);
         var1.spawnParticle(var10, var15, 1, 0.0, 0.0, 0.0, 0.0);
      }
   }

   private void particle(Player var1, String var2, int var3, double var4, double var6, double var8, double var10, double var12) {
      try {
         Particle var14 = Particle.valueOf(var2.toUpperCase(Locale.ROOT));
         var1.spawnParticle(var14, var1.getLocation().clone().add(0.0, var12, 0.0), var3, var4, var6, var8, var10);
      } catch (Exception var15) {
      }
   }

   private void playSound(Player var1, String var2, String var3, float var4, float var5) {
      String var6 = this.getConfig().getString(var2, var3);

      try {
         var1.playSound(var1.getLocation(), Sound.valueOf(var6.toUpperCase(Locale.ROOT)), var4, var5);
      } catch (Exception var8) {
      }
   }

   private String replace(String var1, Object... var2) {
      String var3 = var1 == null ? "" : var1;

      for (byte var4 = 0; var4 + 1 < var2.length; var4 += 2) {
         var3 = var3.replace(String.valueOf(var2[var4]), String.valueOf(var2[var4 + 1]));
      }

      return var3;
   }

   private String color(String var1) {
      if (var1 == null) {
         return "";
      }

      Matcher var2 = HEX.matcher(var1);
      StringBuffer var3 = new StringBuffer();

      while (var2.find()) {
         String var4 = var2.group(1);
         StringBuilder var5 = new StringBuilder("§x");

         for (char var9 : var4.toCharArray()) {
            var5.append('§').append(var9);
         }

         var2.appendReplacement(var3, Matcher.quoteReplacement(var5.toString()));
      }

      var2.appendTail(var3);
      return var3.toString().replace('&', '§').replace("§l", "").replace("§L", "").replace("§o", "").replace("§O", "");
   }

   private record DailyAttempt(int day, int progress, int streak, long at) {
   }
}
