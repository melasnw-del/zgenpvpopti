package com.zzwproject.beaconfix;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.bundle.LegacyPluginBase;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BeaconData;
import java.util.Optional;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public final class ZBeaconSafeRespawn extends LegacyPluginBase implements Listener {
   private ZGenPvP core;
   private int searchRadius;

   @Override
   public void onEnable() {
      this.core = ZGenPvP.getInstance();
      if (this.core == null) {
         this.getLogger().severe("ZGenPvP bulunamadi. Hotfix devre disi birakildi.");
         BundleResolver.disablePlugin(this.getServer().getPluginManager(), this);
      } else {
         this.saveDefaultConfig();
         this.searchRadius = Math.max(1, Math.min(8, this.getConfig().getInt("same-floor-search-radius", 4)));
         this.getServer().getPluginManager().registerEvents(this, this);
         this.getLogger().info("Fener guvenli respawn hotfix aktif. Ust kata isinlanma engellendi.");
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onTeleport(PlayerTeleportEvent var1) {
      if (var1.getCause() == TeleportCause.PLUGIN) {
         Location var2 = var1.getTo();
         Player var3 = var1.getPlayer();
         if (var2 != null && var2.getWorld() != null && this.core != null) {
            double var4 = this.core.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.x", 0.5);
            double var6 = this.core.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.y", 1.1);
            double var8 = this.core.getConfigManager().getConfig().getDouble("beacon.respawn.teleport-offset.z", 0.5);
            int var10 = this.floorNearInteger(var2.getX() - var4);
            int var11 = this.floorNearInteger(var2.getY() - var6);
            int var12 = this.floorNearInteger(var2.getZ() - var8);
            Location var13 = new Location(var2.getWorld(), var10, var11, var12);
            Optional var14 = this.core.getBeaconRepository().findByLocation(var13);
            if (!var14.isEmpty()) {
               BeaconData var15 = (BeaconData)var14.get();
               if (this.core.getBeaconManager().canUseBeacon(var3, var15)) {
                  Location var16 = (Location)BeaconTeleportFallback.find(this, var13, var2.getYaw(), var2.getPitch());
                  if (var16 != null) {
                     var1.setTo(var16);
                  } else {
                     var1.setCancelled(true);
                     var3.sendMessage("§bGenPvP §8» §cFenerinin bulunduğu katta güvenli bir ışınlanma alanı yok.");
                     var3.sendMessage("§7Fenerin çevresinde oyuncu için en az 2 blok yüksekliğinde boş alan bırak.");
                  }
               }
            }
         }
      }
   }

   private Location findSameFloorSafeLocation(Location var1, float var2, float var3) {
      World var4 = var1.getWorld();
      if (var4 == null) {
         return null;
      }

      int var5 = var1.getBlockY() + 1;
      int var6 = var1.getBlockX();
      int var7 = var1.getBlockZ();
      if (this.isSafe(var4, var6, var5, var7)) {
         return this.centered(var4, var6, var5, var7, var2, var3);
      }

      for (int var8 = 1; var8 <= this.searchRadius; var8++) {
         int[][] var9 = new int[][]{{var8, 0}, {-var8, 0}, {0, var8}, {0, -var8}};

         for (int[] var13 : var9) {
            int var14 = var6 + var13[0];
            int var15 = var7 + var13[1];
            if (this.isSafe(var4, var14, var5, var15)) {
               return this.centered(var4, var14, var5, var15, var2, var3);
            }
         }

         for (int var16 = -var8; var16 <= var8; var16++) {
            for (int var17 = -var8; var17 <= var8; var17++) {
               if (Math.max(Math.abs(var16), Math.abs(var17)) == var8) {
                  int var18 = var6 + var16;
                  int var19 = var7 + var17;
                  if (this.isSafe(var4, var18, var5, var19)) {
                     return this.centered(var4, var18, var5, var19, var2, var3);
                  }
               }
            }
         }
      }

      return null;
   }

   private boolean isSafe(World var1, int var2, int var3, int var4) {
      Block var5 = var1.getBlockAt(var2, var3 - 1, var4);
      Block var6 = var1.getBlockAt(var2, var3, var4);
      Block var7 = var1.getBlockAt(var2, var3 + 1, var4);
      Material var8 = var5.getType();
      return var8.isSolid() && !this.dangerousFloor(var8) ? var6.getType().isAir() && var7.getType().isAir() : false;
   }

   private boolean dangerousFloor(Material var1) {
      String var2 = var1.name();
      return var2.equals("MAGMA_BLOCK")
         || var2.equals("CACTUS")
         || var2.contains("CAMPFIRE")
         || var2.equals("FIRE")
         || var2.equals("SOUL_FIRE")
         || var2.equals("LAVA")
         || var2.equals("POWDER_SNOW");
   }

   private Location centered(World var1, int var2, int var3, int var4, float var5, float var6) {
      return new Location(var1, var2 + 0.5, var3, var4 + 0.5, var5, var6);
   }

   private int floorNearInteger(double var1) {
      double var3 = Math.rint(var1);
      return Math.abs(var1 - var3) < 1.0E-4 ? (int)var3 : (int)Math.floor(var1);
   }
}
