package com.zzwproject.zgenboss.hotfix;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class BossLevelBalance {
   private BossLevelBalance() {
   }

   public static Object selectBossType(Object var0, Object var1, Object var2) {
      try {
         int var3 = generatorLevel(var1);
         String var4 = band(var3);
         Object var5 = invoke(var0, "getConfig");
         List var6 = getStringList(var5, "balance.level-bands." + var4 + ".allowed-bosses");
         if (var6.isEmpty()) {
            var6 = fallbackAllowed(var4);
         }

         if (var6.isEmpty()) {
            return var2;
         }

         String var7 = stringField(var2, "id", "");
         if (!var7.isBlank() && var6.contains(var7) && boolField(var2, "enabled", true)) {
            return var2;
         }

         ArrayList<String> var8 = new ArrayList<String>(var6);

         for (int var9 = var8.size() - 1; var9 > 0; var9--) {
            int var10 = ThreadLocalRandom.current().nextInt(var9 + 1);
            String var11 = (String)var8.get(var9);
            var8.set(var9, (String)var8.get(var10));
            var8.set(var10, var11);
         }

         Method var14 = findDeclared(var0.getClass(), "readBossType", 1);
         if (var14 == null) {
            return var2;
         }

         var14.setAccessible(true);

         for (String var16 : var8) {
            Object var12 = var14.invoke(var0, var16);
            if (var12 != null && boolField(var12, "enabled", true)) {
               return var12;
            }
         }
      } catch (Throwable var13) {
      }

      return var2;
   }

   public static void applySpawn(Object var0, Object var1) {
      try {
         Object var2 = field(var1, "entity");
         Object var3 = field(var1, "type");
         int var4 = bossLevel(var1);
         String var5 = band(var4);
         Object var6 = invoke(var0, "getConfig");
         double var7 = getDouble(var6, "balance.level-bands." + var5 + ".health-multiplier", defaultHealth(var5));
         double var9 = getDouble(var6, "balance.level-bands." + var5 + ".damage-multiplier", defaultDamage(var5));
         double var11 = getDouble(var6, "balance.level-bands." + var5 + ".speed-multiplier", defaultSpeed(var5));
         double var13 = getDouble(var6, "combat.manual-melee.damage-multiplier", 0.72);
         double var15 = number(field(var3, "health"), 40.0);
         double var17 = number(field(var3, "damage"), 3.0);
         double var19 = number(field(var3, "speed"), 0.25);
         double var21 = Math.max(12.0, var15 * var7);
         double var23 = Math.max(0.75, var17 * var13 * var9);
         double var25 = Math.max(0.14, var19 * var11);
         callSetAttribute(var0, var2, new String[]{"MAX_HEALTH", "GENERIC_MAX_HEALTH"}, var21);
         callSetAttribute(var0, var2, new String[]{"ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE"}, var23);
         callSetAttribute(var0, var2, new String[]{"MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED"}, var25);
         tryInvoke(var2, "setHealth", var21);
      } catch (Throwable var27) {
         warn(var0, "Boss level dengeleme hatasi: " + var27.getClass().getSimpleName() + ": " + var27.getMessage());
      }
   }

   public static double scaleDamage(Object var0, Object var1, double var2) {
      try {
         int var4 = bossLevel(var1);
         String var5 = band(var4);
         Object var6 = invoke(var0, "getConfig");
         double var7 = getDouble(var6, "balance.level-bands." + var5 + ".damage-multiplier", defaultDamage(var5));
         return Math.max(0.5, var2 * var7);
      } catch (Throwable var9) {
         return Math.max(0.5, var2);
      }
   }

   public static double scaledHealth(Object var0, Object var1) {
      try {
         Object var2 = field(var1, "type");
         double var3 = number(field(var2, "health"), 40.0);
         String var5 = band(bossLevel(var1));
         Object var6 = invoke(var0, "getConfig");
         double var7 = getDouble(var6, "balance.level-bands." + var5 + ".health-multiplier", defaultHealth(var5));
         return Math.max(12.0, var3 * var7);
      } catch (Throwable var9) {
         return 40.0;
      }
   }

   private static int bossLevel(Object var0) throws Exception {
      return generatorLevel(field(var0, "generator"));
   }

   private static int generatorLevel(Object var0) throws Exception {
      if (var0 == null) {
         return 1;
      }

      try {
         return ((Number)field(var0, "level")).intValue();
      } catch (Throwable var4) {
         return tryInvoke(var0, "level") instanceof Number var3 ? var3.intValue() : 1;
      }
   }

   private static String band(int var0) {
      if (var0 <= 20) {
         return "weak";
      } else {
         return var0 <= 30 ? "medium" : "strong";
      }
   }

   private static double defaultHealth(String var0) {
      return switch (var0) {
         case "weak" -> 0.35;
         case "medium" -> 0.65;
         default -> 1.0;
      };
   }

   private static double defaultDamage(String var0) {
      return switch (var0) {
         case "weak" -> 0.35;
         case "medium" -> 0.6;
         default -> 0.9;
      };
   }

   private static double defaultSpeed(String var0) {
      return switch (var0) {
         case "weak" -> 0.9;
         case "medium" -> 0.98;
         default -> 1.02;
      };
   }

   private static List<String> fallbackAllowed(String var0) {
      return switch (var0) {
         case "weak" -> List.of("core_guardian", "dune_guardian");
         case "medium" -> List.of("core_guardian", "dune_guardian", "shadow_hunter", "prison_hunter", "cave_stalker", "end_watcher", "drowned_raider");
         default -> List.of(
            "core_guardian",
            "shadow_hunter",
            "flame_keeper",
            "dune_guardian",
            "prison_hunter",
            "end_watcher",
            "wither_knight",
            "swamp_alchemist",
            "drowned_raider",
            "cave_stalker",
            "brute_enforcer",
            "ravager_prime"
         );
      };
   }

   private static void callSetAttribute(Object var0, Object var1, String[] var2, double var3) throws Exception {
      Method var5 = findDeclared(var0.getClass(), "setAttribute", 3);
      if (var5 != null) {
         var5.setAccessible(true);
         var5.invoke(var0, var1, var2, var3);
      }
   }

   private static Method findDeclared(Class<?> var0, String var1, int var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2) {
               return var7;
            }
         }
      }

      return null;
   }

   private static List<String> getStringList(Object var0, String var1) {
      try {
         if (invoke(var0, "getStringList", var1) instanceof List var3) {
            ArrayList var4 = new ArrayList();

            for (Object var6 : var3) {
               if (var6 != null) {
                  var4.add(String.valueOf(var6));
               }
            }

            return var4;
         }
      } catch (Throwable var7) {
      }

      return List.of();
   }

   private static double getDouble(Object var0, String var1, double var2) {
      try {
         return invoke(var0, "getDouble", var1, var2) instanceof Number var5 ? var5.doubleValue() : var2;
      } catch (Throwable var6) {
         return var2;
      }
   }

   private static Object field(Object var0, String var1) throws Exception {
      for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3.get(var0);
         } catch (NoSuchFieldException var4) {
         }
      }

      throw new NoSuchFieldException(var1);
   }

   private static boolean boolField(Object var0, String var1, boolean var2) {
      try {
         return field(var0, var1) instanceof Boolean var4 ? var4 : var2;
      } catch (Throwable var5) {
         return var2;
      }
   }

   private static String stringField(Object var0, String var1, String var2) {
      try {
         Object var3 = field(var0, var1);
         return var3 == null ? var2 : String.valueOf(var3);
      } catch (Throwable var4) {
         return var2;
      }
   }

   private static double number(Object var0, double var1) {
      return var0 instanceof Number var3 ? var3.doubleValue() : var1;
   }

   private static Object invoke(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = null;

      for (Method var7 : var0.getClass().getMethods()) {
         if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length && compatible(var7.getParameterTypes(), var2)) {
            var3 = var7;
            break;
         }
      }

      if (var3 == null) {
         for (Class var9 = var0.getClass(); var9 != null && var3 == null; var9 = var9.getSuperclass()) {
            for (Method var8 : var9.getDeclaredMethods()) {
               if (var8.getName().equals(var1) && var8.getParameterCount() == var2.length && compatible(var8.getParameterTypes(), var2)) {
                  var3 = var8;
                  break;
               }
            }
         }
      }

      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Object tryInvoke(Object var0, String var1, Object... var2) {
      try {
         return invoke(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static boolean compatible(Class<?>[] var0, Object[] var1) {
      for (int var2 = 0; var2 < var0.length; var2++) {
         if (var1[var2] == null) {
            if (var0[var2].isPrimitive()) {
               return false;
            }
         } else if (!wrap(var0[var2]).isAssignableFrom(var1[var2].getClass())) {
            return false;
         }
      }

      return true;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }

   private static void warn(Object var0, String var1) {
      try {
         invoke(invoke(var0, "getLogger"), "warning", var1);
      } catch (Throwable var3) {
      }
   }
}
