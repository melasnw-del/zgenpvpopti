package com.zzwproject.zgenpvp.generator.sellwand;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.generator.GeneratorManager;
import com.zzwproject.zgenpvp.hotfix.PlaceholderFix;
import com.zzwproject.zgenpvp.level.XpRewardManager;
import com.zzwproject.zgenpvp.level.XpRewardType;
import com.zzwproject.zgenpvp.model.GeneratorData;
import com.zzwproject.zgenpvp.money.MoneyItemManager;
import com.zzwproject.zgenpvp.repository.GeneratorRepository;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class SellWandManager {
   private final ZGenPvP plugin;
   private final GeneratorRepository generatorRepository;
   private final EconomyManager economyManager;
   private final MoneyItemManager moneyItemManager;
   private final XpRewardManager xpRewardManager;
   private final NamespacedKey sellWandKey;
   private final NamespacedKey remainingUsesKey;
   private final NamespacedKey maxUsesKey;

   public SellWandManager(
      ZGenPvP plugin,
      GeneratorRepository generatorRepository,
      EconomyManager economyManager,
      MoneyItemManager moneyItemManager,
      XpRewardManager xpRewardManager
   ) {
      this.plugin = plugin;
      this.generatorRepository = generatorRepository;
      this.economyManager = economyManager;
      this.moneyItemManager = moneyItemManager;
      this.xpRewardManager = xpRewardManager;
      this.sellWandKey = new NamespacedKey(plugin, "sell_wand");
      this.remainingUsesKey = new NamespacedKey(plugin, "sell_wand_uses");
      this.maxUsesKey = new NamespacedKey(plugin, "sell_wand_max_uses");
   }

   public boolean isEnabled() {
      return this.plugin.getConfigManager().getGenerators().getBoolean("sell-wand.enabled", true);
   }

   public ItemStack createWand(int uses) {
      if (!this.isAllowedUses(uses)) {
         return null;
      }

      FileConfiguration config = this.plugin.getConfigManager().getGenerators();
      String path = "sell-wand.types." + uses;
      Material material = Material.matchMaterial(config.getString(path + ".material", "GOLDEN_HOE"));
      if (material == null) {
         material = Material.GOLDEN_HOE;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      int customModelData = config.getInt(path + ".custom-model-data", 0);
      if (customModelData > 0) {
         meta.setCustomModelData(customModelData);
      }

      meta.getPersistentDataContainer().set(this.sellWandKey, PersistentDataType.BYTE, (byte)1);
      meta.getPersistentDataContainer().set(this.remainingUsesKey, PersistentDataType.INTEGER, uses);
      meta.getPersistentDataContainer().set(this.maxUsesKey, PersistentDataType.INTEGER, uses);
      item.setItemMeta(meta);
      this.updateDisplay(item, uses, uses);
      return item;
   }

   public boolean isSellWand(ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         Byte value = (Byte)item.getItemMeta().getPersistentDataContainer().get(this.sellWandKey, PersistentDataType.BYTE);
         return value != null && value == 1;
      } else {
         return false;
      }
   }

   public int getRemainingUses(ItemStack item) {
      if (!this.isSellWand(item)) {
         return 0;
      }

      Integer uses = (Integer)item.getItemMeta().getPersistentDataContainer().get(this.remainingUsesKey, PersistentDataType.INTEGER);
      return uses == null ? 0 : Math.max(0, uses);
   }

   public int getMaxUses(ItemStack item) {
      if (!this.isSellWand(item)) {
         return 0;
      }

      Integer uses = (Integer)item.getItemMeta().getPersistentDataContainer().get(this.maxUsesKey, PersistentDataType.INTEGER);
      return uses == null ? 0 : Math.max(0, uses);
   }

   public boolean isAllowedUses(int uses) {
      ConfigurationSection section = this.plugin.getConfigManager().getGenerators().getConfigurationSection("sell-wand.types." + uses);
      return section != null;
   }

   public boolean sell(Player player, Block block) {
      if (!this.isEnabled()) {
         this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.disabled");
         return false;
      }

      List<GeneratorData> linkedGenerators = this.generatorRepository.findByLinkedChest(block.getLocation());
      if (linkedGenerators.isEmpty()) {
         this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.not-linked");
         return false;
      }

      for (GeneratorData generator : linkedGenerators) {
         UUID ownerUuid = generator.getOwnerUuid();
         UUID playerUuid = player.getUniqueId();
         if (!ownerUuid.equals(playerUuid)) {
            GeneratorManager generatorManager = this.plugin.getGeneratorManager();
            if (generatorManager != null
               && generatorManager.areTeammates(ownerUuid, playerUuid)
               && (this.plugin.getZTeamHook() == null || !this.plugin.getZTeamHook().canUseSellWandOnGeneratorChest(ownerUuid, playerUuid))) {
               this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.private");
               return false;
            }
         }
      }

      if (block.getState() instanceof Container container) {
         Inventory var12 = container.getInventory();
         ItemStack[] var13 = this.cloneContents(var12.getContents());
         double total = this.calculateMoney(var12);
         if (total <= 0.0) {
            this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.no-money");
            return false;
         } else {
            this.removeMoneyItems(var12);
            if (!this.economyManager.deposit(player, total)) {
               var12.setContents(var13);
               this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.economy-error");
               return false;
            } else {
               this.consumeUse(player);
               this.xpRewardManager.reward(player, XpRewardType.GENERATOR_SELL);
               this.plugin
                  .getMessageUtil()
                  .sendActionBar(
                     player,
                     "sell-wand.sold",
                     "%money%",
                     this.format(total),
                     "%uses%",
                     String.valueOf(this.getRemainingUses(player.getInventory().getItemInMainHand()))
                  );
               return true;
            }
         }
      } else {
         this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.invalid-container");
         return false;
      }
   }

   private double calculateMoney(Inventory inventory) {
      double total = 0.0;

      for (ItemStack item : inventory.getContents()) {
         if (this.moneyItemManager.isMoneyItem(item)) {
            double value = this.moneyItemManager.getStackValue(item);
            if (!Double.isNaN(value) && !Double.isInfinite(value) && !(value <= 0.0)) {
               total += value;
            }
         }
      }

      return Math.max(0.0, total);
   }

   private void removeMoneyItems(Inventory inventory) {
      for (int slot = 0; slot < inventory.getSize(); slot++) {
         ItemStack item = inventory.getItem(slot);
         if (this.moneyItemManager.isMoneyItem(item)) {
            inventory.setItem(slot, null);
         }
      }
   }

   private void consumeUse(Player player) {
      ItemStack item = player.getInventory().getItemInMainHand();
      if (this.isSellWand(item)) {
         int remaining = this.getRemainingUses(item);
         int max = this.getMaxUses(item);
         if (--remaining <= 0) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            this.plugin.getMessageUtil().sendActionBar(player, "sell-wand.broken");
            this.plugin.getSoundUtil().play(player, "sell-wand-break");
         } else {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
               meta.getPersistentDataContainer().set(this.remainingUsesKey, PersistentDataType.INTEGER, remaining);
               item.setItemMeta(meta);
               this.updateDisplay(item, remaining, max);
               player.getInventory().setItemInMainHand(item);
            }
         }
      }
   }

   private void updateDisplay(ItemStack item, int remaining, int max) {
      if (item != null && !item.getType().isAir()) {
         FileConfiguration config = this.plugin.getConfigManager().getGenerators();
         String path = "sell-wand.types." + max;
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            String name = config.getString(path + ".name", "&#FF8A00Sell wand &8• &f%uses%/%max_uses%");
            meta.setDisplayName(ColorUtil.color(this.replace(name, "%uses%", String.valueOf(remaining), "%max_uses%", String.valueOf(max))));
            ArrayList<String> lore = new ArrayList<>();

            for (String line : config.getStringList(path + ".lore")) {
               lore.add(ColorUtil.color(this.replace(line, "%uses%", String.valueOf(remaining), "%max_uses%", String.valueOf(max))));
            }

            meta.setLore(lore);
            item.setItemMeta(meta);
         }
      }
   }

   private ItemStack[] cloneContents(ItemStack[] contents) {
      ItemStack[] copy = new ItemStack[contents.length];

      for (int index = 0; index < contents.length; index++) {
         copy[index] = contents[index] == null ? null : contents[index].clone();
      }

      return copy;
   }

   private String replace(String var1, String... var2) {
      return PlaceholderFix.replace(var1, var2);
   }

   private String format(double value) {
      return new DecimalFormat("#,##0.##").format(value);
   }
}
