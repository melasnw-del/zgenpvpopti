package com.zzwproject.zgenpvp.repository;

import com.zzwproject.zgenpvp.database.DatabaseManager;
import com.zzwproject.zgenpvp.model.BeaconData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;

public final class BeaconRepository {
   private final DatabaseManager databaseManager;

   public BeaconRepository(DatabaseManager var1) {
      this.databaseManager = var1;
   }

   public Optional<BeaconData> findByOwner(UUID var1) {
      String var2 = "SELECT *\nFROM beacons\nWHERE owner_uuid = ?\nLIMIT 1;\n";

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2)) {
         var3.setString(1, var1.toString());

         try (ResultSet var4 = var3.executeQuery()) {
            if (var4.next()) {
               return Optional.of(this.readBeacon(var4));
            }
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return Optional.empty();
   }

   public List<BeaconData> findAllByOwner(UUID var1) {
      ArrayList var2 = new ArrayList();
      String var3 = "SELECT * FROM beacons WHERE owner_uuid = ? ORDER BY id ASC;";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setString(1, var1.toString());

         try (ResultSet var5 = var4.executeQuery()) {
            while (var5.next()) {
               var2.add(this.readBeacon(var5));
            }
         }
      } catch (SQLException var12) {
         var12.printStackTrace();
      }

      return var2;
   }

   public int countByOwner(UUID var1) {
      String var2 = "SELECT COUNT(*) FROM beacons WHERE owner_uuid = ?;";

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2)) {
         var3.setString(1, var1.toString());

         try (ResultSet var4 = var3.executeQuery()) {
            return var4.next() ? var4.getInt(1) : 0;
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
         return 0;
      }
   }

   public Optional<BeaconData> findByLocation(Location var1) {
      if (var1.getWorld() == null) {
         return Optional.empty();
      }

      String var2 = "SELECT *\nFROM beacons\nWHERE world = ?\nAND x = ?\nAND y = ?\nAND z = ?\nLIMIT 1;\n";

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2)) {
         var3.setString(1, var1.getWorld().getName());
         var3.setInt(2, var1.getBlockX());
         var3.setInt(3, var1.getBlockY());
         var3.setInt(4, var1.getBlockZ());

         try (ResultSet var4 = var3.executeQuery()) {
            if (var4.next()) {
               return Optional.of(this.readBeacon(var4));
            }
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return Optional.empty();
   }

   public long create(UUID var1, String var2, Location var3) {
      if (var3.getWorld() == null) {
         return -1L;
      }

      String var4 = "INSERT INTO beacons (\n    owner_uuid,\n    name,\n    world,\n    x,\n    y,\n    z,\n    created_at\n)\nVALUES (?, ?, ?, ?, ?, ?, ?);\n";

      try (PreparedStatement var5 = this.databaseManager.getConnection().prepareStatement(var4, 1)) {
         var5.setString(1, var1.toString());
         var5.setString(2, var2);
         var5.setString(3, var3.getWorld().getName());
         var5.setInt(4, var3.getBlockX());
         var5.setInt(5, var3.getBlockY());
         var5.setInt(6, var3.getBlockZ());
         var5.setLong(7, System.currentTimeMillis());
         var5.executeUpdate();

         try (ResultSet var6 = var5.getGeneratedKeys()) {
            if (var6.next()) {
               return var6.getLong(1);
            }
         }
      } catch (SQLException var13) {
         var13.printStackTrace();
      }

      return -1L;
   }

   public boolean updateName(UUID var1, String var2) {
      String var3 = "UPDATE beacons\nSET name = ?\nWHERE owner_uuid = ?;\n";

      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement(var3)) {
         var4.setString(1, var2);
         var4.setString(2, var1.toString());
         return var4.executeUpdate() > 0;
      } catch (SQLException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public Optional<BeaconData> findById(long var1) {
      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("SELECT * FROM beacons WHERE id = ? LIMIT 1;")) {
         var3.setLong(1, var1);

         try (ResultSet var4 = var3.executeQuery()) {
            return var4.next() ? Optional.of(this.readBeacon(var4)) : Optional.empty();
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
         return Optional.empty();
      }
   }

   public boolean updateName(long var1, String var3) {
      try (PreparedStatement var4 = this.databaseManager.getConnection().prepareStatement("UPDATE beacons SET name = ? WHERE id = ?;")) {
         var4.setString(1, var3);
         var4.setLong(2, var1);
         return var4.executeUpdate() > 0;
      } catch (SQLException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public boolean deleteById(long var1) {
      this.hasLinkedBase(var1);
      if (false) {
         return false;
      }

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("DELETE FROM beacons WHERE id = ?;")) {
         var3.setLong(1, var1);
         return var3.executeUpdate() > 0;
      } catch (SQLException var8) {
         var8.printStackTrace();
         return false;
      }
   }

   private boolean hasLinkedBase(long var1) {
      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement("SELECT 1 FROM bases WHERE beacon_id = ? LIMIT 1;")) {
         var3.setLong(1, var1);

         try (ResultSet var4 = var3.executeQuery()) {
            return var4.next();
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
         return true;
      }
   }

   public boolean deleteByOwner(UUID var1) {
      String var2 = "DELETE FROM beacons\nWHERE owner_uuid = ?;\n";

      try (PreparedStatement var3 = this.databaseManager.getConnection().prepareStatement(var2)) {
         var3.setString(1, var1.toString());
         return var3.executeUpdate() > 0;
      } catch (SQLException var8) {
         var8.printStackTrace();
         return false;
      }
   }

   private BeaconData readBeacon(ResultSet var1) throws SQLException {
      return new BeaconData(
         var1.getLong("id"),
         UUID.fromString(var1.getString("owner_uuid")),
         var1.getString("name"),
         var1.getString("world"),
         var1.getInt("x"),
         var1.getInt("y"),
         var1.getInt("z")
      );
   }
}
