package com.zzwproject.zgenpvp.access;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.economy.EconomyManager;
import com.zzwproject.zgenpvp.integration.TeamPermissionBridge;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.repository.BaseRepository;
import com.zzwproject.zgenpvp.repository.DefenseRepository;
import com.zzwproject.zgenpvp.v2.EnergySupport;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Bisected.Half;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.TrapDoor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class DefenseAccessManager {
   private final ZGenPvP plugin;
   private final DefenseRepository defenseRepository;
   private final BaseRepository baseRepository;
   private final EconomyManager economyManager;
   private final SpecialItemFactory itemFactory;
   private final Map<String, DefenseData> cache = new HashMap<>();
   private final Map<String, Long> hitCooldown = new HashMap<>();

   public DefenseAccessManager(ZGenPvP var1, DefenseRepository var2, BaseRepository var3, EconomyManager var4, SpecialItemFactory var5) {
      this.plugin = var1;
      this.defenseRepository = var2;
      this.baseRepository = var3;
      this.economyManager = var4;
      this.itemFactory = var5;
   }

   public void loadCache() {
      this.cache.clear();
      this.loadType(DefenseAccessType.DOOR);
      this.loadType(DefenseAccessType.TRAPDOOR);
      this.plugin.getLogger().info(this.cache.size() + " defans kapisi/Trapdoor yuklendi.");
   }

   private void loadType(DefenseAccessType var1) {
      for (DefenseData var3 : this.defenseRepository.findAllByType(var1.getDatabaseType())) {
         this.cache.put(this.key(var3.getWorldName(), var3.getX(), var3.getY(), var3.getZ()), var3);
      }
   }

   public boolean isEnabled(DefenseAccessType var1) {
      return var1 == null
         ? false
         : this.plugin.getConfigManager().getConfig().getBoolean("modules.defenses", true)
            && this.plugin.getConfigManager().getDefenses().getBoolean(var1.getConfigPath() + ".enabled", true);
   }

   public Optional<DefenseData> get(Block var1) {
      if (var1 == null) {
         return Optional.empty();
      }

      Location var2 = this.normalize(var1);
      return Optional.ofNullable(this.cache.get(this.key(var2)));
   }

   public boolean canManageAccess(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : TeamPermissionBridge.defenseAccess(this.plugin.getZTeamHook(), var1, var2);
      }
   }

   public boolean canManageAccess(Player var1, DefenseData var2) {
      return var1 != null && var2 != null ? TeamPermissionBridge.accessManageIds(this, var2.getOwnerUuid(), var1.getUniqueId(), var2) : false;
   }

   public void showInfo(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         DefenseAccessType var3 = this.getType(var2);
         String var4 = var3 == DefenseAccessType.DOOR ? "access.door-info" : "access.trapdoor-info";
         this.plugin
            .getMessageUtil()
            .sendActionBar(
               var1,
               var4,
               "%level%",
               String.valueOf(var2.getLevel()),
               "%health%",
               String.valueOf(var2.getCurrentHp()),
               "%max_health%",
               String.valueOf(var2.getMaxHp())
            );
      }
   }

   public boolean toggleOpen(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null && this.canManageAccess(var1, var2)) {
         Location var3 = var2.getLocation();
         if (var3 != null && var3.getWorld() != null) {
            DefenseAccessType var4 = this.getType(var2);
            Block var5 = var3.getBlock();
            if (var4 == DefenseAccessType.DOOR) {
               Block var12 = this.normalize(var5).getBlock();
               if (var12.getBlockData() instanceof Door var13) {
                  boolean var14 = !var13.isOpen();
                  var13.setOpen(var14);
                  var12.setBlockData(var13, false);
                  Block var9 = var12.getRelative(0, 1, 0);
                  if (var9.getBlockData() instanceof Door var10) {
                     var10.setOpen(var14);
                     var9.setBlockData(var10, false);
                  }

                  this.plugin.getSoundUtil().play(var1, "button");
                  return true;
               } else {
                  return false;
               }
            } else if (var5.getBlockData() instanceof TrapDoor var7) {
               var7.setOpen(!var7.isOpen());
               var5.setBlockData(var7, false);
               this.plugin.getSoundUtil().play(var1, "button");
               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean place(Player var1, Block var2, DefenseAccessType var3, int var4) {
      if (var1 == null || var2 == null || var3 == null) {
         return false;
      }

      if (!this.isEnabled(var3)) {
         this.plugin.getMessageUtil().send(var1, "access.disabled");
         return false;
      }

      Location var5 = this.normalize(var2);
      if (var5 != null && var5.getWorld() != null) {
         BaseData var6 = TeamPermissionBridge.findOwnOrTeamBase(this.baseRepository, var1.getUniqueId())
            .filter(var2x -> this.isInsideBase(var2x, var5))
            .orElse(null);
         long var7 = 0L;
         if (var6 == null) {
            this.plugin.getMessageUtil().send(var1, "access.base-required");
            return false;
         } else if (this.plugin.getBaseEnergyManager() != null && !this.plugin.getBaseEnergyManager().isPowered(var6)) {
            this.plugin.getMessageUtil().send(var1, "access.energy-required");
            this.plugin.getSoundUtil().play(var1, "error");
            return false;
         } else {
            int var9 = this.defenseRepository.countStructures(var6.getId());
            if (var9 >= var6.getBlockLimit()) {
               this.plugin
                  .getMessageUtil()
                  .send(var1, "access.structure-limit", "%current%", String.valueOf(var9), "%max%", String.valueOf(var6.getBlockLimit()));
               return false;
            } else {
               var7 = var6.getId();
               var9 = this.clampLevel(var3, var4);
               int var10 = this.getHealth(var3, var9);
               long var11 = this.defenseRepository.create(var7, var1.getUniqueId(), var3.getDatabaseType(), var5, var9, var10);
               if (var11 <= 0L) {
                  this.plugin.getMessageUtil().send(var1, "access.place-error");
                  return false;
               } else {
                  DefenseData var13 = new DefenseData(
                     var11,
                     var7,
                     var1.getUniqueId(),
                     var3.getDatabaseType(),
                     var5.getWorld().getName(),
                     var5.getBlockX(),
                     var5.getBlockY(),
                     var5.getBlockZ(),
                     var9,
                     var10,
                     var10
                  );
                  this.cache.put(this.key(var5), var13);
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(
                        var1,
                        var3 == DefenseAccessType.DOOR ? "access.door-placed" : "access.trapdoor-placed",
                        "%level%",
                        String.valueOf(var9),
                        "%health%",
                        String.valueOf(var10)
                     );
                  this.plugin.getSoundUtil().play(var1, "access-place");
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean upgrade(Player var1, DefenseData var2) {
      if (var1 == null || var2 == null) {
         return false;
      }

      if (!this.canManageAccess(var1, var2)) {
         this.sendOwnerInfo(var1, var2);
         return false;
      }

      DefenseAccessType var3 = this.getType(var2);
      int var4 = this.getMaxLevel(var3);
      if (var2.getLevel() >= var4) {
         this.plugin.getMessageUtil().send(var1, "access.max-level");
         return false;
      }

      double var5 = this.getUpgradePrice(var3, var2.getLevel());
      if (!this.economyManager.has(var1, var5)) {
         this.plugin.getMessageUtil().send(var1, "access.not-enough-money", "%price%", this.format(var5));
         return false;
      }

      if (!this.economyManager.withdraw(var1, var5)) {
         this.plugin.getMessageUtil().send(var1, "general.economy-error");
         return false;
      }

      int var7 = var2.getLevel() + 1;
      int var8 = this.getHealth(var3, var7);
      if (!this.defenseRepository.updateLevel(var2.getId(), var7, var8)) {
         this.economyManager.deposit(var1, var5);
         this.plugin.getMessageUtil().send(var1, "general.database-error");
         return false;
      }

      Location var9 = var2.getLocation();
      if (var9 != null && var9.getWorld() != null) {
         if (var3 == DefenseAccessType.DOOR) {
            this.upgradeDoorBlocks(var9.getBlock(), this.getMaterial(var3, var7));
         } else {
            this.upgradeTrapdoorBlock(var9.getBlock(), this.getMaterial(var3, var7));
         }
      }

      var2.setLevel(var7);
      var2.setCurrentHp(var8);
      var2.setMaxHp(var8);
      this.plugin
         .getMessageUtil()
         .send(var1, "access.upgraded", "%level%", String.valueOf(var7), "%health%", String.valueOf(var8), "%price%", this.format(var5));
      this.plugin.getSoundUtil().play(var1, "access-upgrade");
      return true;
   }

   private void upgradeDoorBlocks(Block var1, Material var2) {
      if (var1.getBlockData() instanceof Door var3) {
         Block var7 = var1.getRelative(0, 1, 0);
         Door var5 = (Door)var2.createBlockData();
         var5.setFacing(var3.getFacing());
         var5.setHinge(var3.getHinge());
         var5.setOpen(var3.isOpen());
         var5.setPowered(var3.isPowered());
         var5.setHalf(Half.BOTTOM);
         Door var6 = (Door)var5.clone();
         var6.setHalf(Half.TOP);
         var1.setType(var2, false);
         var1.setBlockData(var5, false);
         var7.setType(var2, false);
         var7.setBlockData(var6, false);
      }
   }

   private void upgradeTrapdoorBlock(Block var1, Material var2) {
      if (var1.getBlockData() instanceof TrapDoor var3) {
         TrapDoor var5 = (TrapDoor)var2.createBlockData();
         var5.setFacing(var3.getFacing());
         var5.setHalf(var3.getHalf());
         var5.setOpen(var3.isOpen());
         var5.setPowered(var3.isPowered());
         var5.setWaterlogged(var3.isWaterlogged());
         var1.setType(var2, false);
         var1.setBlockData(var5, false);
      }
   }

   public void damage(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            DefenseAccessType var3 = this.getType(var2);
            String var4 = var1.getUniqueId() + ":" + var2.getId();
            long var5 = System.currentTimeMillis();
            long var7 = this.plugin.getConfigManager().getDefenses().getLong(var3.getConfigPath() + ".attack.hit-cooldown-milliseconds", 120L);
            Long var9 = this.hitCooldown.get(var4);
            if (var9 == null || var5 - var9 >= var7) {
               this.hitCooldown.put(var4, var5);
               int var10 = Math.max(1, this.plugin.getConfigManager().getDefenses().getInt(var3.getConfigPath() + ".attack.damage-per-hit", 1));
               this.damage(var1, var2, var10, false);
            }
         }
      }
   }

   public void damage(Player var1, DefenseData var2, int var3, boolean var4) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            int var5 = var4 ? var2.getCurrentHp() : Math.max(1, var3);
            if (!EnergySupport.isPowered(this.plugin, var2)) {
               var5 *= 2;
            }

            int var6 = Math.max(0, var2.getCurrentHp() - var5);
            this.plugin
               .getRaidAlertManager()
               .alert(
                  var2.getOwnerUuid(),
                  var1,
                  var2.getType().equals("DEFENSE_DOOR") ? "defans kapisi" : "defans tuzak kapisi",
                  var2.getLocation(),
                  var2.getLevel(),
                  var6,
                  var2.getMaxHp(),
                  var4 ? "Instabreaker/Bomba" : "oyuncu saldirisi"
               );
            if (var6 > 0) {
               boolean var7 = this.defenseRepository.updateHealth(var2.getId(), var6);
               if (var7) {
                  var2.setCurrentHp(var6);
                  this.plugin
                     .getMessageUtil()
                     .sendActionBar(var1, "access.hit-actionbar", "%health%", String.valueOf(var6), "%max_health%", String.valueOf(var2.getMaxHp()));
               }
            } else {
               this.destroy(var1, var2);
            }
         }
      }
   }

   private void destroy(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!this.isFriendly(var1.getUniqueId(), var2.getOwnerUuid())) {
            boolean var3 = this.defenseRepository.delete(var2.getId());
            if (var3) {
               this.cache.remove(this.key(var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()));
               Location var4 = var2.getLocation();
               if (var4 != null && var4.getWorld() != null) {
                  DefenseAccessType var5 = this.getType(var2);
                  if (var5 == DefenseAccessType.DOOR) {
                     Block var6 = var4.getBlock();
                     Block var7 = var6.getRelative(0, 1, 0);
                     var6.setType(Material.AIR, false);
                     var7.setType(Material.AIR, false);
                  } else {
                     var4.getBlock().setType(Material.AIR, false);
                  }
               }

               this.plugin.getMessageUtil().send(var1, "access.destroyed");
               Player var8 = this.plugin.getServer().getPlayer(var2.getOwnerUuid());
               if (var8 != null) {
                  this.plugin.getMessageUtil().send(var8, "access.destroyed-owner", "%attacker%", var1.getName());
               }
            }
         }
      }
   }

   public boolean removeByOwner(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         if (!TeamPermissionBridge.accessBreakOwnerOrAllowed(var2.getOwnerUuid(), var1.getUniqueId(), var2)) {
            return false;
         }

         boolean var3 = this.defenseRepository.delete(var2.getId());
         if (!var3 && this.defenseRepository.existsById(var2.getId())) {
            return false;
         }

         this.cache.remove(this.key(var2.getWorldName(), var2.getX(), var2.getY(), var2.getZ()));
         DefenseAccessType var4 = this.getType(var2);
         boolean var5 = this.plugin.getConfigManager().getDefenses().getBoolean(var4.getConfigPath() + ".owner-break.return-item", true);
         if (var5) {
            ItemStack var6 = var4 == DefenseAccessType.DOOR
               ? this.itemFactory.createDefenseDoor(var2.getLevel())
               : this.itemFactory.createDefenseTrapdoor(var2.getLevel());
            if (var6 != null) {
               HashMap<Integer, ItemStack> var7 = zzw$groundOverflow(var1.getInventory(), new ItemStack[]{var6});

               for (ItemStack var9 : var7.values()) {
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var9);
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public void sendOwnerInfo(Player var1, DefenseData var2) {
      if (var1 != null && var2 != null) {
         String var3 = Optional.ofNullable(this.plugin.getServer().getOfflinePlayer(var2.getOwnerUuid()).getName()).orElse("Bilinmeyen");
         this.plugin.getMessageUtil().send(var1, "access.owner-info", "%owner%", var3);
      }
   }

   public boolean isFriendly(UUID var1, UUID var2) {
      if (var1 == null || var2 == null) {
         return false;
      } else if (var1.equals(var2)) {
         return true;
      } else {
         return this.plugin.getZTeamHook() == null ? false : this.plugin.getZTeamHook().areTeammates(var1, var2);
      }
   }

   public DefenseAccessType getType(DefenseData var1) {
      return var1.getType().equals(DefenseAccessType.DOOR.getDatabaseType()) ? DefenseAccessType.DOOR : DefenseAccessType.TRAPDOOR;
   }

   public int getMaxLevel(DefenseAccessType var1) {
      return Math.max(1, this.plugin.getConfigManager().getDefenses().getInt(var1.getConfigPath() + ".max-level", 5));
   }

   public int getHealth(DefenseAccessType var1, int var2) {
      return this.plugin.getConfigManager().getDefenses().getInt(this.levelPath(var1, var2) + ".health", 250);
   }

   public double getUpgradePrice(DefenseAccessType var1, int var2) {
      return this.plugin.getConfigManager().getDefenses().getDouble(this.levelPath(var1, var2) + ".upgrade-price", 0.0);
   }

   public Material getMaterial(DefenseAccessType var1, int var2) {
      Material var3 = var1 == DefenseAccessType.DOOR ? Material.EXPOSED_COPPER_DOOR : Material.EXPOSED_COPPER_TRAPDOOR;
      String var4 = this.plugin.getConfigManager().getDefenses().getString(this.levelPath(var1, var2) + ".material");
      Material var5 = var4 == null ? null : Material.matchMaterial(var4);
      return var5 == null ? var3 : var5;
   }

   private Location normalize(Block var1) {
      return var1.getBlockData() instanceof Door var3 && var3.getHalf() == Half.TOP ? var1.getRelative(0, -1, 0).getLocation() : var1.getLocation();
   }

   private boolean isInsideBase(BaseData var1, Location var2) {
      if (var1 != null && var2 != null && var2.getWorld() != null && var2.getWorld().getName().equals(var1.getWorldName())) {
         double var3 = var2.getBlockX() - var1.getX();
         double var5 = var2.getBlockZ() - var1.getZ();
         return var3 * var3 + var5 * var5 <= var1.getRadius() * var1.getRadius();
      } else {
         return false;
      }
   }

   private int clampLevel(DefenseAccessType var1, int var2) {
      return Math.max(1, Math.min(this.getMaxLevel(var1), var2));
   }

   private String levelPath(DefenseAccessType var1, int var2) {
      return var1.getConfigPath() + ".levels." + var2;
   }

   private String key(Location var1) {
      return this.key(var1.getWorld().getName(), var1.getBlockX(), var1.getBlockY(), var1.getBlockZ());
   }

   private String key(String var1, int var2, int var3, int var4) {
      return var1 + ":" + var2 + ":" + var3 + ":" + var4;
   }

   private String format(double var1) {
      return new DecimalFormat("#,##0.##").format(var1);
   }

   private static HashMap<Integer, ItemStack> zzw$groundOverflow(org.bukkit.inventory.PlayerInventory var0, ItemStack[] var1) {
      HashMap<Integer, ItemStack> var2 = new HashMap<>();
      var2.put(0, var1[0]);
      return var2;
   }
}
