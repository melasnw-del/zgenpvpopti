package com.zzwproject.zgenpvp.model;

import com.zzwproject.zgenpvp.hotfix.NameSanitizer;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class BaseData {
   private final long id;
   private final long beaconId;
   private final UUID ownerUuid;
   private String name;
   private final String worldName;
   private final int x;
   private final int y;
   private final int z;
   private int level;
   private int currentHp;
   private int maxHp;
   private int radius;
   private int blockLimit;

   public BaseData(
      long id,
      long beaconId,
      UUID ownerUuid,
      String name,
      String worldName,
      int x,
      int y,
      int z,
      int level,
      int currentHp,
      int maxHp,
      int radius,
      int blockLimit
   ) {
      this.id = id;
      this.beaconId = beaconId;
      this.ownerUuid = ownerUuid;
      this.name = name;
      this.worldName = worldName;
      this.x = x;
      this.y = y;
      this.z = z;
      this.level = level;
      this.currentHp = currentHp;
      this.maxHp = maxHp;
      this.radius = radius;
      this.blockLimit = blockLimit;
   }

   public long getId() {
      return this.id;
   }

   public long getBeaconId() {
      return this.beaconId;
   }

   public UUID getOwnerUuid() {
      return this.ownerUuid;
   }

   public String getName() {
      return NameSanitizer.sanitize(this.ownerUuid, this.name);
   }

   public String getWorldName() {
      return this.worldName;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public int getLevel() {
      return this.level;
   }

   public int getCurrentHp() {
      return this.currentHp;
   }

   public void setCurrentHp(int currentHp) {
      this.currentHp = Math.max(0, Math.min(currentHp, this.maxHp));
   }

   public int getMaxHp() {
      return this.maxHp;
   }

   public int getRadius() {
      return this.radius;
   }

   public int getBlockLimit() {
      return this.blockLimit;
   }

   public Location getLocation() {
      World world = Bukkit.getWorld(this.worldName);
      return world == null ? null : new Location(world, this.x, this.y, this.z);
   }
}
