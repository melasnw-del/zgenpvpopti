package com.zzwproject.bundle;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import org.bukkit.Server;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

public final class BundlePlugin extends JavaPlugin {
   private final List<ModuleContext> modules = new ArrayList<>();
   private Object commandMap;
   private Map<Object, Object> lookupNames;

   public void onLoad() {
      try {
         this.commandMap = this.resolveCommandMap();
         this.lookupNames = this.resolveLookupNames();
         this.loadModuleDefinitions();

         for (ModuleContext var2 : this.modules) {
            this.exposeLookup(var2);
         }

         for (ModuleContext var7 : this.orderedModules()) {
            try {
               var7.instance.onLoad();
            } catch (Throwable var4) {
               this.getLogger().log(Level.SEVERE, var7.moduleName + " onLoad hatası", unwrap(var4));
            }
         }
      } catch (Throwable var5) {
         this.getLogger().log(Level.SEVERE, "Bundle hazırlanamadı", unwrap(var5));
      }
   }

   public void onEnable() {
      int var1 = 0;

      for (ModuleContext var3 : this.orderedModules()) {
         try {
            this.registerPermissions(var3);
            this.registerCommands(var3);
            var3.enabled = true;
            var3.instance.onEnable();
            var1++;
            this.getLogger().info("[modül] " + var3.moduleName + " " + var3.description.getVersion() + " aktif");
         } catch (Throwable var5) {
            var3.enabled = false;
            this.getLogger().log(Level.SEVERE, var3.moduleName + " etkinleştirilemedi", unwrap(var5));
         }
      }

      this.getLogger().info(this.getName() + ": " + var1 + "/" + this.modules.size() + " dahili modül aktif.");
   }

   public void onDisable() {
      ArrayList<ModuleContext> var1 = new ArrayList<>(this.orderedModules());
      Collections.reverse(var1);

      for (ModuleContext var3 : var1) {
         if (var3.instance != null) {
            try {
               if (var3.enabled) {
                  var3.instance.onDisable();
               }
            } catch (Throwable var5) {
               this.getLogger().log(Level.WARNING, var3.moduleName + " onDisable hatası", unwrap(var5));
            }

            var3.enabled = false;
            this.cleanupModule(var3);
            this.hideLookup(var3);
            ModuleRegistry.remove(var3);
         }
      }
   }

   private void loadModuleDefinitions() throws Exception {
      try (InputStream var1 = this.getResource("bundle-modules.txt")) {
         if (var1 == null) {
            throw new FileNotFoundException("bundle-modules.txt");
         }

         for (String var4 : new BufferedReader(new InputStreamReader(var1, StandardCharsets.UTF_8)).lines().toList()) {
            String var5 = var4.trim();
            if (!var5.isEmpty() && !var5.startsWith("#")) {
               String[] var6 = var5.split("\\|", 2);
               if (var6.length != 2) {
                  throw new IllegalArgumentException("Bozuk modül satırı: " + var5);
               }

               String var7 = var6[0].trim();
               String var8 = var6[1].trim();
               String var9 = "legacy/" + var7 + "/";

               PluginDescriptionFile var10;
               try (InputStream var11 = this.getClassLoader().getResourceAsStream(var9 + "plugin.yml")) {
                  if (var11 == null) {
                     throw new FileNotFoundException(var9 + "plugin.yml");
                  }

                  Constructor var12 = Class.forName("org.bukkit.plugin.PluginDescriptionFile").getConstructor(InputStream.class);
                  var10 = (PluginDescriptionFile)var12.newInstance(var11);
               }

               ModuleContext var19 = new ModuleContext(this, var7, var8, var10, var9 + "resources/");
               ModuleRegistry.put(var19);
               Class var20 = Class.forName(var8, true, this.getClassLoader());
               if (!(var20.getDeclaredConstructor().newInstance() instanceof LegacyPluginBase var14)) {
                  throw new IllegalStateException(var8 + " LegacyPluginBase değil");
               }

               var19.instance = var14;
               this.modules.add(var19);
            }
         }
      }
   }

   private List<ModuleContext> orderedModules() {
      LinkedHashMap var1 = new LinkedHashMap();

      for (ModuleContext var3 : this.modules) {
         var1.put(var3.moduleName, var3);
      }

      ArrayList var11 = new ArrayList();
      HashSet var12 = new HashSet();

      for (int var4 = 0; var4 < this.modules.size() + 2; var4++) {
         boolean var5 = false;

         for (ModuleContext var7 : this.modules) {
            if (!var12.contains(var7.moduleName)) {
               boolean var8 = true;

               for (String var10 : safeStringList(var7.description, "getDepend")) {
                  if (var1.containsKey(var10) && !var12.contains(var10)) {
                     var8 = false;
                     break;
                  }
               }

               if (var8) {
                  var11.add(var7);
                  var12.add(var7.moduleName);
                  var5 = true;
               }
            }
         }

         if (!var5) {
            break;
         }
      }

      for (ModuleContext var14 : this.modules) {
         if (!var12.contains(var14.moduleName)) {
            var11.add(var14);
         }
      }

      return var11;
   }

   private void registerCommands(ModuleContext var1) throws Exception {
      if (var1.description.getCommands() instanceof Map<?, ?> var3 && !var3.isEmpty()) {
         Class var4 = Class.forName("org.bukkit.plugin.Plugin");
         Class var5 = Class.forName("org.bukkit.command.PluginCommand");
         Constructor var6 = var5.getDeclaredConstructor(String.class, var4);
         var6.setAccessible(true);
         Method var7 = findRegisterMethod(this.commandMap.getClass());

         for (Entry var9 : var3.entrySet()) {
            String var10 = String.valueOf(var9.getKey()).toLowerCase(Locale.ROOT);
            Object var11 = var6.newInstance(var10, var1.instance);
            Map var12 = var9.getValue() instanceof Map var13 ? var13 : Collections.emptyMap();
            setIfPresent(var11, "setDescription", String.class, str(var12.get("description")));
            setIfPresent(var11, "setUsage", String.class, str(var12.get("usage")));
            setIfPresent(var11, "setPermission", String.class, str(var12.get("permission")));
            Object var18 = var12.get("aliases");
            if (var18 != null) {
               ArrayList var19 = new ArrayList();
               if (var18 instanceof Collection) {
                  for (Object var17 : (Collection)var18) {
                     var19.add(String.valueOf(var17));
                  }
               } else {
                  var19.add(String.valueOf(var18));
               }

               setIfPresent(var11, "setAliases", List.class, var19);
            }

            var7.invoke(this.commandMap, var1.moduleName.toLowerCase(Locale.ROOT), var11);
            PluginCommand var20 = (PluginCommand)var11;
            var1.commands.put(var10, var20);
            if (var18 instanceof Collection) {
               for (Object var23 : (Collection)var18) {
                  var1.commands.put(String.valueOf(var23).toLowerCase(Locale.ROOT), var20);
               }
            }
         }
      }
   }

   private void registerPermissions(ModuleContext var1) {
      try {
         Object var2 = this.getServer().getClass().getMethod("getPluginManager").invoke(this.getServer());
         Method var3 = null;

         for (Method var7 : var2.getClass().getMethods()) {
            if (var7.getName().equals("addPermission") && var7.getParameterCount() == 1) {
               var3 = var7;
               break;
            }
         }

         if (var3 == null) {
            return;
         }

         Object var11 = var1.description.getClass().getMethod("getPermissions").invoke(var1.description);
         if (var11 instanceof Iterable) {
            for (Object var14 : (Iterable)var11) {
               try {
                  var3.invoke(var2, var14);
               } catch (Throwable var9) {
               }
            }
         }
      } catch (Throwable var10) {
      }
   }

   private Object resolveCommandMap() throws Exception {
      Server var1 = this.getServer();

      try {
         return var1.getClass().getMethod("getCommandMap").invoke(var1);
      } catch (NoSuchMethodException var4) {
         Object var2 = var1.getClass().getMethod("getPluginManager").invoke(var1);
         Field var3 = findField(var2.getClass(), "commandMap");
         if (var3 == null) {
            throw new NoSuchFieldException("commandMap");
         }

         var3.setAccessible(true);
         return var3.get(var2);
      }
   }

   private Map<Object, Object> resolveLookupNames() throws Exception {
      return LookupBridge.resolve(this);
   }

   private void exposeLookup(ModuleContext var1) {
      if (this.lookupNames != null) {
         this.lookupNames.putIfAbsent(var1.moduleName, var1.instance);

         for (String var3 : safeStringList(var1.description, "getProvides")) {
            this.lookupNames.putIfAbsent(var3, var1.instance);
         }
      }
   }

   private void hideLookup(ModuleContext var1) {
      if (this.lookupNames != null) {
         this.lookupNames.remove(var1.moduleName, var1.instance);

         for (String var3 : safeStringList(var1.description, "getProvides")) {
            this.lookupNames.remove(var3, var1.instance);
         }
      }
   }

   private void cleanupModule(ModuleContext var1) {
      try {
         Class var2 = Class.forName("org.bukkit.event.HandlerList");
         var2.getMethod("unregisterAll", Class.forName("org.bukkit.plugin.Plugin")).invoke(null, var1.instance);
      } catch (Throwable var7) {
      }

      try {
         Object var8 = this.getServer().getClass().getMethod("getScheduler").invoke(this.getServer());
         var8.getClass().getMethod("cancelTasks", Class.forName("org.bukkit.plugin.Plugin")).invoke(var8, var1.instance);
      } catch (Throwable var6) {
      }

      if (this.commandMap != null) {
         for (PluginCommand var3 : new HashSet<>(var1.commands.values())) {
            try {
               var3.getClass().getMethod("unregister", Class.forName("org.bukkit.command.CommandMap")).invoke(var3, this.commandMap);
            } catch (Throwable var5) {
            }
         }
      }
   }

   private static Method findRegisterMethod(Class<?> var0) throws NoSuchMethodException {
      for (Method var4 : var0.getMethods()) {
         if (var4.getName().equals("register") && var4.getParameterCount() == 2 && var4.getParameterTypes()[0] == String.class) {
            return var4;
         }
      }

      throw new NoSuchMethodException("CommandMap.register");
   }

   private static Field findField(Class<?> var0, String var1) {
      for (Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         try {
            return var2.getDeclaredField(var1);
         } catch (NoSuchFieldException var4) {
         }
      }

      return null;
   }

   private static void setIfPresent(Object var0, String var1, Class<?> var2, Object var3) {
      if (var3 != null) {
         try {
            var0.getClass().getMethod(var1, var2).invoke(var0, var3);
         } catch (Throwable var5) {
         }
      }
   }

   private static String str(Object var0) {
      return var0 == null ? null : String.valueOf(var0);
   }

   private static List<String> safeStringList(Object var0, String var1) {
      try {
         if (var0.getClass().getMethod(var1).invoke(var0) instanceof Collection var3) {
            ArrayList var4 = new ArrayList();

            for (Object var6 : var3) {
               var4.add(String.valueOf(var6));
            }

            return var4;
         }
      } catch (Throwable var7) {
      }

      return Collections.emptyList();
   }

   private static Throwable unwrap(Throwable var0) {
      while (var0 instanceof InvocationTargetException var1 && var1.getCause() != null) {
         var0 = var1.getCause();
      }

      return var0;
   }
}
