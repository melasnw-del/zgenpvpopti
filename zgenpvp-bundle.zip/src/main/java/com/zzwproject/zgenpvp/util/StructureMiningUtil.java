package com.zzwproject.zgenpvp.util;

import com.zzwproject.zgenpvp.ZGenPvP;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public final class StructureMiningUtil {
   private static final Map<UUID, StructureMiningUtil.MiningSession> ACTIVE = new HashMap<>();
   private static final AtomicInteger NEXT_CRACK_SOURCE = new AtomicInteger(-1073741824);
   private static BukkitTask globalTask;
   private static ZGenPvP globalPlugin;

   private StructureMiningUtil() {
   }

   public static boolean isPickaxe(Player var0) {
      if (var0 == null) {
         return false;
      }

      Material var1 = var0.getInventory().getItemInMainHand().getType();
      return var1.name().endsWith("_PICKAXE");
   }

   public static int getEnemyHitIntervalTicks(ZGenPvP var0, Player var1) {
      return 20;
   }

   public static int getOwnerRemovalTicks(ZGenPvP var0, Player var1) {
      return 20;
   }

   public static void markSwing(Player var0) {
      if (var0 != null) {
         StructureMiningUtil.MiningSession var1 = ACTIVE.get(var0.getUniqueId());
         if (var1 != null && isValid(var1)) {
            var1.registerInput();
         }
      }
   }

   public static void startEnemyMining(
      ZGenPvP var0, Player var1, Block var2, String var3, IntSupplier var4, IntSupplier var5, BooleanSupplier var6, Runnable var7
   ) {
      start(var0, var1, var2, var3, false, var4, var5, var6, var7);
   }

   public static void startOwnerMining(ZGenPvP var0, Player var1, Block var2, String var3, BooleanSupplier var4, Runnable var5) {
      start(var0, var1, var2, var3, true, () -> 1, () -> 1, var4, var5);
   }

   private static void start(
      ZGenPvP var0, Player var1, Block var2, String var3, boolean var4, IntSupplier var5, IntSupplier var6, BooleanSupplier var7, Runnable var8
   ) {
      if (var0 != null && var1 != null && var2 != null && var3 != null && var5 != null && var6 != null && var7 != null && var8 != null) {
         StructureMiningUtil.MiningSession var9 = ACTIVE.get(var1.getUniqueId());
         if (var9 != null && var9.matches(var2, var3)) {
            var9.registerInput();
         } else {
            stopMining(var1);
            StructureMiningUtil.MiningSession var10 = new StructureMiningUtil.MiningSession(var0, var1, var2, var3, var4, var5, var6, var7, var8);
            ACTIVE.put(var1.getUniqueId(), var10);
            showCrack(var10, 0.0F);
            ensureGlobalTask(var0);
         }
      }
   }

   private static void ensureGlobalTask(ZGenPvP var0) {
      if (globalTask == null) {
         globalPlugin = var0;
         globalTask = var0.getServer().getScheduler().runTaskTimer(var0, StructureMiningUtil::tickAll, 1L, 1L);
      }
   }

   private static void tickAll() {
      if (ACTIVE.isEmpty()) {
         stopGlobalTaskIfIdle();
      } else {
         for (StructureMiningUtil.MiningSession var1 : List.copyOf(ACTIVE.values())) {
            tick(var1);
         }
      }
   }

   private static void tick(StructureMiningUtil.MiningSession var0) {
      Player var1 = var0.player;
      if (ACTIVE.get(var1.getUniqueId()) == var0 && isValid(var0)) {
         var0.ticksSinceInput++;
         if (var0.ticksSinceInput > var0.inputTimeoutTicks) {
            stopMining(var1);
         } else {
            processMining(var0);
         }
      } else {
         stopMining(var1);
      }
   }

   private static boolean isValid(StructureMiningUtil.MiningSession var0) {
      return var0.player.isOnline() && var0.stillExists.getAsBoolean() && isStillLookingAt(var0.player, var0.block);
   }

   private static void processMining(StructureMiningUtil.MiningSession var0) {
      if (ACTIVE.get(var0.player.getUniqueId()) == var0) {
         var0.miningProgress = Math.min(1.0, var0.miningProgress + getVanillaBreakProgressPerTick(var0.player, var0.block));
         showCrack(var0, (float)Math.min(0.99, var0.miningProgress));
         if (var0.miningProgress >= 1.0) {
            var0.miningProgress = 0.0;
            var0.action.run();
            if (!var0.ownerRemoval && var0.stillExists.getAsBoolean()) {
               showCrack(var0, 0.0F);
            } else {
               stopMining(var0.player);
            }
         }
      }
   }

   private static int getInputTimeoutTicks(ZGenPvP var0) {
      int var1 = var0.getConfigManager().getConfig().getInt("structure-breaking.input-timeout-ticks", 20);
      return Math.max(4, Math.min(40, var1));
   }

   private static double getVanillaBreakProgressPerTick(Player var0, Block var1) {
      try {
         double var2 = var1.getBreakSpeed(var0);
         if (Double.isFinite(var2) && var2 > 0.0) {
            return Math.max(1.0E-4, Math.min(1.0, var2));
         }
      } catch (Throwable var4) {
      }

      return 0.025;
   }

   public static void stopMining(Player var0, Block var1) {
      if (var0 != null) {
         StructureMiningUtil.MiningSession var2 = ACTIVE.get(var0.getUniqueId());
         if (var2 != null && (var1 == null || var2.sameBlock(var1))) {
            stopMining(var0);
         }
      }
   }

   public static void stopMining(Player var0) {
      if (var0 != null) {
         StructureMiningUtil.MiningSession var1 = ACTIVE.remove(var0.getUniqueId());
         if (var1 != null) {
            cancelSession(var1);
         }

         stopGlobalTaskIfIdle();
      }
   }

   private static void stopGlobalTaskIfIdle() {
      if (ACTIVE.isEmpty()) {
         if (globalTask != null) {
            globalTask.cancel();
            globalTask = null;
         }

         globalPlugin = null;
      }
   }

   private static void cancelSession(StructureMiningUtil.MiningSession var0) {
      if (var0.player.isOnline()) {
         showCrack(var0, 0.0F);
      }
   }

   private static boolean isStillLookingAt(Player var0, Block var1) {
      if (var0.getWorld() != var1.getWorld()) {
         return false;
      }

      Location var2 = var1.getLocation().add(0.5, 0.5, 0.5);
      if (var0.getLocation().distanceSquared(var2) > 49.0) {
         return false;
      }

      Block var3 = var0.getTargetBlockExact(7);
      return var3 != null && var3.getWorld() == var1.getWorld() && var3.getX() == var1.getX() && var3.getY() == var1.getY() && var3.getZ() == var1.getZ();
   }

   private static void showCrack(StructureMiningUtil.MiningSession var0, float var1) {
      try {
         var0.player.sendBlockDamage(var0.block.getLocation(), Math.max(0.0F, Math.min(0.99F, var1)), var0.crackSourceId);
      } catch (Throwable var3) {
      }
   }

   private static final class MiningSession {
      final ZGenPvP plugin;
      final Player player;
      final Block block;
      final String key;
      final boolean ownerRemoval;
      final IntSupplier currentHealth;
      final IntSupplier maximumHealth;
      final BooleanSupplier stillExists;
      final Runnable action;
      final int crackSourceId;
      final int inputTimeoutTicks;
      double miningProgress;
      int ticksSinceInput;

      MiningSession(ZGenPvP var1, Player var2, Block var3, String var4, boolean var5, IntSupplier var6, IntSupplier var7, BooleanSupplier var8, Runnable var9) {
         this.plugin = var1;
         this.player = var2;
         this.block = var3;
         this.key = var4;
         this.ownerRemoval = var5;
         this.currentHealth = var6;
         this.maximumHealth = var7;
         this.stillExists = var8;
         this.action = var9;
         this.crackSourceId = StructureMiningUtil.NEXT_CRACK_SOURCE.getAndIncrement();
         this.inputTimeoutTicks = StructureMiningUtil.getInputTimeoutTicks(var1);
      }

      void registerInput() {
         this.ticksSinceInput = 0;
      }

      boolean matches(Block var1, String var2) {
         return this.key.equals(var2) && this.sameBlock(var1);
      }

      boolean sameBlock(Block var1) {
         return var1 != null
            && this.block.getWorld() == var1.getWorld()
            && this.block.getX() == var1.getX()
            && this.block.getY() == var1.getY()
            && this.block.getZ() == var1.getZ();
      }
   }
}
