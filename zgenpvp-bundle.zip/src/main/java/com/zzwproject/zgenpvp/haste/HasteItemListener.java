package com.zzwproject.zgenpvp.haste;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class HasteItemListener implements Listener {
   private final HasteItemManager manager;

   public HasteItemListener(HasteItemManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
   public void onInteract(PlayerInteractEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         if (event.getAction().isRightClick()) {
            ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
            if (this.manager.isHasteItem(item)) {
               event.setCancelled(true);
               this.manager.use(event.getPlayer());
            }
         }
      }
   }
}
