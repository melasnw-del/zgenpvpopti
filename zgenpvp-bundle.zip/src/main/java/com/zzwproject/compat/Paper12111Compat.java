package com.zzwproject.compat;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Paper12111Compat {
   private static final Map<Class<?>, Method> ITEM_META = new ConcurrentHashMap<>();
   private static final Map<Class<?>, Method> OPEN_INVENTORY = new ConcurrentHashMap<>();
   private static final Map<Class<?>, Method> SKULL_OWNER = new ConcurrentHashMap<>();
   private static final Map<Class<?>, Method> NEARBY = new ConcurrentHashMap<>();

   private Paper12111Compat() {
   }

   public static void applyItemMeta(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            Method var2 = ITEM_META.computeIfAbsent(var0.getClass(), var1x -> findOneArg((Class<?>)var1x, "setItemMeta", var1));
            if (var2 != null) {
               var2.invoke(var0, var1);
            }
         } catch (Throwable var3) {
         }
      }
   }

   public static void openInventory(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            Method var2 = OPEN_INVENTORY.computeIfAbsent(var0.getClass(), var1x -> findOneArg((Class<?>)var1x, "openInventory", var1));
            if (var2 != null) {
               var2.invoke(var0, var1);
            }
         } catch (Throwable var3) {
         }
      }
   }

   public static void setOwningPlayer(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         try {
            Method var2 = SKULL_OWNER.computeIfAbsent(var0.getClass(), var1x -> findOneArg((Class<?>)var1x, "setOwningPlayer", var1));
            if (var2 != null) {
               var2.invoke(var0, var1);
            }
         } catch (Throwable var3) {
         }
      }
   }

   public static List<org.bukkit.entity.Entity> getNearbyEntities(Object var0, Object var1, double var2, double var4, double var6) {
      if (var0 != null && var1 != null) {
         try {
            Method var8 = NEARBY.computeIfAbsent(
               var0.getClass(),
               var1x -> {
                  for (Method var5 : var1x.getMethods()) {
                     if (var5.getName().equals("getNearbyEntities") && var5.getParameterCount() == 4) {
                        Class[] var6x = var5.getParameterTypes();
                        if ((var6x[0].isInstance(var1) || var6x[0].getName().equals("org.bukkit.Location"))
                           && var6x[1] == double.class
                           && var6x[2] == double.class
                           && var6x[3] == double.class) {
                           try {
                              var5.setAccessible(true);
                           } catch (Throwable var8x) {
                           }

                           return var5;
                        }
                     }
                  }

                  return null;
               }
            );
            if (var8 == null) {
               return Collections.emptyList();
            }

            Object var9 = var8.invoke(var0, var1, var2, var4, var6);
            if (var9 instanceof List var12) {
               return var12;
            }

            if (var9 instanceof Collection var10) {
               return new ArrayList(var10);
            }
         } catch (Throwable var11) {
         }

         return Collections.emptyList();
      } else {
         return Collections.emptyList();
      }
   }

   private static Method findOneArg(Class<?> var0, String var1, Object var2) {
      for (Method var6 : var0.getMethods()) {
         if (var6.getName().equals(var1) && var6.getParameterCount() == 1) {
            Class var7 = var6.getParameterTypes()[0];
            if (var2 == null || var7.isInstance(var2) || var7.isAssignableFrom(var2.getClass())) {
               try {
                  var6.setAccessible(true);
               } catch (Throwable var9) {
               }

               return var6;
            }
         }
      }

      return null;
   }
}
