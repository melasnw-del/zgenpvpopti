package com.zzwproject.zmenu.command;

import com.zzwproject.zmenu.ZMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class NightVisionCommand implements CommandExecutor {
   private final ZMenu p;

   public NightVisionCommand(ZMenu var1) {
      this.p = var1;
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("zmenu.nightvision")) {
            this.p.message().send(var5, "no-permission");
            return true;
         } else {
            boolean var6 = this.p.nightVision().toggle(var5);
            this.p.message().send(var5, var6 ? "nightvision-on" : "nightvision-off");
            this.p.sound().play(var5, var6 ? "nightvision-on" : "nightvision-off");
            return true;
         }
      } else {
         this.p.message().send(var1, "player-only");
         return true;
      }
   }
}
