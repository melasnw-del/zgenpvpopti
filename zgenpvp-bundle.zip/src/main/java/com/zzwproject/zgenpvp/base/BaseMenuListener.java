package com.zzwproject.zgenpvp.base;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BaseData;
import com.zzwproject.zgenpvp.model.DefenseData;
import com.zzwproject.zgenpvp.model.GeneratorData;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

public final class BaseMenuListener implements Listener {
   private final ZGenPvP plugin;
   private final BaseManager baseManager;
   private final BaseMenu baseMenu;
   private final BaseEnergyManager energyManager;
   private final Map<UUID, BaseMenuListener.RenameSelection> renameWaiting = new HashMap<>();

   public BaseMenuListener(ZGenPvP var1, BaseManager var2, BaseMenu var3, BaseEnergyManager var4) {
      this.plugin = var1;
      this.baseManager = var2;
      this.baseMenu = var3;
      this.energyManager = var4;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInventoryClick(InventoryClickEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      if (this.baseMenu.isMenu(var2)) {
         var1.setCancelled(true);
         if (var1.getWhoClicked() instanceof Player var4) {
            int var5 = var1.getRawSlot();
            if (var5 >= 0 && var5 < var2.getSize()) {
               String var6 = this.baseMenu.getAction(var1.getCurrentItem());
               if (var6 != null) {
                  Optional var7 = this.baseMenu.getBase(var2);
                  if (var7.isEmpty()) {
                     var4.closeInventory();
                  } else {
                     BaseData var8 = (BaseData)var7.get();
                     if (!this.baseManager.canManageBase(var4, var8)) {
                        var4.closeInventory();
                        this.baseManager.sendOwnerInfo(var4, var8);
                     } else {
                        if (var6.startsWith("LINKED_PAGE_")) {
                           String var14 = var6.substring("LINKED_PAGE_".length());
                           int var15 = var14.lastIndexOf(95);
                           if (var15 > 0 && var15 + 1 < var14.length()) {
                              try {
                                 String var11 = var14.substring(0, var15);
                                 int var12 = Integer.parseInt(var14.substring(var15 + 1));
                                 this.baseMenu.openLinkedList(var4, var8, var11, var12);
                              } catch (NumberFormatException var13) {
                                 this.baseMenu.openLinked(var4, var8);
                              }
                           }

                           return;
                        }

                        if (var6.startsWith("OPEN_LINKED_")) {
                           this.baseMenu.openLinkedList(var4, var8, var6.substring("OPEN_LINKED_".length()), 0);
                           return;
                        }

                        if (var6.startsWith("BULK_UPGRADE_")) {
                           this.bulkUpgrade(var4, var8, var6.substring("BULK_UPGRADE_".length()));
                           return;
                        }

                        switch (var6) {
                           case "OPEN_POWER":
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "OPEN_LINKED":
                              this.baseMenu.openLinked(var4, var8);
                              break;
                           case "BACK_LINKED":
                              this.baseMenu.openLinked(var4, var8);
                              break;
                           case "BACK_MAIN":
                              this.baseMenu.open(var4, var8);
                              break;
                           case "BACK_POWER":
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "OPEN_REMOVE_CONFIRM":
                              this.baseMenu.openRemoveConfirm(var4, var8);
                              break;
                           case "OPEN_UPGRADE_CONFIRM":
                              this.baseMenu.openUpgradeConfirm(var4, var8);
                              break;
                           case "OPEN_POWER_CONFIRM_1":
                              this.baseMenu.openPowerConfirm(var4, var8, "1");
                              break;
                           case "OPEN_POWER_CONFIRM_6":
                              this.baseMenu.openPowerConfirm(var4, var8, "6");
                              break;
                           case "OPEN_POWER_CONFIRM_12":
                              this.baseMenu.openPowerConfirm(var4, var8, "12");
                              break;
                           case "OPEN_POWER_CONFIRM_24":
                              this.baseMenu.openPowerConfirm(var4, var8, "24");
                              break;
                           case "OPEN_POWER_CONFIRM_FULL":
                              this.baseMenu.openPowerConfirm(var4, var8, "FULL");
                              break;
                           case "CONFIRM_POWER_1":
                              this.energyManager.buyHours(var4, var8, 1.0);
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "CONFIRM_POWER_6":
                              this.energyManager.buyHours(var4, var8, 6.0);
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "CONFIRM_POWER_12":
                              this.energyManager.buyHours(var4, var8, 12.0);
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "CONFIRM_POWER_24":
                              this.energyManager.buyHours(var4, var8, 24.0);
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "CONFIRM_POWER_FULL":
                              this.energyManager.buyFull(var4, var8);
                              this.baseMenu.openPower(var4, var8);
                              break;
                           case "RENAME":
                              var4.closeInventory();
                              this.renameWaiting.put(var4.getUniqueId(), new BaseMenuListener.RenameSelection(var8.getId(), var8.getOwnerUuid()));
                              this.plugin.getMessageUtil().send(var4, "base.rename-enter");
                              break;
                           case "CONFIRM_UPGRADE":
                              if (this.baseManager.upgrade(var4, var8)) {
                                 this.plugin.getSoundUtil().play(var4, "button");
                              }

                              this.baseManager
                                 .getBase(var8.getOwnerUuid())
                                 .filter(var1x -> var1x.getId() == var8.getId())
                                 .ifPresent(var2x -> this.baseMenu.open(var4, var2x));
                              break;
                           case "CONFIRM_REMOVE":
                              this.removeBase(var4, var8);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void bulkUpgrade(Player var1, BaseData var2, String var3) {
      int var4 = 0;
      String var5 = var3 == null ? "" : var3.toUpperCase();
      if ("GENERATOR".equals(var5)) {
         for (GeneratorData var7 : this.plugin.getGeneratorRepository().findAllByBase(var2.getId())) {
            if (this.plugin.getGeneratorManager().upgrade(var1, var7)) {
               var4++;
            }
         }
      } else {
         for (DefenseData var13 : this.plugin.getDefenseRepository().findAllByBase(var2.getId())) {
            boolean var8 = var5.equalsIgnoreCase(var13.getType()) || "DEFENSE_BLOCK".equals(var5) && "DEFENSE_TANK".equalsIgnoreCase(var13.getType());
            if (var8) {
               boolean var9 = switch (var5) {
                  case "DEFENSE_DOOR", "DEFENSE_TRAPDOOR" -> this.plugin.getDefenseAccessManager().upgrade(var1, var13);
                  case "DEFENSE_BLOCK" -> this.plugin.getDefenseManager().upgrade(var1, var13);
                  default -> false;
               };
               if (var9) {
                  var4++;
               }
            }
         }
      }

      this.plugin.getMessageUtil().sendActionBar(var1, "base.bulk-upgrade-result", "%count%", String.valueOf(var4));
      this.baseMenu.openLinkedList(var1, var2, var5, this.baseMenu.getLinkedPage(var1.getOpenInventory().getTopInventory()));
   }

   private void removeBase(Player var1, BaseData var2) {
      if (!var2.getOwnerUuid().equals(var1.getUniqueId())) {
         this.baseManager.sendOwnerInfo(var1, var2);
      } else {
         Location var3 = var2.getLocation();
         long var4 = var2.getId();
         if (!this.baseManager.removeByOwner(var1)) {
            this.plugin.getSoundUtil().play(var1, "error");
         } else {
            this.energyManager.deleteEnergy(var4);
            if (var3 != null && var3.getWorld() != null) {
               var3.getBlock().setType(Material.AIR, false);
            }

            var1.closeInventory();
            this.plugin.getSoundUtil().play(var1, "base-break");
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent var1) {
      Inventory var2 = var1.getView().getTopInventory();
      if (this.baseMenu.isMenu(var2)) {
         for (int var4 : var1.getRawSlots()) {
            if (var4 >= 0 && var4 < var2.getSize()) {
               var1.setCancelled(true);
               return;
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onChat(AsyncPlayerChatEvent var1) {
      Player var2 = var1.getPlayer();
      UUID var3 = var2.getUniqueId();
      BaseMenuListener.RenameSelection var4 = this.renameWaiting.remove(var3);
      if (var4 != null) {
         var1.setCancelled(true);
         String var5 = var1.getMessage().trim();
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (var2.isOnline()) {
               if (var5.equalsIgnoreCase("iptal")) {
                  this.plugin.getMessageUtil().send(var2, "base.rename-cancelled");
               } else {
                  Optional var4x = this.baseManager.getBase(var4.ownerUuid());
                  if (!var4x.isEmpty()) {
                     BaseData var5x = (BaseData)var4x.get();
                     if (var5x.getId() == var4.baseId()) {
                        if (!this.baseManager.canManageBase(var2, var5x)) {
                           this.baseManager.sendOwnerInfo(var2, var5x);
                        } else {
                           this.baseManager.renameBase(var2, var5x, var5);
                        }
                     }
                  }
               }
            }
         });
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      this.renameWaiting.remove(var1.getPlayer().getUniqueId());
   }

   private record RenameSelection(long baseId, UUID ownerUuid) {
   }
}
