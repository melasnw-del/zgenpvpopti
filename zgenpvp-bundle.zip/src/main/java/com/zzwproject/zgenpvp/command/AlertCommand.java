package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.raid.RaidAlertManager;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class AlertCommand implements CommandExecutor, TabCompleter {
   private final RaidAlertManager manager;

   public AlertCommand(RaidAlertManager var1) {
      this.manager = var1;
   }

   public boolean onCommand(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (!(var1 instanceof Player var5)) {
         return true;
      } else {
         if (!this.manager.isEnabled()) {
            this.manager.sendMessage(var5, "messages.system-disabled", Map.of());
            return true;
         }

         if (!this.manager.hasMembershipAccess(var5)) {
            this.manager.sendMessage(var5, "messages.no-membership", Map.of());
            return true;
         }

         if (this.manager.requiresLink() && !this.manager.isLinked(var5.getUniqueId())) {
            this.manager.sendMessage(var5, "messages.link-required", Map.of());
            return true;
         }

         if (var4.length == 0) {
            this.manager.sendMessage(var5, "messages.help", Map.of());
            return true;
         }

         String var6 = var4[0].toLowerCase(Locale.ROOT);
         if (var6.equals("durum") || var6.equals("status")) {
            this.manager.sendMessage(var5, "messages.status", Map.of("%status%", this.manager.status(var5.getUniqueId())));
            return true;
         }

         if (var6.equals("kapat") || var6.equals("disable")) {
            this.manager.disable(var5.getUniqueId());
            this.manager.sendMessage(var5, "messages.disabled", Map.of());
            return true;
         }

         if (var6.equals("test")) {
            this.manager.sendMessage(var5, this.manager.test(var5.getUniqueId()) ? "messages.test-sent" : "messages.target-required", Map.of());
            return true;
         }

         if (var6.equals("dm")) {
            this.manager.sendMessage(var5, this.manager.enableDm(var5.getUniqueId()) ? "messages.dm-enabled" : "messages.link-required", Map.of());
            return true;
         }

         if (!var6.equals("webhook")) {
            this.manager.sendMessage(var5, "messages.help", Map.of());
            return true;
         }

         if (!this.manager.webhookEnabled()) {
            this.manager.sendMessage(var5, "messages.webhook-disabled", Map.of());
            return true;
         }

         String var7 = "";
         Boolean var8 = null;

         for (int var9 = 1; var9 < var4.length; var9++) {
            String var10 = var4[var9];
            if (var10.startsWith("url:")) {
               var7 = var10.substring(4);
            } else if (var10.startsWith("everyone:")) {
               var8 = Boolean.parseBoolean(var10.substring(9));
            } else if (var7.isBlank()) {
               var7 = var10;
            } else if (var8 == null) {
               var8 = Boolean.parseBoolean(var10);
            }
         }

         boolean var11 = var8 == null || var8;
         if (this.manager.setWebhook(var5.getUniqueId(), var7, var11)) {
            this.manager.sendMessage(var5, "messages.webhook-enabled", Map.of("%everyone%", String.valueOf(var11)));
         } else {
            this.manager.sendMessage(var5, "messages.invalid-webhook", Map.of());
         }

         return true;
      }
   }

   public List<String> onTabComplete(@NotNull CommandSender var1, @NotNull Command var2, @NotNull String var3, @NotNull String[] var4) {
      if (!(var1 instanceof Player var5 && this.manager.isEnabled() && this.manager.hasMembershipAccess(var5))) {
         return List.of();
      } else {
         if (var4.length == 1) {
            return this.filter(var4[0], List.of("durum", "dm", "webhook", "test", "kapat"));
         }

         if (var4.length >= 2 && var4[0].equalsIgnoreCase("webhook")) {
            if (var4.length == 2) {
               return this.filter(var4[1], List.of("url:https://discord.com/api/webhooks/"));
            }

            if (var4.length == 3) {
               return this.filter(var4[2], List.of("everyone:true", "everyone:false"));
            }
         }

         return List.of();
      }
   }

   private List<String> filter(String var1, List<String> var2) {
      String var3 = var1 == null ? "" : var1.toLowerCase(Locale.ROOT);
      return var2.stream().filter(var1x -> var1x.toLowerCase(Locale.ROOT).startsWith(var3)).toList();
   }
}
