package com.zzwproject.zmenu.gui;

import com.zzwproject.zmenu.ZMenu;
import com.zzwproject.zmenu.util.ColorUtil;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class ServerMenu {
   private final ZMenu plugin;

   public ServerMenu(ZMenu var1) {
      this.plugin = var1;
   }

   public void open(Player var1) {
      int var2 = MenuItems.normalizeSize(this.plugin.getConfig().getInt("menu.size", 45));
      MenuHolder var3 = new MenuHolder("server");
      Inventory var4 = Bukkit.createInventory(var3, var2, ColorUtil.color(this.plugin.getConfig().getString("menu.title", "sunucu menusu")));
      if (this.plugin.getConfig().getBoolean("menu.filler.enabled", true)) {
         Material var5 = MenuItems.material(this.plugin.getConfig().getString("menu.filler.material"), Material.GRAY_STAINED_GLASS_PANE);
         MenuItems.fill(var4, var5, this.plugin.getConfig().getString("menu.filler.name", " "));
      }

      ConfigurationSection var14 = this.plugin.getConfig().getConfigurationSection("menu.items");
      if (var14 != null) {
         for (String var7 : var14.getKeys(false)) {
            String var8 = "menu.items." + var7;
            int var9 = this.plugin.getConfig().getInt(var8 + ".slot", -1);
            if (var9 >= 0 && var9 < var2) {
               Material var10 = MenuItems.material(this.plugin.getConfig().getString(var8 + ".material"), Material.STONE);
               ArrayList var11 = new ArrayList();

               for (String var13 : this.plugin.getConfig().getStringList(var8 + ".lore")) {
                  var11.add(this.replace(var1, var13));
               }

               var4.setItem(var9, MenuItems.item(var10, this.replace(var1, this.plugin.getConfig().getString(var8 + ".name", var7)), var11));
               var3.action(
                  var9,
                  new MenuAction(
                     this.plugin.getConfig().getString(var8 + ".action", "MESSAGE").toUpperCase(),
                     this.plugin.getConfig().getString(var8 + ".value", ""),
                     this.plugin.getConfig().getBoolean(var8 + ".close", true)
                  )
               );
            }
         }
      }

      var1.openInventory(var4);
      this.plugin.sound().play(var1, "menu-open");
   }

   private String replace(Player var1, String var2) {
      String var3 = var2 == null ? "" : var2;
      return var3.replace("%player%", var1.getName())
         .replace("%nightvision_status%", this.plugin.nightVision().isEnabled(var1) ? "&aAcik" : "&cKapali")
         .replace("%generator_count%", String.valueOf(this.plugin.generatorService().count(var1)))
         .replace("%generator_limit%", String.valueOf(this.plugin.generatorService().limit(var1)));
   }
}
