package com.zzwproject.zsafety;

import com.zzwproject.bundle.LegacyPluginBase;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;

public final class ZSafetyFix extends LegacyPluginBase {
   private static final String BAZOOKA = "zzwraid:bazooka";
   private static final String AMMO = "zzwraid:bazooka_ammo";
   private final List<Object> refs = new ArrayList<>();

   @Override
   public void onEnable() {
      try {
         this.registerEvent("org.bukkit.event.block.BlockBreakEvent", this::onAdminBreak, "HIGHEST", false);
         this.registerEvent("org.bukkit.event.block.BlockPlaceEvent", this::onTurretPlace, "HIGHEST", false);
         this.registerEvent("org.bukkit.event.inventory.InventoryClickEvent", this::onInventoryClick, "HIGHEST", false);

         try {
            this.registerEvent("org.bukkit.event.inventory.InventoryCreativeEvent", this::onInventoryClick, "HIGHEST", false);
         } catch (Throwable var2) {
         }

         this.registerEvent("org.bukkit.event.inventory.InventoryDragEvent", this::onInventoryDrag, "HIGHEST", false);
         this.getLogger().info("[ZSafetyFix] OP/creative kirma, base-taret zorunlulugu ve raid item zirh korumasi aktif.");
      } catch (Throwable var3) {
         this.getLogger().log(Level.SEVERE, "[ZSafetyFix] Baslatma hatasi", unwrap(var3));
      }
   }

   @Override
   public void onDisable() {
      this.refs.clear();
   }

   private void onAdminBreak(Object var1) {
      try {
         Object var2 = call(var1, "getPlayer");
         if (!bool(call(var2, "isOp"))) {
            return;
         }

         if (!"CREATIVE".equalsIgnoreCase(String.valueOf(call(call(var2, "getGameMode"), "name")))) {
            return;
         }

         Object var3 = call(var1, "getBlock");
         Object var4 = call(var3, "getLocation");
         Object var5 = this.core();
         if (var5 == null) {
            return;
         }

         Object var6 = optional(safeCall(safeCall(var5, "getBaseManager"), "getBase", var4));
         if (var6 != null) {
            this.cascade(var5, var6);
            this.deleteBase(var5, var6);
            this.setAir(var3);
            this.finishBreak(var1);
            this.send(var2, "&aBase ve bagli savunmalar yonetici olarak kaldirildi.");
            return;
         }

         Object var7 = optional(safeCall(safeCall(var5, "getBeaconManager"), "getBeacon", var4));
         if (var7 != null) {
            this.removeBasesLinkedToBeacon(var5, var7);
            Object var13 = safeCall(var5, "getBeaconRepository");
            safeCall(var13, "deleteById", id(var7));
            this.setAir(var3);
            this.finishBreak(var1);
            this.send(var2, "&aFener yonetici olarak kaldirildi.");
            return;
         }

         Object var8 = optional(safeCall(safeCall(var5, "getTurretManager"), "getTurret", var4));
         if (var8 != null) {
            this.deleteDefense(var5, var8, true);
            this.setAir(var3);
            this.finishBreak(var1);
            this.send(var2, "&aTaret yonetici olarak kaldirildi.");
            return;
         }

         Object var9 = optional(safeCall(safeCall(var5, "getDefenseManager"), "getDefense", var4));
         if (var9 != null) {
            this.deleteDefense(var5, var9, false);
            this.setAir(var3);
            this.finishBreak(var1);
            this.send(var2, "&aDefans blogu yonetici olarak kaldirildi.");
            return;
         }

         Object var10 = optional(safeCall(safeCall(var5, "getDefenseAccessManager"), "get", var3));
         if (var10 != null) {
            this.deleteAccess(var5, var10);
            this.finishBreak(var1);
            this.send(var2, "&aDefans kapi/tuzak kapisi yonetici olarak kaldirildi.");
            return;
         }

         Object var11 = optional(safeCall(safeCall(var5, "getGeneratorManager"), "getGenerator", var4));
         if (var11 != null) {
            this.deleteGenerator(var5, var11);
            this.setAir(var3);
            this.finishBreak(var1);
            this.send(var2, "&aJenerator yonetici olarak kaldirildi.");
         }
      } catch (Throwable var12) {
         this.getLogger().log(Level.WARNING, "[ZSafetyFix] Admin kirma hatasi", unwrap(var12));
      }
   }

   private void onTurretPlace(Object var1) {
      try {
         Object var2 = this.core();
         if (var2 == null) {
            return;
         }

         Object var3 = call(var1, "getItemInHand");
         Object var4 = safeCall(var2, "getItemFactory");
         if (!bool(safeCall(var4, "isTurret", var3))) {
            return;
         }

         Object var5 = call(var1, "getPlayer");
         Object var6 = call(var1, "getBlockPlaced");
         Object var7 = call(var6, "getLocation");
         if (this.hasActiveFriendlyBase(var2, var5, var7)) {
            return;
         }

         call(var1, "setCancelled", true);
         Object var8 = optional(safeCall(safeCall(var2, "getTurretManager"), "getTurret", var7));
         if (var8 != null) {
            this.deleteDefense(var2, var8, true);
         }

         this.setAir(var6);
         this.send(var5, "&cTaret koymak icin bu konumu kapsayan aktif bir base blogun olmali.");
      } catch (Throwable var9) {
         this.getLogger().log(Level.WARNING, "[ZSafetyFix] Taret yerlestirme kontrolu hatasi", unwrap(var9));
      }
   }

   private boolean hasActiveFriendlyBase(Object var1, Object var2, Object var3) {
      try {
         Object var4 = safeCall(var1, "getBaseRepository");
         Object var5 = optional(safeCall(var4, "findContaining", var3));
         if (var5 == null) {
            return false;
         }

         UUID var6 = (UUID)call(var2, "getUniqueId");
         UUID var7 = (UUID)call(var5, "getOwnerUuid");
         boolean var8 = var6.equals(var7);
         if (!var8) {
            Object var9 = safeCall(var1, "getZTeamHook");
            if (var9 != null) {
               var8 = bool(safeCall(var9, "areTeammates", var6, var7));
            }
         }

         if (!var8) {
            return false;
         }

         Object var13 = call(var5, "getLocation");
         Object var10 = call(var13, "getBlock");
         String var11 = String.valueOf(call(call(var10, "getType"), "name"));
         return !var11.equals("AIR") && !var11.equals("CAVE_AIR") && !var11.equals("VOID_AIR");
      } catch (Throwable var12) {
         return false;
      }
   }

   private void onInventoryClick(Object var1) {
      try {
         Object var2 = safeCall(var1, "getSlotType");
         String var3 = String.valueOf(var2);
         Object var4 = safeCall(var1, "getCursor");
         Object var5 = safeCall(var1, "getCurrentItem");
         String var6 = String.valueOf(safeCall(var1, "getClick"));
         if ("ARMOR".equalsIgnoreCase(var3) && this.isRestricted(var4)) {
            call(var1, "setCancelled", true);
            return;
         }

         if (!"ARMOR".equalsIgnoreCase(var3) && var6.contains("SHIFT") && this.isRestricted(var5)) {
            call(var1, "setCancelled", true);
            return;
         }

         if ("ARMOR".equalsIgnoreCase(var3) && (var6.contains("NUMBER_KEY") || var6.contains("SWAP_OFFHAND"))) {
            Object var7 = safeCall(var1, "getWhoClicked");
            Object var8 = safeCall(var7, "getInventory");
            int var9 = -1;
            Object var10 = safeCall(var1, "getHotbarButton");
            if (var10 instanceof Number) {
               var9 = ((Number)var10).intValue();
            }

            Object var11 = var9 >= 0 ? safeCall(var8, "getItem", var9) : safeCall(var8, "getItemInOffHand");
            if (this.isRestricted(var11)) {
               call(var1, "setCancelled", true);
               return;
            }
         }

         Object var13 = safeCall(var1, "getAction");
         if ("ARMOR".equalsIgnoreCase(var3) && String.valueOf(var13).contains("HOTBAR") && this.isRestricted(var4)) {
            call(var1, "setCancelled", true);
         }
      } catch (Throwable var12) {
      }
   }

   private void onInventoryDrag(Object var1) {
      try {
         Object var2 = safeCall(var1, "getOldCursor");
         if (!this.isRestricted(var2)) {
            return;
         }

         Object var3 = safeCall(var1, "getRawSlots");
         Object var4 = safeCall(var1, "getView");
         if (var3 instanceof Iterable) {
            for (Object var7 : (Iterable)var3) {
               if (var7 instanceof Number) {
                  Object var8 = safeCall(var4, "getSlotType", ((Number)var7).intValue());
                  if ("ARMOR".equalsIgnoreCase(String.valueOf(var8))) {
                     call(var1, "setCancelled", true);
                     return;
                  }
               }
            }
         }
      } catch (Throwable var9) {
      }
   }

   private boolean isRestricted(Object var1) {
      return this.isCustom(var1, "zzwraid:bazooka") || this.isCustom(var1, "zzwraid:bazooka_ammo");
   }

   private boolean isCustom(Object var1, String var2) {
      if (var1 == null) {
         return false;
      }

      try {
         Class var3 = Class.forName("dev.lone.itemsadder.api.CustomStack");
         Object var4 = null;

         try {
            var4 = callStatic(var3, "byItemStack", var1);
         } catch (Throwable var10) {
         }

         if (var4 == null) {
            for (Method var8 : var3.getMethods()) {
               if (var8.getName().equals("getInstance") && var8.getParameterCount() == 1 && var8.getParameterTypes()[0].isInstance(var1)) {
                  var4 = var8.invoke(null, var1);
                  break;
               }
            }
         }

         if (var4 == null) {
            return false;
         }

         for (String var15 : new String[]{"getNamespacedID", "getNamespacedId", "getId"}) {
            Object var9 = safeCall(var4, var15);
            if (var9 != null && var2.equalsIgnoreCase(String.valueOf(var9))) {
               return true;
            }
         }
      } catch (Throwable var11) {
      }

      return false;
   }

   private void removeBasesLinkedToBeacon(Object var1, Object var2) {
      try {
         long var3 = id(var2);
         Object var5 = safeCall(var1, "getBaseRepository");
         Object var6 = safeCall(var5, "findAll");
         if (var6 instanceof Iterable) {
            for (Object var9 : (Iterable)var6) {
               if (((Number)call(var9, "getBeaconId")).longValue() == var3) {
                  this.cascade(var1, var9);
                  this.deleteBase(var1, var9);
               }
            }
         }
      } catch (Throwable var10) {
      }
   }

   private void deleteBase(Object var1, Object var2) {
      try {
         Object var3 = call(var1, "getBaseRepository");
         safeCall(var3, "deleteByOwner", call(var2, "getOwnerUuid"));
         Object var4 = safeCall(var1, "getBaseEnergyManager");
         if (var4 != null) {
            safeCall(var4, "deleteEnergy", id(var2));
         }
      } catch (Throwable var5) {
      }
   }

   private void cascade(Object var1, Object var2) {
      try {
         Class var3 = Class.forName("com.zzwproject.zgenpvp.hotfix.BaseCascade");
         callStatic(var3, "remove", var1, var2);
      } catch (Throwable var4) {
         this.getLogger().log(Level.WARNING, "[ZSafetyFix] Base cascade cagrisi hatasi", unwrap(var4));
      }
   }

   private void deleteDefense(Object var1, Object var2, boolean var3) {
      long var4 = id(var2);
      if (var3) {
         Object var6 = safeCall(var1, "getTurretTask");
         if (var6 != null) {
            safeCall(var6, "removeVisual", var4);
         }
      }

      Object var8 = safeCall(var1, "getDefenseRepository");
      safeCall(var8, "delete", var4);
      Object var7 = safeCall(var1, var3 ? "getTurretManager" : "getDefenseManager");
      if (var7 != null) {
         safeCall(var7, "loadCache");
      }
   }

   private void deleteAccess(Object var1, Object var2) {
      try {
         Object var3 = call(var2, "getLocation");
         String var4 = String.valueOf(call(var2, "getType")).toUpperCase(Locale.ROOT);
         this.clearLocation(var3);
         if (var4.contains("DOOR") && !var4.contains("TRAP")) {
            this.clearRelativeDoor(var3, 1);
            this.clearRelativeDoor(var3, -1);
         }

         Object var5 = safeCall(var1, "getDefenseRepository");
         safeCall(var5, "delete", id(var2));
         Object var6 = safeCall(var1, "getDefenseAccessManager");
         safeCall(var6, "loadCache");
      } catch (Throwable var7) {
      }
   }

   private void deleteGenerator(Object var1, Object var2) {
      try {
         long var3 = id(var2);
         Object var5 = safeCall(var1, "getGeneratorManager");
         Object var6 = safeCall(var1, "getGeneratorRepository");
         safeCall(var6, "delete", var3);
         Object var7 = getField(var5, "visualManager");
         if (var7 != null) {
            safeCall(var7, "remove", var3);
         }

         if (getField(var5, "generatorCache") instanceof Map var9) {
            Object var10 = call(var2, "getLocation");
            String var11 = String.valueOf(safeCall(var5, "key", var10));
            var9.remove(var11);
         }

         safeCall(var5, "loadCache");
      } catch (Throwable var12) {
      }
   }

   private void finishBreak(Object var1) {
      safeCall(var1, "setCancelled", false);
      safeCall(var1, "setDropItems", false);
      safeCall(var1, "setExpToDrop", 0);
   }

   private void clearLocation(Object var1) throws Exception {
      this.setAir(call(var1, "getBlock"));
   }

   private void clearRelativeDoor(Object var1, int var2) {
      try {
         Object var3 = call(var1, "clone");
         call(var3, "add", 0.0, (double)var2, 0.0);
         Object var4 = call(var3, "getBlock");
         String var5 = String.valueOf(call(call(var4, "getType"), "name"));
         if (var5.contains("DOOR") && !var5.contains("TRAP")) {
            this.setAir(var4);
         }
      } catch (Throwable var6) {
      }
   }

   private void setAir(Object var1) throws Exception {
      Class var2 = Class.forName("org.bukkit.Material");
      Enum var3 = Enum.valueOf(var2, "AIR");

      try {
         call(var1, "setType", var3, false);
      } catch (Throwable var5) {
         call(var1, "setType", var3);
      }
   }

   private Object core() {
      try {
         Object var1 = callStatic(Class.forName("org.bukkit.Bukkit"), "getPluginManager");
         Class var2 = Class.forName("com.zzwproject.bundle.BundleResolver");
         return callStatic(var2, "getPlugin", var1, "ZGenPvP");
      } catch (Throwable var3) {
         return null;
      }
   }

   private void registerEvent(String var1, Consumer<Object> var2, String var3, boolean var4) throws Exception {
      ClassLoader var5 = this.getClass().getClassLoader();
      Class var6 = Class.forName("org.bukkit.event.Listener");
      Class var7 = Class.forName("org.bukkit.plugin.EventExecutor");
      Class var8 = Class.forName(var1);
      Class var9 = Class.forName("org.bukkit.event.EventPriority");
      Class var10 = Class.forName("org.bukkit.plugin.Plugin");
      Enum var11 = Enum.valueOf(var9, var3);
      Object var12 = Proxy.newProxyInstance(var5, new Class[]{var6}, (var0, var1x, var2x) -> objMethod(var0, var1x, var2x, "ZSafetyFixListener"));
      Object var13 = Proxy.newProxyInstance(var5, new Class[]{var7}, (var3x, var4x, var5x) -> {
         if (var4x.getName().equals("execute") && var5x != null && var5x.length >= 2) {
            try {
               var2.accept(var5x[1]);
            } catch (Throwable var7x) {
               this.getLogger().log(Level.WARNING, "[ZSafetyFix] Event hatasi: " + var1, unwrap(var7x));
            }
         }

         return null;
      });
      this.refs.add(var12);
      this.refs.add(var13);
      Object var14 = callStatic(Class.forName("org.bukkit.Bukkit"), "getPluginManager");
      Method var15 = findMethod(var14.getClass(), "registerEvent", new Object[]{var8, var12, var11, var13, this, var4});
      if (var15 == null) {
         throw new NoSuchMethodException("registerEvent");
      }

      var15.setAccessible(true);
      var15.invoke(var14, var8, var12, var11, var13, this, var4);
   }

   private static long id(Object var0) {
      try {
         return ((Number)call(var0, "getId")).longValue();
      } catch (Throwable var2) {
         return -1L;
      }
   }

   private static Object optional(Object var0) {
      try {
         return var0 instanceof Optional var1 ? var1.orElse(null) : var0;
      } catch (Throwable var2) {
         return null;
      }
   }

   private void send(Object var1, String var2) {
      try {
         call(var1, "sendMessage", var2.replace('&', '§'));
      } catch (Throwable var4) {
      }
   }

   private static boolean bool(Object var0) {
      return Boolean.TRUE.equals(var0);
   }

   private static Object getField(Object var0, String var1) {
      try {
         for (Class var2 = var0.getClass(); var2 != null; var2 = var2.getSuperclass()) {
            try {
               Field var3 = var2.getDeclaredField(var1);
               var3.setAccessible(true);
               return var3.get(var0);
            } catch (NoSuchFieldException var4) {
            }
         }
      } catch (Throwable var5) {
      }

      return null;
   }

   private static Object objMethod(Object var0, Method var1, Object[] var2, String var3) {
      return switch (var1.getName()) {
         case "toString" -> var3;
         case "hashCode" -> System.identityHashCode(var0);
         case "equals" -> var2 != null && var2.length == 1 && var0 == var2[0];
         default -> null;
      };
   }

   private static Throwable unwrap(Throwable var0) {
      return var0.getCause() != null ? var0.getCause() : var0;
   }

   private static Object safeCall(Object var0, String var1, Object... var2) {
      try {
         return call(var0, var1, var2);
      } catch (Throwable var4) {
         return null;
      }
   }

   private static Object callStatic(Class<?> var0, String var1, Object... var2) throws Exception {
      Method var3 = findMethod(var0, var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getName() + "." + var1);
      }

      var3.setAccessible(true);
      return var3.invoke(null, var2);
   }

   private static Object call(Object var0, String var1, Object... var2) throws Exception {
      if (var0 == null) {
         throw new NullPointerException(var1);
      }

      Method var3 = findMethod(var0.getClass(), var1, var2);
      if (var3 == null) {
         throw new NoSuchMethodException(var0.getClass().getName() + "." + var1 + "/" + var2.length);
      }

      var3.setAccessible(true);
      return var3.invoke(var0, var2);
   }

   private static Method findMethod(Class<?> var0, String var1, Object[] var2) {
      for (Class var3 = var0; var3 != null; var3 = var3.getSuperclass()) {
         for (Method var7 : var3.getDeclaredMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2.length) {
               Class[] var8 = var7.getParameterTypes();
               boolean var9 = true;

               for (int var10 = 0; var10 < var8.length; var10++) {
                  Object var11 = var2[var10];
                  if (var11 == null) {
                     if (var8[var10].isPrimitive()) {
                        var9 = false;
                        break;
                     }
                  } else {
                     Class var12 = wrap(var8[var10]);
                     if (!var12.isInstance(var11) && (!Number.class.isAssignableFrom(var12) || !(var11 instanceof Number))) {
                        var9 = false;
                        break;
                     }
                  }
               }

               if (var9) {
                  return var7;
               }
            }
         }
      }

      for (Method var16 : var0.getMethods()) {
         if (var16.getName().equals(var1) && var16.getParameterCount() == var2.length) {
            Class[] var17 = var16.getParameterTypes();
            boolean var18 = true;

            for (int var19 = 0; var19 < var17.length; var19++) {
               Object var20 = var2[var19];
               if (var20 == null) {
                  if (var17[var19].isPrimitive()) {
                     var18 = false;
                     break;
                  }
               } else {
                  Class var21 = wrap(var17[var19]);
                  if (!var21.isInstance(var20) && (!Number.class.isAssignableFrom(var21) || !(var20 instanceof Number))) {
                     var18 = false;
                     break;
                  }
               }
            }

            if (var18) {
               return var16;
            }
         }
      }

      return null;
   }

   private static Class<?> wrap(Class<?> var0) {
      if (!var0.isPrimitive()) {
         return var0;
      } else if (var0 == int.class) {
         return Integer.class;
      } else if (var0 == long.class) {
         return Long.class;
      } else if (var0 == double.class) {
         return Double.class;
      } else if (var0 == float.class) {
         return Float.class;
      } else if (var0 == boolean.class) {
         return Boolean.class;
      } else if (var0 == short.class) {
         return Short.class;
      } else if (var0 == byte.class) {
         return Byte.class;
      } else {
         return var0 == char.class ? Character.class : var0;
      }
   }
}
