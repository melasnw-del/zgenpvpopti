package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.access.DefenseAccessType;
import com.zzwproject.zgenpvp.item.SpecialItemFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class ZGenPvPCommand implements CommandExecutor, TabCompleter {
   private final ZGenPvP plugin;
   private final SpecialItemFactory itemFactory;

   public ZGenPvPCommand(ZGenPvP var1, SpecialItemFactory var2) {
      this.plugin = var1;
      this.itemFactory = var2;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("zgenpvp.admin")) {
         this.plugin.getMessageUtil().send(var1, "general.no-permission");
         return true;
      }

      if (var4.length == 0) {
         this.sendHelp(var1);
         return true;
      }

      switch (var4[0].toLowerCase(Locale.ROOT)) {
         case "reload":
            this.plugin.reloadPlugin();
            this.plugin.getMessageUtil().send(var1, "general.reload");
            break;
         case "status":
            this.sendStatus(var1);
            break;
         case "givebeacon":
            this.giveBeacon(var1, var4);
            break;
         case "givebase":
            this.giveBase(var1, var4);
            break;
         case "givegenerator":
            this.giveGenerator(var1, var4);
            break;
         case "givemoney":
            this.giveMoney(var1, var4);
            break;
         case "givelinker":
            this.giveLinker(var1, var4);
            break;
         case "givesellwand":
            this.giveSellWand(var1, var4);
            break;
         case "givedefense":
            this.giveDefense(var1, var4);
            break;
         case "giveturret":
            this.giveTurret(var1, var4);
            break;
         case "givedoor":
            this.giveDoor(var1, var4);
            break;
         case "givetrapdoor":
            this.giveTrapdoor(var1, var4);
            break;
         default:
            this.sendHelp(var1);
      }

      return true;
   }

   private void giveBeacon(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         this.giveItem(var3, this.itemFactory.createRespawnBeacon());
         this.plugin.getMessageUtil().send(var1, "admin.beacon-given", "%player%", var3.getName());
         this.plugin.getMessageUtil().send(var3, "admin.beacon-received");
      }
   }

   private void giveBase(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         this.giveItem(var3, this.itemFactory.createBaseBlock());
         this.plugin.getMessageUtil().send(var1, "admin.base-given", "%player%", var3.getName());
         this.plugin.getMessageUtil().send(var3, "admin.base-received");
      }
   }

   private void giveGenerator(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         int var4 = this.getLevel(var1, var2, this.plugin.getGeneratorManager().getMaxLevel());
         if (var4 != -1) {
            this.giveItem(var3, this.plugin.getGeneratorManager().createGeneratorItem(var4));
            this.plugin.getMessageUtil().send(var1, "admin.generator-given", "%player%", var3.getName(), "%level%", String.valueOf(var4));
            this.plugin.getMessageUtil().send(var3, "admin.generator-received", "%level%", String.valueOf(var4));
         }
      }
   }

   private void giveMoney(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         if (var2.length < 3) {
            this.plugin.getMessageUtil().sendList(var1, "admin.help");
         } else {
            double var4;
            try {
               var4 = Double.parseDouble(var2[2]);
            } catch (NumberFormatException var9) {
               this.plugin.getMessageUtil().send(var1, "admin.invalid-money");
               return;
            }

            if (Double.isFinite(var4) && !(var4 <= 0.0)) {
               int var6 = 1;
               if (var2.length >= 4) {
                  try {
                     var6 = Integer.parseInt(var2[3]);
                  } catch (NumberFormatException var8) {
                     this.plugin.getMessageUtil().send(var1, "admin.invalid-money-count");
                     return;
                  }
               }

               if (var6 >= 1 && var6 <= 64) {
                  ItemStack var7 = this.plugin.getMoneyItemManager().createMoney(var4);
                  if (var7 == null) {
                     this.plugin.getMessageUtil().send(var1, "general.error");
                  } else {
                     var7.setAmount(var6);
                     this.giveItem(var3, var7);
                     this.plugin
                        .getMessageUtil()
                        .send(var1, "admin.money-given", "%player%", var3.getName(), "%value%", this.formatNumber(var4), "%count%", String.valueOf(var6));
                     this.plugin.getMessageUtil().send(var3, "admin.money-received", "%value%", this.formatNumber(var4), "%count%", String.valueOf(var6));
                  }
               } else {
                  this.plugin.getMessageUtil().send(var1, "admin.invalid-money-count");
               }
            } else {
               this.plugin.getMessageUtil().send(var1, "admin.invalid-money");
            }
         }
      }
   }

   private String formatNumber(double var1) {
      return var1 == Math.rint(var1) ? String.valueOf((long)var1) : String.valueOf(var1);
   }

   private void giveLinker(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         this.giveItem(var3, this.plugin.getGeneratorLinkItem().create());
         this.plugin.getMessageUtil().send(var1, "admin.linker-given", "%player%", var3.getName());
         this.plugin.getMessageUtil().send(var3, "admin.linker-received");
      }
   }

   private void giveSellWand(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         if (var2.length < 3) {
            this.plugin.getMessageUtil().send(var1, "admin.invalid-sell-wand");
         } else {
            int var4;
            try {
               var4 = Integer.parseInt(var2[2]);
            } catch (NumberFormatException var6) {
               this.plugin.getMessageUtil().send(var1, "admin.invalid-sell-wand");
               return;
            }

            if (!this.plugin.getSellWandManager().isAllowedUses(var4)) {
               this.plugin.getMessageUtil().send(var1, "admin.invalid-sell-wand");
            } else {
               ItemStack var5 = this.plugin.getSellWandManager().createWand(var4);
               if (var5 == null) {
                  this.plugin.getMessageUtil().send(var1, "admin.item-disabled");
               } else {
                  this.giveItem(var3, var5);
                  this.plugin.getMessageUtil().send(var1, "admin.sell-wand-given", "%player%", var3.getName(), "%uses%", String.valueOf(var4));
                  this.plugin.getMessageUtil().send(var3, "admin.sell-wand-received", "%uses%", String.valueOf(var4));
               }
            }
         }
      }
   }

   private void giveDefense(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         int var4 = this.getLevel(var1, var2, this.plugin.getDefenseManager().getMaxLevel());
         if (var4 != -1) {
            this.giveItem(var3, this.itemFactory.createDefenseBlock(var4));
            this.plugin.getMessageUtil().send(var1, "admin.defense-given", "%player%", var3.getName(), "%level%", String.valueOf(var4));
            this.plugin.getMessageUtil().send(var3, "admin.defense-received", "%level%", String.valueOf(var4));
         }
      }
   }

   private void giveTurret(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         int var4 = this.getLevel(var1, var2, this.plugin.getTurretManager().getMaxLevel());
         if (var4 != -1) {
            this.giveItem(var3, this.itemFactory.createTurret(var4));
            this.plugin.getMessageUtil().send(var1, "admin.turret-given", "%player%", var3.getName(), "%level%", String.valueOf(var4));
            this.plugin.getMessageUtil().send(var3, "admin.turret-received", "%level%", String.valueOf(var4));
         }
      }
   }

   private void giveDoor(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         int var4 = this.getLevel(var1, var2, this.plugin.getDefenseAccessManager().getMaxLevel(DefenseAccessType.DOOR));
         if (var4 != -1) {
            this.giveItem(var3, this.itemFactory.createDefenseDoor(var4));
            this.plugin.getMessageUtil().send(var1, "admin.door-given", "%player%", var3.getName(), "%level%", String.valueOf(var4));
            this.plugin.getMessageUtil().send(var3, "admin.door-received", "%level%", String.valueOf(var4));
         }
      }
   }

   private void giveTrapdoor(CommandSender var1, String[] var2) {
      Player var3 = this.getTarget(var1, var2);
      if (var3 != null) {
         int var4 = this.getLevel(var1, var2, this.plugin.getDefenseAccessManager().getMaxLevel(DefenseAccessType.TRAPDOOR));
         if (var4 != -1) {
            this.giveItem(var3, this.itemFactory.createDefenseTrapdoor(var4));
            this.plugin.getMessageUtil().send(var1, "admin.trapdoor-given", "%player%", var3.getName(), "%level%", String.valueOf(var4));
            this.plugin.getMessageUtil().send(var3, "admin.trapdoor-received", "%level%", String.valueOf(var4));
         }
      }
   }

   private void sendStatus(CommandSender var1) {
      this.plugin
         .getMessageUtil()
         .sendList(
            var1,
            "admin.status",
            "%version%",
            this.plugin.getDescription().getVersion(),
            "%database%",
            this.plugin.getDatabaseManager().isConnected() ? "&aʙᴀɢʟɪ" : "&cʙᴀɢʟɪ ᴅᴇɢɪʟ",
            "%economy%",
            this.plugin.getEconomyManager().isAvailable() ? "&a" + this.plugin.getEconomyManager().getProviderName() : "&cʙᴜʟᴜɴᴀᴍᴀᴅɪ",
            "%beacon%",
            this.status(this.plugin.getBeaconManager().isEnabled()),
            "%base%",
            this.status(this.plugin.getBaseManager().isEnabled()),
            "%generator%",
            this.status(this.plugin.getGeneratorManager().isEnabled()),
            "%sell_wand%",
            this.status(this.plugin.getSellWandManager().isEnabled()),
            "%defense%",
            this.status(this.plugin.getDefenseManager().isEnabled()),
            "%turret%",
            this.status(this.plugin.getTurretManager().isEnabled()),
            "%door%",
            this.status(this.plugin.getDefenseAccessManager().isEnabled(DefenseAccessType.DOOR)),
            "%trapdoor%",
            this.status(this.plugin.getDefenseAccessManager().isEnabled(DefenseAccessType.TRAPDOOR))
         );
   }

   private String status(boolean var1) {
      return var1 ? "&aᴀᴋᴛɪꜰ" : "&cᴋᴀᴘᴀʟɪ";
   }

   private Player getTarget(CommandSender var1, String[] var2) {
      if (var2.length < 2) {
         this.plugin.getMessageUtil().send(var1, "admin.player-required");
         return null;
      }

      Player var3 = Bukkit.getPlayer(var2[1]);
      if (var3 == null) {
         this.plugin.getMessageUtil().send(var1, "general.player-not-found");
      }

      return var3;
   }

   private int getLevel(CommandSender var1, String[] var2, int var3) {
      int var4 = 1;
      if (var2.length >= 3) {
         try {
            var4 = Integer.parseInt(var2[2]);
         } catch (NumberFormatException var6) {
            this.plugin.getMessageUtil().send(var1, "admin.invalid-level", "%max%", String.valueOf(var3));
            return -1;
         }
      }

      if (var4 >= 1 && var4 <= var3) {
         return var4;
      }

      this.plugin.getMessageUtil().send(var1, "admin.invalid-level", "%max%", String.valueOf(var3));
      return -1;
   }

   private void giveItem(Player var1, ItemStack var2) {
      if (var2 != null) {
         HashMap<Integer, ItemStack> var3 = var1.getInventory().addItem(new ItemStack[]{var2});

         for (ItemStack var5 : var3.values()) {
            var1.getWorld().dropItemNaturally(var1.getLocation(), var5);
         }
      }
   }

   private void sendHelp(CommandSender var1) {
      this.plugin.getMessageUtil().sendList(var1, "admin.help");
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("zgenpvp.admin")) {
         return Collections.emptyList();
      }

      if (var4.length == 1) {
         return this.filter(
            var4[0],
            List.of(
               "status",
               "reload",
               "givebeacon",
               "givebase",
               "givegenerator",
               "givemoney",
               "givelinker",
               "givesellwand",
               "givedefense",
               "giveturret",
               "givedoor",
               "givetrapdoor"
            )
         );
      }

      if (var4.length == 2 && this.isGiveCommand(var4[0])) {
         return this.filter(var4[1], Bukkit.getOnlinePlayers().stream().<String>map(Player::getName).toList());
      }

      if (var4.length == 3 && var4[0].equalsIgnoreCase("givesellwand")) {
         return this.filter(var4[2], List.of("15", "30", "50"));
      }

      if (var4.length == 3 && var4[0].equalsIgnoreCase("givemoney")) {
         return this.filter(var4[2], List.of("1", "100", "500", "1000", "5000", "7500", "10000"));
      }

      if (var4.length == 4 && var4[0].equalsIgnoreCase("givemoney")) {
         return this.filter(var4[3], List.of("1", "2", "4", "8", "16", "32", "64"));
      }

      if (var4.length != 3) {
         return Collections.emptyList();
      }

      int var5 = this.getMaximumLevel(var4[0]);
      if (var5 <= 0) {
         return Collections.emptyList();
      }

      ArrayList var6 = new ArrayList();

      for (int var7 = 1; var7 <= var5; var7++) {
         var6.add(String.valueOf(var7));
      }

      return this.filter(var4[2], var6);
   }

   private boolean isGiveCommand(String var1) {
      return switch (var1.toLowerCase(Locale.ROOT)) {
         case "givebeacon", "givebase", "givegenerator", "givemoney", "givelinker", "givesellwand", "givedefense", "giveturret", "givedoor", "givetrapdoor" -> true;
         default -> false;
      };
   }

   private int getMaximumLevel(String var1) {
      return switch (var1.toLowerCase(Locale.ROOT)) {
         case "givegenerator" -> this.plugin.getGeneratorManager().getMaxLevel();
         case "givedefense" -> this.plugin.getDefenseManager().getMaxLevel();
         case "giveturret" -> this.plugin.getTurretManager().getMaxLevel();
         case "givedoor" -> this.plugin.getDefenseAccessManager().getMaxLevel(DefenseAccessType.DOOR);
         case "givetrapdoor" -> this.plugin.getDefenseAccessManager().getMaxLevel(DefenseAccessType.TRAPDOOR);
         default -> 0;
      };
   }

   private List<String> filter(String var1, List<String> var2) {
      String var3 = var1.toLowerCase(Locale.ROOT);
      return var2.stream().filter(var1x -> var1x.toLowerCase(Locale.ROOT).startsWith(var3)).toList();
   }
}
