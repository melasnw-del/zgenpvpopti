package com.zzwproject.zgenpvp.raid;

import com.zzwproject.bundle.BundleResolver;
import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.model.BeaconData;
import com.zzwproject.zgenpvp.util.ColorUtil;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.Plugin;

public final class RaidAlertManager implements Listener {
   private final ZGenPvP plugin;
   private final File dataFile;
   private final YamlConfiguration data;
   private final HttpClient http;
   private final Map<UUID, RaidAlertManager.Window> windows = new HashMap<>();

   public RaidAlertManager(ZGenPvP var1) {
      this.plugin = var1;
      this.dataFile = new File(var1.getDataFolder(), "raid-alerts.yml");
      this.data = YamlConfiguration.loadConfiguration(this.dataFile);
      this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(this.timeout())).build();
      var1.getServer().getPluginManager().registerEvents(this, var1);
   }

   private FileConfiguration cfg() {
      return this.plugin.getConfigManager().getAlerts();
   }

   public boolean isEnabled() {
      return this.cfg().getBoolean("system.enabled", true);
   }

   public boolean requiresLink() {
      return this.cfg().getBoolean("system.require-linked-account", true);
   }

   public boolean isLinked(UUID var1) {
      return this.zbotLinked(var1);
   }

   public boolean hasMembershipAccess(Player var1) {
      if (var1 != null && this.isEnabled()) {
         List<String> var2 = this.cfg().getStringList("system.access-permissions");
         if (var2.isEmpty()) {
            return var1.hasPermission("zgenpvp.raidalerts.use");
         }

         for (String var4 : var2) {
            if (var4 != null && !var4.isBlank() && var1.hasPermission(var4)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean hasAccess(Player var1) {
      return this.hasMembershipAccess(var1) && (!this.requiresLink() || this.zbotLinked(var1.getUniqueId()));
   }

   public void alert(UUID var1, Player var2, String var3, Location var4, int var5, int var6, int var7, String var8) {
      if (this.isEnabled() && var1 != null && var4 != null && var4.getWorld() != null) {
         if (!this.cfg().getBoolean("notifications.destroyed-only", true) || var6 <= 0) {
            this.dispatch(var1, var2, var3, var4.getBlock().getType().name(), var4, var5, var8, 0);
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void captureBeaconBreak(BlockBreakEvent var1) {
      if (this.isEnabled() && var1.getBlock().getType() == Material.BEACON) {
         Location var2 = var1.getBlock().getLocation();
         Optional var3 = this.plugin.getBeaconManager().getBeacon(var2);
         if (!var3.isEmpty() && !((BeaconData)var3.get()).getOwnerUuid().equals(var1.getPlayer().getUniqueId())) {
            BeaconData var4 = (BeaconData)var3.get();
            int var5 = this.defenseCount(var4.getOwnerUuid());
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
               if (!this.plugin.getBeaconManager().getBeacon(var2).isPresent()) {
                  int var5x = Math.max(0, var5 - this.defenseCount(var4.getOwnerUuid()));
                  this.dispatch(var4.getOwnerUuid(), var1.getPlayer(), "respawn beacon", "BEACON", var2, 1, "dusman oyuncu tarafından kirildi", var5x);
               }
            }, 1L);
         }
      }
   }

   private int defenseCount(UUID var1) {
      Optional<com.zzwproject.zgenpvp.model.BaseData> var2 = this.plugin.getBaseRepository().findByOwner(var1);
      return var2.<Integer>map(var1x -> this.plugin.getDefenseRepository().findAllByBase(var1x.getId()).size()).orElse(0);
   }

   private void dispatch(UUID var1, Player var2, String var3, String var4, Location var5, int var6, String var7, int var8) {
      if (this.canDeliver(var1)) {
         long var9 = System.currentTimeMillis();
         RaidAlertManager.Window var11 = this.windows.get(var1);
         if (var11 != null && var9 - var11.startedAt < this.spamSeconds() * 1000L) {
            var11.extra++;
            var11.objects.merge(var3, 1, Integer::sum);
            var11.lastAttacker = this.attackerName(var2);
            var11.beaconCascade += var8;
         } else {
            RaidAlertManager.Window var12 = new RaidAlertManager.Window(var9, this.attackerName(var2));
            var12.objects.put(var3, 1);
            var12.beaconCascade = var8;
            this.windows.put(var1, var12);
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.summary(var1, var12), this.spamSeconds() * 20L);
            LinkedHashMap var13 = new LinkedHashMap();
            var13.put(this.field("object", "koruma nesnesi"), var3);
            var13.put(this.field("material", "blok materyali"), this.readable(var4));
            var13.put(this.field("level", "Seviye"), String.valueOf(var6));
            var13.put(this.field("world", "dunya"), var5.getWorld().getName());
            var13.put(this.field("coordinates", "Konum"), this.coordinates(var5));
            var13.put(this.field("attacker", "saldiran oyuncu"), var12.lastAttacker);
            var13.put(this.field("attack-source", "Kullanilan arac"), this.attackSource(var7));
            var13.put(this.field("reason", "yikim nedeni"), var7 == null ? "Bilinmiyor" : var7);
            if (var3.equalsIgnoreCase("respawn beacon") || var8 > 0) {
               var13.put(this.field("beacon-cascade", "beacon ile silinen savunma"), String.valueOf(var8));
            }

            this.notifyGame(
               var1,
               "messages.in-game-alert",
               Map.of(
                  "%object%",
                  var3,
                  "%world%",
                  var5.getWorld().getName(),
                  "%x%",
                  String.valueOf(var5.getBlockX()),
                  "%y%",
                  String.valueOf(var5.getBlockY()),
                  "%z%",
                  String.valueOf(var5.getBlockZ())
               )
            );
            this.send(
               var1,
               this.cfg().getString("embed.detail-title", "koruma uyarisi"),
               this.cfg().getString("embed.detail-description", "koruma alaninizda yikim tespit edildi."),
               var13,
               this.cfg().getInt("embed.detail-color", 15548997),
               true
            );
         }
      }
   }

   private void summary(UUID var1, RaidAlertManager.Window var2) {
      if (this.windows.get(var1) == var2) {
         this.windows.remove(var1);
         if (var2.extra > 0 && this.canDeliver(var1)) {
            int var3 = Math.max(1, this.cfg().getInt("notifications.summary-max-object-types", 8));
            ArrayList var4 = new ArrayList();

            for (Entry var6 : var2.objects.entrySet()) {
               if (var4.size() >= var3) {
                  break;
               }

               var4.add((String)var6.getKey() + " ×" + var6.getValue());
            }

            LinkedHashMap var7 = new LinkedHashMap();
            var7.put(this.field("summary-count", "ek yikim"), String.valueOf(var2.extra));
            var7.put(this.field("summary-objects", "Yikilan nesneler"), String.join("\n", var4));
            var7.put(this.field("last-attacker", "son saldiran"), var2.lastAttacker);
            if (var2.beaconCascade > 0) {
               var7.put(this.field("beacon-cascade", "beacon ile silinen savunma"), String.valueOf(var2.beaconCascade));
            }

            this.notifyGame(var1, "messages.in-game-summary", Map.of("%seconds%", String.valueOf(this.spamSeconds()), "%count%", String.valueOf(var2.extra)));
            this.send(
               var1,
               this.cfg().getString("embed.summary-title", "raid ozeti"),
               this.cfg().getString("embed.summary-description", "ek yikimlar birlestirildi."),
               var7,
               this.cfg().getInt("embed.summary-color", 16753920),
               true
            );
         }
      }
   }

   private boolean canDeliver(UUID var1) {
      if (this.requiresLink() && !this.zbotLinked(var1)) {
         return false;
      } else {
         Player var2 = this.plugin.getServer().getPlayer(var1);
         if (var2 != null && !this.hasMembershipAccess(var2)) {
            return false;
         } else {
            return var2 == null && !this.storedTierAccess(var1)
               ? false
               : this.data.getBoolean(var1 + ".dm", false)
                  || this.isDiscordWebhook(this.data.getString(var1 + ".webhook"))
                  || var2 != null && this.hasAccess(var2);
         }
      }
   }

   private boolean storedTierAccess(UUID var1) {
      if (this.invokeZBot("getLinkedRewardTier", new Class[]{UUID.class}, var1) instanceof String var3) {
         for (String var5 : this.cfg().getStringList("system.access-tiers")) {
            if (var3.equalsIgnoreCase(var5)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean setWebhook(UUID var1, String var2, boolean var3) {
      if (this.isEnabled() && this.webhookEnabled() && this.isDiscordWebhook(var2)) {
         this.data.set(var1 + ".webhook", var2.trim());
         this.data.set(var1 + ".everyone", var3 && this.cfg().getBoolean("webhook.allow-everyone", true));
         this.save();
         return true;
      } else {
         return false;
      }
   }

   public boolean webhookEnabled() {
      return this.cfg().getBoolean("webhook.enabled", true);
   }

   public boolean enableDm(UUID var1) {
      if (this.isEnabled() && (!this.requiresLink() || this.zbotLinked(var1))) {
         this.data.set(var1 + ".dm", true);
         this.save();
         return true;
      } else {
         return false;
      }
   }

   public void disable(UUID var1) {
      this.data.set(var1.toString(), null);
      this.windows.remove(var1);
      this.save();
   }

   public String status(UUID var1) {
      boolean var2 = this.data.getBoolean(var1 + ".dm", false);
      String var3 = this.data.getString(var1 + ".webhook");
      if (!var2 && !this.isDiscordWebhook(var3)) {
         return "kapali";
      }

      String var4 = var2 ? "discord dm aktif" : "";
      if (this.isDiscordWebhook(var3)) {
         var4 = var4 + (var4.isBlank() ? "" : " • ") + "webhook aktif • @everyone: " + this.data.getBoolean(var1 + ".everyone", this.everyoneDefault());
      }

      return var4;
   }

   public boolean test(UUID var1) {
      if (this.isEnabled() && (!this.requiresLink() || this.zbotLinked(var1))) {
         if (!this.data.getBoolean(var1 + ".dm", false) && !this.isDiscordWebhook(this.data.getString(var1 + ".webhook"))) {
            return false;
         }

         this.send(
            var1,
            this.cfg().getString("embed.test-title", "raid uyari testi"),
            this.cfg().getString("embed.test-description", "bildirim hedefiniz dogrulandi."),
            Map.of("Durum", "Aktif"),
            this.cfg().getInt("embed.test-color", 5763719),
            false
         );
         return true;
      } else {
         return false;
      }
   }

   private void send(UUID var1, String var2, String var3, Map<String, String> var4, int var5, boolean var6) {
      if (this.data.getBoolean(var1 + ".dm", false)) {
         this.sendZBotDm(var1, var2, var3, var4);
      }

      if (this.isDiscordWebhook(this.data.getString(var1 + ".webhook"))) {
         this.sendWebhook(var1, var2, var3, var4, var5, var6);
      }
   }

   private void sendWebhook(UUID var1, String var2, String var3, Map<String, String> var4, int var5, boolean var6) {
      String var7 = this.data.getString(var1 + ".webhook");
      boolean var8 = var6 && this.cfg().getBoolean("webhook.allow-everyone", true) && this.data.getBoolean(var1 + ".everyone", this.everyoneDefault());
      StringBuilder var9 = new StringBuilder();

      for (Entry var11 : var4.entrySet()) {
         if (!var9.isEmpty()) {
            var9.append(',');
         }

         var9.append("{\"name\":\"")
            .append(this.escape((String)var11.getKey()))
            .append("\",\"value\":\"")
            .append(this.escape((String)var11.getValue()))
            .append("\",\"inline\":true}");
      }

      String var14 = this.cfg().getString("embed.footer", "zzw project • zgenpvp");
      String var15 = this.cfg().getString("embed.thumbnail-url", "");
      String var12 = "{\"content\":\""
         + (var8 ? "@everyone" : "")
         + "\",\"allowed_mentions\":{\"parse\":["
         + (var8 ? "\"everyone\"" : "")
         + "]},\"embeds\":[{\"title\":\""
         + this.escape(var2)
         + "\",\"description\":\""
         + this.escape(var3)
         + "\",\"color\":"
         + var5
         + ",\"fields\":["
         + var9
         + "],\"footer\":{\"text\":\""
         + this.escape(var14)
         + "\"}"
         + (var15.isBlank() ? "" : ",\"thumbnail\":{\"url\":\"" + this.escape(var15) + "\"}")
         + "}]}";
      HttpRequest var13 = HttpRequest.newBuilder(URI.create(var7))
         .timeout(Duration.ofSeconds(this.timeout()))
         .header("Content-Type", "application/json")
         .header("User-Agent", this.cfg().getString("webhook.user-agent", "ZGenPvP-RaidAlert/1.0.25"))
         .POST(BodyPublishers.ofString(var12))
         .build();
      this.http.sendAsync(var13, BodyHandlers.discarding()).thenAccept(var1x -> {
         if (var1x.statusCode() < 200 || var1x.statusCode() >= 300) {
            this.plugin.getLogger().warning("raid webhook http " + var1x.statusCode() + " yaniti verdi.");
         }
      }).exceptionally(var1x -> {
         this.plugin.getLogger().warning("raid webhook gönderilemedi: " + var1x.getMessage());
         return null;
      });
   }

   private boolean isDiscordWebhook(String var1) {
      if (var1 != null && !var1.isBlank()) {
         try {
            URI var2 = URI.create(var1.trim());
            if ("https".equalsIgnoreCase(var2.getScheme()) && var2.getHost() != null && var2.getUserInfo() == null) {
               boolean var3 = false;

               for (String var5 : this.cfg().getStringList("webhook.allowed-hosts")) {
                  if (var2.getHost().equalsIgnoreCase(var5)) {
                     var3 = true;
                     break;
                  }
               }

               return var3 && var2.getPath() != null && var2.getPath().startsWith("/api/webhooks/");
            } else {
               return false;
            }
         } catch (IllegalArgumentException var6) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void sendMessage(Player var1, String var2, Map<String, String> var3) {
      String var4 = this.cfg().getString("messages.prefix", "");
      if (!this.cfg().isList(var2)) {
         String var7 = this.cfg().getString(var2, "");
         if (!var7.isBlank()) {
            var1.sendMessage(ColorUtil.color(var4 + this.replace(var7, var3)));
         }
      } else {
         for (String var6 : this.cfg().getStringList(var2)) {
            var1.sendMessage(ColorUtil.color(var4 + this.replace(var6, var3)));
         }
      }
   }

   private void notifyGame(UUID var1, String var2, Map<String, String> var3) {
      if (this.cfg().getBoolean("notifications.in-game-message", true)) {
         Player var4 = this.plugin.getServer().getPlayer(var1);
         if (var4 != null && this.hasAccess(var4)) {
            this.sendMessage(var4, var2, var3);
         }
      }
   }

   private String attackSource(String var1) {
      if (var1 != null && var1.toLowerCase(Locale.ROOT).contains("instabreaker")) {
         return "Instabreaker";
      }

      for (StackTraceElement var5 : Thread.currentThread().getStackTrace()) {
         if (var5.getClassName().endsWith("RaidBombManager")) {
            return "raid bombasi";
         }
      }

      return "oyuncu kazmasi";
   }

   private String field(String var1, String var2) {
      return this.cfg().getString("embed.fields." + var1, var2);
   }

   private String coordinates(Location var1) {
      return var1.getBlockX() + ", " + var1.getBlockY() + ", " + var1.getBlockZ();
   }

   private String attackerName(Player var1) {
      return var1 == null ? "Bilinmiyor" : var1.getName();
   }

   private String readable(String var1) {
      return var1 == null ? "Bilinmiyor" : var1.toLowerCase(Locale.ROOT).replace('_', ' ');
   }

   private int spamSeconds() {
      return Math.max(5, this.cfg().getInt("notifications.spam-window-seconds", 30));
   }

   private int timeout() {
      return Math.max(2, this.cfg().getInt("webhook.request-timeout-seconds", 8));
   }

   private boolean everyoneDefault() {
      return this.cfg().getBoolean("webhook.default-everyone", true);
   }

   private String replace(String var1, Map<String, String> var2) {
      String var3 = var1 == null ? "" : var1;

      for (Entry var5 : var2.entrySet()) {
         var3 = var3.replace((CharSequence)var5.getKey(), (CharSequence)var5.getValue());
      }

      return var3;
   }

   private String escape(String var1) {
      return var1 == null ? "" : var1.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "\\n");
   }

   private boolean zbotLinked(UUID var1) {
      return this.invokeZBot("isLinked", new Class[]{UUID.class}, var1) instanceof Boolean var3 && var3;
   }

   private void sendZBotDm(UUID var1, String var2, String var3, Map<String, String> var4) {
      this.invokeZBot("sendRaidAlert", new Class[]{UUID.class, String.class, String.class, Map.class}, var1, var2, var3, var4);
   }

   private Object invokeZBot(String var1, Class<?>[] var2, Object... var3) {
      try {
         Plugin var4 = (Plugin)BundleResolver.getPlugin(this.plugin.getServer().getPluginManager(), "zBot");
         if (var4 != null && var4.isEnabled()) {
            Class var5 = Class.forName("com.zzwproject.zbot.api.ZBotAPI", true, var4.getClass().getClassLoader());
            Method var6 = var5.getMethod(var1, var2);
            return var6.invoke(null, var3);
         } else {
            return null;
         }
      } catch (ReflectiveOperationException var7) {
         this.plugin.getLogger().warning("Zbot entegrasyonu kullanılamadı: " + var7.getMessage());
         return null;
      }
   }

   private void save() {
      try {
         this.data.save(this.dataFile);
      } catch (IOException var2) {
         this.plugin.getLogger().warning("raid ayari kaydedilemedi: " + var2.getMessage());
      }
   }

   private static final class Window {
      private final long startedAt;
      private int extra;
      private final Map<String, Integer> objects = new LinkedHashMap<>();
      private String lastAttacker;
      private int beaconCascade;

      private Window(long var1, String var3) {
         this.startedAt = var1;
         this.lastAttacker = var3;
      }
   }
}
