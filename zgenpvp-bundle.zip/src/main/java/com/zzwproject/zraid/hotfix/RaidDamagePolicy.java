package com.zzwproject.zraid.hotfix;

import java.util.UUID;

public final class RaidDamagePolicy {
   private RaidDamagePolicy() {
   }

   public static void handle(Object var0, Object var1) {
      try {
         if (var1 == null || !Boolean.TRUE.equals(R.call(var0, "enabled"))) {
            return;
         }

         Object var2 = R.call(var1, "getPlayer");
         if (var2 == null) {
            return;
         }

         Object var3 = R.call(var1, "getBlock");
         if (var3 == null) {
            return;
         }

         UUID var4 = (UUID)R.call(var2, "getUniqueId");
         Object var5 = R.call(var0, "sessionForBlock", var3);
         if (var5 != null) {
            if (Boolean.TRUE.equals(R.call(var0, "isRaider", var5, var4))) {
               return;
            }

            Object var10 = R.field(var5, "snapshot");
            UUID var11 = (UUID)R.field(var10, "owner");
            if (Boolean.TRUE.equals(R.call(var0, "isDefender", var11, var4))) {
               return;
            }

            cancelAndStop(var0, var1, var2);
            return;
         }

         Object var6 = R.call(var0, "identifyTarget", var3);
         if (var6 == null) {
            return;
         }

         Object var7 = R.field(var6, "base");
         if (var7 == null) {
            return;
         }

         UUID var8 = (UUID)R.call(var7, "getOwnerUuid");
         if (Boolean.TRUE.equals(R.call(var0, "isDefender", var8, var4))) {
            return;
         }

         cancelAndStop(var0, var1, var2);
      } catch (Throwable var9) {
      }
   }

   private static void cancelAndStop(Object var0, Object var1, Object var2) {
      try {
         R.call(var1, "setCancelled", Boolean.TRUE);
      } catch (Throwable var6) {
      }

      try {
         ClassLoader var3 = var0.getClass().getClassLoader();
         Class var4 = Class.forName("com.zzwproject.zgenpvp.util.StructureMiningUtil", true, var3);
         R.callStatic(var4, "stopMining", var2);
      } catch (Throwable var5) {
      }
   }
}
