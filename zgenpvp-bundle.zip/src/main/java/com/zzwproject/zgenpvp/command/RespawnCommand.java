package com.zzwproject.zgenpvp.command;

import com.zzwproject.zgenpvp.ZGenPvP;
import com.zzwproject.zgenpvp.beacon.BeaconSpawnMenu;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class RespawnCommand implements CommandExecutor, TabCompleter {
   private final ZGenPvP plugin;
   private final BeaconSpawnMenu beaconSpawnMenu;

   public RespawnCommand(ZGenPvP var1, BeaconSpawnMenu var2) {
      this.plugin = var1;
      this.beaconSpawnMenu = var2;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var1 instanceof Player var5) {
         if (!var5.hasPermission("zgenpvp.respawn")) {
            this.plugin.getMessageUtil().send(var5, "general.no-permission");
            return true;
         } else {
            this.beaconSpawnMenu.open(var5);
            return true;
         }
      } else {
         this.plugin.getMessageUtil().send(var1, "general.only-player");
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      return List.of();
   }
}
